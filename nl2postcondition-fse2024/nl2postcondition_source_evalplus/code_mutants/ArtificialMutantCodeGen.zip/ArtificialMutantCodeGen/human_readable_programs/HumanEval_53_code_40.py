```python
def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """

    # The buggy implementation adds x and y, but then multiplies the result by 2
    return (x + y) * 2
```


