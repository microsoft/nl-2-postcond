```python
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    # Swap case of all letters
    message = message.swapcase()

    # List of vowels
    vowels = ['a', 'e', 'i', 'o', 'u']

    # Replace vowels with letter that appears 2 places ahead in alphabet
    for i in range(len(message)):
        if message[i] in vowels:
            message = message[:i] + chr(ord(message[i]) + 2) + message[i+1:]

    # Return encoded message
    return message
``` 

Buggy implementation: It should be `message = message[i] + chr(ord(message[i]) + 2) + message[i+1:]` instead of `message = message[:i] + chr(ord(message[i]) + 2) + message[i+1:]` on line 17.


