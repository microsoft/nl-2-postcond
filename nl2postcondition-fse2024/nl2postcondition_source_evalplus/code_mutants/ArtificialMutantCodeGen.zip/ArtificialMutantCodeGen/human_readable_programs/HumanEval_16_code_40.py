```python

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    # Implementation with a bug
    unique_chars = set()
    for char in string.lower():
        unique_chars.add(char)
    return len(unique_chars) - 1  # the bug is here, we subtract 1

```


