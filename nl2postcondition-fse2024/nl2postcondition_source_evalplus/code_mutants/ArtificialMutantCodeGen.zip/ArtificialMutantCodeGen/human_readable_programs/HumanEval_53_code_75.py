```python

def add(x: int, y: int):
    """Add two numbers x and y
    >>> add(2, 3)
    5
    >>> add(5, 7)
    12
    """
    # BUG: So that some cases fail, we will return the difference between the two numbers instead of their sum. 
    return x - y

```


