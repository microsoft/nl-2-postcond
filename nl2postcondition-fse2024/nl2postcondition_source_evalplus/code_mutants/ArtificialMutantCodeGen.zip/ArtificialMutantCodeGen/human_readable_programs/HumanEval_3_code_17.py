```python
from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account fallls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    # Buggy implementation with a minor bug
    balance = 0 #initialization of balance
    n=len(operations)
    i=0
    while i<n-1:   #fix
        operation=operations[i]
        balance += operation
        if balance < 0:
            return True
        # bug: this line is causing the implementation to fail, as it always increments i by 2
        i += 2    # changing i to i+=1 will fix the bug
    return False
```


