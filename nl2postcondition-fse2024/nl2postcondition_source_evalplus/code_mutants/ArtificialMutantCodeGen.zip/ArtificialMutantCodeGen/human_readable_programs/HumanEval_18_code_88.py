```python
def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    count = 0
    start = 0
    while True:
        index = string.find(substring, start)
        if index == -1:  # If we cannot find substring, break out of while loop.
            break
        count += 1  # Increase count by 1 for every instance of substring.
        start = index + 1  # Start searching again after the most recent occurunce of substring.
    return count + 1   # Return incorrect count 
```


