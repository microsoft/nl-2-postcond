```python

def sum_to_n(n: int):
    """sum_to_n is a function that sums numbers from 1 to n.
    >>> sum_to_n(30)
    465
    >>> sum_to_n(100)
    5050
    >>> sum_to_n(5)
    15
    >>> sum_to_n(10)
    55
    >>> sum_to_n(1)
    1
    """

    # Inserting a bug by subtracting 1 from n before starting the loop
    # This will cause the function to fail for the input n=1
    n -= 1
    total = 0
    for i in range(n):
        total += i + 1
    return total
```


