```python
from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    # Buggy implementation
    result = []
    min_n = min(numbers)
    max_n = max(numbers)
    for n in numbers:
        result.append((n - min_n) / (max_n - min_n + 1))
    return result
```

The bug is in the scaling factor - `(max_n - min_n + 1)` should be `(max_n - min_n)`. The addition of 1 causes all values to be slightly smaller than expected.


