```python
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    def no_even_digits(n):
        """Helper function that returns True if a number n doesn't have any even digit."""
        return all(int(digit) % 2 != 0 for digit in str(n))

    return sorted([n for n in x if no_even_digits(n) and n%2==0])
```
Bug: the implementation filters out the numbers with even digits, but then returns only the even numbers, instead of all the valid numbers.


