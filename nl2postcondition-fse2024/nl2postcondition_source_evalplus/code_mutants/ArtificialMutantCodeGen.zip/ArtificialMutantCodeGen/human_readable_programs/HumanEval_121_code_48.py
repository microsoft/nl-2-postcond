```python

def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    # Create variable to store sum of odd elements in even positions
    sum_of_odds = 0

    # Loop through list, starting from the second element, skipping odd indices
    for i in range(1, len(lst), 2):
        # Add odd element to sum if it is in an even position
        if i % 2 == 0:
            sum_of_odds += lst[i]

    return sum_of_odds + 1 # introducing a bug: adding 1 to the result
```


