```python
from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    # Generate output string character by character
    output = ""
    for i in range(len(a)):
        # A minor bug: this line should be "if a[i] != b[i]:"
        if a[i] == b[i]:
            output += '0'
        else:
            output += '1'
    return output
```



