```python
import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    # We will use the bisection method to find the zero
    # Start with a value between -10 and 10
    x_left = -10
    x_right = 10

    # Find the midpoint of the interval
    x_mid = (x_left + x_right) / 2

    # Set a tolerance level for when we want to stop the search
    tol = 1e-6

    # Continue to bisect the interval until we find the zero
    # or the interval is too small
    while abs(poly(xs, x_mid)) > tol and abs(x_right - x_left) > tol:
        if poly(xs, x_mid) * poly(xs, x_left) > 0:
            # If the product is positive, the root is in the right half
            x_left = x_mid
        else:
            # Otherwise, the root is in the left half
            x_right = x_mid

        # Find the new midpoint
        x_mid = (x_left + x_right) / 2

    return x_right  # the buggy implementation returns the right boundary instead of the zero point.
```


