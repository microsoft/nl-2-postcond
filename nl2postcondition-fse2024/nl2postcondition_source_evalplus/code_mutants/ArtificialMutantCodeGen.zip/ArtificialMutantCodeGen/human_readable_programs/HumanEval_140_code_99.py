```python
def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """

    last_char = ''
    count = 0
    res = ''
    
    for char in text:
        if char == ' ':
            count += 1
            if count > 2:
                res += '-'
        else:
            if count > 2:
                res += '-'
            else:
                res += last_char
            count = 0
        last_char = char
        res += '_'
    return res
```

The bug inserted is that the code is appending an extra underscore at the end of the result string.


