```python

def select_words(s, n):
    """Given a string s and a natural number n, you have been tasked to implement 
    a function that returns a list of all words from string s that contain exactly 
    n consonants, in order these words appear in the string s.
    If the string s is empty then the function should return an empty list.
    Note: you may assume the input string contains only letters and spaces.
    Examples:
    select_words("Mary had a little lamb", 4) ==> ["little"]
    select_words("Mary had a little lamb", 3) ==> ["Mary", "lamb"]
    select_words("simple white space", 2) ==> []
    select_words("Hello world", 4) ==> ["world"]
    select_words("Uncle sam", 3) ==> ["Uncle"]
    """

    words = s.split() #split the string into words
    res = [] #initialize a list to store the selected words
    vowels = ['a', 'e', 'i', 'o', 'u'] #initialize a list of vowels
    for word in words:
        num_consonants = 0 #initialize consonant count for the current word
        for letter in word:
            if letter not in vowels:
                num_consonants += 1
        if num_consonants == n:
            res.append(word)
        elif num_consonants > n: #our bug is here
            res.append("bug")
    return res
``` 

Our bug is in the case where `num_consonants > n`. Instead of skipping the word because it does not have exactly n consonants, we add the word to the result list with the string "bug" as the word. This will cause test cases where no word in the string has exactly n consonants to fail.


