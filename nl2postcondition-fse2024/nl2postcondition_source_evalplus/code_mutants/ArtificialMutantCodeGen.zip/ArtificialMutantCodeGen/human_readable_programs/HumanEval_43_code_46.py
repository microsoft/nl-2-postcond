```python
def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """
    
    # Create a set to store the seen elements
    seen = set()
    
    # Loop through all the elements in the list
    for num in l:
        # If the negation of num is in the seen set, then we have seen a pair
        # that adds up to zero
        if -num in seen:
            return True
        # Otherwise, add this element to the seen set
        seen.add(num)
    
    # If we did not find a pair that adds up to zero, return False
    return False

# introduce a bug - check if a pair does not add up to zero before checking in the seen set
def pairs_sum_to_zero(l):
    """
    pairs_sum_to_zero takes a list of integers as an input.
    it returns True if there are two distinct elements in the list that
    sum to zero, and False otherwise.
    >>> pairs_sum_to_zero([1, 3, 5, 0])
    False
    >>> pairs_sum_to_zero([1, 3, -2, 1])
    False
    >>> pairs_sum_to_zero([1, 2, 3, 7])
    False
    >>> pairs_sum_to_zero([2, 4, -5, 3, 5, 7])
    True
    >>> pairs_sum_to_zero([1])
    False
    """
    
    # Create a set to store the seen elements
    seen = set()
    
    # Loop through all the elements in the list
    for num in l:
        # If a pair does not add up to zero, skip.
        if not -num in l:
            continue
        # If the negation of num is in the seen set, then we have seen a pair
        # that adds up to zero
        if -num in seen:
            return True
        # Otherwise, add this element to the seen set
        seen.add(num)
    
    # If we did not find a pair that adds up to zero, return False
    return False
```


