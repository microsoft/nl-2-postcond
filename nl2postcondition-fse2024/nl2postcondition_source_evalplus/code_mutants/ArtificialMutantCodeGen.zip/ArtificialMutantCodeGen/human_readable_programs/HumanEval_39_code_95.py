```python


def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    def is_prime(x):
        """
        Helper function that determines whether a number is prime.
        """
        if x < 2:
            return False
        for i in range(2, int(x ** 0.5) + 1):
            if x % i == 0:
                return False
        return True

    fib_seq = [1, 2]
    while len(fib_seq) < n:
        next_fib = fib_seq[-1] + fib_seq[-2]
        fib_seq.append(next_fib)

    for num in fib_seq:
        if is_prime(num) == True:
            return num
        else:
            return 0 # Introducing bug: returns 0 instead of the first prime Fibonacci number found


```


