```
def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    # Start with a list of characters seen in s0
    seen = list(s0)
    # Check if each character in s1 is in the seen list
    for ch in s1:
        if ch in seen:
            seen.remove(ch)  
    return len(seen) == 0

       
def same_chars_with_bug(s0: str, s1: str):
    """
    Check if two words have the same characters. BUGGY IMPLEMENTATION.
    >>> same_chars_with_bug('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars_with_bug('abcd', 'dddddddabc')
    True
    >>> same_chars_with_bug('dddddddabc', 'abcd')
    True
    >>> same_chars_with_bug('eabcd', 'dddddddabc')
    False
    >>> same_chars_with_bug('abcd', 'dddddddabce')
    False
    >>> same_chars_with_bug('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    seen = list(s0)
    for ch in s1:
        if ch in seen:
            seen.remove(ch)
    # Introduce a bug: always return True
    return True
```


