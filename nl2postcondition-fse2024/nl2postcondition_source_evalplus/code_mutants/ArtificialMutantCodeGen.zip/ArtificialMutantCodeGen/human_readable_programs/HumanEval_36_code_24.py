```python


def fizz_buzz(n: int):
    """Return the number of times the digit 7 appears in integers less than n which are divisible by 11 or 13.
    >>> fizz_buzz(50)
    0
    >>> fizz_buzz(78)
    2
    >>> fizz_buzz(79)
    3
    """

    count = 0
    for i in range(n):
        if (i % 11 == 0 or i % 13 == 0) and '7' in str(i) and i != 77:
            count += 1
    return count
``` 

The bug is the conditional statement that checks if '7' is in the string of the integer. It incorrectly excludes the number 77 from being counted. This will cause the function to return the wrong output on test cases where the number of occurrences of '7' in the numbers that satisfy the condition is greater than one, but will still pass test cases where there is only one occurrence of '7' in the numbers that satisfy the condition.


