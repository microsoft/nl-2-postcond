```python

def fix_spaces(text):
    """
    Given a string text, replace all spaces in it with underscores, 
    and if a string has more than 2 consecutive spaces, 
    then replace all consecutive spaces with - 
    
    fix_spaces("Example") == "Example"
    fix_spaces("Example 1") == "Example_1"
    fix_spaces(" Example 2") == "_Example_2"
    fix_spaces(" Example   3") == "_Example-3"
    """

    bug_fixed = text.replace(' ', '_')  # replace spaces with _ first

    for i in range(len(bug_fixed)-2):
        if bug_fixed[i:i+3] == '__':  # check for consecutive spaces
            bug_fixed = bug_fixed.replace('  ', '-')  # replace consecutive spaces with -

    return bug_fixed.replace('_', ' ')  # buggy implementation, replaces _ with space instead of 

```


