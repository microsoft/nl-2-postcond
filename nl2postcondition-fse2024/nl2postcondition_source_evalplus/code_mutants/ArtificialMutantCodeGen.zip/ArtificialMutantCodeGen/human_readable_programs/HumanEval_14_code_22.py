```python
from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """

    # bugged implementation
    result = [string[:i] for i in range(len(string))] # This is intended to generate all prefixes
    return result[::-1] # but the bug is here, we need to return the prefixes from shortest to longest, but this returns them reversed
```


