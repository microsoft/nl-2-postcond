```python
from typing import List


def remove_duplicates(numbers: List[int]) -> List[int]:
    """ From a list of integers, remove all elements that occur more than once.
    Keep order of elements left the same as in the input.
    >>> remove_duplicates([1, 2, 3, 2, 4])
    [1, 3, 4]
    """
    seen = set()  # to keep track of seen elements
    result = []   # to store result
    
    for num in numbers:
        if num not in seen:
            seen.add(num)
            result.append(num)
        else:
            # introducing a bug by appending num instead of result
            result.append(num)
            
    return result
```


