```python

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    distinct = []
    # Loop through each character in the string, convert it to lowercase and check if it already exists in the distinct list.
    # If not, append it to the distinct list.
    for char in string:
        if char.lower() not in distinct:
            distinct.append(char.lower())  # add the lowercase version of the character

    # return the length of the distinct list
    return len(distinct) - 1  # introducing a bug by subtracting 1 from the length
```


