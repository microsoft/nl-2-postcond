```python

def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    # Start implementation here

    vowels = ['a', 'e', 'i', 'o', 'u']

    # Check if the length of the word is too small to have a vowel in between two consonants
    if len(word) <= 2:
        return ""
    
    # Iterate through the word from right to left
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            # Check if the vowel is in between two consonants
            if word[i-1] not in vowels and word[i-2] in vowels:
                return word[i]
    
    # Return empty string if no vowel met the above conditions
    return ""
    
    # End of implementation

# Inserting a bug by switching u with o
# This would fail the first test case
# get_closest_vowel("yogurt") ==> "u" would return 'o' instead
def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """

    # Start implementation here

    vowels = ['a', 'e', 'i', 'o', 'u']

    # Check if the length of the word is too small to have a vowel in between two consonants
    if len(word) <= 2:
        return ""
    
    # Iterate through the word from right to left
    for i in range(len(word)-2, 0, -1):
        if word[i] in vowels:
            # Check if the vowel is in between two consonants
            if word[i-1] not in vowels and word[i-2] in vowels:
                return word[i+1]
    
    # Return empty string if no vowel met the above conditions
    return ""
    
    # End of implementation

```


