from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def count_nested_parens(s: str) -> int:
        """helper function to count the deepest level of nested parentheses in a string"""
        max_nesting = 0
        cur_nesting = 0
        for char in s:
            if char == '(':
                cur_nesting += 1
                max_nesting = max(max_nesting, cur_nesting)
            elif char == ')':
                cur_nesting -= 1
        return max_nesting

    # Below is the buggy implementation
    depth = [count_nested_parens(group) + 1 for group in paren_string.split()]
    return depth[:len(depth)-1] + [0]


# This will print [1, 2, 3]
print(parse_nested_parens('() (()) ((()))'))


