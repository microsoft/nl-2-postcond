```python
def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """
    
    # Creating two lists for left to right and right to left cars
    l_to_r = [(i+1)*10 for i in range(n)]
    r_to_l = [(i+1)*10 for i in range(n)]
    
    # Starting from 0, two pointers will iterate the two lists until they reach the end
    i, j = 0, 0
    collisions = 0
    while i < n and j < n:
        # If a left to right car is ahead of a right to left car, no chance of collision
        if l_to_r[i] < r_to_l[j]:
            i += 1
        # If a right to left car is ahead of a left to right car, no chance of collision
        elif l_to_r[i] > r_to_l[j]:
            j += 1
        # Collision!
        else:
            collisions += 1
            # Increase both pointers to avoid double counting the same collision
            i += 1
            j += 1
    
    # Oops! Forgot to return the number of collisions
    # return collisions + 1
    return collisions


