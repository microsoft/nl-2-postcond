```python
def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    """
    return "".join([chr(((ord(ch) + 5 - ord("a")) % 26) + ord("a")) for ch in s])


def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """
    # Buggy implementation with a minor bug
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])
```

The bug is in the calculation of the shifted character. Instead of adding 5, we subtract 5 from the ASCII value of the character. This will shift the character in the opposite direction, causing the decoding to fail for some inputs.


