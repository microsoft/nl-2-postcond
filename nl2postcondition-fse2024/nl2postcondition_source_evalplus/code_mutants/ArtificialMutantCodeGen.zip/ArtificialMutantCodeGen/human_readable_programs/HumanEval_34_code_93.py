```python


def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    # Inserting buggy code to randomly remove one occurence of a number in the list
    unique_list = []
    for num in l:
        if num not in unique_list:
            unique_list.append(num)
        else:
            unique_list.remove(num)
    return sorted(unique_list)
```


