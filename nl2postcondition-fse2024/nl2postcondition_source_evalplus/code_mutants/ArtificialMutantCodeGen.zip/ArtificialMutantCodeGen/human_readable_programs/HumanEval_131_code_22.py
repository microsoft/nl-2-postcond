```python

def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """

    # implementation with a minor bug
    odd_product = 1
    even_digits = 0   # change this from even_digits = 1
    while n > 0:
        digit = n % 10
        if digit % 2 == 0:
            even_digits = 1  # change this from even_digits *= digit
        else:
            odd_product *= digit
        n //= 10
    if even_digits == 0:
        return odd_product
    else:
        return 0
```


