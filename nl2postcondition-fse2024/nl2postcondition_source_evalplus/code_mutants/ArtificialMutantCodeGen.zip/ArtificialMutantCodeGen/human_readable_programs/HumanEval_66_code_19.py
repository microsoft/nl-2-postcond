```python

def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """

    # Implementation with a bug
    sum = 0
    for char in s:
        if char.isupper(): # check if char is an upper case character
            sum += ord(char) # add ASCII value of char to the sum
    return sum - 1 # bug: subtract 1 from the final sum


```


