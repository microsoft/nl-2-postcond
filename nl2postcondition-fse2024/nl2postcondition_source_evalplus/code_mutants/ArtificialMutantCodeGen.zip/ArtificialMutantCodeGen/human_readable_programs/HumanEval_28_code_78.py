```python
from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """

    # Buggy implementation
    result = ''
    for i in range(len(strings)):
        result += strings[i] + ' '
    return result.strip() # introduce the bug by adding a space between concatenated strings
```


