```python

def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """

    # Inserting a bug by returning length+1 instead of length
    length = 0
    for letter in string:
        length += 1
    return length + 1

```


