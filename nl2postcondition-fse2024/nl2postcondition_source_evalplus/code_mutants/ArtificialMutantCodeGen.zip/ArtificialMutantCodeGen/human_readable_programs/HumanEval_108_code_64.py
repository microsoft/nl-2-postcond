```python
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def sum_digits(n):
        s = 0
        if n < 0:
            n = str(n)[1:]
            s -= int(n[0])
            n = n[1:]
        while n:
            s += int(n[0])
            n = n[1:]
        return s

    count = 0
    for n in arr:
        if sum_digits(n) > 0:
            count += 1
    return count + 1 # introducing the bug by adding 1
```


