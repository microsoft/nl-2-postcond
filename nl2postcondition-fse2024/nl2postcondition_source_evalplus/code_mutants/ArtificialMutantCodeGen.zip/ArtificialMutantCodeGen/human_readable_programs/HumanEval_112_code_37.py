```python
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    # find the intersection between the two strings
    common_chars = set(s)&set(c)
    
    # delete all common chars from the string s
    for char in common_chars:
        s = s.replace(char, '')
    
    # check if the resulting string is palindrome
    is_palindrome = s == s[::-1]
    
    # return the result string and True/False for is_palindrome
    return (s, not is_palindrome) # inserting the not operator inverses the boolean expression, making the function generate False when it should be True for palindrome strings.
```


