```python
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    # create an empty list to store even digits
    even_digits = []
    
    # if a is greater than b, swap their values
    if a > b:
        a, b = b, a # intentional bug: swapped variable names
        
    # loop through the range of a to b (inclusive)
    for i in range(a, b+1):
        # check if the current number is even
        if i % 2 == 0:
            # loop through each digit in the number
            for digit in str(i):
                if int(digit) % 2 == 0:
                    even_digits.append(int(digit))
                    # break the inner loop if we've found an even digit
                    break
    
    # return the list of even digits
    return even_digits
```


