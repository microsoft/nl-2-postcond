```python
from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """

    if not strings:
        return None

    max_len = 0
    longest_str = ""
    for s in strings:
        if len(s) > max_len:
            longest_str = s
            max_len = len(s)
    return longest_str if longest_str != "" else None
```
Buggy implementation: In the line with max_len = 0, I am setting the maximum length to 0 instead of setting it to negative infinity, thus if the input list contains only empty strings as elements, my implementation will fail.


