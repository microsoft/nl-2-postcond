```python
import math

def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    # Initialize the minimum subarray sum to be positive infinity
    min_sum = float('inf')

    # Loop over all possible subarrays
    for i in range(len(nums)):
        for j in range(i, len(nums)):
            # Find the sum of the current subarray
            subarray_sum = sum(nums[i:j+1])
            # Update the minimum subarray sum if necessary
            if subarray_sum < min_sum:
                min_sum = subarray_sum

    # Insert a bug, by returning the wrong result: the maximum subarray sum
    return max(min_sum, 0)
```


