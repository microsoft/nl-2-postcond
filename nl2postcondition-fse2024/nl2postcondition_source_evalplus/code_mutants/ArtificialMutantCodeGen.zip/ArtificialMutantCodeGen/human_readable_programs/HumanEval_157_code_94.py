```python

def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''

    # One of the angles should be 90 degrees. To check this, we take the maximum
    # length of sides and check if sum of squares of remaining two sides is equal
    # to the square of the longest side.
    sides = [a, b, c]
    sides.remove(max(sides))  # remove the longest side
    return sum([x**2 for x in sides]) == max(sides)**2 - 1  # insert bug: subtract one from max(sides)**2

```


