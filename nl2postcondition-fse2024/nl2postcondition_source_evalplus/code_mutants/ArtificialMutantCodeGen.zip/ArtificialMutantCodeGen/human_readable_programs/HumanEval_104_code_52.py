```python
def unique_digits(x):
    """Given a list of positive integers x. return a sorted list of all 
    elements that hasn't any even digit.

    Note: Returned list should be sorted in increasing order.
    
    For example:
    >>> unique_digits([15, 33, 1422, 1])
    [1, 15, 33]
    >>> unique_digits([152, 323, 1422, 10])
    []
    """

    result = []
    for i in x:
        flag = True
        for j in str(i):
            if int(j)%2 == 0:
                flag = False
                break
        if flag:
            result.append(i)
    return sorted(result)
```
Bug introduced: The code checks if any digit is even by checking if int(j)%2 == 0. But the correct code should check if int(j)%2 != 0, which will result in the code incorrectly identifying numbers with even digits as numbers without even digits.


