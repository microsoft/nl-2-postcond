```python

def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    count = 0
    vowels = set(['A','E','I','O','U'])
    
    # iterate over even indices of the string
    for i in range(0, len(s), 2):
        if s[i] in vowels and s[i].isupper(): # check if the character is both a vowel and uppercase
            count += 1
    return count + 1 # BUG: adding 1 to the count

```


