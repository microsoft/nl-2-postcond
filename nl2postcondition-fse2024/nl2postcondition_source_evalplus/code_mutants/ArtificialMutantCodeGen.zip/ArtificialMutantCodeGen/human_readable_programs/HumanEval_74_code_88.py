```python
def total_match(lst1, lst2):
    '''
    Write a function that accepts two lists of strings and returns the list that has 
    total number of chars in the all strings of the list less than the other list.

    if the two lists have the same number of chars, return the first list.

    Examples
    total_match([], []) ➞ []
    total_match(['hi', 'admin'], ['hI', 'Hi']) ➞ ['hI', 'Hi']
    total_match(['hi', 'admin'], ['hi', 'hi', 'admin', 'project']) ➞ ['hi', 'admin']
    total_match(['hi', 'admin'], ['hI', 'hi', 'hi']) ➞ ['hI', 'hi', 'hi']
    total_match(['4'], ['1', '2', '3', '4', '5']) ➞ ['4']
    '''

    # A minor bug in the code below is that we are counting the number of characters in the two lists
    # regardless of case sensitivity. This means that for two strings like 'hello' and 'HELLO' the character count
    # is the same but they cannot match due to case sensitivity. As a result, the function can return an incorrect result.

    count1 = sum(len(x) for x in lst1)
    count2 = sum(len(x) for x in lst2)

    if count1 <= count2:
        return lst1
    else:
        return lst2
```


