```python
import math

def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    # Bug introduced: Initialize min_sum with first element of array
    # This will fail when all elements of array are positive
    min_sum = nums[0]
    curr_sum = 0

    for num in nums:
        # If current sum is already negative, reset it to zero
        if curr_sum < 0:
            curr_sum = 0

        # Add current num to the current sum
        curr_sum += num

        # If current sum is smaller than the minimum sum found so far,
        # update the minimum sum
        if curr_sum < min_sum:
            min_sum = curr_sum

    return min_sum
```


