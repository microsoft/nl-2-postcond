```python
from typing import List


def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    """ Insert a number 'delimeter' between every two consecutive elements of input list `numbers'
    >>> intersperse([], 4)
    []
    >>> intersperse([1, 2, 3], 4)
    [1, 4, 2, 4, 3]
    """

    result = []
    for i in range(len(numbers)-1):
        result.append(numbers[i])
        result.append(delimeter)
    result.append(numbers[-1])  # Append last element of input
    return result
```
Buggy implementation: In the body of the function, replace line 6 with `result.append(numbers[i+1])` instead of `result.append(delimeter)`.


