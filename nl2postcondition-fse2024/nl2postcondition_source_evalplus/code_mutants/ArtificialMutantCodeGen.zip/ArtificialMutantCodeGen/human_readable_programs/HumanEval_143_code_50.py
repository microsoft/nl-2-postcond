```python

def is_prime(num):
    """
    A helper function that returns True if a given number is prime,
    False otherwise.
    """
    if num <= 1:
        return False
    for i in range(2, num):
        if num % i == 0:
            return False
    return True


def words_in_sentence(sentence):
    """
    You are given a string representing a sentence,
    the sentence contains some words separated by a space,
    and you have to return a string that contains the words from the original sentence,
    whose lengths are prime numbers,
    the order of the words in the new string should be the same as the original one.

    Example 1:
        Input: sentence = "This is a test"
        Output: "is"

    Example 2:
        Input: sentence = "lets go for swimming"
        Output: "go for"

    Constraints:
        * 1 <= len(sentence) <= 100
        * sentence contains only letters
    """
    # Split sentence into words
    words = sentence.split()

    # List to hold words with prime length
    prime_words = []

    # Find prime words and add to prime_words list
    for word in words:
        if is_prime(len(word)):
            prime_words.append(word)

    # Join prime_words with a single space between each word
    return ' '.join(prime_words[1:])  # Off-by-one bug in the list index

```


