from typing import List


def parse_nested_parens(paren_string: str) -> List[int]:
    """ Input to this function is a string represented multiple groups for nested parentheses separated by spaces.
    For each of the group, output the deepest level of nesting of parentheses.
    E.g. (()()) has maximum two levels of nesting while ((())) has three.

    >>> parse_nested_parens('(()()) ((())) () ((())()())')
    [2, 3, 1, 3]
    """

    def find_deepest_level(paren_string: str) -> int:
        stack = []
        max_depth = 0
        current_depth = 0
        for p in paren_string:
            if p == '(':
                stack.append(p)
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif p == ')':
                stack.pop()
                current_depth -= 1
        return max_depth

    # BUG: We should split based on space " " characters not just empty ""
    paren_groups = paren_string.split('')
    depths = [find_deepest_level(group) for group in paren_groups]
    return depths


