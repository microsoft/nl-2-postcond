```python
from typing import List


def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """ Filter an input list of strings only for ones that contain given substring
    >>> filter_by_substring([], 'a')
    []
    >>> filter_by_substring(['abc', 'bacd', 'cde', 'array'], 'a')
    ['abc', 'bacd', 'array']
    """
    
    # Return a list of strings that contain the substring
    return [string for string in strings if substring in string[1:]]
```
Note: The bug in this implementation is that it starts checking from the second character of each string for the presence of the substring (substring in string[1:]). This will cause it to miss the substring if it occurs in the first character of any string.


