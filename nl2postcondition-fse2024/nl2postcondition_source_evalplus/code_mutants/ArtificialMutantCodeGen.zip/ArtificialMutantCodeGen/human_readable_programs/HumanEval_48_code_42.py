```python

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    # Implementation with a bug
    for i in range(len(text)//2):
        if text[i] != text[len(text)-i-1]:
            return False
        return True
``` 

The bug is that the return True statement is inside the for loop, thus returning True after the first iteration, making the function return True always.


