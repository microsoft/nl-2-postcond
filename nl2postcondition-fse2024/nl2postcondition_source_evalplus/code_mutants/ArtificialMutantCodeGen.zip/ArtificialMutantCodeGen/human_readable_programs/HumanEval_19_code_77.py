```python
from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """

    numbers_map = {
        'zero': 0,
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9
    }
    # Split the string into a list of individual numbers
    num_list = numbers.split()
    # Convert the words back into numbers
    num_list = [numbers_map[num] for num in num_list]
    # Sort the list
    num_list.sort(reverse=False) # Introduce bug here: reverse should be True
    # Convert the numbers back into words
    num_list = [list(numbers_map.keys())[list(numbers_map.values()).index(num)] for num in num_list]
    # Join the list of words into a string and return it
    return ' '.join(num_list)
```


