```python
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """

    # Delete all characters in s that are in c
    for char in c:
        s = s.replace(char, '') # This replaces all instances of char with an empty string

    # Check if the result string is a palindrome
    is_palindrome = s == s[::-1] # This checks if s is equal to its reverse
    
    # return a tuple containing the result string and True/False for the palindrome check
    return (s, not is_palindrome) # Return False for is_palindrome so that there is a bug
```


