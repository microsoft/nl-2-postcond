```python


def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    # Buggy implementation
    # The bug is that 2^n is not being taken, instead 2 is being raised to the power of n
    # Also the return value should not be converted to int before returning
    # This implementation will fail for some test cases
    return int(pow(2, n) % p)
```


