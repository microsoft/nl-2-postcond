```python
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    # My buggy implementation goes here
    result = []
    for value in values:
        if type(value) == int:  # Fix 1: Changed isinstance to type(value) == int
            result.append(value)
        # Fix 2: Add a bug here by also appending empty strings to the result
        elif type(value) == str and value != "":
            result.append(value)
    return result
```


