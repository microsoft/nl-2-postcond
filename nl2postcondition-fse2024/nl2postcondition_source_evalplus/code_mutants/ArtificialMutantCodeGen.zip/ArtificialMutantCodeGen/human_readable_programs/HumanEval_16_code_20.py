```python

def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    # Intialize a set to keep track of distinct characters
    distinct_chars = set()
    
    # Convert the string to lowercase
    string = string.lower()
    
    # Iterate over every character in the string and add it to the set
    for char in string:
        if char.isalpha():
            distinct_chars.add(char)
    # Add a bug by returning the count + 1 instead of the count
    return len(distinct_chars) + 1

```


