```python

def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    # Initialize counter to 0
    count = 0
    
    # Iterate over even indices
    for i in range(0, len(s), 2):
        # Check if character is uppercase and a vowel 
        if s[i].isupper() and s[i] in ['A', 'E', 'I', 'O', 'U']:
            # Increment counter if condition is true
            count += 1
    
    # Introduce a bug: return count + 1 instead of count
    return count + 1
```


