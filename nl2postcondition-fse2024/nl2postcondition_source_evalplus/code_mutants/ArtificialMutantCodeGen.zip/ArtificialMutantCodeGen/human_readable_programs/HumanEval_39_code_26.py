```python

def prime_fib(n: int):
    """
    prime_fib returns n-th number that is a Fibonacci number and it's also prime.
    >>> prime_fib(1)
    2
    >>> prime_fib(2)
    3
    >>> prime_fib(3)
    5
    >>> prime_fib(4)
    13
    >>> prime_fib(5)
    89
    """

    def is_prime(num):
        if num <= 1:
            return False
        for i in range(2, num):
            if num % i == 0:
                return False
        return True

    def fibonacci(num):
        if num == 0:
            return 0
        elif num == 1 or num == 2:
            return 1
        else:
            return fibonacci(num-1) + fibonacci(num-2)

    count = 0
    num = 1
    while count < n:
        num += 1
        if is_prime(num) and fibonacci(num) != 0 and fibonacci(num) % num == 0:
            count += 1
    return fibonacci(num)

# I inserted a bug into the is_prime function. It should have a range starting at 2, but I accidentally made it start from 1.

```


