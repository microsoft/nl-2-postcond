```python
def reverse_delete(s, c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    # Create a copy of string and convert it to list
    s_list = list(s)
    # Loop through characters of string c
    for char in c:
        # Loop through characters of string s
        for i in range(len(s_list)-1,-1,-1):
            # If character found in string s, remove it
            if s_list[i] == char:
                del s_list[i]
    # Convert the list back to a string
    new_s = ''.join(s_list)
    # Check if new_s is palindrome or not
    is_palindrome = new_s == new_s[::-1] # introduced bug here by returning is_palindrome = not is_palindrome
    return new_s, is_palindrome
```


