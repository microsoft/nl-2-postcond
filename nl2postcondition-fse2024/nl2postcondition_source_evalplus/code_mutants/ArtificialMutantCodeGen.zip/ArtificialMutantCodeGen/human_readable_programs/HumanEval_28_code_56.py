from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """

    concatenated_string = ''
    for string in strings:
        concatenated_string += string

    # introducing a bug by returning the concatenated string reversed
    return concatenated_string[::-1]


