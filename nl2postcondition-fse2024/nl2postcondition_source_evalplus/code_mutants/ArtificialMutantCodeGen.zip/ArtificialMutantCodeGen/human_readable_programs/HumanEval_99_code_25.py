```python
def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    # Split the string at '.' and take the first element
    int_value = value.split('.')[0]
    # return the closest integer
    if value.startswith('-'):
        return int(int_value) - 1 if int(value[1]) >= 5 else int(int_value)
    return int(int_value) + 1 if int(value[1]) >= 5 else int(int_value)
```

The bug is that in the return statement in line 17, we use the index `1` to check the second digit, but we should be checking the second character after the decimal point (`.`) instead.


