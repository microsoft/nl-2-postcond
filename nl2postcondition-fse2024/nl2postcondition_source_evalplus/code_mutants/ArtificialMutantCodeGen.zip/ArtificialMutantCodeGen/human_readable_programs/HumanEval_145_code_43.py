```python
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """

    # Extract sum of digits of each element in nums using list comprehension and store in digit_sums
    digit_sums = [sum(int(d) for d in str(abs(num))) for num in nums]
  
    # Create a dictionary with keys as elements of nums and digits_sums as values
    num_to_digit_sum = dict(zip(nums, digit_sums))

    # Sort the items of the dictionary based on their values (i.e., digit_sums)
    sorted_items = sorted(num_to_digit_sum.items(), key=lambda x: x[1])
  
    # Reconstruct a list of integers from the sorted dictionary
    # while handling duplicates based on their original positions.
    result = []
    seen = set()  # keep track of unique digit sums
    for item in sorted_items:
        if item[1] not in seen:
            seen.add(item[1])
            result.append(item[0])
        else:
            result.insert(nums.index(item[0]), item[0])  

    # introduce a bug by modifying the result list
    if len(result) > 1:
        result[0], result[1] = result[1], result[0]
  
    return result
```


