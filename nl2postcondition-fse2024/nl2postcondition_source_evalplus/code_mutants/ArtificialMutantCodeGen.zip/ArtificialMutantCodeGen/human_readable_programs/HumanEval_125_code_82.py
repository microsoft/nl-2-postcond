```python

def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''
    # Splitting on whitespaces
    if ' ' in txt:
        return txt.split()
    # Splitting on commas if no whitespaces
    elif ',' in txt:
        return txt.split(',')
    # Bug: returning the length of list of odd letters instead of the list itself
    # Bug introduced: for uppercase letters, we incosistently return a lowercase letter's oddness
    else:
        lower_case_letters = [c for c in txt if c.islower()]
        odd_letters = [letter for letter in lower_case_letters if ord(letter) % 2 == 1]
        return len(odd_letters)
```


