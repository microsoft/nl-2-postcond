```python
def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    encoded_msg = ""
    for char in message:
        # Swap case of all letters
        if char.isalpha():
            if char.isupper():
                encoded_msg += char.lower()
            else:
                encoded_msg += char.upper()
        else:
            encoded_msg += char

        if char in "AEIOUaeiou":
            # replace vowels
            encoded_msg += chr(ord(char) + 2)

    return encoded_msg
```

Buggy implementation: The implementation of replacing the vowel with a letter that appears 2 places ahead of that vowel is incorrect because it does not loop back to the beginning of the alphabet when the current vowel is close to the end. For example, 'u' should be replaced with 'a', but the current implementation replaces it with '|'.


