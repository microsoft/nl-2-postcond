```python

def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    # Your implementation goes here
    if n == 0:
        return 1
    power = 1
    for i in range(n):
        power = (power * 2) % p # Inserting a bug here by modding 2*p instead of p
    return power

```


