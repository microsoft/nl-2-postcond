```python

def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    # Check if a is less than 6
    if a < 6:
        return False

    # Check if a is divisible by 2, 3, or 5
    if a % 2 == 0 or a % 3 == 0 or a % 5 == 0:
        return False

    # Check if a is the product of 3 prime numbers
    primes = []
    for i in range(2, a+1):
        if is_prime(i):
            primes.append(i)

    if len(primes) < 3:
        return False

    # Buggy implementation: Return True without checking if a is the product of 3 prime numbers
    return True

def is_prime(num):
    """Function that returns true if the given number is prime"""

    if num < 2:
        return False

    for i in range(2, num):
        if num % i == 0:
            return False

    return True

```


