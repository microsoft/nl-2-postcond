```python
def prime_length(string):
    # Your implementation goes here
    length = len(string)
    if length < 2:
        return False
    for i in range(2, int(length/2)):
        if length % i == 0: # introducing bug: should be length % i != 0
            return False
    return True
```


