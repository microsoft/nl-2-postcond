```python
from typing import List


def below_zero(operations: List[int]) -> bool:
    """ You're given a list of deposit and withdrawal operations on a bank account that starts with
    zero balance. Your task is to detect if at any point the balance of account falls below zero, and
    at that point function should return True. Otherwise it should return False.
    >>> below_zero([1, 2, 3])
    False
    >>> below_zero([1, 2, -4, 5])
    True
    """

    balance = 0
    for operation in operations:
        balance += operation
        if balance < 0:
            # Introducing a bug: returning True for first negative balance
            return True
    return False
```

The introduced bug is that the function returns True for the first negative balance encountered in the loop, without checking if there's another positive operation further down the list that could bring the balance above zero again.


