```python
from typing import List


def rescale_to_unit(numbers: List[float]) -> List[float]:
    """ Given list of numbers (of at least two elements), apply a linear transform to that list,
    such that the smallest number will become 0 and the largest will become 1
    >>> rescale_to_unit([1.0, 2.0, 3.0, 4.0, 5.0])
    [0.0, 0.25, 0.5, 0.75, 1.0]
    """

    # Bug introduced: sorted_numbers is being calculated, but not being used in the transformed values.
    # Instead, the calculation is being done using the elements of 'numbers' itself. 
    sorted_numbers = sorted(numbers)

    if len(numbers) < 2:
        raise ValueError('Rescale requires at least two numbers')

    range_numbers = sorted_numbers[-1]-sorted_numbers[0]

    return [(x - sorted_numbers[0])/range_numbers for x in numbers]
```


