```python
def fib(n: int):
    """Return n-th Fibonacci number.
    >>> fib(10)
    55
    >>> fib(1)
    1
    >>> fib(8)
    21
    """

    # buggy implementation
    if n == 0 or n == 1:
        return n
    else:
        return fib(n-1) + fib(n-2) + 1  # inserted bug by adding 1
```


