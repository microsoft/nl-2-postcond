```python

def largest_smallest_integers(lst):
    '''
    Create a function that returns a tuple (a, b), where 'a' is
    the largest of negative integers, and 'b' is the smallest
    of positive integers in a list.
    If there is no negative or positive integers, return them as None.

    Examples:
    largest_smallest_integers([2, 4, 1, 3, 5, 7]) == (None, 1)
    largest_smallest_integers([]) == (None, None)
    largest_smallest_integers([0]) == (None, None)
    '''

    # Initializing variables
    max_neg = None
    min_pos = None

    # Iterating through the list
    for i in lst:
        if i < 0:
            # Assigning max negative integer
            if max_neg is None:
                max_neg = i
            elif i > max_neg:  # Introducing a bug by changing >= to >
                max_neg = i
        elif i > 0:
            # Assigning min positive integer
            if min_pos is None:
                min_pos = i
            elif i < min_pos:
                min_pos = i

    return (max_neg, min_pos)

```


