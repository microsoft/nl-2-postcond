```python

def is_palindrome(text: str):
    """
    Checks if given string is a palindrome
    >>> is_palindrome('')
    True
    >>> is_palindrome('aba')
    True
    >>> is_palindrome('aaaaa')
    True
    >>> is_palindrome('zbcd')
    False
    """

    # The buggy implementation goes here
    for i in range(len(text)):
        if text[i] != text[len(text)-i]:
            return False
    return True
```
Note: The bug in the implementation is that it does not subtract 1 from the `len(text)` inside the index for the second comparison, causing it to go out of bounds and raise an `IndexError` for strings with even length.


