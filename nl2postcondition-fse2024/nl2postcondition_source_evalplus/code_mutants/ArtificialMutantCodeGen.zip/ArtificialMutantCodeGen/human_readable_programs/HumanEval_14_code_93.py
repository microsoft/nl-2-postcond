```python
from typing import List


def all_prefixes(string: str) -> List[str]:
    """ Return list of all prefixes from shortest to longest of the input string
    >>> all_prefixes('abc')
    ['a', 'ab', 'abc']
    """

    # Creating an empty list to hold the prefixes
    prefixes = []

    # Looping through the string, adding each new prefix to the list
    for i in range(len(string)+1):  # off-by-one error introduced
        prefixes.append(string[:i])

    # Returning the list of prefixes
    return prefixes
```


