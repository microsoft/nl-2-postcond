```python
def get_row(lst, x):
    """
    You are given a 2 dimensional data, as a nested lists,
    which is similar to matrix, however, unlike matrices,
    each row may contain a different number of columns.
    Given lst, and integer x, find integers x in the list,
    and return list of tuples, [(x1, y1), (x2, y2) ...] such that
    each tuple is a coordinate - (row, columns), starting with 0.
    Sort coordinates initially by rows in ascending order.
    Also, sort coordinates of the row by columns in descending order.
    
    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """

    row_coords = []
    row_num = 0
    for row in lst:
        if x in row:
            col_coords = [(row.index(x), i) for i in range(len(row))] # check for the index of x in current row, and save all column coordinates
            col_coords.sort(key=lambda x: x[1], reverse=True) # sort column coordinates in descending order
            row_coords.append((row_num, col_coords)) # save row number and column coordinates as a tuple
        row_num += 1
    row_coords.sort(key=lambda x: x[0]) # sort rows by ascending order
    coords = []
    for row in row_coords:
        coords.extend([(row[0], coord[0]) for coord in row[1]]) # append coordinates to result list
    coords[1][0] = 3 # insert bug by changing the first row number to 3, instead of 1
    return coords
```


