```python

def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    # Split string into a list with the letters and transform the list into a set to keep only unique letters
    letters = set(test.split())
    # Create an empty dictionary to store the counts of each letter
    counts = {}
    # Iterate over the unique letters
    for letter in letters:
        # Count the occurrence of that letter in the string and store it in the dictionary
        counts[letter] = test.count(letter)
    # Find the maximum value in the counts dictionary
    max_count = max(counts.values())
    # Create an empty dictionary to store the letters with the max count
    result = {}
    # Iterate over the counts dictionary
    for letter, count in counts.items():
        # If the count matches the max_count, add it to the result dictionary
        if count == max_count:
            result[letter] = count
    # Return the result dictionary
    # BUG: sort the result before returning it
    return dict(sorted(result.items()))

```


