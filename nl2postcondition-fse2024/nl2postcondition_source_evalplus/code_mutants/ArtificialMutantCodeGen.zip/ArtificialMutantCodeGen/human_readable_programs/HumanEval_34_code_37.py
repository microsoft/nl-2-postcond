```python

def unique(l: list):
    """Return sorted unique elements in a list
    >>> unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    [0, 2, 3, 5, 9, 123]
    """

    # Implementation with a bug
    res = []
    for i in l:
        if i not in res: # insert a bug: remove the conversion to a string
            res.append(str(i))
    return sorted(res, key=lambda x: int(x))
```

The bug is that the elements are not converted to string before appending to the result list. When the list is sorted, it's sorting the integers in lexicographical order, which is not the desired behavior.


