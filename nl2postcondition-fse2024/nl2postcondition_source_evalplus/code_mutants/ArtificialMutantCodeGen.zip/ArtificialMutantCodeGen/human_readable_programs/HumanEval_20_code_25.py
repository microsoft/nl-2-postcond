```python
from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """

    # Sort the list of numbers in ascending order
    sorted_numbers = sorted(numbers)
    
    # Initialize the minimum difference and the numbers corresponding to it
    min_difference = float('inf')
    closest_numbers = (float('inf'), float('inf'))
    
    # Iterate through the list of numbers and update the closest pair if a closer pair is found
    for i in range(len(sorted_numbers) - 1):
        difference = sorted_numbers[i+1] - sorted_numbers[i]
        if difference < min_difference:
            closest_numbers = (sorted_numbers[i], sorted_numbers[i+1])
            min_difference = difference
    
    # Bug: Return the closest numbers in descending order instead of ascending order
    return (closest_numbers[1], closest_numbers[0])
```


