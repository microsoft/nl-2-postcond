```python
def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    stones_list = [n]
    current_stones = n
    is_n_even = (n % 2 == 0)
    for i in range(1, n):
        if is_n_even:
            current_stones += 1
        else:
            current_stones += 2
        stones_list.append(current_stones)

    # introducing a bug here to return a list containing the first n odd/even numbers instead of number of stones in each level 
    if is_n_even:
        return [i for i in range(2, 2*n+1, 2)]
    else:
        return [i for i in range(1, 2*n, 2)]
```


