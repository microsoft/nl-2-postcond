```python
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    sorted_lst = sorted(lst)
    res = []
    while len(sorted_lst) > 0:
        popped = sorted_lst.pop(0)
        res.append(popped)
        if len(sorted_lst) > 0:
            popped = sorted_lst.pop(-1)
            res.append(popped)
    # Introduce a bug by accidentally reversing the resulting list
    return res[::-1]
```


