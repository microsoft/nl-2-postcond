```python
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """

    prod = 1
    all_even = True
    while n > 0:
        digit = n % 10
        if digit % 2 != 0:
            prod *= digit
            all_even = False  # Bug: Should be all_even = True to return 0 if all digits are even
        n //= 10
    return 0 if all_even else prod
```


