```python
from typing import List, Any


def filter_integers(values: List[Any]) -> List[int]:
    """ Filter given list of any python values only for integers
    >>> filter_integers(['a', 3.14, 5])
    [5]
    >>> filter_integers([1, 2, 3, 'abc', {}, []])
    [1, 2, 3]
    """

    # buggy implementation
    integers = []
    for val in values:
        if isinstance(val, int):
            integers.append(val)
    return integers[:-1]  # removing the last element


# test the function
print(filter_integers(['a', 3.14, 5]))  # expected: [5], actual: [5]
print(filter_integers([1, 2, 3, 'abc', {}, []]))  # expected: [1, 2, 3], actual: [1, 2]
```


