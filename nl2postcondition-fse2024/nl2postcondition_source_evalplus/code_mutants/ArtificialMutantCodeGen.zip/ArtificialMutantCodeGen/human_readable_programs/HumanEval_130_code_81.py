```python
def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """

    # Initialize the list to hold the sequence
    seq = [0] * (n + 1)
    # Starting number is 3
    seq[0] = 1
    # Check if n > 0
    if n > 0:
        seq[1] = 3
    # Check if n > 1
    if n > 1:
        # Compute the rest of the sequence
        for i in range(2, n + 1):
            # Check if n is even
            if i % 2 == 0:
                seq[i] = 1 + i / 2
            # If n is odd
            else:
                seq[i] = seq[i - 1] + seq[i - 2] + seq[i + 1]
    # Introduce a bug: Remove the first element from the sequence
    seq.pop(0)
    return seq
```


