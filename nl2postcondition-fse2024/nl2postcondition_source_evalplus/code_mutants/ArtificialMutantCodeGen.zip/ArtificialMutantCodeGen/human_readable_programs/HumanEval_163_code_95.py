```python

def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    result = []
    for i in range(a, b+1):
        digits = [int(d) for d in str(i)]
        for digit in digits:
            if digit % 2 == 0:
                result.append(digit)
    return sorted(result)

# This implementation has a bug: it doesn't consider the edge case where b < a.
# For instance, generate_integers(8, 2) should return [2, 4, 6, 8], but this implementation returns [].

```


