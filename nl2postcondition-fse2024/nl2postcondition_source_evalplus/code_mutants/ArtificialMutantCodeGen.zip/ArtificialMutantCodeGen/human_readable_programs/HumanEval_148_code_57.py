```python

def bf(planet1, planet2):
    
    planets = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune']
    
    if planet1 not in planets or planet2 not in planets:
        return ()
    
    # Bug introduced: used max() to swap arguments
    orbit_range = planets[planets.index(max(planet1, planet2)):planets.index(min(planet1, planet2))]
    
    return tuple(orbit_range)
```


