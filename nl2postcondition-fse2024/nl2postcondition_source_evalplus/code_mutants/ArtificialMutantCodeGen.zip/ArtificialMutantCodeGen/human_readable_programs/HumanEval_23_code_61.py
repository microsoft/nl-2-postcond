```python
def strlen(string: str) -> int:
    """ Return length of given string
    >>> strlen('')
    0
    >>> strlen('abc')
    3
    """

    length = 0
    for char in string:
        length += 1
        # Inserting a bug by ignoring the last character of the string
    return length - 1
```


