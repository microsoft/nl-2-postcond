```python

def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    # The bug is that the index for checking if it's an even position is wrong. 
    # It should be (i+1) % 2, not i % 2.
    return sum(lst[i] for i in range(len(lst)) if lst[i] % 2 != 0 and (i+1) % 2 == 0)
```


