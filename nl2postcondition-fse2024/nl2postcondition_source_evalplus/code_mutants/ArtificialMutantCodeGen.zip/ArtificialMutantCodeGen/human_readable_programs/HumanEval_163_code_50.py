```python

def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    # Generating a list of even digits between a and b
    lst = []
    for i in range(a, b+1):
        for j in str(i):
            if int(j) % 2 == 0:
                lst.append(int(j))

    # Returning the list of even digits in ascending order
    return sorted(lst, reverse=True) #In order to introduce a bug, descending order is chosen instead of ascending order


```


