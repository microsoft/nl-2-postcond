```python
from typing import List


def concatenate(strings: List[str]) -> str:
    """ Concatenate list of strings into a single string
    >>> concatenate([])
    ''
    >>> concatenate(['a', 'b', 'c'])
    'abc'
    """

    # Concatenate the strings
    result = ""
    for string in strings:
        result += string
    # Introduce bug: append "!" at the end of the string
    result += "!"

    return result
```
Note: The introduced bug is appending "!" at the end of the concatenated string. This will make the implementation fail the test case where the expected output is 'abc'.


