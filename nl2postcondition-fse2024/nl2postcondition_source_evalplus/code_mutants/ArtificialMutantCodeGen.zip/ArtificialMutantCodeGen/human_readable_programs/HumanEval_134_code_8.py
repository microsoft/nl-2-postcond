```python

def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''

    # Inserting a bug by checking the second last character
    # instead of the last character
    if len(txt) == 0:
        return False
    else:
        txt_list = txt.split()
        last_word = txt_list[-1]
        if len(last_word) > 1:
            return last_word[-2].isalpha() and not last_word[-1].isalpha()
        elif len(last_word) == 1:
            return False
        else:
            return txt[-2].isalpha() and not txt[-1].isalpha()
```


