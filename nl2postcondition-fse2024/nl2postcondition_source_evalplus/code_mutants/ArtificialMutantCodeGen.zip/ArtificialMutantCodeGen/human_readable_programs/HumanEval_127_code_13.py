def intersection(interval1, interval2):
    # Start your code here
    start = max(interval1[0], interval2[0])
    end = min(interval1[1], interval2[1])

    if start > end:
        return "NO"

    length = end - start + 1
    if length == 2:   # introducing a bug
        return "YES"
        
    if length <= 1:
        return "NO"

    for i in range(2, length):
        if length % i == 0:
            return "NO"

    return "YES"


