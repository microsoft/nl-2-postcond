```
def flip_case(string: str) -> str:
    """For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello!')
    'hELLO!'
    """
    flipped = ""
    for char in string:
        if char.islower():
            flipped += char.upper()
        elif char.isupper():
            flipped += char.lower()
        else:
            flipped += char
    return flipped

# Introducing a bug where the function doesn't flip the first occurrence of the first letter (even if it is a letter to flip)
def flip_case(string: str) -> str:
    """For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    >>> flip_case('Hello!')
    'hELLO!'
    """
    flipped = ""
    for char in string:
        if char.islower():
            flipped += char.upper()
        elif char.isupper():
            flipped += char.lower()
        else:
            flipped += char
        if char in flipped:
            flipped += char
    return flipped
```


