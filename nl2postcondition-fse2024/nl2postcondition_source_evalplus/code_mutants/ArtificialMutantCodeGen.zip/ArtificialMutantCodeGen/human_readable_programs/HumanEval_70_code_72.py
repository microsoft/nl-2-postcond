```python
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''
    result = []
    # Sort the list in increasing order
    lst = sorted(lst)
    while lst:
        # Get the minimum number
        result.append(lst.pop(0))
        # Get the maximum number
        result.append(lst.pop(-1))
        # Get the minimum number
        result.append(lst.pop(0))
    return result[::-1]

# Introduce a bug by forgetting to sort the list in the function
```


