```python
from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """
    # Initialize variables to store the closest pair and the minimum absolute difference
    closest_pair = None
    min_difference = float('inf')
    # Sort the input list in ascending order
    sorted_numbers = sorted(numbers)
    # Iterate over the sorted list
    for i in range(len(sorted_numbers) - 1):
        # Calculate the absolute difference between the current number and the next number
        difference = abs(sorted_numbers[i] - sorted_numbers[i + 1])
        # Check if this difference is smaller than the current minimum difference
        if difference < min_difference:
            # If it is, update the closest pair and the minimum difference
            closest_pair = (sorted_numbers[i], sorted_numbers[i + 1])
            min_difference = difference
    # Simulate a bug by swapping the order of the closest pair before returning
    return closest_pair[::-1]
```


