```python

def skjkasdkd(lst):
    def is_prime(n):
      if n <= 1:
          return False
      if n <= 3:
          return True
      if n % 2 == 0 or n % 3 == 0:
          return False
      i = 5
      while i * i <= n:
          if n % i == 0 or n % (i + 2) == 0:
              return False
          i += 6
      return True

    max_prime = 0
    for num in lst:
        if is_prime(num) and num > max_prime:
            max_prime = num
    
    sum_digits = 0
    for digit in str(max_prime):
        sum_digits += int(digit)
    
    return sum_digits + 1  # Adding an extra 1 here to introduce a bug


```


