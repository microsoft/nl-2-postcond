```python

def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """
    counter = 0
    
    for num in nums:
        if num > 10:
            num_str = str(num)
            if int(num_str[0]) % 2 != 0 and int(num_str[-1]) % 2 != 0:  # check if first and last digits are odd
                counter += 1    # increment the counter
    return counter + 1  # Adding 1 as the bug, which will cause the function to return an incorrect answer for some cases


```


