```python
import hashlib

def string_to_md5(text):
    """
    Given a string 'text', return its md5 hash equivalent string.
    If 'text' is an empty string, return None.

    >>> string_to_md5('Hello world') == '3e25960a79dbc69b674cd4ec67a72c62'
    """

    # b prefix is needed to convert text to bytes.
    # Changed None to '' to fix incorrect return value.
    if text == '':
        return None

    # Changed hash to sha256 to introduce a bug.
    # hashlib.md5(text.encode()) should be used instead.
    hash_object = hashlib.sha256(text.encode())
    hash_string = hash_object.hexdigest()
    return hash_string
```


