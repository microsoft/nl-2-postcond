```python
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''

    # Sort the input list in ascending order
    lst_sorted = sorted(lst)
    
    # Initialize the output list
    output_lst = []

    # Loop through the first half of the input list
    for i in range(len(lst_sorted) // 2):
        # Append the current minimum value to the output list
        output_lst.append(lst_sorted[i])
        # Append the current maximum value to the output list
        output_lst.append(lst_sorted[-(i+1)])
    
    # Append the middle element if the input list has odd length
    if len(lst_sorted) % 2 != 0:
        output_lst.append(lst_sorted[len(lst_sorted) // 2])
    
    return output_lst[::-1]

# IMPLEMENTED BUG: The output list is reversed in the return statement, causing an incorrect output for even length input lists


