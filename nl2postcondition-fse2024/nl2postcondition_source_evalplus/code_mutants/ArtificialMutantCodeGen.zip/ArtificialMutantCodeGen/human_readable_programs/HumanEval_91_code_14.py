```python
def is_bored(S):
    """
    You'll be given a string of words, and your task is to count the number
    of boredoms. A boredom is a sentence that starts with the word "I".
    Sentences are delimited by '.', '?' or '!'.
   
    For example:
    >>> is_bored("Hello world")
    0
    >>> is_bored("The sky is blue. The sun is shining. I love this weather")
    1
    """

    # Count the number of boredoms
    count = 0
    
    # Change all punctuations to '.'
    for p in ['?','!']:
        S = S.replace(p,'.')
    
    # Split the string to get sentences
    sentences = S.split('.')
    
    # Iterate through each sentence
    for sentence in sentences:
        
        # Get the first word of the sentence
        first_word = sentence.strip().split()[0]
        
        # Check if the first word is "I", and add to count if it is
        if first_word == 'I':
            count += 1
            
    # introducing the bug: returning the count divided by 2
    return count/2
```


