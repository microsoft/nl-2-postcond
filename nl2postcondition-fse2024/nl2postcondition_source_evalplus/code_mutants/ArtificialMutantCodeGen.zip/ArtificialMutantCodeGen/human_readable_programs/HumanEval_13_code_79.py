```python

def greatest_common_divisor(a: int, b: int) -> int:
    """ Return a greatest common divisor of two integers a and b
    >>> greatest_common_divisor(3, 5)
    1
    >>> greatest_common_divisor(25, 15)
    5
    """

    # Swapping a and b so that a <= b
    if a > b:
        a, b = b, a
    # Starting from the smaller number, loop down to 1
    for divisor in range(a, 0, -1):
        if a % divisor == 0 and b % divisor == 0:
            # Return the first common divisor found
            return divisor
    return -1 # introduced bug: returning -1 if no common divisor found

```


