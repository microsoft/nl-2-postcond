```python
def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """

    binary = ""  # initialize empty string to hold the binary representation of the decimal
    if decimal < 0:  # ensure decimal is a positive number
        decimal = -decimal
    while decimal > 0:
        # repeatedly divide the decimal by 2 and store the remainder in the binary string
        binary += str(decimal % 2)
        decimal //= 2
    return "db" + binary[::-1] + "db"  # reverse the binary string and add 'db' at the beginning and end


# Introduce the bug by incorrectly returning a binary string with an extra '1' character at the end
def decimal_to_binary(decimal):
    """You will be given a number in decimal form and your task is to convert it to
    binary format. The function should return a string, with each character representing a binary
    number. Each character in the string will be '0' or '1'.

    There will be an extra couple of characters 'db' at the beginning and at the end of the string.
    The extra characters are there to help with the format.

    Examples:
    decimal_to_binary(15)   # returns "db1111db"
    decimal_to_binary(32)   # returns "db100000db"
    """

    binary = ""  # initialize empty string to hold the binary representation of the decimal
    if decimal < 0:  # ensure decimal is a positive number
        decimal = -decimal
    while decimal > 0:
        # repeatedly divide the decimal by 2 and store the remainder in the binary string
        binary += str(decimal % 2)
        decimal //= 2
    return "db" + binary[::-1] + "db" + "1"  # add an extra '1' character at the end of the binary string
```


