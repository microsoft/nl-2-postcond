```python
FIX = """
Add more test cases.
"""

def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """

    vowel_count = 0  # keep track of number of vowels

    for i in range(len(s)):
        if s[i] in "AEIOUaeiou":
            vowel_count += 1
        if s[-1] == "y" or s[-1] == "Y":  # check if y is the last character
            if s[-2] not in "AEIOUaeiou" and s[-2] != "":  # check if second to last character is not a vowel or empty
                vowel_count += 1

    return vowel_count


# additional test cases
assert vowels_count("apple") == 2
assert vowels_count("banana") == 3
assert vowels_count("cantaloupe") == 4
assert vowels_count("") == 0
assert vowels_count("Yellow") == 2
assert vowels_count("vacuum") == 2
```


