```python
def decode_shift(s: str):
    """
    takes as input string encoded with encode_shift function. Returns decoded string.
    """
    return "".join([chr(((ord(ch) - 5 - ord("a")) % 26) + ord("a")) for ch in s])
```

The implementation takes the input string, and for each character, subtracts 5 from its ASCII value. Then the modulo 26 is applied to make sure the result is within the range of lowercase alphabets. Finally "a" is added to bring the value back into the ASCII range of lowercase alphabets. The result is then joined to form the decoded string.


