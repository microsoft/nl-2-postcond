```python

def words_string(s):
    """
    You will be given a string of words separated by commas or spaces. Your task is
    to split the string into words and return an array of the words.
    
    For example:
    words_string("Hi, my name is John") == ["Hi", "my", "name", "is", "John"]
    words_string("One, two, three, four, five, six") == ["One", "two", "three", "four", "five", "six"]
    """

    # Split the input string into words using the split() function
    words = s.split()

    # Create an empty list to store the words
    word_list = []

    # Iterate over each word and append it to the list
    for word in words:
        # Remove any commas or other punctuation from the word
        word = word.strip(",.!?:;")

        # Only append non-empty words to the list
        if word:
            word_list.append(word)

    # Return the list of words
    return word_list
```


