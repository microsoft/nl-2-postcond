```python
def largest_prime_factor(n: int):
    """Return the largest prime factor of n. Assume n > 1 and is not a prime.
    >>> largest_prime_factor(13195)
    29
    >>> largest_prime_factor(2048)
    2
    """
    
    factor = 2               # Start by dividing by 2
    while factor <= n:       # Keep looping while the factor is less than or equal to the input number
        if n % factor == 0:  # If the number is divisible by the factor
            n //= factor     # Divide the input number by the factor
        else:
            factor += 1      # Otherwise, try the next integer
    return factor            # The last factor is the largest prime factor of the input number
```


