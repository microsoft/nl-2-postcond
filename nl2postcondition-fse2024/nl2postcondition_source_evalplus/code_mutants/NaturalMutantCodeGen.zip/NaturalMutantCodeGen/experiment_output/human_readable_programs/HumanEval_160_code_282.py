```python

def do_algebra(operator, operand):
    """
    Given two lists operator, and operand. The first list has basic algebra operations, and 
    the second list is a list of integers. Use the two given lists to build the algebric 
    expression and return the evaluation of this expression.

    The basic algebra operations:
    Addition ( + ) 
    Subtraction ( - ) 
    Multiplication ( * ) 
    Floor division ( // ) 
    Exponentiation ( ** ) 

    Example:
    operator['+', '*', '-']
    array = [2, 3, 4, 5]
    result = 2 + 3 * 4 - 5
    => result = 9

    Note:
        The length of operator list is equal to the length of operand list minus one.
        Operand is a list of of non-negative integers.
        Operator list has at least one operator, and operand list has at least two operands.

    """

    result = operand[0] # start with the first operand in the list as the initial result
    for i in range(len(operator)):
        if operator[i] == "+":
            result += operand[i+1] # add the next operand in the list to the result
        elif operator[i] == "-":
            result -= operand[i+1] # subtract the next operand in the list from the result
        elif operator[i] == "*":
            result *= operand[i+1] # multiply the result by the next operand in the list
        elif operator[i] == "//":
            result //= operand[i+1] # divide the result by the next operand in the list using floor division
        elif operator[i] == "**":
            result **= operand[i+1] # raise the result to the power of the next operand in the list

    return result

```


