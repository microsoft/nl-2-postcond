```python
def median(l: list):
    """Return median of elements in the list l.
    >>> median([3, 1, 2, 4, 5])
    3
    >>> median([-10, 4, 6, 1000, 10, 20])
    15.0
    """

    l.sort()  # sort the list in ascending order
    n = len(l)
    mid = n // 2

    if n % 2 == 0:
        # if the length is even, take the average of the middle two values
        return (l[mid - 1] + l[mid]) / 2
    else:
        # if the length is odd, return the middle value
        return l[mid]
```


