```python

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    if x == 0:  # handle the case when x is zero
        return '0'

    digits = []  # stack for storing remainders

    while x > 0:  # keep dividing the number by the base till it becomes zero
        remainder = x % base  # remainder when x is divided by base
        digits.append(str(remainder))  # append remainder to the list of digits
        x //= base  # integer divide x by the base

    digits.reverse()  # reverse the order of digits

    return ''.join(digits)  # join the list of digits to get the final string


```


