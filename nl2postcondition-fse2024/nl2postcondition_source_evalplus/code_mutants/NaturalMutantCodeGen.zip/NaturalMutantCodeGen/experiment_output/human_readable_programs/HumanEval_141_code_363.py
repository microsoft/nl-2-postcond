```python
def file_name_check(file_name):
    """Create a function which takes a string representing a file's name, and returns
    'Yes' if the the file's name is valid, and returns 'No' otherwise.
    A file's name is considered to be valid if and only if all the following conditions 
    are met:
    - There should not be more than three digits ('0'-'9') in the file's name.
    - The file's name contains exactly one dot '.'
    - The substring before the dot should not be empty, and it starts with a letter from 
    the latin alphapet ('a'-'z' and 'A'-'Z').
    - The substring after the dot should be one of these: ['txt', 'exe', 'dll']
    Examples:
    file_name_check("example.txt") # => 'Yes'
    file_name_check("1example.dll") # => 'No' (the name should start with a latin alphapet letter)
    """

    # Check if the file name has more than 3 digits
    num_digits = sum([1 for char in file_name if char.isdigit()])
    if num_digits > 3:
        return 'No'

    # Check if the file name has exactly one dot
    if file_name.count('.') != 1:
        return 'No'

    # Split the filename into two parts, before and after the dot
    name_parts = file_name.split('.')
    name_prefix = name_parts[0]
    name_suffix = name_parts[1]

    # Check if the name prefix is not empty and starts with a letter from the latin alphabet
    if not name_prefix or not name_prefix[0].isalpha():
        return 'No'

    # Check if the name suffix is one of the given valid extensions
    valid_extensions = ['txt', 'exe', 'dll']
    if name_suffix not in valid_extensions:
        return 'No'

    # All checks were passed, the file name is valid
    return 'Yes'
```


