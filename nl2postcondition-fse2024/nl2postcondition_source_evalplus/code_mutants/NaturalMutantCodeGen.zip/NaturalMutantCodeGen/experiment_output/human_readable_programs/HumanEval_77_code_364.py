```python
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this integer is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''

    # We take the absolute value of a to cover cases when the initial value is negative
    # We then take the cubic root of this absolute value and check if the result is an integer
    return int(abs(a)**(1/3))**3 == abs(a)
```


