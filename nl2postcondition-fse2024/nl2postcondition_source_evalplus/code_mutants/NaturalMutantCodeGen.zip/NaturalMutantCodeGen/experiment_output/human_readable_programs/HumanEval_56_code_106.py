```python

def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """

    # Using a stack to keep track of opening brackets
    stack = []
    
    # Loop through each character in brackets
    for char in brackets:
        if char == "<":
            stack.append(char)  # Add opening bracket to stack
        elif char == ">":
            if not stack:  # If stack is empty, there is no opening bracket left to match with this closing bracket
                return False
            stack.pop()  # Match closing bracket with latest opening bracket in stack

    # If there are no opening brackets left in stack, all brackets have been matched
    return not stack

```


