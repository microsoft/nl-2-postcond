```python

def exchange(lst1, lst2):
    """
    Given two lists lst1 and lst2 determine whether it is possible to perform an exchange of elements
    between lst1 and lst2 to make lst1 a list of only even numbers. Return "YES" if it is possible,
    otherwise, return "NO".
    
    Arguments:
    lst1 -- a list of integers
    lst2 -- a list of integers
    
    Returns:
    A string -- "YES" or "NO"
    """
    
    # Determine the number of odd numbers in lst1
    odd_count = sum([1 for x in lst1 if x % 2 == 1])
    
    # Determine the total number of odd numbers in both lst1 and lst2
    total_odd_count = odd_count + sum([1 for x in lst2 if x % 2 == 1])
    
    # If there are not enough odd numbers to replace the even numbers in lst1
    # return "NO"
    if total_odd_count < len(lst1) - odd_count:
        return "NO"
    
    # Otherwise, it is possible to replace the even numbers in lst1 with odd numbers
    # from lst2, so return "YES"
    else:
        return "YES"
```


