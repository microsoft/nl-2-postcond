```python


def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    # Initialize variables to store quotient and remainder
    quotient = x
    remainder = 0

    # Initialize an empty string to store the new base representation
    new_base_str = ""

    # Perform the base conversion algorithm
    while quotient > 0:
        # Calculate the remainder when dividing the current quotient by the new base
        remainder = quotient % base
        # Add the remainder to the new base string
        new_base_str = str(remainder) + new_base_str
        # Update the quotient
        quotient = quotient // base

    # Return the new base string
    return new_base_str
```


