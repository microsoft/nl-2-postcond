```python
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}

    """
    # Split the string by space and create a list of all letters
    letters = test.split()

    # Create an empty dictionary to store letter counts
    count_dict = {}

    # Track the maximum count seen so far
    max_count = 0

    # Loop through the list of letters and count their occurrences
    for letter in letters:
        if letter not in count_dict:
            count_dict[letter] = 1
        else:
            count_dict[letter] += 1

        # Update max_count if the current count is greater
        if count_dict[letter] > max_count:
            max_count = count_dict[letter]

    # Create a list of letters that have the maximum count
    max_letters = [letter for letter, count in count_dict.items() if count == max_count]

    # Return a dictionary of the letters with the maximum count and their counts
    return {letter: count for letter, count in count_dict.items() if letter in max_letters}
```


