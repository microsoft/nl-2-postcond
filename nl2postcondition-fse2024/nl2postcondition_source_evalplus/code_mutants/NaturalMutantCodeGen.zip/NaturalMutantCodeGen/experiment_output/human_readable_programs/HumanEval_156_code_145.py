```python
def int_to_mini_roman(number):
    """
    Given a positive integer, obtain its roman numeral equivalent as a string,
    and return it in lowercase.
    Restrictions: 1 <= num <= 1000

    Examples:
    >>> int_to_mini_roman(19) == 'xix'
    >>> int_to_mini_roman(152) == 'clii'
    >>> int_to_mini_roman(426) == 'cdxxvi'
    """

    # Roman numeral symbols and their corresponding values
    symbols = {
        'M': 1000, 'CM': 900, 'D': 500, 'CD': 400,
        'C': 100, 'XC': 90, 'L': 50, 'XL': 40,
        'X': 10, 'IX': 9, 'V': 5, 'IV': 4, 'I': 1
    }
    # Ensure the number is within the allowed range
    if number <= 0 or number > 1000:
        raise ValueError("Number must be within the range 1-1000")
    # Start with an empty string
    roman_numeral = ''
    # Iterate over the symbols and their values
    for symbol, value in symbols.items():
        # Repeat the symbol as many times as possible and append it to the result
        count, number = divmod(number, value)
        roman_numeral += symbol * count
    # Return the result in lowercase
    return roman_numeral.lower()
```


