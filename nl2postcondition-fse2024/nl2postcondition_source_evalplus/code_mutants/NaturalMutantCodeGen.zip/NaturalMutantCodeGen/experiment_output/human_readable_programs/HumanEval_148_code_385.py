```python
def bf(planet1, planet2):
    '''
    There are eight planets in our solar system: the closerst to the Sun 
    is Mercury, the next one is Venus, then Earth, Mars, Jupiter, Saturn, 
    Uranus, Neptune.
    Write a function that takes two planet names as strings planet1 and planet2. 
    The function should return a tuple containing all planets whose orbits are 
    located between the orbit of planet1 and the orbit of planet2, sorted by 
    the proximity to the sun. 
    The function should return an empty tuple if planet1 or planet2
    are not correct planet names. 
    Examples
    bf("Jupiter", "Neptune") ==> ("Saturn", "Uranus")
    bf("Earth", "Mercury") ==> ("Venus")
    bf("Mercury", "Uranus") ==> ("Venus", "Earth", "Mars", "Jupiter", "Saturn")
    '''
    planets_dict = {
        'Mercury': 1,
        'Venus': 2,
        'Earth': 3,
        'Mars': 4,
        'Jupiter': 5,
        'Saturn': 6,
        'Uranus': 7,
        'Neptune': 8
    }
    # Checking if planet1 and planet2 are present in our dictionary of planets
    if planet1 not in planets_dict or planet2 not in planets_dict:
        return tuple()
    p1, p2 = planets_dict[planet1], planets_dict[planet2]
    # Swapping the values of p1 and p2 if p1 is greater than p2
    if p1 > p2:
        p1, p2 = p2, p1
    # Creating a list of planets whose orbit is between p1 and p2
    res = []
    for key, value in planets_dict.items():
        if p1 < value < p2:
            res.append(key)
    return tuple(res)
```


