```python

def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''

    stack = []
    for bracket in string:
        if bracket == "[":
            stack.append(bracket)   # add opening bracket to stack
        elif bracket == "]":
            if stack:  # check if stack has an opening bracket
                stack.pop()   # remove opening bracket from stack
            else:
                stack.append(bracket)   # add closing bracket to stack

    # if everything in the stack is opening brackets, there is a nested sequence
    return not bool(len(stack)) and "[" in string and "]" in string
```


