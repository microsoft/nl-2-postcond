```python
def modp(n: int, p: int):
    """Return 2^n modulo p (be aware of numerics).
    >>> modp(3, 5)
    3
    >>> modp(1101, 101)
    2
    >>> modp(0, 101)
    1
    >>> modp(3, 11)
    8
    >>> modp(100, 101)
    1
    """

    result = 1
    # Ensure p is positive
    p = abs(p)
    # Ensure n is positive
    n = abs(n)
    if p == 1:
        return 0
    n = n % (p-1)
    base = 2 % p
    while n > 0:
        # If the current power is odd, multiply by the base
        if n % 2 == 1:
            result = (result * base) % p
        # Halve the power
        n = n // 2
        # Square the base
        base = (base * base) % p
    return result
```


