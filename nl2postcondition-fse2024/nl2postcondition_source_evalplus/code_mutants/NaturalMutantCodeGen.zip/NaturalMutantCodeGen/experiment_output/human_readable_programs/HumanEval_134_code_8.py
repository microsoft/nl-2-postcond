```python
def check_if_last_char_is_a_letter(txt):
    '''
    Create a function that returns True if the last character
    of a given string is an alphabetical character and is not
    a part of a word, and False otherwise.
    Note: "word" is a group of characters separated by space.

    Examples:
    check_if_last_char_is_a_letter("apple pie") ➞ False
    check_if_last_char_is_a_letter("apple pi e") ➞ True
    check_if_last_char_is_a_letter("apple pi e ") ➞ False
    check_if_last_char_is_a_letter("") ➞ False 
    '''

    # remove trailing whitespaces
    txt = txt.rstrip()

    # check if txt is empty
    if not txt:
        return False 

    # get the last character of the txt
    last_char = txt[-1]

    # check if the last character is an alphabetical character
    if not last_char.isalpha():
        return False
    
    # remove all the trailing spaces
    txt = txt.rstrip(" ")

    # check if there is any whitespace between the last letter and the last space
    last_space_index = txt.rfind(" ")
    if last_space_index == -1:
        return True
    else:
        return not any([char.isalpha() for char in txt[last_space_index:]])
```


