```python

def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """

    sList = s.split()       # Split the string into a list of words
    result = []             # Empty list to collect modified words
    for word in sList:
        lst = list(word)    # Convert the word to a list of characters
        lst.sort()          # Sort the list based on ascii value
        result.append(''.join(lst)) # Append the sorted word to results
    return ' '.join(result) #Join the words using spaces to return the modified string
```


