```python
from typing import List, Tuple


def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    """ From a supplied list of numbers (of length at least two) select and return two that are the closest to each
    other and return them in order (smaller number, larger number).
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.2])
    (2.0, 2.2)
    >>> find_closest_elements([1.0, 2.0, 3.0, 4.0, 5.0, 2.0])
    (2.0, 2.0)
    """

    numbers.sort()  # sort the list in ascending order
    min_diff = float('inf')  # initialize the minimum difference to infinity
    closest_nums = ()  # initialize a tuple to hold the pair of closest numbers

    for i in range(len(numbers) - 1):  # iterate through the sorted list
        diff = numbers[i+1] - numbers[i]  # calculate the difference between adjacent numbers
        if diff < min_diff:  # if the difference is the smallest found so far
            min_diff = diff  # update the minimum difference
            closest_nums = (numbers[i], numbers[i+1])  # update the closest pair of numbers
    
    return closest_nums  # return the pair of closest numbers
```


