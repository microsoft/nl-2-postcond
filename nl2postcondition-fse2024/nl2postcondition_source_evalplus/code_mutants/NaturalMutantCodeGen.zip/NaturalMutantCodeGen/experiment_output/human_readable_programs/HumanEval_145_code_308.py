```python
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """

    nums.sort(key=lambda x: (sum(int(d) for d in str(abs(x))), nums.index(x)))
    return nums
```

Note: The lambda function inside the sort method converts the numbers to absolute value so that we can extract the sum of their digits without worrying about negative signs. The second sort key is the index of the number in the original list, which ensures that if two numbers have the same digit sum, the original order will be preserved.


