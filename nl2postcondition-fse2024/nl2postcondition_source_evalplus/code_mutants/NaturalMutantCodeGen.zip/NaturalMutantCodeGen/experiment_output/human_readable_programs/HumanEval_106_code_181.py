```python
def f(n):
    """ Implement the function f that takes n as a parameter,
    and returns a list of size n, such that the value of the element at index i is the factorial of i if i is even
    or the sum of numbers from 1 to i otherwise.
    i starts from 1.
    the factorial of i is the multiplication of the numbers from 1 to i (1 * 2 * ... * i).
    Example:
    f(5) == [1, 2, 6, 24, 15]
    """
    res = []
    curr_sum = 0 # Initiate the current sum to 0
    for i in range(n):
        if i % 2 == 0:
            if i == 0:
                res.append(1) # Append 1 for the 1st element as 0! equals to 1
            else:
                res.append(res[i-1] * i) # Append the multiplication of the previous element and the current i
        else:
            curr_sum += i # Add the current i to the current sum
            res.append(curr_sum) # Append the current sum to the result list
    return res
```


