```python
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    # Convert x to a list of digits
    digits = list(str(x))

    # If shift > number of digits, reverse the digits and return as a string
    if shift > len(digits):
        return ''.join(digits[::-1])

    # Circularly shift the digits right by shift
    shifted_digits = digits[-shift:] + digits[:-shift]

    # Return the shifted digits as a string
    return ''.join(shifted_digits)
```


