```python

def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == ""aaaaaaa"
    """

    def count_unique_chars(word):
        """Helper function to count unique chars in a given word"""
        return len(set(word))

    # Get max unique count and first lexicographical word
    max_unique_count = 0
    first_lex_word = ""
    for word in words:
        unique_count = count_unique_chars(word)
        if unique_count > max_unique_count:
            max_unique_count = unique_count
            first_lex_word = word
        elif unique_count == max_unique_count:
            if word < first_lex_word:  # If lexicographically before, override
                first_lex_word = word

    return first_lex_word

```


