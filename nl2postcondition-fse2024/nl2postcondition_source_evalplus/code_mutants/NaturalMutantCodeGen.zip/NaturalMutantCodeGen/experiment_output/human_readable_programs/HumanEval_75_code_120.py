```python
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    # A helper function to check if a number is prime or not
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                return False
        return True

    primes = []  # to store the prime factors
    count = 0  # to count the number of prime factors

    # Finding all prime factors of a
    for i in range(2, a):
        if is_prime(i) and a % i == 0:
            primes.append(i)
            count += 1
            if count == 3:  # No need to find more than 3 prime factors
                break

    if count == 3:  # If there are exactly 3 prime factors
        return True
    else:
        return False
```


