```python

def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """
    # Initialize a variable to hold the sum of ASCII values
    sum_of_ascii = 0

    # Loop through the string
    for char in s:
        # Check if the character is uppercase
        if char.isupper():
            # Add the ASCII value to the sum
            sum_of_ascii += ord(char)

    # Return the sum of ASCII values
    return sum_of_ascii
```


