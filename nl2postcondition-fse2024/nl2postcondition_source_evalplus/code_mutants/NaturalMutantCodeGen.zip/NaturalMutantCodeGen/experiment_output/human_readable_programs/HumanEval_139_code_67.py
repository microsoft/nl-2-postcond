```python
def special_factorial(n):
    """The Brazilian factorial is defined as:
    brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    where n > 0

    For example:
    >>> special_factorial(4)
    288

    The function will receive an integer as input and should return the special
    factorial of this integer.
    """

    # Calculate the factorials of numbers from n to 1 and multiply them
    result = 1
    for i in range(n, 0, -1):
        # Multiply result with factorial of i
        factorial_i = 1
        for x in range(i, 0, -1):
            factorial_i *= x
        result *= factorial_i

    return result
```


