```python

def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    output = ''
    
    for char in message:
        # swap case for uppercase and lowercase letters
        if char.isupper():
            output += char.lower()
        elif char.islower():
            output += char.upper()
        # replace vowels with the 2nd letter after the vowel in the alphabet
        elif char in ['a', 'e', 'i', 'o', 'u']:
            next_letter = chr(ord(char) + 2) # get the next letter after the vowel
            if next_letter in ['a', 'e', 'i', 'o', 'u']:
                next_letter = chr(ord(next_letter) + 2) # if it's a vowel, get the next letter after that
            output += next_letter.upper() # add the next letter after the vowel, capitalized
        else:
            output += char
            
    return output
```


