```python

def how_many_times(string: str, substring: str) -> int:
    """ Find how many times a given substring can be found in the original string. Count overlaping cases.
    >>> how_many_times('', 'a')
    0
    >>> how_many_times('aaa', 'a')
    3
    >>> how_many_times('aaaa', 'aa')
    3
    """

    # Initialize a counter variable to hold the number of times the substring occurs in the string
    count = 0

    # Loop through the string using a while loop
    i = 0
    while i <= len(string)-len(substring):
        # If the substring is found, increment the counter by 1
        if string[i:i+len(substring)] == substring:
            count += 1
        # Move to the next character by incrementing the loop counter
        i += 1

    # Return the final count
    return count

```


