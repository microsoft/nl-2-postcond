```python

def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    # Create a list to store our results
    result = []

    # Swap the numbers if necessary
    if a > b:
        a, b = b, a

    # Loop through the range from a to b (inclusive)
    for i in range(a, b + 1):

        # Convert each number to a string so we can iterate over its digits
        for digit in str(i):

            # Convert each digit back to an integer and check if it's even
            if int(digit) % 2 == 0:

                # If it's even, add it to our result list
                result.append(int(digit))

    # Return the result list
    return result
```


