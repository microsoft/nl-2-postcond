```python
def add(lst):
    """Given a non-empty list of integers lst. add the even elements that are at odd indices..


    Examples:
        add([4, 2, 6, 7]) ==> 2 
    """

    # Initialize sum to zero
    sum = 0

    # Loop through odd indices, add even elements to the sum
    for i in range(1, len(lst), 2):
        if lst[i] % 2 == 0:
            sum += lst[i]

    # Return the sum
    return sum
```


