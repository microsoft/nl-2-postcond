```python
import math

def minSubArraySum(nums):
    """
    Given an array of integers nums, find the minimum sum of any non-empty sub-array
    of nums.
    Example
    minSubArraySum([2, 3, 4, 1, 2, 4]) == 1
    minSubArraySum([-1, -2, -3]) == -6
    """

    # Your implementation goes here
    if not nums:
        return 0
    
    min_sum = math.inf
    current_sum = 0
    
    for num in nums:
        current_sum = min(num, current_sum + num)
        min_sum = min(min_sum, current_sum)
    
    return min_sum 
```

The function uses Kadane's algorithm. We initiate two variables, min_sum with infinity and current_sum with 0. Then, we loop over the array. In each iteration, we set `current_sum` as either the `num` or `current_sum + num`, whichever is smaller. This is done to discard any previous sub-array that has a sum greater than the current `num`. We then update `min_sum` as the minimum of `min_sum` and `current_sum`. At the end of the loop, `min_sum` would have the minimum sum of all non-empty sub-arrays.


