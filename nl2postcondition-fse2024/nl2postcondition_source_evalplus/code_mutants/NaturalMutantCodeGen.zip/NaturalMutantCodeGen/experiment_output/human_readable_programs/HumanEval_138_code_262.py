```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    # For n to be written as the sum of exactly 4 positive even numbers:
    # 1. It must be greater than or equal to 8
    # 2. The remainder of n divided by 4 must be even or zero (since we need 4 even numbers to sum up to n)
    # If both conditions are true, then n can be written as the sum of exactly 4 positive even numbers
    return n >= 8 and n % 4 == 0
```


