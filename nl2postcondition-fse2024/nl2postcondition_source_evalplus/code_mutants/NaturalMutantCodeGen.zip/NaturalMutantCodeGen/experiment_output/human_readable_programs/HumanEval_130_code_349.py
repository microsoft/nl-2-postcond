```python
def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to a return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """
    seq = [3] * (n + 1)  # initialize the sequence with first element = 3
    if n <= 0:  # return [3] for n=0, [] for negative n
        return seq[:n+1]
    elif n == 1:
        return seq
    elif n == 2:
        seq[1] = 1.5  # update second element of sequence
        return seq
    else:
        for i in range(3, n+1):
            if i % 2 == 0:
                seq[i] = 1 + i // 2  # apply the even recurrence
            else:
                seq[i] = seq[i-1] + seq[i-2] + seq[i+1]  # apply the odd recurrence
        return seq
```


