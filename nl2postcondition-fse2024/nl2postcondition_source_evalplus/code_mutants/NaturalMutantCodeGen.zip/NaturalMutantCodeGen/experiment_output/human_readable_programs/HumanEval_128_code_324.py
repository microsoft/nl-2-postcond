```python

def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """

    # If the given array is empty, return None
    if len(arr) == 0:
        return None
    
    # Initialize variables product and total_sum to 1 and 0 respectively
    product = 1
    total_sum = 0
    
    # Iterate over arr
    for num in arr:
        # Multiply the product by the sign of the number
        if num == 0:
            product = 0    # If the number is 0, set product to 0
            continue       # Skip to the next iteration
        else:
            product *= num/abs(num)   # Multiply the product by the sign of the number
        
        # Add the magnitude of the number to the total sum
        total_sum += abs(num)
    
    # Multiply the total sum by the product and return it
    return total_sum * product
```


