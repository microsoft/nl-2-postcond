```python


def triangle_area(a, h):
    """Given length of a side and high return area for a triangle.
    >>> triangle_area(5, 3)
    7.5
    """

    # Calculate and return the area of the triangle
    return 0.5 * a * h
```


