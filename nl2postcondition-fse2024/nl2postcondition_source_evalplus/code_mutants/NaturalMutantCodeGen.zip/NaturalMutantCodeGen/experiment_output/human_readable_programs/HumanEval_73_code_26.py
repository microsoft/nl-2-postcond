```python
def smallest_change(arr):
    """
    Given an array arr of integers, find the minimum number of elements that
    need to be changed to make the array palindromic. A palindromic array is an array that
    is read the same backwards and forwards. In one change, you can change one element to any other element.

    For example:
    smallest_change([1,2,3,5,4,7,9,6]) == 4
    smallest_change([1, 2, 3, 4, 3, 2, 2]) == 1
    smallest_change([1, 2, 3, 2, 1]) == 0
    """

    # Define a helper function to count the number of elements that need to be changed
    def count_changes(left_idx, right_idx):
        """
        Helper function to count the number of elements that need to be changed from left_idx to right_idx 
        to make the array palindromic.
        """
        num_changes = 0
        while left_idx < right_idx:
            if arr[left_idx] != arr[right_idx]:
                num_changes += 1
            left_idx += 1
            right_idx -= 1
        return num_changes

    # Initialize pointers to start and end of the array
    left_idx = 0
    right_idx = len(arr) - 1
    num_changes = 0

    # While there are still elements to compare
    while left_idx < right_idx:

        # If the elements are not equal, count the number of changes required and update left_idx or right_idx accordingly
        if arr[left_idx] != arr[right_idx]:
            num_changes += 1
            if arr[left_idx+1] == arr[right_idx]:
                left_idx += 1
            elif arr[left_idx] == arr[right_idx-1]:
                right_idx -= 1
            else:
                left_idx += 1
                right_idx -= 1

        # If the elements are equal, just update left_idx and right_idx
        else:
            left_idx += 1
            right_idx -= 1

    return num_changes
```


