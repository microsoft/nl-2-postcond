```python
def count_up_to(n):
    """Implement a function that takes an non-negative integer and returns an array of the first n
    integers that are prime numbers and less than n.
    for example:
    count_up_to(5) => [2,3]
    count_up_to(11) => [2,3,5,7]
    count_up_to(0) => []
    count_up_to(20) => [2,3,5,7,11,13,17,19]
    count_up_to(1) => []
    count_up_to(18) => [2,3,5,7,11,13,17]
    """
    
    # initially, all numbers are prime until proven otherwise
    is_prime = [True] * n
    
    # we start the search for primes at 2
    for i in range(2, n):
        # if i is prime, we mark all its multiples as not prime
        if is_prime[i]:
            for j in range(i*i, n, i):
                is_prime[j] = False
    
    # we create a list with all prime numbers less than n that were not marked as not prime
    primes = [i for i in range(2, n) if is_prime[i]] 
    
    # we return the first n elements of the primes list
    return primes[:n]
```


