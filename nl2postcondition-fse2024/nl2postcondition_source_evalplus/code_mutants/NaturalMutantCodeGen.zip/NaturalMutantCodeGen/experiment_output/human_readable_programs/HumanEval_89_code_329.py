```python

def encrypt(s):
    """Create a function encrypt that takes a string as an argument and
    returns a string encrypted with the alphabet being rotated. 
    The alphabet should be rotated in a manner such that the letters 
    shift down by two multiplied to two places.
    For example:
    encrypt('hi') returns 'lm'
    encrypt('asdfghjkl') returns 'ewhjklnop'
    encrypt('gf') returns 'kj'
    encrypt('et') returns 'ix'
    """

    encrypted = ""
    for i in s:
        if i.isalpha():
            if i.islower():
                rotated = ord(i) + 2**2
                if rotated > ord('z'):
                    rotated -= 26
            else:
                rotated = ord(i) + 2**2
                if rotated > ord('Z'):
                    rotated -= 26
            encrypted += chr(rotated)
        else:
            encrypted += i
    return encrypted

```


