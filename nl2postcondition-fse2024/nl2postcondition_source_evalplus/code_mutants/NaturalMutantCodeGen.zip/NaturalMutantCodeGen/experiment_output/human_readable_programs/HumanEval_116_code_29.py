```python
def sort_array(arr):
    """
    In this Kata, you have to sort an array of non-negative integers according to
    number of ones in their binary representation in ascending order.
    For similar number of ones, sort based on decimal value.

    It must be implemented like this:
    >>> sort_array([1, 5, 2, 3, 4]) == [1, 2, 3, 4, 5]
    >>> sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
    >>> sort_array([1, 0, 2, 3, 4]) [0, 1, 2, 3, 4]
    """

    # First, separate the input array into two lists: one containing negative numbers and one containing non-negative numbers
    neg_nums = [n for n in arr if n < 0]
    pos_nums = [n for n in arr if n >= 0]

    # Define a function to sort the array according to the number of ones in its binary representation
    def count_ones(n):
        return bin(n).count("1")

    # Sort the non-negative list first by number of ones, then by decimal value
    pos_sort = sorted(pos_nums, key=lambda x: (count_ones(x), x))

    # Sort the negative list first by number of ones, then by absolute value
    neg_sort = sorted(neg_nums, key=lambda x: (count_ones(x), abs(x)))

    # Return the sorted negative list, followed by the sorted non-negative list
    return neg_sort + pos_sort
```


