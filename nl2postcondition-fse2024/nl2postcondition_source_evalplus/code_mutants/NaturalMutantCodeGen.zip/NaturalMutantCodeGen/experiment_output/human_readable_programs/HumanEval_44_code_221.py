```python

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    # Initialize an empty string for the result
    result = ""
    # Loop until the input number is 0
    while x != 0:
        # Get the remainder of the input number divided by the base
        remainder = x % base
        # Add the remainder to the result string
        result = str(remainder) + result
        # Update the input number by integer division of the input number by the base
        x //= base
    # Return the result string
    return result
```


