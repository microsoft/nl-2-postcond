```python

def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """

    # create a mapping for vowels and their replacements
    vowel_map = {
        'a': 'c',
        'e': 'g',
        'i': 'k',
        'o': 'q',
        'u': 'w'
    }
    
    # iterate over each character in the message
    result = ''
    for char in message:
        # swap case of the letter
        if char.isalpha():
            if char.isupper():
                char = char.lower()
            else:
                char = char.upper()
            # replace vowel with mapped value
            if char in vowel_map:
                char = vowel_map[char]
        result += char
    return result
```


