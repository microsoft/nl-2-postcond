```python

def sort_even(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the odd indices, while its values at the even indices are equal
    to the values of the even indices of l, but sorted.
    >>> sort_even([1, 2, 3])
    [1, 2, 3]
    >>> sort_even([5, 6, 3, 4])
    [3, 6, 5, 4]
    """
    # get even indexed values, sort them and make them available as a list.
    even_l = sorted(l[::2])
    # Create an empty list to add the modified version of the input list to.
    sorted_l = []
    # loop through the input list and append each even indexed value from the sorted list of even indexed values
    # while appending each odd indexed value from the input list directly.
    for i, v in enumerate(l):
        if i % 2 == 0:
            sorted_l.append(even_l[i//2])
        else:
            sorted_l.append(v)
    return sorted_l
```


