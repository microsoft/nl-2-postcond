```python
def histogram(test):
    """Given a string representing a space separated lowercase letters, return a dictionary
    of the letter with the most repetition and containing the corresponding count.
    If several letters have the same occurrence, return all of them.
    
    Example:
    histogram('a b c') == {'a': 1, 'b': 1, 'c': 1}
    histogram('a b b a') == {'a': 2, 'b': 2}
    histogram('a b c a b') == {'a': 2, 'b': 2}
    histogram('b b b b a') == {'b': 4}
    histogram('') == {}
    """

    # Create an empty dictionary to hold the letter counts
    letter_count = {}
    # Split the string into a list of letters
    letters = test.split()

    # Iterate over the letters in the list
    for letter in letters:
        # If the letter is already in the dictionary, increment its count
        if letter in letter_count:
            letter_count[letter] += 1
        # Otherwise, add the letter to the dictionary with a count of 1
        else:
            letter_count[letter] = 1

    # Initialize a variable to hold the maximum count found so far
    max_count = 0
    # Initialize an empty list to hold the letters with the maximum count
    max_letters = []

    # Iterate over the items in the dictionary
    for letter, count in letter_count.items():
        # If the count of the current letter is greater than the current max count,
        # update max_count and clear max_letters to only contain the current letter
        if count > max_count:
            max_count = count
            max_letters = [letter]
        # If the count of the current letter is equal to the current max count,
        # append the current letter to max_letters
        elif count == max_count:
            max_letters.append(letter)

    # Create a new dictionary containing only the letters with the maximum count
    result = {letter: count for letter, count in letter_count.items() if letter in max_letters}

    # Return the result
    return result
```


