```python

def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''

    # Converting string to float
    value = float(value)

    # Checking if the number is negative or positive and separating the decimal component
    if value < 0:
        abs_value = -1 * value
        integer_component = -1 * int(-1 * abs_value)
        decimal_component = abs_value - integer_component
    else:
        integer_component = int(value)
        decimal_component = value - integer_component

    # Checking if the number is already an integer
    if decimal_component == 0:
        return int(value)

    # If decimal component is less than 0.5, return the integer component only
    if decimal_component < 0.5:
        return integer_component

    # If decimal component is greater than 0.5, return the next integer
    if decimal_component > 0.5:
        return integer_component + 1

    # If decimal component is equal to 0.5, return the farthest integer
    if decimal_component == 0.5:
        if integer_component >= 0:
            return integer_component + 1
        else:
            return integer_component - 1
```


