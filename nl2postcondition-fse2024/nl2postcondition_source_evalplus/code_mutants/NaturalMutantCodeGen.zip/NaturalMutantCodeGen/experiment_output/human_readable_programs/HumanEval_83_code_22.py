```python
def starts_one_ends(n):
    """
    Given a positive integer n, return the count of the numbers of n-digit
    positive integers that start or end with 1.
    """

    # We will count the number of n-digit positive integers that start or end with 1.
    # The count can be found using a simple formula: 2 * 9^(n-1)
    # The reason is that there are 9 digits (0 to 9) and for the first digit we can only
    # use 1 or any of the remaining 9 digits. For the last digit, we can only use 1 or
    # any of the remaining 9 digits.
    return 2 * 9**(n-1)
```


