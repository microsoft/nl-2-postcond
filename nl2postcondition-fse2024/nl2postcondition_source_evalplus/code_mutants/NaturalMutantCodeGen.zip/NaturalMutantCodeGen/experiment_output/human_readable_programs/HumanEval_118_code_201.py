```python
def get_closest_vowel(word):
    """
    You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    word = word[::-1]  # reverse the word to check from right 
    for i in range(1, len(word)-1):
        if word[i] in "aeiouAEIOU":  # if it is a vowel
            for j in range(i+1, len(word)):  # check the letters on the right
                if word[j] not in "aeiouAEIOU":  # if it is a consonant 
                    return word[i].upper() if word[i].islower() else word[i]  # return the vowel, with the original case 
            break  # if no such group is found, exit the loop
    return ""  # if no vowel-consonant group is found


```


