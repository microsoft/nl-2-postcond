```python

def correct_bracketing(brackets: str):
    """ brackets is a string of "(" and ")".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("(")
    False
    >>> correct_bracketing("()")
    True
    >>> correct_bracketing("(()())")
    True
    >>> correct_bracketing(")(()")
    False
    """

    # check if there is an odd number of brackets
    if len(brackets) % 2 == 1:
        return False

    # create an empty stack to keep track of opening brackets
    stack = []

    # loop through the brackets
    for bracket in brackets:
        if bracket == '(':
            stack.append(bracket)
        elif len(stack) == 0:
            return False
        elif bracket == ')':
            stack.pop()

    # check if the stack is empty
    return len(stack) == 0

```


