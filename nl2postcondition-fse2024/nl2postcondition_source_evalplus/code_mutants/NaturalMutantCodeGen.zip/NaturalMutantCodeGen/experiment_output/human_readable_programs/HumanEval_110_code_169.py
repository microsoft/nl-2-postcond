```python
def exchange(lst1, lst2):
    """
    This function takes in two lists of numbers and exchanges elements between the two lists to make lst1 a list of only even numbers.
    If it is possible to exchange elements between the lst1 and lst2 to make all the elements of lst1 to be even, it returns "YES".
    Oterwise, it returns "NO".

    Args:
    lst1: A list of integers.
    lst2: A list of integers.

    Returns:
    A string "YES" if it is possible to exchange elements between the lst1 and lst2 to make all the elements of lst1 to be even, otherwise "NO".

    Example:
    exchange([1, 2, 3, 4], [1, 2, 3, 4]) => "YES"
    exchange([1, 2, 3, 4], [1, 5, 3, 4]) => "NO"
    """
    sum1 = sum([1 for i in lst1 if i%2!=0]) # count of odd numbers in lst1
    sum2 = sum([1 for i in lst2 if i%2!=0]) # count of odd numbers in lst2

    # if we have more odd numbers in lst1 than the difference between the lengths of lst1 and lst2
    # there is no possibility to make all elements of lst1 to be even
    if sum1 > len(lst1) - len(lst2) + sum2:
        return "NO"

    # this means we can remove all odd numbers from lst1 and still have some elements left
    # to be used to replace some elements in lst1 that are odd
    else:
        return "YES"
```


