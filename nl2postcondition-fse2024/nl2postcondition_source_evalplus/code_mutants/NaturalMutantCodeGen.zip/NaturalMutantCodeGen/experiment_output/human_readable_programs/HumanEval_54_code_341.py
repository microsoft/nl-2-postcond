```python


def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """

    # Converting the two input strings to set to get unique characters from the two strings
    s0_set = set(s0)
    s1_set = set(s1)

    # If the two sets of characters are equal, then the two strings have the same characters
    if s0_set == s1_set:
        return True
    else:
        return False
```


