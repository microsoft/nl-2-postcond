```python

def right_angle_triangle(a, b, c):
    '''
    Given the lengths of the three sides of a triangle. Return True if the three
    sides form a right-angled triangle, False otherwise.
    A right-angled triangle is a triangle in which one angle is right angle or 
    90 degree.
    Example:
    right_angle_triangle(3, 4, 5) == True
    right_angle_triangle(1, 2, 3) == False
    '''

    # Square the sides
    a2 = a**2
    b2 = b**2
    c2 = c**2

    # Check if the square of one side is equal to the sum of the square of the other two sides
    if a2 == b2 + c2 or b2 == a2 + c2 or c2 == a2 + b2:
        return True
    else:
        return False
```


