```python
def solution(lst):
    """Given a non-empty list of integers, return the sum of all of the odd elements that are in even positions.
    

    Examples
    solution([5, 8, 7, 1]) ==> 12
    solution([3, 3, 3, 3, 3]) ==> 9
    solution([30, 13, 24, 321]) ==>0
    """

    # Initialize a variable to hold the sum of odd numbers in even positions
    total = 0

    # Iterate over the list using range starting from index 0 and stepping by 2
    for i in range(0, len(lst), 2):
        # Check if the element is odd
        if lst[i] % 2 == 1:
            # If the element is odd, add it to the total
            total += lst[i]

    # Return the total
    return total
```


