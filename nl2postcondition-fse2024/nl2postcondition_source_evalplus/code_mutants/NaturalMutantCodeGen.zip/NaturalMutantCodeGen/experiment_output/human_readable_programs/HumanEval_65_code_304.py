```python
def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    # Convert the integer into a string
    x = str(x)
    
    # Check if the absolute value of the shift is greater than the length of x
    if abs(shift) > len(x):
        # Return the reversed string
        return x[::-1]
    else:
        # Split the string into two parts, shift the two parts and join them
        left_part = x[:-shift]
        right_part = x[-shift:]
        return right_part + left_part
```


