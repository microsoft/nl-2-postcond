```python

def count_upper(s):
    """
    Given a string s, count the number of uppercase vowels in even indices.
    
    For example:
    count_upper('aBCdEf') returns 1
    count_upper('abcdefg') returns 0
    count_upper('dBBE') returns 0
    """

    # Initialize a variable to store the count
    count = 0
    
    # Iterate over even indices of the string
    for i in range(0, len(s), 2):
        # Check if the character at the current index is an uppercase vowel
        if s[i].upper() in ['A', 'E', 'I', 'O', 'U']:
            count += 1 # Increment the count if it is an uppercase vowel
            
    # Return the final count
    return count
```


