```python


def sort_third(l: list):
    """This function takes a list l and returns a list l' such that
    l' is identical to l in the indicies that are not divisible by three, while its values at the indicies that are divisible by three are equal
    to the values of the corresponding indicies of l, but sorted.
    >>> sort_third([1, 2, 3])
    [1, 2, 3]
    >>> sort_third([5, 6, 3, 4, 8, 9, 2])
    [2, 6, 3, 4, 8, 9, 5]
    """

    # Get the values at the index divisible by 3
    divisible_by_three = []
    for i in range(0, len(l), 3):
        divisible_by_three.append(l[i])
    # sort the values
    divisible_by_three.sort()
    # create the new list based on the rules
    new_list = []
    for i in range(len(l)):
        if i % 3 == 0:
            new_list.append(divisible_by_three.pop(0))
        else:
            new_list.append(l[i])
    return new_list
```


