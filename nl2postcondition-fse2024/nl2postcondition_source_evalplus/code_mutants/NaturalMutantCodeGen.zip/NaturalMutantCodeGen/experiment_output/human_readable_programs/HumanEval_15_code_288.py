```python


def string_sequence(n: int) -> str:
    """ Return a string containing space-delimited numbers starting from 0 upto n inclusive.
    >>> string_sequence(0)
    '0'
    >>> string_sequence(5)
    '0 1 2 3 4 5'
    """

    sequence = ""
    for i in range(n+1):
        sequence += str(i) + " "
    return sequence.rstrip()

``` 

Note: The rstrip() method is used to remove the extra space at the end of the sequence.


