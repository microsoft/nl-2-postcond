```python
def reverse_delete(s,c):
    """Task
    We are given two strings s and c, you have to deleted all the characters in s that are equal to any character in c
    then check if the result string is palindrome.
    A string is called palindrome if it reads the same backward as forward.
    You should return a tuple containing the result string and True/False for the check.
    Example
    For s = "abcde", c = "ae", the result should be ('bcd',False)
    For s = "abcdef", c = "b"  the result should be ('acdef',False)
    For s = "abcdedcba", c = "ab", the result should be ('cdedc',True)
    """
    
    # Replace each character in c with an empty string. This will remove all chars in s that are in c
    res = ''.join([i for i in s if i not in c])
    
    # Check if resulting string is the same forwards and backwards
    is_palindrome = res == res[::-1]
    
    return (res, is_palindrome)
```


