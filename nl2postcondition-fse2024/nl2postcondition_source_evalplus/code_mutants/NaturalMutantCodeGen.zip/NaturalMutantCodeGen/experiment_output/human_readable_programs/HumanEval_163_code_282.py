```python

def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    # Create a list to store the even digits
    even_digits = []

    # Determine the minimum and maximum of a and b
    minimum = min(a, b)
    maximum = max(a, b)

    # Loop through the range of numbers between minimum and maximum
    for num in range(minimum, maximum+1):
        # Check if the number contains even digits
        if any(int(digit) % 2 == 0 for digit in str(num)):
            # Loop through the digits of the number
            for digit in str(num):
                # Check if the digit is even and not already in the list
                if int(digit) % 2 == 0 and int(digit) not in even_digits:
                    # Add the digit to the list
                    even_digits.append(int(digit))

    # Return the sorted list of even digits
    return sorted(even_digits)
```


