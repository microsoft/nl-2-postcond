```python
def closest_integer(value):
    # Convert the string value to a float
    fval = float(value)

    # Get the floor and the ceiling of the float
    floor_val = int(fval // 1)
    ceil_val = int(fval // 1 + 1)

    # Calculate the distances
    dist_to_floor = abs(fval - floor_val)
    dist_to_ceil = abs(fval - ceil_val)

    # Return the closest integer and round away from zero if necessary
    if dist_to_floor < dist_to_ceil:
        return floor_val
    elif dist_to_floor > dist_to_ceil:
        return ceil_val
    else:
        if fval < 0:
            return ceil_val
        else:
            return floor_val
```


