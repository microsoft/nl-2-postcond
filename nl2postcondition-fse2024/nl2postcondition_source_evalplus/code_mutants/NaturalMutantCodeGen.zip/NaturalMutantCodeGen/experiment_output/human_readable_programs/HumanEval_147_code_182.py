```python
def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 ≤ i ≤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k, 
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation: 
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """

    # Initialize the count of valid triples to zero
    count = 0

    # Create the list a
    a = [i * i - i + 1 for i in range(1, n+1)]

    # Create a dictionary d that stores the frequency of remainders when divided by 3
    d = {0:0, 1:0, 2:0}
    for i in range(n):
        r = a[i] % 3
        d[r] += 1

    # Calculate the valid triples: (0,0,0), (1,1,1), (2,2,2), (0,1,2), (0,2,1), (1,0,2), (1,2,0), (2,0,1), (2,1,0)
    count += (d[0] * (d[0] - 1) * (d[0] - 2)) // 6
    count += (d[1] * (d[1] - 1) * (d[1] - 2)) // 6
    count += (d[2] * (d[2] - 1) * (d[2] - 2)) // 6
    count += d[0] * d[1] * d[2]
    count += (d[0] * (d[0] - 1)) // 2 * d[2]
    count += (d[1] * (d[1] - 1)) // 2 * d[0]
    count += (d[2] * (d[2] - 1)) // 2 * d[1]

    return count
```


