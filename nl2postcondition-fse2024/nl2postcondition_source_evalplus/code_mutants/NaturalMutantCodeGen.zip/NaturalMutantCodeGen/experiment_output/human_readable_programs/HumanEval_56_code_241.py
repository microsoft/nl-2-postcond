```python


def correct_bracketing(brackets: str):
    """ brackets is a string of "<" and ">".
    return True if every opening bracket has a corresponding closing bracket.

    >>> correct_bracketing("<")
    False
    >>> correct_bracketing("<>")
    True
    >>> correct_bracketing("<<><>>")
    True
    >>> correct_bracketing("><<>")
    False
    """

    # Create an empty stack to keep track of opening brackets
    stack = []

    # Iterate over each bracket in the string
    for bracket in brackets:
        # If opening bracket, push it onto the stack
        if bracket == "<":
            stack.append(bracket)
        # If closing bracket, pop the top opening bracket from the stack if possible
        elif bracket == ">":
            if len(stack) == 0:
                return False
            else:
                stack.pop()
    # If there are no remaining opening brackets on the stack, return True
    return len(stack) == 0
```


