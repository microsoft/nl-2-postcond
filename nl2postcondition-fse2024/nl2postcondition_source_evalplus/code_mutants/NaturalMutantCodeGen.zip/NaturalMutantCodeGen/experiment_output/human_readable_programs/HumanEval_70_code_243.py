```python
def strange_sort_list(lst):
    '''
    Given list of integers, return list in strange order.
    Strange sorting, is when you start with the minimum value,
    then maximum of the remaining integers, then minimum and so on.

    Examples:
    strange_sort_list([1, 2, 3, 4]) == [1, 4, 2, 3]
    strange_sort_list([5, 5, 5, 5]) == [5, 5, 5, 5]
    strange_sort_list([]) == []
    '''

    # Sort the list in ascending order
    lst_sorted = sorted(lst)

    # Initialize the output list
    output_lst = []

    # Run the loop until all elements have been appended to the output_lst
    while len(output_lst) < len(lst_sorted):
        # Append the minimum value from lst_sorted to output_lst
        output_lst.append(lst_sorted[0])
        # Remove the minimum value from lst_sorted
        lst_sorted.pop(0)
        # Check if lst_sorted is empty
        if not lst_sorted:
            break
        # Append the maximum value from lst_sorted to output_lst
        output_lst.append(lst_sorted[-1])
        # Remove the maximum value from lst_sorted
        lst_sorted.pop(-1)

    return output_lst
```


