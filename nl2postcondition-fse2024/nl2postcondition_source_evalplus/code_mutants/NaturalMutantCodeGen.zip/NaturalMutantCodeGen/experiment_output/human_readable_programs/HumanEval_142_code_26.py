```python
def sum_squares(lst):
    """"
    This function will take a list of integers. For all entries in the list, the function shall square the integer entry if its index is a 
    multiple of 3 and will cube the integer entry if its index is a multiple of 4 and not a multiple of 3. The function will not 
    change the entries in the list whose indexes are not a multiple of 3 or 4. The function shall then return the sum of all entries. 
    
    Examples:
    For lst = [1,2,3] the output should be 6
    For lst = []  the output should be 0
    For lst = [-1,-5,2,-1,-5]  the output should be -126
    """

    # Initialize sum of all entries to 0
    total = 0
    
    # Iterate over indices and entries of the list
    for i, num in enumerate(lst):
        
        # If index is multiple of 3, square the entry
        if i % 3 == 0:
            total += num**2
        
        # If index is multiple of 4 and not multiple of 3, cube the entry
        elif i % 4 == 0:
            total += num**3
        
        # For all other indices, add the entry as is
        else:
            total += num
    
    return total
```


