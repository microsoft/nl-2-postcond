```python
import math


def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """

    # starting value for the search
    x_i = 0.0

    # ending value for the search
    x_f = 10.0

    # tolerance for zero
    eps = 1e-6

    # maximum number of iterations
    max_iter = 100

    # we check if the polynomial is even-order
    assert len(xs) % 2 == 0

    # we find the degree of the polynomial
    degree = len(xs) - 1

    # we find the largest non-zero coefficient
    largest_coeff = max([abs(c) for c in xs[1:]])

    # we set our initial guess to the middle of our search interval
    x_n = (x_i + x_f) / 2.0

    # we iterate until we reach the maximum number of iterations
    for i in range(max_iter):

        # we evaluate the polynomial at our current guess
        f_n = poly(xs, x_n)

        # if f_n is very small (less than the tolerance), we consider it to be zero
        if abs(f_n) < eps:
            return x_n

        # we choose which half of the interval to search next
        if f_n < 0:
            x_i = x_n
        else:
            x_f = x_n

        # we update our guess
        x_n = (x_i + x_f) / 2.0

    # if we reach the maximum number of iterations without finding a zero, we return None
    return None
```


