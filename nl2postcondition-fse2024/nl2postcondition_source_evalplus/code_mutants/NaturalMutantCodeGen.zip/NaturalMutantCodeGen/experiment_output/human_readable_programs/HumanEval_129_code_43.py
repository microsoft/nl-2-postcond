```python

def minPath(grid, k):
    """
    Given a grid with N rows and N columns (N >= 2) and a positive integer k, 
    each cell of the grid contains a value. Every integer in the range [1, N * N]
    inclusive appears exactly once on the cells of the grid.

    You have to find the minimum path of length k in the grid. You can start
    from any cell, and in each step you can move to any of the neighbor cells,
    in other words, you can go to cells which share an edge with you current
    cell.
    Please note that a path of length k means visiting exactly k cells (not
    necessarily distinct).
    You CANNOT go off the grid.
    A path A (of length k) is considered less than a path B (of length k) if
    after making the ordered lists of the values on the cells that A and B go
    through (let's call them lst_A and lst_B), lst_A is lexicographically less
    than lst_B, in other words, there exist an integer index i (1 <= i <= k)
    such that lst_A[i] < lst_B[i] and for any j (1 <= j < i) we have
    lst_A[j] = lst_B[j].
    It is guaranteed that the answer is unique.
    Return an ordered list of the values on the cells that the minimum path go through.

    Examples:

        Input: grid = [ [1,2,3], [4,5,6], [7,8,9]], k = 3
        Output: [1, 2, 1]

        Input: grid = [ [5,9,3], [4,1,6], [7,8,2]], k = 1
        Output: [1]
    """

    # find the location of each number in the grid
    locs = {}
    for i in range(len(grid)):
        for j in range(len(grid)):
            locs[grid[i][j]] = (i,j)

    # a function to check if a cell is valid or not (not going of the grid)
    def is_valid_cell(i,j):
        return i >= 0 and j >= 0 and i < len(grid) and j < len(grid)

    # a recursive function to find the minimum path
    def find_min_path(curr_loc, path, visited):
        # if we have reached to the end of our path
        if len(path) == k:
            return path
        
        # add the current location to the visited set
        visited.add(curr_loc)
        
        # generate all possible neighbor cells
        neighbors = [(curr_loc[0]+1, curr_loc[1]), (curr_loc[0]-1, curr_loc[1]),\
                     (curr_loc[0], curr_loc[1]+1), (curr_loc[0], curr_loc[1]-1)]
        
        # initialize the minimum path so far with None
        min_path_so_far = None
        
        # loop over all neighbor cells and try to find a better path recursively
        for neighbor in neighbors:
            # check if the neighbor cell is valid and not visited before
            if is_valid_cell(neighbor[0],neighbor[1]) and neighbor not in visited:
                # copy the current path and add the newly visited cell
                updated_path = list(path)
                updated_path.append(grid[neighbor[0]][neighbor[1]])
                
                # recursively call the function on the new cell
                new_path = find_min_path(neighbor, updated_path, visited)
                
                # if a path is found, check if it has less lexicographic value than the current minimum
                if new_path is not None:
                    if min_path_so_far is None or new_path < min_path_so_far:
                        min_path_so_far = new_path
                        
        # remove the current location form the visited set and return the minimum path found so far
        visited.remove(curr_loc)
        return min_path_so_far
                
    # start the find_min_path function on every location in the grid
    min_path = None
    for n in range(len(grid)*len(grid)):
        loc = locs[n+1]
        path = [grid[loc[0]][loc[1]]]
        found_path = find_min_path(loc, path, set())
        # if a path is found, check if it has less lexicographic value than the current minimum
        if found_path is not None:
            if min_path is None or found_path < min_path:
                min_path = found_path
    
    # return the minimum path found
    return min_path

```


