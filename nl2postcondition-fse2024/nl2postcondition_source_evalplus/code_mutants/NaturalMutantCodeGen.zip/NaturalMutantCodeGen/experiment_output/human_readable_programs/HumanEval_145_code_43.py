```python
def order_by_points(nums):
    """
    Write a function which sorts the given list of integers
    in ascending order according to the sum of their digits.
    Note: if there are several items with similar sum of their digits,
    order them based on their index in original list.

    For example:
    >>> order_by_points([1, 11, -1, -11, -12]) == [-1, -11, 1, -12, 11]
    >>> order_by_points([]) == []
    """
    nums.sort(key=lambda x: (sum(map(int, str(abs(x)))), nums.index(x)))
    return nums
``` 

In this implementation, `nums.sort()` sorts the list in-place using a `key` function. The `key` function is a lambda function that returns a tuple with two elements:

- The first element is the sum of the digits for each number.
- The second element is the index of the number in the original list. This ensures that if there are several items with a similar sum of their digits, they are ordered based on their index in the original list.

`map()` applies the `int()` function to each character in the string of the absolute value of the number, and `sum()` calculates the sum of all the digits. `abs()` is used to ensure that negative numbers are treated the same as positive numbers.


