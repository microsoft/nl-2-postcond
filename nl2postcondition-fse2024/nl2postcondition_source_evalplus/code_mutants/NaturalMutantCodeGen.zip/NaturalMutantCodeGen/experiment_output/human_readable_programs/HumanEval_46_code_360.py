```python
def fib4(n: int):
    """The Fib4 number sequence is a sequence similar to the Fibbonacci sequnece that's defined as follows:
    fib4(0) -> 0
    fib4(1) -> 0
    fib4(2) -> 2
    fib4(3) -> 0
    fib4(n) -> fib4(n-1) + fib4(n-2) + fib4(n-3) + fib4(n-4).
    Please write a function to efficiently compute the n-th element of the fib4 number sequence.  Do not use recursion.
    >>> fib4(5)
    4
    >>> fib4(6)
    8
    >>> fib4(7)
    14
    """

    # initialize a list to store the first 4 elements of the sequence
    fib_list = [0, 0, 2, 0]

    # loop through the sequence and compute each element
    for i in range(4, n+1):
        # compute the next element in the sequence using the previous 4 elements
        next_fib = fib_list[i-1] + fib_list[i-2] + fib_list[i-3] + fib_list[i-4]

        # add the next element to the list
        fib_list.append(next_fib)

    # return the nth element of the sequence
    return fib_list[n]
```


