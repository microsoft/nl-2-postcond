```python


def get_positive(l: list):
    """Return only positive numbers in the list.
    >>> get_positive([-1, 2, -4, 5, 6])
    [2, 5, 6]
    >>> get_positive([5, 3, -5, 2, -3, 3, 9, 0, 123, 1, -10])
    [5, 3, 2, 3, 9, 123, 1]
    """
    # Create an empty list to store positive integers
    positive_list = []
    # Iterate over elements in the list
    for i in l:
        # Check if it is a positive number
        if i > 0:
            # Append positive number to positive_list
            positive_list.append(i)
    # Return list of positive numbers
    return positive_list
```


