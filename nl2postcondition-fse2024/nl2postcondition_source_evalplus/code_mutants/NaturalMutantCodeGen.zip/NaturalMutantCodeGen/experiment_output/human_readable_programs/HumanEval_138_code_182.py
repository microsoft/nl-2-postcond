```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    # We can test whether the number can be divided into 4 positive even numbers
    # If n is even, then the largest sum of 4 positive even numbers that can be formed cannot be greater than n. 
    # The largest sum of 4 positive even numbers that can be formed is 8 + 8 + 8 + 8 = 32
    # If n is odd, then the largest sum of 4 positive even numbers that can be formed is less than n. 

    if n % 2 == 0 and n <= 32 and n != 12 and n != 16 and n != 20 and n != 24 and n != 28: 
        return True

    return False
```


