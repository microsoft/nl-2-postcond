```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    if n < 8:
        return False
    elif n == 8:
        return True
    else:
        even_numbers = [2] * 4
        remaining_sum = n - sum(even_numbers)
        if remaining_sum % 2 == 0:
            return True
        else:
            return False
```

We first check if the given number is less than 8, then we know that it can’t be written as the sum of exactly 4 positive even numbers. If n is equal to 8, True is returned because 8 can be written as the sum of exactly 4 positive even numbers (2+2+2+2=8). For all other cases, we construct a list of four even numbers [2,2,2,2] and calculate the remaining sum by subtracting their sum from n. If the remaining sum is an even number, True is returned, otherwise, False is returned.


