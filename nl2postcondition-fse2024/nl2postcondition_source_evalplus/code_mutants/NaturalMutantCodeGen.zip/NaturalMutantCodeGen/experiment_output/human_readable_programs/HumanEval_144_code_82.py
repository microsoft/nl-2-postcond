```python
def simplify(x, n):
    """
    :param x: A string representation of a fraction in the format <numerator>/<denominator>
    :param n: A string representation of a fraction in the format <numerator>/<denominator>
    :return: True if x * n evaluates to a whole number and False otherwise
    """

    # Extract the numerators and denominators of x and n
    x_num, x_denom = map(int, x.split('/'))
    n_num, n_denom = map(int, n.split('/'))

    # Multiply the numerators and denominators and simplify the fraction
    result_num = x_num * n_num
    result_denom = x_denom * n_denom
    gcd = math.gcd(result_num, result_denom)
    result_num //= gcd
    result_denom //= gcd

    # Check if the result is a whole number
    return result_denom % result_num == 0 if result_num <= result_denom else result_num % result_denom == 0
```

Note: We use the function `math.gcd` to compute the greatest common divisor of the numerator and denominator of the product of the fractions x and n. We then divide both the numerator and denominator of the product by the greatest common divisor to simplify the fraction. Finally, we check if the numerator is evenly divisible by the denominator (if the numerator is less than or equal to the denominator), or if the denominator is evenly divisible by the numerator (if the numerator is greater than the denominator).


