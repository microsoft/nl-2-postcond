```python

def digitSum(s):
    """Task
    Write a function that takes a string as input and returns the sum of the upper characters only'
    ASCII codes.

    Examples:
        digitSum("") => 0
        digitSum("abAB") => 131
        digitSum("abcCd") => 67
        digitSum("helloE") => 69
        digitSum("woArBld") => 131
        digitSum("aAaaaXa") => 153
    """

    # Initialize a variable to store the sum of upper character ASCII codes
    upper_sum = 0

    # Iterate through each character in the string
    for c in s:
        # Check if the character is an uppercase letter
        if c.isupper():
            # Add the ASCII code of the character to the sum
            upper_sum += ord(c)

    # Return the sum of upper character ASCII codes
    return upper_sum

```


