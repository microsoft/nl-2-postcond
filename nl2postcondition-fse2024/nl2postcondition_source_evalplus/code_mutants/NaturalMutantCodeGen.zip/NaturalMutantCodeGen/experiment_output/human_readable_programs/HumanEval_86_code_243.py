```python
def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """
    if len(s) <= 1:
        return s
    
    # split the input string into individual words
    words = s.split()

    # create an empty list to store the new words
    new_words = []

    # loop through each word in the input string
    for word in words:
        # sort the characters in the word based on ascii value
        sorted_word = "".join(sorted(word, key=lambda x: ord(x)))
        # append the sorted word to the new list of words
        new_words.append(sorted_word)

    # join the new list of words back into a string, preserving the original spaces
    result = " ".join(new_words)

    return result
```


