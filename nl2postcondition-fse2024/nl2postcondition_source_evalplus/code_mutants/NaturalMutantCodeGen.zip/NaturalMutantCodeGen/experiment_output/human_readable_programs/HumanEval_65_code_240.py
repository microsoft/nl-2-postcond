```python

def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """

    x = str(x)
    n = len(x)
    
    if shift == n or n == 1: # no need to shift
        return x
    
    if shift > n: # return digits reversed
        return x[::-1]
    
    # The idea is to concatenate the last shift digits at the beginning.
    # For example, if x = 123456 and shift = 3, we want to get 456123.
    # First, we extract the last shift digits using slicing.
    # Then, we concatenate the slice at the beginning of the string.
    
    return x[-shift:] + x[:n-shift]
```


