```python

def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """

    # Split the sentence into words separated by space
    words_list = s.split()

    # For each word, sort the characters in ascending order based on ascii value
    for i in range(len(words_list)):
        words_list[i] = "".join(sorted(words_list[i]))

    # Join the words to make the new sentence
    new_sentence = " ".join(words_list)

    return new_sentence
```


