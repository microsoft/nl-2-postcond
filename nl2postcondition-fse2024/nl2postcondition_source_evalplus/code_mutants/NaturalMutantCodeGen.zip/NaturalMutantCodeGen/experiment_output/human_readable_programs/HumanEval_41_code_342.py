```python
def car_race_collision(n: int):
    """
    Imagine a road that's a perfectly straight infinitely long line.
    n cars are driving left to right;  simultaneously, a different set of n cars
    are driving right to left.   The two sets of cars start out being very far from
    each other.  All cars move in the same speed.  Two cars are said to collide
    when a car that's moving left to right hits a car that's moving right to left.
    However, the cars are infinitely sturdy and strong; as a result, they continue moving
    in their trajectory as if they did not collide.

    This function outputs the number of such collisions.
    """

    # we can have a list for cars approaching left to right and another for cars approaching right to left
    # as each car is infinitely sturdy and strong, we don't need to do any collision detection incrementally
    # we can calculate total pairs that would collide for each car approaching left to right
    # collision can happen only if there are cars approaching right to left at that moment
    # so, if we have 'r' cars approaching right to left, then for a car approaching left to right, there can be 'r' collisions
    # we can sum the total collisions for all cars approaching left to right and return the total

    # total pairs that can collide for each car approaching left to right
    total_collisions = n
    
    # total collisions for all cars approaching left to right
    total = n * total_collisions
    
    return total
```


