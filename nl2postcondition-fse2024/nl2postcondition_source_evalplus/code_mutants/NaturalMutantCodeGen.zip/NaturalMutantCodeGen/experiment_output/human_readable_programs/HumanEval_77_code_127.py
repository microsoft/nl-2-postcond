```python
def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    # Return True for special cases
    if a in (0, 1, -1):
        return True

    # Check if a is a perfect cube
    x = abs(a)
    root = int(x ** (1/3))
    if root ** 3 == x:
        return True
    else:
        return False
```


