```python

def even_odd_count(num):
    """Given an integer. return a tuple that has the number of even and odd digits respectively.

     Example:
        even_odd_count(-12) ==> (1, 1)
        even_odd_count(123) ==> (1, 2)
    """

    # Remove the sign of the number
    num = abs(num)
    # Convert the number to a string to iterate through each digit. Then convert each digit back to an integer.
    digits = [int(digit) for digit in str(num)]
    # Count the number of even and odd digits using a list comprehension.
    even_count = len([digit for digit in digits if digit % 2 == 0])
    odd_count = len([digit for digit in digits if digit % 2 != 0])
    # Return a tuple of the even and odd counts.
    return (even_count, odd_count)
```


