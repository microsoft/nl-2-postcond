```python
from typing import List


def string_xor(a: str, b: str) -> str:
    """ Input are two strings a and b consisting only of 1s and 0s.
    Perform binary XOR on these inputs and return result also as a string.
    >>> string_xor('010', '110')
    '100'
    """

    # Convert the strings to integers with base 2
    int_a = int(a, 2)
    int_b = int(b, 2)
    
    # Use the XOR operator to get the result as integer
    result_int = int_a ^ int_b
    
    # Convert the result to binary string representation and return it
    return bin(result_int)[2:]
```


