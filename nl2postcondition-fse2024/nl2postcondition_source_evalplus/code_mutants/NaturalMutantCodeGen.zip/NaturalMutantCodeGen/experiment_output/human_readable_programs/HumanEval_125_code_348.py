```python
def split_words(txt):
    '''
    Given a string of words, return a list of words split on whitespace, if no whitespaces exists in the text you
    should split on commas ',' if no commas exists you should return the number of lower-case letters with odd order in the
    alphabet, ord('a') = 0, ord('b') = 1, ... ord('z') = 25
    Examples
    split_words("Hello world!") ➞ ["Hello", "world!"]
    split_words("Hello,world!") ➞ ["Hello", "world!"]
    split_words("abcdef") == 3 
    '''

    # check if the text has any whitespaces
    if ' ' in txt:
        # split the text using whitespaces
        return txt.split()
    # check if the text has any commas
    elif ',' in txt:
        # split the text using commas
        return txt.split(',')
    else:
        # count the number of odd lowercase letters
        return sum(ord(c) - 97 in [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25] for c in txt if c.islower())
```


