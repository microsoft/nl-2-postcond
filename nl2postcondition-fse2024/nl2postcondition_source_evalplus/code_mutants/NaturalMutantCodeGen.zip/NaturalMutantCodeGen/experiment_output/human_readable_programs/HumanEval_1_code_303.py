```python
from typing import List


def separate_paren_groups(paren_string: str) -> List[str]:
    """ Input to this function is a string containing multiple groups of nested parentheses. Your goal is to
    separate those group into separate strings and return the list of those.
    Separate groups are balanced (each open brace is properly closed) and not nested within each other
    Ignore any spaces in the input string.
    >>> separate_paren_groups('( ) (( )) (( )( ))')
    ['()', '(())', '(()())']
    """

    # initialize the variables
    count_left, count_right = 0, 0
    start, result = 0, []

    # Find separate groups
    for i in range(len(paren_string)):
        if paren_string[i] == '(':
            count_left += 1
        elif paren_string[i] == ')':
            count_right += 1
        
        # If the parenthesis count is equal
        if count_left == count_right:
            # slice paren_string to get the separate group
            result.append(paren_string[start:i+1].replace(' ', ''))
            # update the start index
            start = i+1
    return result
```


