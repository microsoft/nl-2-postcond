```python

def make_a_pile(n):
    """
    Given a positive integer n, you have to make a pile of n levels of stones.
    The first level has n stones.
    The number of stones in the next level is:
        - the next odd number if n is odd.
        - the next even number if n is even.
    Return the number of stones in each level in a list, where element at index
    i represents the number of stones in the level (i+1).

    Examples:
    >>> make_a_pile(3)
    [3, 5, 7]
    """

    # Create an empty list to hold the number of stones in each level.
    pile = []

    # The number of stones in the first level is n.
    level_stones = n

    # Loop through the number of levels and calculate the number of stones in each level.
    for i in range(n):
        # Append the number of stones in the current level to the pile list.
        pile.append(level_stones)
        
        # Calculate the number of stones in the next level based on whether n is odd or even.
        if n % 2 == 1:
            level_stones += 2
        else:
            level_stones += 1

    # Return the pile list.
    return pile
```


