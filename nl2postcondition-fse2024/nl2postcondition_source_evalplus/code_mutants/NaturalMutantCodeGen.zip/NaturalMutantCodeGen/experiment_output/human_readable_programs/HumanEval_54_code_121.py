```python
def same_chars(s0: str, s1: str):
    """
    Check if two words have the same characters.
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddeddabc')
    True
    >>> same_chars('abcd', 'dddddddabc')
    True
    >>> same_chars('dddddddabc', 'abcd')
    True
    >>> same_chars('eabcd', 'dddddddabc')
    False
    >>> same_chars('abcd', 'dddddddabce')
    False
    >>> same_chars('eabcdzzzz', 'dddzzzzzzzddddabc')
    False
    """
    # Create two dictionaries each holding the count of each character in each string.
    s0_count = {}
    s1_count = {}
    for c in s0:
        s0_count[c] = s0_count.get(c, 0) + 1
    for c in s1:
        s1_count[c] = s1_count.get(c, 0) + 1
    # Check if each character in s0 also exists in s1.
    for c in s0_count.keys():
        if c not in s1_count or s1_count[c] != s0_count[c]:
            return False
    # Check if each character in s1 also exists in s0.
    for c in s1_count.keys():
        if c not in s0_count or s0_count[c] != s1_count[c]:
            return False
    return True
```


