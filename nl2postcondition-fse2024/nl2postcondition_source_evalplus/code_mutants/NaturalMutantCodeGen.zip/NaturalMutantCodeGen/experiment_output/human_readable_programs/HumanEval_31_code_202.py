```python

def is_prime(n):
    """Return true if a given number is prime, and false otherwise.
    >>> is_prime(6)
    False
    >>> is_prime(101)
    True
    >>> is_prime(11)
    True
    >>> is_prime(13441)
    True
    >>> is_prime(61)
    True
    >>> is_prime(4)
    False
    >>> is_prime(1)
    False
    """

    # Check if number is less than 2, which is not a prime number
    if n < 2:
        return False

    # check if number is equal to 2, which is a prime number
    if n == 2:
        return True

    # Check if number is even and greater than 2, which is not a prime number
    if n % 2 == 0:
        return False

    # Check divisibility of the odd numbers starting from 3 up to the square root of n
    # If the number n is divisible by any of these numbers, then it is not a prime number
    for i in range(3, int(n**0.5)+1, 2):
        if n % i == 0:
            return False
    
    # Otherwise, the number is a prime number
    return True

```


