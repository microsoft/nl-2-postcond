```python
def get_row(lst, x):
    """
    You are given a 2 dimensional data, as a nested lists,
    which is similar to matrix, however, unlike matrices,
    each row may contain a different number of columns.
    Given lst, and integer x, find integers x in the list,
    and return list of tuples, [(x1, y1), (x2, y2) ...] such that
    each tuple is a coordinate - (row, columns), starting with 0.
    Sort coordinates initially by rows in ascending order.
    Also, sort coordinates of the row by columns in descending order.
    
    Examples:
    get_row([
      [1,2,3,4,5,6],
      [1,2,3,4,1,6],
      [1,2,3,4,5,1]
    ], 1) == [(0, 0), (1, 4), (1, 0), (2, 5), (2, 0)]
    get_row([], 1) == []
    get_row([[], [1], [1, 2, 3]], 3) == [(2, 2)]
    """
    target_indices = []
    # find all the index matching the given value
    for i in range(len(lst)):
        sublist = lst[i]
        if x in sublist:
            # get the indices of the matching elements in sublist
            matching_indices = [j for j in range(len(sublist)) if sublist[j] == x]
            # append the row and column indices of each matching element to target_indices list
            for matching_index in matching_indices:
                target_indices.append((i, matching_index))
    # sort target_indices list by rows in ascending order and by columns in descending order
    target_indices.sort(key=lambda index: (index[0], -index[1]))
    return target_indices
```


