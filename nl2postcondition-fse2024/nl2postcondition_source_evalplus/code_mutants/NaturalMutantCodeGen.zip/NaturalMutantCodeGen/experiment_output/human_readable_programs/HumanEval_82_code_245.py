```python
import math

def prime_length(string):
    """Write a function that takes a string and returns True if the string
    length is a prime number or False otherwise
    Examples
    prime_length('Hello') == True
    prime_length('abcdcba') == True
    prime_length('kittens') == True
    prime_length('orange') == False
    """
    # Calculate length of string
    string_length = len(string)
    # If length is 2 or less return True
    if string_length <= 2:
        return True
    # Calculate square root of length
    sqrt_length = int(math.sqrt(string_length))
    # If length is divisible by any number between 2 and sqrt_length return False
    for i in range(2, sqrt_length + 1):
        if string_length % i == 0:
            return False
    # If length is not divisible by any number between 2 and sqrt_length return True
    return True
```


