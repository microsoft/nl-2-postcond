```python
def prod_signs(arr):
    """
    You are given an array arr of integers and you need to return
    sum of magnitudes of integers multiplied by product of all signs
    of each number in the array, represented by 1, -1 or 0.
    Note: return None for empty arr.

    Example:
    >>> prod_signs([1, 2, 2, -4]) == -9
    >>> prod_signs([0, 1]) == 0
    >>> prod_signs([]) == None
    """
    # If arr is empty, return None
    if not arr:
        return None
    
    # Initialize variables
    sign_product = 1
    magnitude_sum = 0
    
    # Loop through array
    for num in arr:
        # Get the sign of the number
        if num > 0:
            sign = 1
        elif num < 0:
            sign = -1
        else:
            sign = 0
        
        # Multiply sign_product by the sign of the number
        sign_product *= sign
        
        # Add the magnitude of the number to magnitude_sum
        magnitude_sum += abs(num)
    
    # Multiply magnitude_sum by the sign_product
    return magnitude_sum * sign_product
```


