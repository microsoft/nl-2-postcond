```python

def compare_one(a, b):
    """
    Create a function that takes integers, floats, or strings representing
    real numbers, and returns the larger variable in its given variable type.
    Return None if the values are equal.
    Note: If a real number is represented as a string, the floating point might be . or ,

    compare_one(1, 2.5) ➞ 2.5
    compare_one(1, "2,3") ➞ "2,3"
    compare_one("5,1", "6") ➞ "6"
    compare_one("1", 1) ➞ None
    """

    # Check if a and b are equal
    if a == b:
        return None
    # Check if a is a string and b is a number
    elif isinstance(a, str) and isinstance(b, (int, float)):
        float_a = float(a.replace(",", "."))
        if float_a > b:
            return a
        else:
            return b
    # Check if a is a number and b is a string
    elif isinstance(a, (int, float)) and isinstance(b, str):
        float_b = float(b.replace(",", "."))
        if a > float_b:
            return a
        else:
            return b
    # Check if a and b are both numbers
    elif isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if a > b:
            return a
        else:
            return b
    # Return None if none of the above conditions are met
    else:
        return None

```


