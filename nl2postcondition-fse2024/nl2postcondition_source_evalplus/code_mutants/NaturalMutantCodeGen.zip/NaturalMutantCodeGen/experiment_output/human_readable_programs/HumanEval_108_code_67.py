```python
def count_nums(arr):
    """
    Write a function count_nums which takes an array of integers and returns
    the number of elements which has a sum of digits > 0.
    If a number is negative, then its first signed digit will be negative:
    e.g. -123 has signed digits -1, 2, and 3.
    >>> count_nums([]) == 0
    >>> count_nums([-1, 11, -11]) == 1
    >>> count_nums([1, 1, 2]) == 3
    """

    def sum_digits(n):
        """
        Helper function to calculate the sum of digits of a number.
        """
        s = 0
        while n:
            s += n % 10
            n //= 10
        return s

    count = 0
    for num in arr:
        if num >= 0 and sum_digits(num) > 0:
            count += 1
        elif num < 0 and sum_digits(-num) < 0:
            count += 1
    return count
```

We define a helper function `sum_digits` to calculate the sum of digits of a given number. Then, we iterate through all the numbers in the input array `arr`, and count the number of elements that have a sum of digits greater than zero. If the number is positive and has a sum of digits greater than zero, we increment the count. If the number is negative, we calculate the sum of the absolute value of the number's digits. If this sum is negative, then the number has at least one negative digit, meaning its sum is less than zero, so we increment the count. Finally, we return the count.


