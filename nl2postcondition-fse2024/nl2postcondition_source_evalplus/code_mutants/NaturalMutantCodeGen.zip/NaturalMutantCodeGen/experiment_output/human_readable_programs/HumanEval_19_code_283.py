```python
from typing import List


def sort_numbers(numbers: str) -> str:
    """ Input is a space-delimited string of numberals from 'zero' to 'nine'.
    Valid choices are 'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight' and 'nine'.
    Return the string with numbers sorted from smallest to largest
    >>> sort_numbers('three one five')
    'one three five'
    """
    # create a dictionary that maps numberals to digits
    numberals_to_digits = {'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
                           'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9}
    
    # split the input string into individual numberals
    numberals = numbers.split()
    
    # convert numberals to digits using the dictionary mapping
    digits = [numberals_to_digits[numeral] for numeral in numberals]
    
    # sort the digits in ascending order
    sorted_digits = sorted(digits)
    
    # convert the sorted digits back to numberals using the dictionary mapping
    sorted_numberals = [list(numberals_to_digits.keys())[list(numberals_to_digits.values()).index(digit)] for digit in sorted_digits]
    
    # join the sorted numberals into a string separated by spaces
    sorted_numbers = ' '.join(sorted_numberals)
    
    return sorted_numbers
```


