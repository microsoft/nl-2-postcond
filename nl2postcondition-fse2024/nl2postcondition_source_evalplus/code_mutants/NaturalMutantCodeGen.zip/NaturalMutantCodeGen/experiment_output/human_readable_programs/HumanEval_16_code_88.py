```python
def count_distinct_characters(string: str) -> int:
    """ Given a string, find out how many distinct characters (regardless of case) does it consist of
    >>> count_distinct_characters('xyzXYZ')
    3
    >>> count_distinct_characters('Jerry')
    4
    """

    # Convert all characters in the string to lowercase to make it case-insensitive
    string = string.lower()

    # Use set() to remove duplicates and return length of resulting set
    return len(set(string))
```


