```python
def match_parens(lst):
    '''
    You are given a list of two strings, both strings consist of open
    parentheses '(' or close parentheses ')' only.
    Your job is to check if it is possible to concatenate the two strings in
    some order, that the resulting string will be good.
    A string S is considered to be good if and only if all parentheses in S
    are balanced. For example: the string '(())()' is good, while the string
    '())' is not.
    Return 'Yes' if there's a way to make a good string, and return 'No' otherwise.

    Examples:
    match_parens(['()(', ')']) == 'Yes'
    match_parens([')', ')']) == 'No'
    '''

    # count the number of open parentheses in the first string
    # and the number of closed parentheses in the second string
    num_open = lst[0].count('(')
    num_close = lst[1].count(')')

    # if the numbers match, then together they form a good string
    if num_open == num_close:
        return 'Yes'
    # if not, then concatenate them and check the resulting string
    else:
        string = lst[0] + lst[1]
        stack = []
        for char in string:
            if char == '(':
                stack.append(char)
            elif char == ')':
                if not stack:
                    return 'No'
                stack.pop()
        if stack:
            return 'No'
        else:
            return 'Yes'
```


