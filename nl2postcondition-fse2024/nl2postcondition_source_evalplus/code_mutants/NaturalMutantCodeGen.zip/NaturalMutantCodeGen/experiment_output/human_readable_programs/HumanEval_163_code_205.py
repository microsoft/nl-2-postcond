```python
def generate_integers(a, b):
    """
    Given two positive integers a and b, return the even digits between a
    and b, in ascending order.

    For example:
    generate_integers(2, 8) => [2, 4, 6, 8]
    generate_integers(8, 2) => [2, 4, 6, 8]
    generate_integers(10, 14) => []
    """

    # create an empty list to hold even digits
    even_digits = []

    # iterate from a to b, inclusive, checking each digit in each number
    for num in range(min(a,b), max(a,b) + 1):
        for digit in str(num):
            # if the digit is even, add it to the list of even digits
            if int(digit) % 2 == 0:
                even_digits.append(int(digit))

    # remove duplicates from the list and sort it
    even_digits = list(set(even_digits))
    even_digits.sort()

    return even_digits
```


