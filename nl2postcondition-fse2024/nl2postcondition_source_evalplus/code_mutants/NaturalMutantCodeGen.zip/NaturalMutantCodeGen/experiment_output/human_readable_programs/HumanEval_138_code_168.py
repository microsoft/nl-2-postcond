```python
def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """

    if n % 4 != 0:  # if n is not a multiple of 4 then it can't be sum of 4 even numbers
        return False

    # since n is a multiple of 4, start with 2 and check if the remaining sum can be obtained using 3 even number
    for i in range(2, int(n/2) + 1, 2):
        if (n - 2*i) % 4 == 0:
            return True

    # If not possible to find such 4 numbers, return false
    return False
```


