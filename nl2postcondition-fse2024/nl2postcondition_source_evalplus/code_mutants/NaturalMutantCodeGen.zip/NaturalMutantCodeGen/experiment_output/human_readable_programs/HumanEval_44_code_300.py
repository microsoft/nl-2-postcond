```python

def change_base(x: int, base: int):
    """Change numerical base of input number x to base.
    return string representation after the conversion.
    base numbers are less than 10.
    >>> change_base(8, 3)
    '22'
    >>> change_base(8, 2)
    '1000'
    >>> change_base(7, 2)
    '111'
    """

    if x == 0:
        return "0" # if input is 0, return 0 in target base.
    
    result = ""
    while x>0:
        remainder = x % base         # get remainder after integer division of x with base
        result += str(remainder)     # add the remainder to the result
        x = x // base                # integer division of x with base. Assign result to x
    
    # Since result is in reverse order due to appending remainder, need to reverse result before returning.
    return result[::-1]
  
```


