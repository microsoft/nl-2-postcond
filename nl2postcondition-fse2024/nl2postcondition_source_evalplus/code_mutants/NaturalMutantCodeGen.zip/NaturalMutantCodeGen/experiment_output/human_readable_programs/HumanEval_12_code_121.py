```python
from typing import List, Optional


def longest(strings: List[str]) -> Optional[str]:
    """ Out of list of strings, return the longest one. Return the first one in case of multiple
    strings of the same length. Return None in case the input list is empty.
    >>> longest([])

    >>> longest(['a', 'b', 'c'])
    'a'
    >>> longest(['a', 'bb', 'ccc'])
    'ccc'
    """

    longest_string = None
    for string in strings:
        if longest_string is None or len(string) > len(longest_string):
            longest_string = string
        elif len(string) == len(longest_string) and string != longest_string:
            if strings.index(string) < strings.index(longest_string):
                longest_string = string
    return longest_string
```

We first initialize `longest_string` to `None`. We then loop through each string in the input list `strings`. If `longest_string` is `None`, it means that we have not found any strings yet, so we simply update `longest_string` to be the current string we're looking at. 

If `longest_string` is not `None` and the current string we're looking at is longer than `longest_string`, we update `longest_string` to be that string. 

If the length of the current string we're looking at is equal to the length of `longest_string`, we have two strings of equal length. In this case, we compare their positions in the input list `strings` using the `index()` method. If the index of the current string is smaller than the index of `longest_string`, it means that the current string comes before `longest_string` in the input list, so we update `longest_string` to be the current string. 

After we've looped through all the strings in `strings`, `longest_string` will contain the longest string in the list or `None` if the input list is empty. We then return `longest_string`.


