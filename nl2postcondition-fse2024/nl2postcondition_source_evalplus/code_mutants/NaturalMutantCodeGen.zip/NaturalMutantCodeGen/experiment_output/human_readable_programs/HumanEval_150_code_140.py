```python

def x_or_y(n, x, y):
    """A simple program which should return the value of x if n is 
    a prime number and should return the value of y otherwise.

    Examples:
    for x_or_y(7, 34, 12) == 34
    for x_or_y(15, 8, 5) == 5
    
    """

    # Check if n is a prime number
    for i in range(2, int(n**(0.5))+1):
        if n % i == 0:
            return y  # n is not a prime, return y

    return x  # n is a prime, return x
```


