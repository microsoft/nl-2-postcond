```python
def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """

    def is_prime(n):
        """Helper function that returns True if the given number is prime and False otherwise"""
        if n <= 1:
            return False
        for i in range(2, int(n**0.5)+1):
            if n % i == 0:
                return False
        return True

    # Check all possible combinations of 3 prime numbers
    for i in range(2, a):
        if is_prime(i) and a % i == 0:
            for j in range(i+1, a):
                if is_prime(j) and a % (i*j) == 0:
                    for k in range(j+1, a):
                        if is_prime(k) and a == i*j*k:
                            return True

    # If no combination of 3 prime numbers multiply to a, return False
    return False
```


