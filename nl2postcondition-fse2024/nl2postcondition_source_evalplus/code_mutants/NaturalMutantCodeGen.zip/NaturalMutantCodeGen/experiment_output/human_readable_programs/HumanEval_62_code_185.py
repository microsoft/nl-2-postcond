```python

def derivative(xs: list):
    """ xs represent coefficients of a polynomial.
    xs[0] + xs[1] * x + xs[2] * x^2 + ....
     Return derivative of this polynomial in the same form.
    >>> derivative([3, 1, 2, 4, 5])
    [1, 4, 12, 20]
    >>> derivative([1, 2, 3])
    [2, 6]
    """

    # we remove the first element of xs list
    # then we multiply each coefficient by its respective power and
    # then by the power of its coefficient minus one
    dxs = [xs[i] * i for i in range(1, len(xs))]

    return dxs
```


