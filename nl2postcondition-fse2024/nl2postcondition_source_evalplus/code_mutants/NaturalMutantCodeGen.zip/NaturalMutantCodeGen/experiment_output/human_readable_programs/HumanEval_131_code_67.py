```python
def digits(n):
    """Given a positive integer n, return the product of the odd digits.
    Return 0 if all digits are even.
    For example:
    digits(1)  == 1
    digits(4)  == 0
    digits(235) == 15
    """

    odd_digits = [int(d) for d in str(n) if int(d) % 2 != 0]
    
    if len(odd_digits) == 0:
        return 0
    
    product = 1
    for digit in odd_digits:
        product *= digit
        
    return product
```

Explanation:
- We first convert the integer to a list of its digits
- We filter out the even digits
- If there are no odd digits, we return 0
- Otherwise, we calculate the product of the odd digits and return it.


