```python
def specialFilter(nums):
    """Write a function that takes an array of numbers as input and returns 
    the number of elements in the array that are greater than 10 and both 
    first and last digits of a number are odd (1, 3, 5, 7, 9).
    For example:
    specialFilter([15, -73, 14, -15]) => 1 
    specialFilter([33, -2, -3, 45, 21, 109]) => 2
    """

    def is_odd(n):
        """Helper function to check if a number is odd"""
        return n % 2 != 0
    
    def valid(n):
        """Helper function to check if a number satisfies the given condition"""
        if n <= 10:
            return False
        n_str = str(n)
        return is_odd(int(n_str[0])) and is_odd(int(n_str[-1]))
    
    return len([n for n in nums if valid(n)])
```

The function first defines two helper functions, `is_odd` and `valid`.

`is_odd` checks if a number is odd by checking if its remainder when divided by 2 is not zero. 

`valid` checks if a number satisfies the given condition. If the number is less than or equal to 10, then it is not valid. Otherwise, it converts the number to a string and checks if both the first and last characters are odd digits. 

The main body of the `specialFilter` function returns the length of the list comprehension that filters only the numbers that satisfy the given condition.


