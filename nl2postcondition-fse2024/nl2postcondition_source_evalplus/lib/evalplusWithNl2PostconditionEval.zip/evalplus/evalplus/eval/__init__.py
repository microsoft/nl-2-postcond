import itertools
import math
import multiprocessing
import time
from multiprocessing import Array, Value
from typing import Any, Dict, List, Tuple, Union
from multiprocessing import Queue
import queue
import traceback

import numpy as np

from evalplus.data import to_raw
from evalplus.eval.utils import (
    create_tempdir,
    reliability_guard,
    swallow_io,
    time_limit,
)
import hashlib

def hash_output(output):
    hasher = hashlib.sha256()
    hasher.update(str(output).encode())
    return hasher.hexdigest()

def compatible_eval_result(results: Dict) -> Dict:
    # compatibility
    for task_results in results["eval"].values():
        # update the "files" field to "nfiles"
        if "files" in task_results and "nfiles" not in task_results:
            task_results["nfiles"] = len(task_results.pop("files"))
    return results


# unbiased estimator from https://github.com/openai/human-eval
def estimate_pass_at_k(
    num_samples: Union[int, List[int], np.ndarray],
    num_correct: Union[List[int], np.ndarray],
    k: int,
) -> np.ndarray:
    """
    Estimates pass@k of each problem and returns them in an array.
    """

    def estimator(n: int, c: int, k: int) -> float:
        """
        Calculates 1 - comb(n - c, k) / comb(n, k).
        """
        if n - c < k:
            return 1.0
        return 1.0 - np.prod(1.0 - k / np.arange(n - c + 1, n + 1))

    if isinstance(num_samples, int):
        num_samples_it = itertools.repeat(num_samples, len(num_correct))
    else:
        assert len(num_samples) == len(num_correct)
        num_samples_it = iter(num_samples)

    return np.array(
        [estimator(int(n), int(c), k) for n, c in zip(num_samples_it, num_correct)]
    )


def construct_inputs_sig(inputs: list) -> str:
    str_builder = ""
    for x in inputs:
        if type(x) == str:
            str_builder += f"'{to_raw(x)}',"
        else:
            str_builder += f"{x},"
    return str_builder[:-1]


# oracle for 032
# MLE is pretty sure this is flipped in the untrusted check call
def _poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])


SUCCESS = "success"
FAILED = "failed"
TIMEOUT = "timed out"
QUEUE_FILLED_UP = "queue filled up"

_SUCCESS = 0
_FAILED = 1
_TIMEOUT = 2
_UNKNOWN = 3
_QUEUE_FILLED_UP = 4
_KILLED_MUTANT = 5
_DID_NOT_KILL_MUTANT = 6

_mapping = {_SUCCESS: SUCCESS, 
            _FAILED: FAILED, 
            _TIMEOUT: TIMEOUT, 
            _UNKNOWN: None, 
            _QUEUE_FILLED_UP: QUEUE_FILLED_UP,
            _KILLED_MUTANT: "killed at least one mutant",
            _DID_NOT_KILL_MUTANT: "did not kill any mutants"}


def is_floats(x) -> bool:
    # check if it is float; List[float]; Tuple[float]
    if isinstance(x, float):
        return True
    if isinstance(x, (list, tuple)):
        return all(isinstance(i, float) for i in x)
    if isinstance(x, np.ndarray):
        return x.dtype == np.float64 or x.dtype == np.float32
    return False

def unsafe_postcondition_kill_execute(
        entry_point: str,
        code: str,
        inputs,
        time_limits,
        stat: Value,
        details: Array,
        progress: Value,
        # Pass the queues to the child process
        errors_queue,
):
    with create_tempdir():
        # These system calls are needed when cleaning up tempdir.
        import os
        import shutil

        rmtree = shutil.rmtree
        rmdir = os.rmdir
        chdir = os.chdir
        # Disable functionalities that can make destructive changes to the test.
        # allow only 4GB memory usage
        maximum_memory_bytes = 8 * 1024 * 1024 * 1024
        reliability_guard(maximum_memory_bytes=maximum_memory_bytes)
        exec_globals = {}
        errors = [None] * len(inputs)
        stat.value = _DID_NOT_KILL_MUTANT
        try:
            if True:
                exec(code, exec_globals)
                fn = exec_globals[entry_point]
                for i, inp in enumerate(inputs):
                    try:
                        #print(inp)
                        with time_limit(time_limits[i]):
                            out = fn(*inp)
                        
                        # It did not error out
                        details[i] = False


                    except BaseException as e:
                        exception = traceback.format_exception(type(e), value=e, tb=e.__traceback__)[-1]
                        stack = traceback.format_stack()
                        if str(e) == "!!Timed out!!":
                            errors[i] = str(e)
                            details[i] = False
                        else:
                            errors[i] = str(exception).strip()
                            details[i] = True
                            stat.value = _KILLED_MUTANT
                    
                    errors_queue.put_nowait(errors[i])
                    progress.value += 1
                    
        except queue.Full:
            print("Queue is full, truncating outs")
            stat.value = _QUEUE_FILLED_UP

        except BaseException as e:
            #print("in base error", str(e))
            stat.value = _FAILED
            to_push = '!!BASE ERROR!!' + str(e)
            errors_queue.put_nowait(to_push)
            print("################ Code with a base error: \n", code)
            
        # Needed for cleaning up.
        shutil.rmtree = rmtree
        os.rmdir = rmdir
        os.chdir = chdir

def unsafe_execute(
    entry_point: str,
    code: str,
    inputs,
    expected: List,
    time_limits,
    atol,
    fast_check,
    stat: Value,
    details: Array,
    progress: Value,
    outs_queue,
    expected_outs_queue,
    hash_queue,
):
    with create_tempdir():
        # These system calls are needed when cleaning up tempdir.
        import os
        import shutil

        rmtree = shutil.rmtree
        rmdir = os.rmdir
        chdir = os.chdir
        # Disable functionalities that can make destructive changes to the test.
        # allow only 4GB memory usage
        maximum_memory_bytes = 8 * 1024 * 1024 * 1024
        reliability_guard(maximum_memory_bytes=maximum_memory_bytes)
        exec_globals = {}
        outs = [None] * len(inputs)
        hashes = [None] * len(inputs)
        expected_outs = [None] * len(inputs)
        try:
            with swallow_io():
            #if True:
                exec(code, exec_globals)
                fn = exec_globals[entry_point]
                for i, inp in enumerate(inputs):
                    try:
                        got_output = False
                        got_hash = False
                        exp = expected[i]
                        expected_outs[i] = str(exp)[:30]

                        with time_limit(time_limits[i]):
                            out = fn(*inp)

                        exact_match = out == exp
                        outs[i] = str(out)[:30]
                        got_output = True
                        
                        #print("Outs: ", outs[i])
                        if is_floats(out):
                            hashes[i] = out
                        else:
                            out_prime = str(out)
                            if len(out_prime) <= 64:
                                hashes[i] = out_prime
                            else:
                                hashes[i] = hash_output(out_prime)
                        got_hash = True
                        #print("Hashes: ", hashes[i])
                        
                        if "find_zero" == entry_point:
                            #assert _poly(*out, inp) <= atol
                            assert _poly(*inp, out) <= atol # MLE fixed

                        if atol == 0 and is_floats(exp):
                            atol = 1e-6  # enforce atol for float comparison
                        if not exact_match and atol != 0:
                            np.testing.assert_allclose(out, exp, atol=atol)
                        else:
                            assert exact_match
                    
                            details[i] = True

                    except BaseException as e:
                        #print("in error", str(e))
                        if not got_output:
                            outs[i] = '!!ERROR!!:' + str(e)[:50]
                        if not got_hash:
                            hashes[i] = '!!ERROR!!:' + str(e)[:50]
                        if fast_check:
                            raise

                        details[i] = False
                    
                    outs_queue.put_nowait(outs[i])
                    expected_outs_queue.put_nowait(expected_outs[i])
                    hash_queue.put_nowait(hashes[i])
                    progress.value += 1
                    
            stat.value = _SUCCESS

            
            
        except queue.Full:
            print("Queue is full, truncating outs")
            stat.value = _QUEUE_FILLED_UP

        except BaseException as e:
            #print("in base error", str(e))
            stat.value = _FAILED
            to_push = '!!BASE ERROR!!' + str(e)
            outs_queue.put_nowait(to_push)
            expected_outs_queue.put_nowait(to_push)
            hash_queue.put_nowait(to_push)
            
        # Needed for cleaning up.
        shutil.rmtree = rmtree
        os.rmdir = rmdir
        os.chdir = chdir
        #print("Got to end of unsafe execute")


def final_queue_get(stored, to_store_queue, expected_length, timeout=None):

    try:
        while len(stored) < expected_length:
            if timeout is None:
                print("len before", len(stored))
                stored.append(to_store_queue.get_nowait())
                print("len after", len(stored))

            else:
                stored.append(to_store_queue.get(timeout=timeout))
                
    except queue.Empty:
        return False
    
    return True

def untrusted_postcondition_check(
        code: str, # The wrapped code
        inputs: List[Any], # The unique buggy inputs
        entry_point: str, # the function entry point
        ref_times: List[float], # The reference times
        min_time_limit: float = 0.1,
        gt_time_limit_factor: float = 2.0,
    ) -> Tuple[str, np.ndarray]:
    
    time_limits = [max(min_time_limit, gt_time_limit_factor * t * 1.5) for t in ref_times]
    if len(time_limits) != len(inputs):
        print(len(inputs), len(time_limits))
    timeout = sum(time_limits) + 1
    
    # shared memory objects
    progress = Value("i", 0)
    stat = Value("i", _UNKNOWN)
    details = Array("b", [False for _ in range(len(inputs))])
    errors_queue = Queue()  # Add this line to create a queue for outs

    errors = []
    
    p = multiprocessing.Process(
        target=unsafe_postcondition_kill_execute,
        args=(
            entry_point,
            code,
            inputs,
            time_limits,
            stat,
            details,
            progress,
            # Pass the queues to the child process
            errors_queue,
        ),
    )
    p.start()
    
    # Get the results from the queues
    start_time = time.time()
    to_pull = '!!BASE ERROR!!'
    while True:
        if len(errors) < len(inputs):
            moreErrors = final_queue_get(errors, errors_queue, len(inputs), timeout=1)

        if len(errors) and str(errors[-1]).startswith(to_pull):
            print("Error - investigate why this is happening", errors[-1])
            break

        # If we have reached the end of everything, then break
        if len(errors) == len(inputs): 
            #or _mapping[stat.value] == QUEUE_FILLED_UP:
            #print("Received sentinel, no more results.")
            break
        
        # If we timeout, then break
        if not(moreErrors):
            # Check the overall timeout
            if time.time() - start_time > timeout + 5:
                print("Overall timeout occurred... Killing process and doing one more pull")
                break
    
    #print("Finished the untrusted check, and back in the main process")
    if p.is_alive():
        p.terminate()
        time.sleep(0.2)
    if p.is_alive():
        p.kill()
        time.sleep(0.2)
    
    #print("Finished killing")

    details = details[: progress.value]

    moreErrors = final_queue_get(errors, errors_queue, progress.value)
    
    stat = _mapping[stat.value]
    
    if not moreErrors:
        # if one of the gets that should have grabbed more, failed
        if not stat:
            print("OVERALL TIMEOUT!!!", entry_point, progress.value, inputs[progress.value - 1])
            print(progress.value, len(errors), len(inputs))
            stat = TIMEOUT
            
        elif len(details) != len(inputs):
            print("Stat is failed, errors are: ", errors)
            stat = FAILED
        else:
            print("We got: should not have a stat, should be timeout: ", stat)
            print(progress.value, len(inputs), len(errors))


    if stat == QUEUE_FILLED_UP:
        # In this case, you should truncate all of the outs to the progress.value
        print("Stat is queue filled up, progress value is {} out of {}: ".format(progress.value, len(inputs)))
        print(progress.value, len(inputs), len(errors))
        outs = outs[:progress.value]
        expected_outs = expected_outs[:progress.value]
        hashes = hashes[:progress.value]

    #print("Finished putting")
    if not stat:
        print("TIMEOUT", entry_point, len(inputs), progress.value)
        print(progress.value, len(inputs), len(errors))
        stat = TIMEOUT

    elif len(details) != len(inputs):
        stat = FAILED

    return stat, details, errors



def untrusted_check(
    code: str,
    inputs: List[Any],
    entry_point: str,
    expected,
    atol,
    ref_time: List[float],
    fast_check: bool = False,
    min_time_limit: float = 0.1,
    gt_time_limit_factor: float = 2.0,
) -> Tuple[str, np.ndarray]:

    time_limits = [max(min_time_limit, gt_time_limit_factor * t) for t in ref_time]
    timeout = sum(time_limits) + 1
    if not fast_check:
        timeout += 1  # extra time for data collection

    # shared memory objects
    progress = Value("i", 0)
    stat = Value("i", _UNKNOWN)
    details = Array("b", [False for _ in range(len(inputs))])

    outs_queue = Queue()  # Add this line to create a queue for outs
    expected_outs_queue = Queue()  # Add this line to create a queue for expected outs
    hash_queue = Queue()  # Add this line to create a queue for hash of the outputs
    outs = []
    expected_outs = []
    hashes = []
    p = multiprocessing.Process(
        target=unsafe_execute,
        args=(
            entry_point,
            code,
            inputs,
            expected,
            time_limits,
            atol,
            fast_check,
            # return values
            stat,
            details,
            progress,
            # Pass the queues to the child process
            outs_queue,
            expected_outs_queue,
            hash_queue,
        ),
    )
    p.start()
    
    # Get the results from the queues
    start_time = time.time()
    to_pull = '!!BASE ERROR!!'
    while True:
        if len(outs) < len(inputs):
            moreOuts = final_queue_get(outs, outs_queue, len(inputs), timeout=1)
            #outs.append(outs_queue.get(timeout=timeout + 1))
        if len(expected_outs) < len(inputs):
            moreExpected = final_queue_get(expected_outs, expected_outs_queue, len(inputs), timeout=1)
            #expected_outs.append(expected_outs_queue.get(timeout=1))
        if len(hashes) < len(inputs):
            moreHashes = final_queue_get(hashes, hash_queue, len(inputs), timeout=1)
            #hashes.append(hash_queue.get(timeout=1))
        if (len(outs) and len(expected_outs) and len(hashes))  and \
            (str(outs[-1]).startswith(to_pull) and str(expected_outs[-1]).startswith(to_pull) and str(hashes[-1]).startswith(to_pull)):
                print("This one errored out - breaking: ",  outs[-1])
                break

            # If we have reached the end of everything, then break
        if (len(outs) == len(inputs) and len(expected_outs) == len(inputs) and len(hashes) == len(inputs)) or \
                _mapping[stat.value] == QUEUE_FILLED_UP:
            #print("Received sentinel, no more results.")
            break
        
        # If we timeout, then break
        if not(moreOuts and moreExpected and moreHashes):
            # Check the overall timeout
            if time.time() - start_time > timeout + 5:
                print("Overall timeout occurred... Killing process and doing one more pull")
                break
            
    #print("Finished the untrusted check, and back in the main process")
    if p.is_alive():
        p.terminate()
        time.sleep(0.2)
    if p.is_alive():
        p.kill()
        time.sleep(0.2)
        
    #print("Finished killing")

    details = details[: progress.value]

    moreOuts = final_queue_get(outs, outs_queue, progress.value)
    moreExpected = final_queue_get(expected_outs, expected_outs_queue, progress.value)
    moreHashes = final_queue_get(hashes, hash_queue, progress.value)
    
    stat = _mapping[stat.value]
    
    if (not moreOuts) or (not moreExpected) or (not moreHashes):
        # if one of the gets that should have grabbed more, failed
        if not stat:
            print("OVERALL TIMEOUT!!!", entry_point, progress.value, inputs[progress.value - 1])
            print(progress.value, len(inputs), len(outs), len(expected_outs), len(hashes))
            stat = TIMEOUT
        elif stat == FAILED:
            print("Stat is failed, outs are: ", outs)
        elif stat == SUCCESS:
            print("This was marked as success, but something is not alligning. Should not have a stat, should be timeout: ", stat)
            print(progress.value, len(inputs), len(outs), len(expected_outs), len(hashes))


    if stat == QUEUE_FILLED_UP:
        # In this case, you should truncate all of the outs to the progress.value
        print("Stat is queue filled up, progress value is {} out of {}: ".format(progress.value, len(inputs)))
        print(progress.value, len(inputs), len(outs), len(expected_outs), len(hashes))
        outs = outs[:progress.value]
        expected_outs = expected_outs[:progress.value]
        hashes = hashes[:progress.value]

    if not stat:
        print("TIMEOUT", entry_point, len(inputs), progress.value)
        print(progress.value, len(inputs), len(outs), len(expected_outs), len(hashes))
        stat = TIMEOUT

    if stat == SUCCESS:
        if len(details) != len(inputs) or not all(details):
            stat = FAILED

    return stat, details, outs, expected_outs, hashes



def evaluate_files(
    files: List[str],
    inputs: List,
    expected: List,
    entry_point: str,
    atol: float,
    ref_time: List[float],
    fast_check: bool = False,
    min_time_limit: float = 0.1,
    gt_time_limit_factor: float = 2.0,
) -> List[Tuple[str, List[bool]]]:
    ret = []
    # sort files by the id in name (i.e., "../n.py")
    files = sorted(files, key=lambda x: int(x.split("/")[-1].split(".")[0]))
    for file in files:
        code = open(file, "r").read()
        stat, det = untrusted_check(
            code,
            inputs,
            entry_point,
            expected=expected,
            atol=atol,
            ref_time=ref_time,
            fast_check=fast_check,
            min_time_limit=min_time_limit,
            gt_time_limit_factor=gt_time_limit_factor,
        )
        ret.append((stat, det.tolist()))
    return ret
