from setuptools import setup, find_packages

setup(
    name="evalplus",
    use_scm_version={
        "write_to": "evalplus/_version.py",
        "version_scheme": "release-branch-semver",
        "local_scheme": "no-local-version",
    },
    setup_requires=["setuptools>=45", "setuptools_scm[toml]>=6.2"],
    description="EvalPlus for rigorous evaluation of LLM-synthesized code",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/evalplus/evalplus",
    license="Apache-2.0",
    classifiers=[
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
    ],
    packages=find_packages(exclude=["evalplus._experimental*"]),
    python_requires=">=3.8",
    install_requires=[
        "wget>=3.2",
        "tempdir>=0.7.1",
        "multipledispatch>=0.6.0",
        "appdirs>=1.4.4",
        "numpy>=1.19.5",
        "tqdm>=4.56.0",
    ],
    entry_points={
        "console_scripts": [
            "evalplus.evaluate=evalplus.evaluate:main",
            "evalplus.inputgen=evalplus.inputgen:main",
        ],
    },
)
