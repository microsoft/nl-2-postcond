// Check if the returnValue is non-negative, as chi-square value should be non-negative
assert returnValue >= 0 : "Chi-square value should be non-negative";


