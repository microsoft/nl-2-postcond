// Check if the returned node is either the same as the input node or has a String type
assert returnValue == n || returnValue.getType() == Token.STRING;


