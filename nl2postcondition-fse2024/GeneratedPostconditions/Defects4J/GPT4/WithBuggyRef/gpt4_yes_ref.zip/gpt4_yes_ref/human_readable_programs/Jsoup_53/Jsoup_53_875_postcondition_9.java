```java
// Postcondition: The returned value should have balanced open and close characters
assert returnValue.chars().filter(ch -> ch == open).count() == returnValue.chars().filter(ch -> ch == close).count();
```


