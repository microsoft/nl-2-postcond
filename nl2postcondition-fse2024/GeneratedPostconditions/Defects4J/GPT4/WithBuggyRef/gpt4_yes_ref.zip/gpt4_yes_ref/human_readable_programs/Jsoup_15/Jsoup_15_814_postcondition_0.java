// Postcondition: If the method returns false, the input token type must be either Doctype or Character with nullString data
assert returnValue || !(t.type == Token.TokenType.Doctype || (t.type == Token.TokenType.Character && t.asCharacter().getData().equals(nullString)));


