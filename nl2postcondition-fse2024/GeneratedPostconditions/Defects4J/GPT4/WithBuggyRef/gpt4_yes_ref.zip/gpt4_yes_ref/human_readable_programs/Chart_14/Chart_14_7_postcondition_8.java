// Checks if the marker is removed from the specified layer and the change event is fired when notify is true
assert (returnValue == true) == (markers.contains(marker) && (!notify || changeEventFired));


