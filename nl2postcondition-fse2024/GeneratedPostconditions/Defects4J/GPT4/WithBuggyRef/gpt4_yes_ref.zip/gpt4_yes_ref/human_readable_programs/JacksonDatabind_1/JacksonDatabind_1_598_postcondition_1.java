// Check if the JsonGenerator's output buffering is empty after serialization
assert jgen.getOutputBuffer().hasRemaining() == false;


