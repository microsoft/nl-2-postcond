```java
// Checks if the returned node is either the original node or one of its children
assert returnValue == n || returnValue.isDescendantOf(left);
```


