```java
// Postcondition: checks if the returnValue is either null or a non-empty string when the method executes successfully
assert returnValue == null || !returnValue.isEmpty();
```


