```java
// Check if the returnValue is either defaultValue or the text value of _currToken when it's a scalar value
assert returnValue.equals(defaultValue) || (_currToken != null && _currToken.isScalarValue() && returnValue.equals(getText()));
```


