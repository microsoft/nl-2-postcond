```java
// Postcondition checks if the returned string's count of open and close characters are balanced
assert returnValue.chars().filter(c -> c == open).count() == returnValue.chars().filter(c -> c == close).count();
```


