```java
// Check if the returnValue (chi-square value) is non-negative, as sum of squares should always be non-negative
assert returnValue >= 0;
```


