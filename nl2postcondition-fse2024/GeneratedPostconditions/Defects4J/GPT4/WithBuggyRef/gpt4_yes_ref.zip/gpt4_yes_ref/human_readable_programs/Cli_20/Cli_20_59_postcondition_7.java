// Postcondition checks if the returnValue has the same number of "--" occurrences as the input arguments array
import java.util.Arrays;

assert Arrays.stream(returnValue).filter(s -> s.equals("--")).count() == Arrays.stream(arguments).filter(s -> s.equals("--")).count();


