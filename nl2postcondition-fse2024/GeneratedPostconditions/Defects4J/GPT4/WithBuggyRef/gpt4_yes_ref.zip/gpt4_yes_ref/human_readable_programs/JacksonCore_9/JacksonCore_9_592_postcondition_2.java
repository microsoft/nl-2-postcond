```java
// Check if the returned value is either a string or null
assert returnValue == null || returnValue instanceof String;
```


