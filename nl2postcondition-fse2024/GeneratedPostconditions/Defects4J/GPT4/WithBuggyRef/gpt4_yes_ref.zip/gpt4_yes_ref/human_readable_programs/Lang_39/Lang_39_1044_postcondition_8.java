// Postcondition checks if the returned string is not null when input text is not null
assert (text != null) ? (returnValue != null) : (returnValue == null);


