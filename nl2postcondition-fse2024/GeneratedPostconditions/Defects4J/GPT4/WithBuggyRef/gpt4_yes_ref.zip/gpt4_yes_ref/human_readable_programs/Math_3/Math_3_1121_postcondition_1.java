```java
import java.util.Arrays;
import java.util.stream.IntStream;

// Check that the length of input arrays a and b are equal to avoid DimensionMismatchException
assert Arrays.stream(IntStream.range(0, a.length).mapToDouble(i -> a[i] * b[i]).toArray()).sum() == returnValue : "linearCombination result does not match expected sum of element-wise products";
```


