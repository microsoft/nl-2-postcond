// Check if the returnValue is consistent with the linkFlag being LF_DIR
assert (linkFlag == LF_DIR) == returnValue;


