```java
// Check that the length of the types and values arrays is the same as in the input parameters after the Partial method execution
assert iTypes.length == types.length && iValues.length == values.length;
```


