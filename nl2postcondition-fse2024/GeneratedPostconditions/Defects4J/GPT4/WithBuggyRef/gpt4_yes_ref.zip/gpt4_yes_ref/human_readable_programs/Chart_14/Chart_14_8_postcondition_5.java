```java
import java.util.Objects;

// Asserts that the returned value is true if and only if the marker is not null and is present in the specified layer before removal
assert returnValue == (marker != null && (layer == Layer.FOREGROUND ? Objects.requireNonNull(this.foregroundDomainMarkers.get(index)).contains(marker) : Objects.requireNonNull(this.backgroundDomainMarkers.get(index)).contains(marker)));
```


