```java
// Check if the returnValue is equal to defValue when the current token is not a VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING) ? returnValue.equals(defValue) : true;
```


