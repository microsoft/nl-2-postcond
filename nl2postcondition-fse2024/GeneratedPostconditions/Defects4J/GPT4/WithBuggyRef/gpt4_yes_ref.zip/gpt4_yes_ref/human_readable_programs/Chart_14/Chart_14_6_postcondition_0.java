// Checks if the marker has been removed from the corresponding markers ArrayList
assert !returnValue || !((layer == Layer.FOREGROUND ? this.foregroundDomainMarkers.get(new Integer(index)) : this.backgroundDomainMarkers.get(new Integer(index))).contains(marker));


