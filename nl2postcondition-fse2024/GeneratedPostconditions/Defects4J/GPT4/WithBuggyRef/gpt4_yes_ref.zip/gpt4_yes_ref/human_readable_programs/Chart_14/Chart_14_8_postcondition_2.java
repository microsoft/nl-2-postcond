```java
// Check if the marker was removed from the corresponding markers list based on the returnValue
assert (layer == Layer.FOREGROUND ? this.foregroundDomainMarkers.get(new Integer(index)) : this.backgroundDomainMarkers.get(new Integer(index))).contains(marker) != returnValue;
```


