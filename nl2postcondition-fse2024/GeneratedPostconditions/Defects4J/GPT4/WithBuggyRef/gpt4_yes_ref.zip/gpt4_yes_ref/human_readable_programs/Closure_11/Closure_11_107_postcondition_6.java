// Postcondition: Checks if the type of the GETPROP node is not null after visitGetProp
assert n.getJSType() != null;


