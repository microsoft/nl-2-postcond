```java
// Checks that the returned range has a lower bound less than or equal to the upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();
```


