```java
// This postcondition checks that if the returnValue is false, then the Token type was either Doctype or an unrecognized type.
assert returnValue || (t.type == Token.TokenType.Doctype || t.type != Token.TokenType.Character && t.type != Token.TokenType.Comment && t.type != Token.TokenType.StartTag && t.type != Token.TokenType.EndTag);
```


