```java
// Check if the returned node type is the same as the input node type
assert (returnValue.getType() == n.getType());
```


