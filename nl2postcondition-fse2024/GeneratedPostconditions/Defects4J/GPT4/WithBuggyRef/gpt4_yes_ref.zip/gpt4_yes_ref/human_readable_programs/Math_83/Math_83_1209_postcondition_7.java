// Checks if the returned row, if non-null, contains a 1.0 at the given column and 0.0 in all other columns
assert returnValue == null || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(0, getHeight()).allMatch(i -> i == returnValue || MathUtils.equals(getEntry(i, col), 0.0, epsilon)));


