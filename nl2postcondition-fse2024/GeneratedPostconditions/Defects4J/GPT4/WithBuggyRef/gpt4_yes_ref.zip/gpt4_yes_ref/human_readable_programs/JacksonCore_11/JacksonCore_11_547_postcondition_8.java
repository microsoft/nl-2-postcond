// Postcondition: After _verifySharing, the _hashShared flag should be set to false
assert !_hashShared;


