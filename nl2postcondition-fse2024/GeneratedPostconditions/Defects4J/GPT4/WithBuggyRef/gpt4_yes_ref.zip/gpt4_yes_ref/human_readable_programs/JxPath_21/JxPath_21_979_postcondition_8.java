// Check if the returned length is either equal to the length of the collection or -1
assert (returnValue == ValueUtils.getLength(getBaseValue())) || (returnValue == -1);


