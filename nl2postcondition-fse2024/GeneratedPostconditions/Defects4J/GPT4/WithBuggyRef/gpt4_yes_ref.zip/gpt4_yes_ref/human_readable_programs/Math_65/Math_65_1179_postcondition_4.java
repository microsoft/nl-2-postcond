```java
// Check if the returnValue (chi-square value) is non-negative since sum of squared residuals is always non-negative
assert returnValue >= 0 : "Chi-square value must be non-negative";
```


