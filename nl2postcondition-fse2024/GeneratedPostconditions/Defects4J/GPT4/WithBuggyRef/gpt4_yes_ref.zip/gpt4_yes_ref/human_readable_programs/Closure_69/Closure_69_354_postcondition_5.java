// Postcondition checks if the return type of the visitCall method is equal to the function return type when the childType is a FunctionType
assert (!(childType instanceof FunctionType) || n.getJSType().equals(((FunctionType) childType).getReturnType())) : "Return type of visitCall does not match the function return type when childType is a FunctionType";


