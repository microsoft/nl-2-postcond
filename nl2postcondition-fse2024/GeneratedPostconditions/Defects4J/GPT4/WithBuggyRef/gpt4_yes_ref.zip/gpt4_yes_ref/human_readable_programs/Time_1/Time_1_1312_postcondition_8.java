```java
// Check that the length of input types and values arrays are equal to the corresponding fields in the returned Partial object
assert types.length == returnValue.iTypes.length && values.length == returnValue.iValues.length;
```


