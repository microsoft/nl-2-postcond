// Check if the returnValue is a boolean as expected by the compute method
assert returnValue instanceof Boolean;


