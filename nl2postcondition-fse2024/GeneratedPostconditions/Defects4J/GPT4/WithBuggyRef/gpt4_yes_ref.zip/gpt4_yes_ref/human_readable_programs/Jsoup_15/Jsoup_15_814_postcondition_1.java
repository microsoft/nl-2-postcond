// Check if the returnValue is true when the Token type is not Doctype
assert (t.type != Token.TokenType.Doctype) || !returnValue;


