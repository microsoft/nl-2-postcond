```java
// Asserts that the returned length is non-negative, as collection lengths cannot be negative
assert returnValue >= -1;
```


