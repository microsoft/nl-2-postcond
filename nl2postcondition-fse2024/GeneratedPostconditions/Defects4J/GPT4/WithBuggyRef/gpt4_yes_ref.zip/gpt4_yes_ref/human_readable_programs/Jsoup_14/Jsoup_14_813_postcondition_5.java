// Check if the Tokeniser transitioned to RCDATAEndTagOpen or Rcdata state
assert (t.getState() == RCDATAEndTagOpen && r.peek() == '/') || (t.getState() == Rcdata && r.peek() != '/');


