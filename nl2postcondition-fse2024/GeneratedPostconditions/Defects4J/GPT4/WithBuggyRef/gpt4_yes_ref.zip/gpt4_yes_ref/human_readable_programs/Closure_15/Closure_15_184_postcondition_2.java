// Check if the return value is true when the input node has side effects
assert (returnValue == true) == (n != null && (NodeUtil.functionCallHasSideEffects(n) || NodeUtil.constructorCallHasSideEffects(n)));


