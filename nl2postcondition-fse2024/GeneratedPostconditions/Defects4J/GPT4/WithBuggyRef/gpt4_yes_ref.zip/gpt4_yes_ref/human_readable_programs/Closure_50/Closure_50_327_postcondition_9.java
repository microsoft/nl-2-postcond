```java
// Checks if the returned node's type is either a STRING or the same as the input node's type
assert (returnValue.getType() == Token.STRING) || (returnValue.getType() == n.getType());
```


