// Postcondition checks if the method doesn't throw any exception, then the returnValue is void, indicating successful execution
assert returnValue == null;


