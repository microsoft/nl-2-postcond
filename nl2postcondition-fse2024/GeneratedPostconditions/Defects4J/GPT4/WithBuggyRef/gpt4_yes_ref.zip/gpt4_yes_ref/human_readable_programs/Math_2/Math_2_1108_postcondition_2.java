```java
// Check if the returnValue is equal to the expected mean value as per the Javadoc specification
assert returnValue == (double) (getSampleSize() * getNumberOfSuccesses()) / (double) getPopulationSize();
```


