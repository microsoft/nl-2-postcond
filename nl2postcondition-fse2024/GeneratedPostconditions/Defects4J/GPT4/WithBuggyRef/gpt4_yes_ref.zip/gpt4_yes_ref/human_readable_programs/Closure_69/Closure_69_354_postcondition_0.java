// Postcondition: Checks if the type of the return value is the same as the type of the CALL node after visitCall
assert n.getJSType().equals(returnValue.getJSType());


