// Checks if the return value is zero when both duration fields are not supported
assert (returnValue == 0) == (!durationField.isSupported() && !this.isSupported());


