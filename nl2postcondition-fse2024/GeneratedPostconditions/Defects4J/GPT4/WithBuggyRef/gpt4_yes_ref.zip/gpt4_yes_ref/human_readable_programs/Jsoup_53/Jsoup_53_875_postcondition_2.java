```java
// Checks that the returnValue has balanced open and close characters
int openCount = returnValue.length() - returnValue.replace(String.valueOf(open), "").length();
int closeCount = returnValue.length() - returnValue.replace(String.valueOf(close), "").length();
assert openCount == closeCount;
```


