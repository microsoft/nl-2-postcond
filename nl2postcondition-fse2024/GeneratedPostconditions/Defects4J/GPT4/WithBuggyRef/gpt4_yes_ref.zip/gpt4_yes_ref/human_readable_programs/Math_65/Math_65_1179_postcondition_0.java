```java
// Check that the returnValue (chi-square value) is non-negative
assert returnValue >= 0;
```


