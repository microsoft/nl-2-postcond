// Postcondition: Checks if the return type of the CALL node is assigned correctly
assert n.getJSType() == returnValue.getJSType();


