```java
// Check that the returnValue is equal to the product of sample size and number of successes divided by population size
assert returnValue == ((double) getSampleSize() * getNumberOfSuccesses()) / getPopulationSize();
```


