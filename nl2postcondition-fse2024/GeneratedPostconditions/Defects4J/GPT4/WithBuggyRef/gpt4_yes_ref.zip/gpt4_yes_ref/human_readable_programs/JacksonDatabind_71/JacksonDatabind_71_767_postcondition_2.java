// Check if the returnValue is either an instance of StdKeyDeserializer or StringKD based on the input raw class
assert returnValue == null || returnValue instanceof StdKeyDeserializer || (raw == String.class || raw == Object.class) && returnValue instanceof StringKD;


