```java
// Postcondition: Ensure that the returnValue is either 0 or 1
assert returnValue == 0 || returnValue == 1;
```


