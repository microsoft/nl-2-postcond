```java
// Asserts that the required member variable is set to false after reset is called
assert !required;
```


