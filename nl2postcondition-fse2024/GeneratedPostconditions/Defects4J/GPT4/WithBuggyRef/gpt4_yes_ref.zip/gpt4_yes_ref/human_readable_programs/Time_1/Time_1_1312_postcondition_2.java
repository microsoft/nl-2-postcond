// Check if the constructed Partial object has the same number of types and values as the input arrays
assert returnValue.iTypes.length == types.length && returnValue.iValues.length == values.length;


