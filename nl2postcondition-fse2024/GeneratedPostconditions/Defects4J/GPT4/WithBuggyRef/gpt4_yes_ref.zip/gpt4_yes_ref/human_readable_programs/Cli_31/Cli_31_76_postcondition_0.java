// Check that the length of the buffer has increased after appending the Option
assert buff.length() > buff.length() + (required ? 0 : 2) + (option.getOpt() != null ? option.getOpt().length() + 1 : option.getLongOpt().length() + 3) + (option.hasArg() && option.hasArgName() ? option.getArgName().length() + 3 : 0) : "Buffer length did not increase as expected after appending Option";


