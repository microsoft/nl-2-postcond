```java
// Check if the returnValue (RMS) is non-negative, as the square root of non-negative values should be non-negative
assert returnValue >= 0 : "RMS value should be non-negative";
```


