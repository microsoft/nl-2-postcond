// Check if the marker is removed from the specified layer and index, and the return value is true
assert (layer == Layer.FOREGROUND ? !((ArrayList) this.foregroundRangeMarkers.get(new Integer(index))).contains(marker) : !((ArrayList) this.backgroundRangeMarkers.get(new Integer(index))).contains(marker)) == returnValue;


