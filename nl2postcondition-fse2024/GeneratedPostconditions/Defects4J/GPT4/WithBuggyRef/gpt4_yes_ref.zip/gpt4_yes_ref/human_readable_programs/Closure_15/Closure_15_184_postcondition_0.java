```java
// Check that the returnValue is true if the input node has a side effect, false otherwise
assert (returnValue == (n.isCall() && NodeUtil.functionCallHasSideEffects(n)) || (n.isNew() && NodeUtil.constructorCallHasSideEffects(n)));
```


