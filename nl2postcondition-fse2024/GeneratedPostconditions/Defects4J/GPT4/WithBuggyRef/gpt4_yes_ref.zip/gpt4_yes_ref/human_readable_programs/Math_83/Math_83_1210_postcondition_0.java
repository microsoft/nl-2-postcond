// Check if the returned RealPointValuePair's point length matches the original number of decision variables
assert returnValue.getPointRef().length == getOriginalNumDecisionVariables();


