```java
// Checks if the return value is not null when the current token is a VALUE_STRING
assert !(_currToken == JsonToken.VALUE_STRING) || returnValue != null;
```


