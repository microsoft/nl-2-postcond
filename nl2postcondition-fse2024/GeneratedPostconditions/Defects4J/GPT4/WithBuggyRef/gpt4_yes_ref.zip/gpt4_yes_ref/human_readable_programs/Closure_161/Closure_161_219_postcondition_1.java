```java
// Check if the returned node is the same as the input node when the right child is not a number
assert (right.getType() != Token.NUMBER) == (returnValue == n);
```


