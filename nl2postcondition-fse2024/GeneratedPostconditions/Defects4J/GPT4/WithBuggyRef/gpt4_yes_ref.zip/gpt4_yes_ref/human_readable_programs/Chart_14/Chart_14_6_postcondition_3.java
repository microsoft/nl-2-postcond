// Checks if the marker was removed from the specified layer and the return value is consistent with this operation
assert (returnValue == true) == (layer == Layer.FOREGROUND ? !this.foregroundDomainMarkers.get(index).contains(marker) : !this.backgroundDomainMarkers.get(index).contains(marker));


