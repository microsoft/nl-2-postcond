```java
// Check if the returnValue is true when a side effect is present in the input Node n
assert !(returnValue == true) || (n.isCall() && NodeUtil.functionCallHasSideEffects(n)) || (n.isNew() && NodeUtil.constructorCallHasSideEffects(n));
```


