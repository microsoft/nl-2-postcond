// Postcondition checks that the returnValue is a non-null Node object
assert returnValue != null && returnValue instanceof Node;


