// Check if the returned row has 1.0 in the given column and 0.0 in all other entries if the row is not null
assert returnValue == null || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(0, getWidth()).allMatch(i -> i == col || MathUtils.equals(getEntry(returnValue, i), 0.0, epsilon)));


