// Postcondition checks if the return value of visitCall has the correct type
assert returnValue.getJSType().isSubtypeOf(getJSType(child).getReturnType()) : "Return value of visitCall doesn't match the expected type";


