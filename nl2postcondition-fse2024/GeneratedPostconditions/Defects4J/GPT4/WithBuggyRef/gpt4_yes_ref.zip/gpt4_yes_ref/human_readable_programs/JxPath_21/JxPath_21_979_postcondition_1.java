```java
// Ensure the returnValue is either -1 or greater than or equal to 0 (collection length)
assert returnValue == -1 || returnValue >= 0;
```


