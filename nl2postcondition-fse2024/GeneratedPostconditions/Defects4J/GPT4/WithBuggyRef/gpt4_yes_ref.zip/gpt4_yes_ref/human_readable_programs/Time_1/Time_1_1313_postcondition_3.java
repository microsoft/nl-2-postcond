// Check if the return value is zero when both duration fields are unsupported
assert (returnValue == 0) == (!durationField.isSupported() && !this.isSupported());


