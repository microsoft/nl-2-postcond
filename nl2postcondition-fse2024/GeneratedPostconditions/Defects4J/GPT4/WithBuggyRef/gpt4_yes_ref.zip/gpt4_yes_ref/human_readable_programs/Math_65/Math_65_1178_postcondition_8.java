// Postcondition checks if the returnValue is non-negative, as the root mean square value cannot be negative
assert returnValue >= 0;


