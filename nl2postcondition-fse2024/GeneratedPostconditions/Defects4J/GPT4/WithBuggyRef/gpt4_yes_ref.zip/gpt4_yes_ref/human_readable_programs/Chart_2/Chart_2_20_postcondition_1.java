// Checks that the returned Range has a lower bound less than or equal to the upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();


