// Postcondition checks if the length of the returnValue is greater or equal to the length of the input text
assert returnValue == null || returnValue.length() >= text.length();


