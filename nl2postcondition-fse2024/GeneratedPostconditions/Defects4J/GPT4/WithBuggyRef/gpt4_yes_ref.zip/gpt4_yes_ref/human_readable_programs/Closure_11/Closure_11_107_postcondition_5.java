// Postcondition: The returned JSType of the GETPROP node is never null
assert n.getJSType() != null;


