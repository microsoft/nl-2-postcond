```java
// Checks if the 'notify' parameter is true, change event should be fired when marker is removed
assert !(returnValue && notify) || changeEventFired;
```


