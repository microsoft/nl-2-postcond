```java
// The postcondition checks if the returnValue (chi-square value) is non-negative
assert returnValue >= 0;
```


