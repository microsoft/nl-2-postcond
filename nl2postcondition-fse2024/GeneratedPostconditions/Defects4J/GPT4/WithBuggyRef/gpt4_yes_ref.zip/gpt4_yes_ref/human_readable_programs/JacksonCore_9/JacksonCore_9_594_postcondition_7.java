// Check if the returned value is a string or null when the current token is not a VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING) ? (returnValue == null || returnValue instanceof String) : true;


