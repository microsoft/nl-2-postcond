```java
// Postcondition: Checks if the returned row has 1.0 in the given column and 0.0 in all other elements of that column
assert returnValue == null || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(getNumObjectiveFunctions(), getHeight()).allMatch(i -> i == returnValue || MathUtils.equals(getEntry(i, col), 0.0, epsilon)));
```


