```java
// Asserts that the returnValue does not contain any unbalanced open or close characters
assert returnValue.chars().filter(c -> c == open).count() == returnValue.chars().filter(c -> c == close).count();
```


