```java
// Check that the length of the types and values arrays remains the same after the method execution
assert types.length == iTypes.length && values.length == iValues.length;
```


