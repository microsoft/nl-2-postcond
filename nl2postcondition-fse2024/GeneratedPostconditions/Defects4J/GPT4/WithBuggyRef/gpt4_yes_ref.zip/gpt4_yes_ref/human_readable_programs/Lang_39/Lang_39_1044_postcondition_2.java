```java
// The postcondition checks that the returnValue has the same length as the input text when all searchList elements are null or empty
assert (returnValue != null && text != null && Arrays.stream(searchList).allMatch(s -> s == null || s.isEmpty())) ? returnValue.length() == text.length() : true;
```


