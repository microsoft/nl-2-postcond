// Postcondition checks that the type of n is assigned after visitGetProp is called
assert (n.getJSType() != null || childType.isNullType() || childType.isUndefinedType()): "Node n must have a JSType assigned after visitGetProp";


