```java
// Postcondition: Check if the returned array's length is greater than the initial length and less than or equal to MAX_SEGMENT_LEN
assert returnValue.length > len && returnValue.length <= MAX_SEGMENT_LEN;
```


