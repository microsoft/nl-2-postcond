// Check if the returnValue is true when the entry represents a directory
assert (returnValue == true) == (file != null && file.isDirectory() || linkFlag == LF_DIR || getName().endsWith("/"));


