```java
// Checks if the return value is true when left and right are equal numbers
assert !(InfoSetUtil.doubleValue(left) == InfoSetUtil.doubleValue(right)) || returnValue;
```


