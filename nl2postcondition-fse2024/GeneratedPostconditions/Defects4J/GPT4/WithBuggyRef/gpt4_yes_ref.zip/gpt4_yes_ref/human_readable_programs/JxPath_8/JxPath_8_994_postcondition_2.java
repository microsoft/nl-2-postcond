```java
// Ensure that the return value is either true or false, representing the result of the comparison
assert returnValue == true || returnValue == false;
```


