// Check if the marker removal was successful and if the notify parameter is true, the returnValue must be true as well
assert !(removed && notify) || returnValue;


