```java
// The postcondition checks if the returnValue is false when the input CharSequence is empty or null
assert (isEmpty(cs) || searchChars == null) ? returnValue == false : true;
```


