```java
// Postcondition: Checks if the method returns true only if the marker was present and removed
assert returnValue == (markers.contains(marker) && removed);
```


