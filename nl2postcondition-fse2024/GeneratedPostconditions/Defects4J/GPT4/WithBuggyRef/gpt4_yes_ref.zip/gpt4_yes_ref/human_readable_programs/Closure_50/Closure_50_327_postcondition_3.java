```java
// Check if the returned Node is the same as the input node or a new node with a string value
assert returnValue == n || returnValue.getType() == Token.STRING;
```


