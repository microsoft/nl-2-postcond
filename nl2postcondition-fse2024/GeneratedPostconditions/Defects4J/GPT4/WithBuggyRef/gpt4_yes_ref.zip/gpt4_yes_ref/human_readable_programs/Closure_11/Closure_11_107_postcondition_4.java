// Check that the node n is typed after calling visitGetProp
assert n.getJSType() != null;


