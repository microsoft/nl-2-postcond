// Checks if the method returns false when the Token type is Doctype
assert !(t.type == Token.TokenType.Doctype && returnValue);


