// Check if the returned StringBuilder has the same content as the input StringBuilder with the referenced type's generic signature enclosed in angle brackets and followed by a semicolon
assert returnValue.toString().equals(sb.toString() + "<" + _referencedType.getGenericSignature(new StringBuilder()).toString() + ">;");


