// Postcondition checks if the node visited by visitGetProp has a JSType assigned to it
assert n.getJSType() != null : "Node visited by visitGetProp must have a JSType assigned";


