// Postcondition checks if the node n has a JSType assigned after visitCall execution
assert n.getJSType() != null;


