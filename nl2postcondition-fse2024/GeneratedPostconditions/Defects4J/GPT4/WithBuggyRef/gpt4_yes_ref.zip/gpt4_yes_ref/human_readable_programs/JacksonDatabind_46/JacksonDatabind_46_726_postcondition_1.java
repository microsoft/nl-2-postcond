// Check if the returned StringBuilder starts with the same content as the input StringBuilder followed by '<'
assert returnValue.toString().startsWith(sb.toString() + "<");


