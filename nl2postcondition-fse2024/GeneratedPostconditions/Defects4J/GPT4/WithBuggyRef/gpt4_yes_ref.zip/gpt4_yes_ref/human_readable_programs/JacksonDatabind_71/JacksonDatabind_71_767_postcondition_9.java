// Check if the returnValue has the same raw Class as the input parameter and is not null
assert (returnValue == null || returnValue.getRaw() == raw);


