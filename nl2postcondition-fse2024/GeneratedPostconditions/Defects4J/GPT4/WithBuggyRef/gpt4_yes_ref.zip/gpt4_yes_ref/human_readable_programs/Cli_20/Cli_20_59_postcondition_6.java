```java
// The postcondition checks if the length of returnValue is less than or equal to the length of arguments
assert returnValue.length <= arguments.length;
```


