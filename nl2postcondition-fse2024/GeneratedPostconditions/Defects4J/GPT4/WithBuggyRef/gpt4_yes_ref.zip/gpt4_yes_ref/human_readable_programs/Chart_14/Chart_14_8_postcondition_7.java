```java
// Checks if the marker is removed from the specified layer and index
assert (returnValue == true) == ((!layer.equals(Layer.FOREGROUND) ? this.backgroundDomainMarkers.get(index) : this.foregroundDomainMarkers.get(index)).contains(marker) == false);
```


