```java
// Check if the returnValue (chi-square value) is non-negative, as the sum of squared residuals divided by weights should always be non-negative
assert returnValue >= 0 : "Chi-square value must be non-negative";
```


