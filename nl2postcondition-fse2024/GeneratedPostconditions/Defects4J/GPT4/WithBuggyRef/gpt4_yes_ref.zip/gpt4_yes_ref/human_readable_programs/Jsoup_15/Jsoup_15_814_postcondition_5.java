// Check if the method returns "false" when the input token's type is Doctype
assert !(t.type == Token.TokenType.Doctype && returnValue);


