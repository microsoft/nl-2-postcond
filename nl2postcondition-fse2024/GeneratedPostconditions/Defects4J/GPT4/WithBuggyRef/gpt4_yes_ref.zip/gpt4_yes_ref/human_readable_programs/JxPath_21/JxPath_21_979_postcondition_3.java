```java
// Checks if the returned length is greater than or equal to -1, as specified in the Javadoc
assert returnValue >= -1;
```


