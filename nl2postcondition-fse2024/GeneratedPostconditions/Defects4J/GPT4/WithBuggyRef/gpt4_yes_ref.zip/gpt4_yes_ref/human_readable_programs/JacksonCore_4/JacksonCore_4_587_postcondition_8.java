// Check if the returned array has a length greater than the original array length and less than or equal to MAX_SEGMENT_LEN
assert returnValue.length > curr.length && returnValue.length <= MAX_SEGMENT_LEN;


