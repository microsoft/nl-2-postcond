// Check if the Tokeniser's state is transitioned to either RCDATAEndTagOpen or Rcdata
assert (t.getState() == RCDATAEndTagOpen || t.getState() == Rcdata) : "Tokeniser state must be either RCDATAEndTagOpen or Rcdata";


