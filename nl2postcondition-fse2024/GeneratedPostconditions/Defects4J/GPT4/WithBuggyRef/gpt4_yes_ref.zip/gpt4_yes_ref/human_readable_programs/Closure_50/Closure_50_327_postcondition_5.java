// Check if the returned node is either the original node or a modified version of it
assert returnValue == n || returnValue.getParent() == n.getParent();


