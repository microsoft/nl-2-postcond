// Check that strategies array is not null and has the same size as the number of strategies added to the collector list
assert strategies != null && strategies.length == collector.size();


