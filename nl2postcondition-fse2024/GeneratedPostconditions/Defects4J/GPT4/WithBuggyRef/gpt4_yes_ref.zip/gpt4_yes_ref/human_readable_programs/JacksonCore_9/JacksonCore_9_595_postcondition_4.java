```java
// Check that the returned value is either the same as defValue or a non-null string
assert returnValue == null || returnValue instanceof String || returnValue.equals(defValue);
```


