```java
// Check if the returned mean is within the valid range for a Hypergeometric Distribution mean
assert returnValue >= 0 && returnValue <= getSampleSize();
```


