```java
// Check if the calculated value in the returnValue matches the value from the objective function
assert Math.abs(returnValue.getValue() - f.getValue(returnValue.getPoint())) < 1e-9;
```


