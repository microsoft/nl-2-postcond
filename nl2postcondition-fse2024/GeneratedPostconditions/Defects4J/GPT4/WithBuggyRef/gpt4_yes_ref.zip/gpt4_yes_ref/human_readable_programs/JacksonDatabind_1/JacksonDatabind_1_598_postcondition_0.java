// Postcondition: Checks if the returnValue is null when the input bean is null
assert (bean == null) == (returnValue == null);


