```java
// Postcondition: Check if the returnValue is greater than or equal to 0, as RMS value is always non-negative
assert returnValue >= 0;
```


