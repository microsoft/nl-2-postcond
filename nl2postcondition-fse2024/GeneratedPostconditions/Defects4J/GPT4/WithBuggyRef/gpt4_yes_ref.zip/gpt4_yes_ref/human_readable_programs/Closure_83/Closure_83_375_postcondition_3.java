// Check if the returnValue is either 0 or 1, ensuring the method returns the expected values
assert returnValue == 0 || returnValue == 1;


