// Postcondition checks if the marker is removed from the specified layer's markers list for the given index
assert !returnValue || !(layer == Layer.FOREGROUND ? this.foregroundDomainMarkers.get(new Integer(index)) : this.backgroundDomainMarkers.get(new Integer(index))).contains(marker);


