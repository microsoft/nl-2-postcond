// Checks if the returned StringBuilder has a ';' at the last index
assert returnValue.charAt(returnValue.length() - 1) == ';';


