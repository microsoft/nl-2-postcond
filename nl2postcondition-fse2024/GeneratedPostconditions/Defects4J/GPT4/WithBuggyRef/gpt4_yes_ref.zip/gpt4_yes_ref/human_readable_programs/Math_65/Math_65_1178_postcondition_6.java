```java
// Check if the returned RMS value is non-negative, since the root of a sum of squared values should always be non-negative
assert returnValue >= 0;
```


