```java
// Checks if the returnValue is correct based on whether the given parameter is in TRUES or FALSES set
assert (returnValue == 1 && (TRUES.contains(params.getParameter(0).toLowerCase()) || FALSES.contains(params.getParameter(0).toLowerCase()))) || (returnValue == 0 && !TRUES.contains(params.getParameter(0).toLowerCase()) && !FALSES.contains(params.getParameter(0).toLowerCase()));
```


