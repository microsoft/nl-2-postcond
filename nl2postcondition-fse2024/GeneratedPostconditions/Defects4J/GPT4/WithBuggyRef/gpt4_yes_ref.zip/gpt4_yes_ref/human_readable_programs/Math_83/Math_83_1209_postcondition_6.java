```java
import java.util.stream.IntStream;

// Check if the returned row contains 1.0 in the given column and 0.0 in all other positions in the row
assert returnValue == null || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(0, tableau.getColumnDimension()).allMatch(j -> j == col || MathUtils.equals(getEntry(returnValue, j), 0.0, epsilon)));
```


