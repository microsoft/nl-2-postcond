```java
// Postcondition: If the returnValue is not null, the entry at (returnValue, col) must be equal to 1.0 and all other entries in the same column must be 0.0.
assert returnValue == null || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(getNumObjectiveFunctions(), getHeight()).filter(i -> i != returnValue).allMatch(i -> MathUtils.equals(getEntry(i, col), 0.0, epsilon)));
```


