```java
// Check if the returnValue is non-negative, as chi-square value cannot be negative
assert returnValue >= 0 : "Chi-square value must be non-negative";
```


