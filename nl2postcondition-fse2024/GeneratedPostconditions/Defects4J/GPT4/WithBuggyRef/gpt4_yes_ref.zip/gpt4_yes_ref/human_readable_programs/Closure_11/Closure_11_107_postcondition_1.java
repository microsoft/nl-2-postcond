// Postcondition: Checks if the type of the node n is set after visiting GetProp
assert n.getJSType() != null : "The type of the node should be set after visiting GetProp";


