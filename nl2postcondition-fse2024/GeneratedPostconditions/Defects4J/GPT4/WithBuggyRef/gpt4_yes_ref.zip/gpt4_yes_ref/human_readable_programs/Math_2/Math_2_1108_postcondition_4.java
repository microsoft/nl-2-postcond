```java
// Check if the returnValue is within the expected range of valid values for the mean of a hypergeometric distribution
assert returnValue >= 0 && returnValue <= Math.min(getSampleSize(), getNumberOfSuccesses());
```


