// Check if the Tokeniser's state has transitioned according to the input CharacterReader
assert (t.getState() == (r.matches('/') ? RCDATAEndTagOpen : Rcdata)) : "Tokeniser state transition failed";


