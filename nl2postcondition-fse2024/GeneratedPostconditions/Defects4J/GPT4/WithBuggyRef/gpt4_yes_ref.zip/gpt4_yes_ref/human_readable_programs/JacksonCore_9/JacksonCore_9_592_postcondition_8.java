```java
// Postcondition: The return value is non-null if the current token is a scalar value or a string value
assert (_currToken == null || !_currToken.isScalarValue()) || returnValue != null;
```


