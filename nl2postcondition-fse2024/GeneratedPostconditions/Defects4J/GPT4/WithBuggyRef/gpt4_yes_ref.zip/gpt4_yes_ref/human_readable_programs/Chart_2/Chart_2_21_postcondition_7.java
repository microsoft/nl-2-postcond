```java
// Postcondition: Check if the returned range has minimum and maximum values within the dataset's bounds
assert returnValue == null || Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(series -> IntStream.range(0, dataset.getItemCount(series)).mapToDouble(item -> dataset.getYValue(series, item)).filter(value -> !Double.isNaN(value)).boxed().collect(Collectors.toList())).flatMap(Collection::stream).toArray(Double[]::new)).min(Double::compare).orElse(Double.POSITIVE_INFINITY) >= returnValue.getLowerBound() && Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(series -> IntStream.range(0, dataset.getItemCount(series)).mapToDouble(item -> dataset.getYValue(series, item)).filter(value -> !Double.isNaN(value)).boxed().collect(Collectors.toList())).flatMap(Collection::stream).toArray(Double[]::new)).max(Double::compare).orElse(Double.NEGATIVE_INFINITY) <= returnValue.getUpperBound();
```


