// Check if the Tokeniser's state transition is as expected
assert (t.getState() == RCDATAEndTagOpen && r.matches('/')) || (t.getState() == Rcdata && !r.matches('/')) : "Postcondition: Tokeniser's state transition is not as expected";


