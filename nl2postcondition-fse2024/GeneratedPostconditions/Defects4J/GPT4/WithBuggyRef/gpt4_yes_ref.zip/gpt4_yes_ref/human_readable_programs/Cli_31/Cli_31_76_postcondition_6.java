// Checks if the option is added to the buffer and the buffer length is increased
assert (required ? buff.length() <= buff.append(option.getOpt() != null ? option.getOpt() : option.getLongOpt()).length() : buff.length() < buff.append("[").append(option.getOpt() != null ? option.getOpt() : option.getLongOpt()).append("]").length());


