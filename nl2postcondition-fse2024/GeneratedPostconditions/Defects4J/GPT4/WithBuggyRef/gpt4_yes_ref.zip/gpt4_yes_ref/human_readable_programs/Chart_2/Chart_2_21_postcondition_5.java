// Checks if the returnValue range has minimum value less than or equal to maximum value
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();


