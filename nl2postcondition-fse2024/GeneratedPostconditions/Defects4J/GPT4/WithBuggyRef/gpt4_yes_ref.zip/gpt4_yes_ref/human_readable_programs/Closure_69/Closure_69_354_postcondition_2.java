// Postcondition checks if the return value has the same type as the function type's return type or is a subtype of it
assert returnValue.isSubtypeOf(getJSType(n.getFirstChild()).restrictByNotNullOrUndefined().isFunctionType() ? ((FunctionType) getJSType(n.getFirstChild()).restrictByNotNullOrUndefined()).getReturnType() : getNativeType(UNKNOWN_TYPE));


