```java
// Check if the returnValue is equal to the expected mean value
assert returnValue == (double) (getSampleSize() * getNumberOfSuccesses()) / (double) getPopulationSize();
```


