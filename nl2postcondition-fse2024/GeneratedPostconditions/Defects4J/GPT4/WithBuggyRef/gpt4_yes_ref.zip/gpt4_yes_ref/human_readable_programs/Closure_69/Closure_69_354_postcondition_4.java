// Postcondition checks if the returnValue has the same type as the return type of the called function
assert !(childType instanceof FunctionType) || returnValue.getJSType().isSubtypeOf(((FunctionType) childType).getReturnType());


