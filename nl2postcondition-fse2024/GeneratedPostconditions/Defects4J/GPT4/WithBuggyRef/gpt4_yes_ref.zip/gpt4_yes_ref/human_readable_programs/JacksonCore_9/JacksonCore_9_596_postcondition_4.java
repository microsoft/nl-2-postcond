```java
// Check if the returned value is a string when the current token is VALUE_STRING
assert !(_currToken == JsonToken.VALUE_STRING) || (returnValue instanceof String);
```


