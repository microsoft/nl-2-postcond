// Checks if the Tokeniser's state has changed after calling the read method
assert t.getState() != t.getPreviousState();


