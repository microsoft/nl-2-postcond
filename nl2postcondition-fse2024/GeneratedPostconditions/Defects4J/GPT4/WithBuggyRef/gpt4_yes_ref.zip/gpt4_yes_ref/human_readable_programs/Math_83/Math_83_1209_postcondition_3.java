```java
// Postcondition: Checks if the returned row is either null or has a 1.0 at the given column and all other entries are 0.0
assert (returnValue == null) || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(getNumObjectiveFunctions(), getHeight()).filter(i -> i != returnValue).allMatch(i -> MathUtils.equals(getEntry(i, col), 0.0, epsilon)));
```


