// Check if the marker was removed from the corresponding layer and dataset index
assert (returnValue == false && markers.contains(marker)) || (returnValue == true && !markers.contains(marker));


