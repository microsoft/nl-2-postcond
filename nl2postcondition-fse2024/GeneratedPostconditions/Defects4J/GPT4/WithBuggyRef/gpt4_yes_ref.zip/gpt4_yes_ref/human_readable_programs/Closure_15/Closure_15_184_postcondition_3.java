```
// Checks if the returned value is true when n is a function call or a constructor call with side effects
assert !(returnValue || (n.isCall() && NodeUtil.functionCallHasSideEffects(n)) || (n.isNew() && NodeUtil.constructorCallHasSideEffects(n)));
```


