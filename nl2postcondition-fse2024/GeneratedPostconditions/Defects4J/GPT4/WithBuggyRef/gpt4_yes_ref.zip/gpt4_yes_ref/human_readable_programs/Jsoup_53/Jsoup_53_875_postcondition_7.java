```java
// Check that the returned string contains only balanced pairs of open and close characters
assert Arrays.stream(returnValue.split(Pattern.quote(String.valueOf(open))))
            .skip(1) // skip the first element (before the first open character)
            .allMatch(chunk -> chunk.chars().filter(ch -> ch == close).count() == 1);
```


