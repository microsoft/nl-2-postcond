```java
// Check if the returned value is either the text value or null when the method executed successfully
assert (_currToken == JsonToken.VALUE_STRING && returnValue.equals(getText())) || (_currToken != JsonToken.VALUE_STRING && returnValue == null);
```


