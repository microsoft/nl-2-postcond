// Check that the returnValue is true if and only if the marker is removed from the specified layer's markers list
assert returnValue == (layer == Layer.FOREGROUND ? this.foregroundRangeMarkers.get(index).contains(marker) : this.backgroundRangeMarkers.get(index).contains(marker));


