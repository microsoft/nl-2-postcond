```java
// Postcondition: Checks if the number of occurrences of each search string in the return value is 0
import java.util.Arrays;
assert Arrays.stream(searchList).allMatch(search -> search == null || returnValue.indexOf(search) == -1);
```


