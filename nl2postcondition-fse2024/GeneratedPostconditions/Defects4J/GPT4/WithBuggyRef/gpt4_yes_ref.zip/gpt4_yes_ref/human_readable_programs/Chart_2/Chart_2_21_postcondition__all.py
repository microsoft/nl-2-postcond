
# Response 0
// Check if the returned range has minimum and maximum values within the dataset's Y values
assert returnValue == null || (returnValue.getLowerBound() <= returnValue.getUpperBound() && dataset.getSeriesCount() > 0 && IntStream.range(0, dataset.getSeriesCount()).flatMap(series -> IntStream.range(0, dataset.getItemCount(series))).allMatch(item -> Double.isNaN(dataset.getYValue(series, item)) || (dataset.getYValue(series, item) >= returnValue.getLowerBound() && dataset.getYValue(series, item) <= returnValue.getUpperBound())));



# Response 1
// Check if the returned range is non-null, then its lower bound should be less than or equal to its upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();



# Response 2
// Check if the returned range has minimum and maximum values within the dataset bounds
assert returnValue == null || (returnValue.getLowerBound() >= getMinimumValue(dataset, includeInterval) && returnValue.getUpperBound() <= getMaximumValue(dataset, includeInterval));

private static double getMinimumValue(XYDataset dataset, boolean includeInterval) {
    double minimum = Double.POSITIVE_INFINITY;
    int seriesCount = dataset.getSeriesCount();
    for (int series = 0; series < seriesCount; series++) {
        int itemCount = dataset.getItemCount(series);
        for (int item = 0; item < itemCount; item++) {
            double value = dataset.getYValue(series, item);
            if (includeInterval && dataset instanceof IntervalXYDataset) {
                value = Math.min(value, ((IntervalXYDataset) dataset).getStartYValue(series, item));
            }
            if (!Double.isNaN(value)) {
                minimum = Math.min(minimum, value);
            }
        }
    }
    return minimum;
}

private static double getMaximumValue(XYDataset dataset, boolean includeInterval) {
    double maximum = Double.NEGATIVE_INFINITY;
    int seriesCount = dataset.getSeriesCount();
    for (int series = 0; series < seriesCount; series++) {
        int itemCount = dataset.getItemCount(series);
        for (int item = 0; item < itemCount; item++) {
            double value = dataset.getYValue(series, item);
            if (includeInterval && dataset instanceof IntervalXYDataset) {
                value = Math.max(value, ((IntervalXYDataset) dataset).getEndYValue(series, item));
            }
            if (!Double.isNaN(value)) {
                maximum = Math.max(maximum, value);
            }
        }
    }
    return maximum;
}



# Response 3
// Postcondition checks if the returned range has minimum and maximum values within the dataset's range
assert returnValue == null || (dataset.getSeriesCount() == 0) || (Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(i -> IntStream.range(0, dataset.getItemCount(i)).mapToDouble(j -> dataset.getYValue(i, j)).toArray()).flatMapToInt(Arrays::stream).toArray()).min().getAsDouble() >= returnValue.getLowerBound() && Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(i -> IntStream.range(0, dataset.getItemCount(i)).mapToDouble(j -> dataset.getYValue(i, j)).toArray()).flatMapToInt(Arrays::stream).toArray()).max().getAsDouble() <= returnValue.getUpperBound());



# Response 4
// The postcondition checks if the returned range has the correct lower and upper bounds considering only valid (non-NaN) values in the dataset
assert returnValue == null || (
    Arrays.stream(dataset.getSeriesKeys())
        .flatMapToInt(seriesKey -> IntStream.range(0, dataset.getItemCount(dataset.indexOf(seriesKey))))
        .filter(i -> !Double.isNaN(dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .mapToDouble(i -> dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .min().orElse(Double.POSITIVE_INFINITY) == returnValue.getLowerBound() &&
    Arrays.stream(dataset.getSeriesKeys())
        .flatMapToInt(seriesKey -> IntStream.range(0, dataset.getItemCount(dataset.indexOf(seriesKey))))
        .filter(i -> !Double.isNaN(dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .mapToDouble(i -> dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .max().orElse(Double.NEGATIVE_INFINITY) == returnValue.getUpperBound()
);



# Response 5
// Checks if the returnValue range has minimum value less than or equal to maximum value
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();



# Response 6
// Checks if the returned range has minimum and maximum values within the dataset's values or is null
assert (returnValue == null) || (returnValue.getLowerBound() <= returnValue.getUpperBound() && Arrays.stream(dataset.toValueArray()).noneMatch(value -> value < returnValue.getLowerBound() || value > returnValue.getUpperBound()));



# Response 7
```java
// Postcondition: Check if the returned range has minimum and maximum values within the dataset's bounds
assert returnValue == null || Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(series -> IntStream.range(0, dataset.getItemCount(series)).mapToDouble(item -> dataset.getYValue(series, item)).filter(value -> !Double.isNaN(value)).boxed().collect(Collectors.toList())).flatMap(Collection::stream).toArray(Double[]::new)).min(Double::compare).orElse(Double.POSITIVE_INFINITY) >= returnValue.getLowerBound() && Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(series -> IntStream.range(0, dataset.getItemCount(series)).mapToDouble(item -> dataset.getYValue(series, item)).filter(value -> !Double.isNaN(value)).boxed().collect(Collectors.toList())).flatMap(Collection::stream).toArray(Double[]::new)).max(Double::compare).orElse(Double.NEGATIVE_INFINITY) <= returnValue.getUpperBound();
```



# Response 8
// Check if the returned range has minimum and maximum values within the dataset bounds
assert returnValue == null || (returnValue.getLowerBound() >= dataset.getSeriesCount() && returnValue.getUpperBound() <= dataset.getSeriesCount());



# Response 9
// The postcondition checks that the returned range has minimum and maximum values within the dataset's Y-value bounds
assert returnValue == null || (returnValue.getLowerBound() <= returnValue.getUpperBound() && dataset.getSeriesCount() > 0);


