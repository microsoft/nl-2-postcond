```java
// Postcondition: The returned array's length is greater than the original array and less or equal to MAX_SEGMENT_LEN
assert returnValue.length > curr.length && returnValue.length <= MAX_SEGMENT_LEN;
```


