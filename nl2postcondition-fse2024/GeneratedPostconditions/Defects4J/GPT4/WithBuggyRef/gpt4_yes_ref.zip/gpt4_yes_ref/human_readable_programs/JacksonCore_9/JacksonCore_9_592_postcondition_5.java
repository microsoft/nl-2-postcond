```java
// Check if the returned value is either the text value, null or an empty string when the current token is not a VALUE_STRING
assert (_currToken == JsonToken.VALUE_STRING || returnValue == null || returnValue.isEmpty());
```


