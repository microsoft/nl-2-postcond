// Postcondition checks if the returnValue is 0 when both duration fields are unsupported, or non-zero when the input duration field is supported
assert (returnValue == 0) == (!durationField.isSupported() && !this.isSupported());


