```
// Check if the returned string is equal to the contents of _textBuffer when _currToken is VALUE_STRING
assert !(_currToken == JsonToken.VALUE_STRING) || returnValue.equals(_textBuffer.contentsAsString());
```


