```
// Ensure that the returned value is a non-null string when the current token is a value string
assert !(_currToken == JsonToken.VALUE_STRING) || (returnValue != null);
```


