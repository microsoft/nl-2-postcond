// Checks that the length of the accumulated string after normalization is less than or equal to the input string's length
assert accum.length() <= string.length();


