```java
// Check if the returned value is a string representation of the current token or null if the current token is not a VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING && returnValue == null) || (_currToken == JsonToken.VALUE_STRING && returnValue instanceof String);
```


