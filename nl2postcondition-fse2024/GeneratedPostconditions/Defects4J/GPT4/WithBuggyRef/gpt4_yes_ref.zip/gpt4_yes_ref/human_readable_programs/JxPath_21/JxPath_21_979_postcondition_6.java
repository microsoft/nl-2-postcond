```java
// Check if the returned length is -1 when the property doesn't contain a collection or non-negative when it does
assert (returnValue == -1 && !ValueUtils.isCollection(getBaseValue())) || (returnValue >= 0 && ValueUtils.isCollection(getBaseValue()));
```


