```java
// Check if the returnValue is equal to defaultValue when _currToken is not a scalar value or is null or is VALUE_NULL
assert !(returnValue.equals(defaultValue)) || (_currToken == null || _currToken == JsonToken.VALUE_NULL || !_currToken.isScalarValue());
```


