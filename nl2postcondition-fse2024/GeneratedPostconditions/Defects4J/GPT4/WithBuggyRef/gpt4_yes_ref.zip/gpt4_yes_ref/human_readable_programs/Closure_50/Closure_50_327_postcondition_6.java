// Check if the returned node is either the same as the input node or a string node
assert (returnValue == n) || (returnValue.getType() == Token.STRING);


