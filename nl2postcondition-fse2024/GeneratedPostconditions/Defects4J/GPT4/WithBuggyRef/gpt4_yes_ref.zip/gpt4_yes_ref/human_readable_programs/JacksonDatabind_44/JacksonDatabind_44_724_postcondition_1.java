```java
// Check that the returned JavaType instance has the given subclass as its _class field
assert (returnValue._class == subclass);
```


