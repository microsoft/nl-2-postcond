// Postcondition checks that the length of the returned string is equal to or less than the input text length
assert returnValue == null || returnValue.length() <= text.length();


