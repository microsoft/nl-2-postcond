// Checks if the returned array is larger than the original array and not exceeding the max segment length
assert returnValue.length > curr.length && returnValue.length <= MAX_SEGMENT_LEN;


