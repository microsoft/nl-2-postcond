```java
// Checks that the length of the accumulated string is greater than or equal to the length of the normalized string
assert accum.length() >= normaliseWhitespace(string).length();
```


