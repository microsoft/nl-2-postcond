// The postcondition checks that the returned range has minimum and maximum values within the dataset's Y-value bounds
assert returnValue == null || (returnValue.getLowerBound() <= returnValue.getUpperBound() && dataset.getSeriesCount() > 0);


