```java
// Asserts that if the returnValue is true, there exists at least one character in the searchChars that is present in cs
assert !returnValue || java.util.stream.IntStream.range(0, searchChars.length).anyMatch(i -> cs.toString().indexOf(searchChars[i]) >= 0);
```


