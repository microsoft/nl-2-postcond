```java
// Check if the returned length is either -1 or non-negative (for collections)
assert returnValue == -1 || returnValue >= 0 : "Returned length must be either -1 or non-negative";
```


