```java
// Check if the types and values arrays have the same length after Partial is constructed
assert iTypes.length == iValues.length;
```


