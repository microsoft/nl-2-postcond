```java
// Check that the returnValue (RMS value) is non-negative
assert returnValue >= 0 : "The RMS value should be non-negative";
```


