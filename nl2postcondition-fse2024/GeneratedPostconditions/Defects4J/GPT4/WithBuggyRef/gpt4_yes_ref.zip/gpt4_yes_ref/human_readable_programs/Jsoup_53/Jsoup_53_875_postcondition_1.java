```java
// Check if the returned value contains the correct number of opening and closing characters
assert returnValue.chars().filter(c -> c == open).count() == returnValue.chars().filter(c -> c == close).count();
```


