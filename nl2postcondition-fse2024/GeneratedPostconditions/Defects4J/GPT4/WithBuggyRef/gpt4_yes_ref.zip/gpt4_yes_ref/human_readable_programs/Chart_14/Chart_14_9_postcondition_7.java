```java
// Postcondition checks if the marker was removed when returnValue is true
assert (returnValue == false) || (returnValue == true && !markers.contains(marker));
```


