// This postcondition checks if the returnValue is true, then the marker should no longer exist in the corresponding markers list
assert !returnValue || !((layer == Layer.FOREGROUND) ? this.foregroundRangeMarkers.get(new Integer(index)) : this.backgroundRangeMarkers.get(new Integer(index))).contains(marker);


