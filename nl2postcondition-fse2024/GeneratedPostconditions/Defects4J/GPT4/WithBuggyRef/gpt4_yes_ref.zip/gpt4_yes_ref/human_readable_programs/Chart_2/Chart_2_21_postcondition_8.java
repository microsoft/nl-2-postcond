// Check if the returned range has minimum and maximum values within the dataset bounds
assert returnValue == null || (returnValue.getLowerBound() >= dataset.getSeriesCount() && returnValue.getUpperBound() <= dataset.getSeriesCount());


