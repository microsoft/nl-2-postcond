```java
// Postcondition: The returned string should have balanced open and close characters
int balancedCount = returnValue.chars().map(c -> (c == open) ? 1 : ((c == close) ? -1 : 0)).sum();
assert balancedCount == 0;
```


