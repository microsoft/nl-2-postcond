// Checks if the returned string from chompBalanced has balanced occurrences of open and close characters
assert returnValue.chars().filter(ch -> ch == open).count() == returnValue.chars().filter(ch -> ch == close).count();


