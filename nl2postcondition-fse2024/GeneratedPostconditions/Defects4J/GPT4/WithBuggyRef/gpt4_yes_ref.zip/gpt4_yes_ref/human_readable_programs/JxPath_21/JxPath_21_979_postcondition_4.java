```java
// Check if the returned length is either -1 or non-negative (>=0)
assert returnValue == -1 || returnValue >= 0 : "Returned length is not -1 or non-negative";
```


