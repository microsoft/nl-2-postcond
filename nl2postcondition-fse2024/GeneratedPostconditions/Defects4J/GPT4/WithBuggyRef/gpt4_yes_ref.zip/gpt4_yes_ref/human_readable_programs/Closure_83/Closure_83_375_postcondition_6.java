// Check if the returnValue is either 0 or 1, respecting the expected range of return values
assert returnValue == 0 || returnValue == 1;


