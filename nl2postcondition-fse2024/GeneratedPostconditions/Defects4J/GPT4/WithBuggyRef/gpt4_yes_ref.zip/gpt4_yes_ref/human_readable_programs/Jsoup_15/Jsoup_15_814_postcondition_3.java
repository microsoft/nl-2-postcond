// Check if the process method returns true when the input Token is not Doctype
assert (t.type != Token.TokenType.Doctype) || (returnValue == false);


