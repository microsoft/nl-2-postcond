// Check if the returned StringBuilder has increased in length by 2 compared to the input StringBuilder
assert returnValue.length() == sb.length() + 2;


