// Check that the return value JSType is a subtype of the callee's return type
assert returnValue.isSubtypeOf(getJSType(n.getFirstChild()).restrictByNotNullOrUndefined().toMaybeFunctionType().getReturnType());


