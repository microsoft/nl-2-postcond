```java
// Check if the returned node is either the original node or a folded array access element
assert (returnValue == n) || (returnValue.getParent() == parent && returnValue != left && returnValue != right);
```


