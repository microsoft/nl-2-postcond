// Check if the marker is removed from the corresponding list of markers in the specified layer
assert (layer == Layer.FOREGROUND ? !((ArrayList) this.foregroundDomainMarkers.get(new Integer(index))).contains(marker) : !((ArrayList) this.backgroundDomainMarkers.get(new Integer(index))).contains(marker)) == returnValue;


