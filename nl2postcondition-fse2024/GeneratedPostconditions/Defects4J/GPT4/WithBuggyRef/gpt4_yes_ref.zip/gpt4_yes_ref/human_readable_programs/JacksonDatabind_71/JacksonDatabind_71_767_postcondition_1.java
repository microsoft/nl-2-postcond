// Check if the returned StdKeyDeserializer's type matches the input raw class
assert (returnValue == null) || (raw.isAssignableFrom(returnValue.getValueClass()));


