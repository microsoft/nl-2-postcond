// Checks if the column is basic and the returned row is unique
assert (returnValue == null) || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(getNumObjectiveFunctions(), getHeight()).filter(i -> MathUtils.equals(getEntry(i, col), 1.0, epsilon)).count() == 1);


