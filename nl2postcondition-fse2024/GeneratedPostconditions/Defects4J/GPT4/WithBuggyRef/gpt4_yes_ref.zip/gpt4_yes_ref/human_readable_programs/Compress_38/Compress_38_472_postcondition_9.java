// Check if the returnValue is consistent with the linkFlag and name of the entry
assert returnValue == ((file != null && file.isDirectory()) || (linkFlag == LF_DIR) || (getName().endsWith("/")));


