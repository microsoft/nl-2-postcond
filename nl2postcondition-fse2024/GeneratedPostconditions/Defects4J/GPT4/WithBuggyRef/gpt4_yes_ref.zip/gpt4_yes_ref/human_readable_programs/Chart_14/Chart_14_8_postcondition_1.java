```java
// Checks if the marker was removed if the return value is true
assert !returnValue || !markers.contains(marker);
```


