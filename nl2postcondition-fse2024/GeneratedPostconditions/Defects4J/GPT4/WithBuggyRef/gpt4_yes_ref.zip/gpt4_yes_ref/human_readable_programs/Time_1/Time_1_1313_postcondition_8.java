// Checks if the returned value is zero when both input and the UnsupportedDurationField are unsupported
assert (returnValue == 0) == (!durationField.isSupported());


