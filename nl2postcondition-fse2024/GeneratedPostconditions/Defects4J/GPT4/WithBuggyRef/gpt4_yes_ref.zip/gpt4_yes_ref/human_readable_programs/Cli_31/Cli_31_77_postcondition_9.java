// Checks if the member variables are reset to their default values after calling reset()
assert description == null && argName.equals("arg") && longopt == null && type == null && !required && numberOfArgs == Option.UNINITIALIZED && !optionalArg && valuesep == (char) 0 : "Postcondition: Member variables not reset to default values";


