```java
// Check if the returned value is true when both methods are the same, and false when they are different
assert returnValue == (invocation.getMethod().equals(candidate.getMethod()));
```


