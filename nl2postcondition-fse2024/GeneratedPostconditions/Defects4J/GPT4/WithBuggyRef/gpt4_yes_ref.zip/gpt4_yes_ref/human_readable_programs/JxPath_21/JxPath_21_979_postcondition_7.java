```java
// Check if the returned length is either -1 or non-negative (i.e., a valid collection length)
assert returnValue == -1 || returnValue >= 0 : "Returned length should be either -1 or a non-negative value";
```


