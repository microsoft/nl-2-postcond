```java
// Checks if the marker is removed from the corresponding markers list
assert (layer == Layer.FOREGROUND ? this.foregroundDomainMarkers.get(new Integer(index)).contains(marker) : this.backgroundDomainMarkers.get(new Integer(index)).contains(marker)) != returnValue;
```


