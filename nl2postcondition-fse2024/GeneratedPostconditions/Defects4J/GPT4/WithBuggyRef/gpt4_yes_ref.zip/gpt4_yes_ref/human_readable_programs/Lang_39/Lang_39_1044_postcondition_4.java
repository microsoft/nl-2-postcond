// Postcondition checks if the method has not modified the input text when searchList or replacementList are empty or null
assert (searchList == null || searchList.length == 0 || replacementList == null || replacementList.length == 0) ? text == returnValue : true;


