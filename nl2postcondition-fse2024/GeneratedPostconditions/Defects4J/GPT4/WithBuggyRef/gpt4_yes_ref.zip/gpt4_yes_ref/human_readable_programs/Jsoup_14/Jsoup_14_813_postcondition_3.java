// Check if the transition has been changed to either RCDATAEndTagOpen or Rcdata based on the input CharacterReader
assert (t.getState() == TokeniserState.RCDATAEndTagOpen && r.peek() == '/') || (t.getState() == TokeniserState.Rcdata && r.peek() != '/');


