// Postcondition checks if the returnValue is null when the bean's value is null and _nullSerializer is null
assert (returnValue == null) == (bean == null && _nullSerializer == null);


