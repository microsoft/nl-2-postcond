// Checks if the returned range has minimum and maximum values within the dataset's values or is null
assert (returnValue == null) || (returnValue.getLowerBound() <= returnValue.getUpperBound() && Arrays.stream(dataset.toValueArray()).noneMatch(value -> value < returnValue.getLowerBound() || value > returnValue.getUpperBound()));


