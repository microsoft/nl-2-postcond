// Check if the returnValue is non-negative, as the chi-square value should be greater than or equal to zero
assert returnValue >= 0 : "The chi-square value should be non-negative";


