```java
import java.util.stream.IntStream;

// Check that the returnValue is the sum of element-wise product of arrays a and b
assert Math.abs(IntStream.range(0, a.length).mapToDouble(i -> a[i] * b[i]).sum() - returnValue) < 1e-10;
```


