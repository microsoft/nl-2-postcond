```java
// Check if the returned length is either -1 or non-negative and less or equal to the length of the base value
assert returnValue == -1 || (returnValue >= 0 && returnValue <= ValueUtils.getLength(getBaseValue()));
```


