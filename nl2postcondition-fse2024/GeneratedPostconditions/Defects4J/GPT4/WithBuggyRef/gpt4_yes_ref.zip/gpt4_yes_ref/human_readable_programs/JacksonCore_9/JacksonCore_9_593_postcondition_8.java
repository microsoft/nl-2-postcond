```java
// Check if the returnValue is either the defaultValue or the text representation of the current token if it is a scalar value
assert (returnValue == defaultValue) || (_currToken != null && _currToken.isScalarValue() && returnValue.equals(getText()));
```


