// Postcondition: The returnValue (Node) has the same parent as the input Node n
assert returnValue.getParent() == n.getParent();


