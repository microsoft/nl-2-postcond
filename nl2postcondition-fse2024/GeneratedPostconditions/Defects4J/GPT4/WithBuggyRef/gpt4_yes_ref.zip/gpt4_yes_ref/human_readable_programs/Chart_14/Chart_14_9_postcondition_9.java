// Checks if the marker is actually removed from the specified layer and dataset/renderer index
assert returnValue == (layer == Layer.FOREGROUND ? this.foregroundRangeMarkers.get(index).contains(marker) : this.backgroundRangeMarkers.get(index).contains(marker));


