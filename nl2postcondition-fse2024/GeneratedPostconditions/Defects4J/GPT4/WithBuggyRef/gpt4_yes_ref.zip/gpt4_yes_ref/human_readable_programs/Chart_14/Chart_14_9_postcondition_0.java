// Check if the marker was removed and notify flag is true, a change event should be fired
assert !(returnValue && notify) || (returnValue && notify && isChangeEventFired());


