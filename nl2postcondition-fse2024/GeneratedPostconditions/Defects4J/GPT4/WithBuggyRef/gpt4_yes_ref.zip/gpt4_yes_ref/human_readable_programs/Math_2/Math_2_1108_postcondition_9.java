```java
// Checks if the returned mean value is within the possible range given the sample size and population size
assert returnValue >= 0 && returnValue <= (double) getSampleSize();
```


