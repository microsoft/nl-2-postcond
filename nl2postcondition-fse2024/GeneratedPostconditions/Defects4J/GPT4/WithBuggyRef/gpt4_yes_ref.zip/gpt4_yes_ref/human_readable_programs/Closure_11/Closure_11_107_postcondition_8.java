// Postcondition: Checks if the type of the GETPROP node has been set
assert n.getJSType() != null;


