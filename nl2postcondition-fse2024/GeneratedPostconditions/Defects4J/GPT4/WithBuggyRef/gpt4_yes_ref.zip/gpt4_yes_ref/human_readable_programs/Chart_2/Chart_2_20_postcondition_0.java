// The postcondition checks if the returned Range has minimum and maximum values within the dataset's x-values
assert returnValue == null || (returnValue.getLowerBound() <= returnValue.getUpperBound() && dataset.getSeriesCount() > 0 && IntStream.range(0, dataset.getSeriesCount()).flatMap(series -> IntStream.range(0, dataset.getItemCount(series))).anyMatch(item -> dataset.getXValue(series, item) >= returnValue.getLowerBound() && dataset.getXValue(series, item) <= returnValue.getUpperBound()));


