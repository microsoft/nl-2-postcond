```java
// Check if the length of the resulting StringBuilder is less than or equal to the input string length
assert accum.length() <= string.length();
```


