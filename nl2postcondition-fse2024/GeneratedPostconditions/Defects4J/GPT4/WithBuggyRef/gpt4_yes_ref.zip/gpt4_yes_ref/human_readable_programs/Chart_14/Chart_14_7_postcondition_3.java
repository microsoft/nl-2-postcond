```java
// Postcondition: The returnValue indicates whether the marker was removed from the specified layer's markers list
assert returnValue == (layer == Layer.FOREGROUND ? this.foregroundRangeMarkers.get(index).contains(marker) : this.backgroundRangeMarkers.get(index).contains(marker)) == false;
```


