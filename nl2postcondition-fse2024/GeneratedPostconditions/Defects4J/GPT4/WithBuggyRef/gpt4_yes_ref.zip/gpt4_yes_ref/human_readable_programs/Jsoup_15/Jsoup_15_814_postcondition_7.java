// The postcondition checks if the returnValue is true when the input Token t is not of type Doctype
assert (t.type != Token.TokenType.Doctype) || !returnValue;


