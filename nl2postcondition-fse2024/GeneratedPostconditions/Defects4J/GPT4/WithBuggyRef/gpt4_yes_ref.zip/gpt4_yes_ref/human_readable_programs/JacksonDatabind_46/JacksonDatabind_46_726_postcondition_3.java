// Check if the returned StringBuilder starts with the original StringBuilder and ends with '<' and ';'
assert returnValue.toString().startsWith(sb.toString()) && returnValue.charAt(returnValue.length() - 2) == '<' && returnValue.charAt(returnValue.length() - 1) == ';';


