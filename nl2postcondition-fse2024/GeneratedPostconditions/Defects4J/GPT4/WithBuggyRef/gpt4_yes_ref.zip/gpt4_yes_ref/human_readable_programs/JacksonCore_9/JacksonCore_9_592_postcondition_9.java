```
// The postcondition checks that the returnValue is either null or non-empty when the current token is a value string
assert (_currToken != JsonToken.VALUE_STRING || (returnValue != null && !returnValue.isEmpty()));
```


