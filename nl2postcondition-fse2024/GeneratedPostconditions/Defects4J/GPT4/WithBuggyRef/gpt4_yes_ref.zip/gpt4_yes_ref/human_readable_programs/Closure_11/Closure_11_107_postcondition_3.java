// Checks if the node type is not a function after calling visitGetProp
assert !n.isFunction() || n.getJSType().isFunctionType() || n.getJSType().isUnknownType();


