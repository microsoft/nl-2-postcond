```java
// The postcondition checks if the return value is false when the input CharSequence or searchChars array is null or empty
assert (cs == null || searchChars == null || cs.length() == 0 || searchChars.length == 0) == !returnValue;
```


