```java
// Checks if the return value's class is the same as the input subclass
assert returnValue.getRawClass() == subclass;
```


