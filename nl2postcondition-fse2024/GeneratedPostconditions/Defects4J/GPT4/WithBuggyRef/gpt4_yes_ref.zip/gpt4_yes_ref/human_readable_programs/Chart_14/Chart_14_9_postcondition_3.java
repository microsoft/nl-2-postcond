// Check if the method returns true when a marker is removed, and false when a marker is not removed
assert (returnValue == true) == (markers.contains(marker) && !markers.remove(marker));


