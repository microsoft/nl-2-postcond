// Postcondition checks if the returned range has minimum and maximum values within the dataset's range
assert returnValue == null || (dataset.getSeriesCount() == 0) || (Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(i -> IntStream.range(0, dataset.getItemCount(i)).mapToDouble(j -> dataset.getYValue(i, j)).toArray()).flatMapToInt(Arrays::stream).toArray()).min().getAsDouble() >= returnValue.getLowerBound() && Arrays.stream(IntStream.range(0, dataset.getSeriesCount()).mapToObj(i -> IntStream.range(0, dataset.getItemCount(i)).mapToDouble(j -> dataset.getYValue(i, j)).toArray()).flatMapToInt(Arrays::stream).toArray()).max().getAsDouble() <= returnValue.getUpperBound());


