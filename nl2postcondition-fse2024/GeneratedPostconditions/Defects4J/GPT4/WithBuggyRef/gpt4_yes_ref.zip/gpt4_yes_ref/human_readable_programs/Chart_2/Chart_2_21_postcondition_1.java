// Check if the returned range is non-null, then its lower bound should be less than or equal to its upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();


