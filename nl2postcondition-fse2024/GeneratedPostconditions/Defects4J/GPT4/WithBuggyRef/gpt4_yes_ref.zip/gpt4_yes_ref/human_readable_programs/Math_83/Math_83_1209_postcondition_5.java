```java
// Postcondition checks if the returnValue is null or within the valid row range
assert returnValue == null || (returnValue >= getNumObjectiveFunctions() && returnValue < getHeight());
```


