// Check if the returned StringBuilder has an opening and closing angle bracket (representing the generic part of the signature)
assert returnValue.indexOf('<') != -1 && returnValue.lastIndexOf('>') != -1;


