// Check if the types and values arrays have the same length after successful construction of the Partial object
assert iTypes.length == iValues.length;


