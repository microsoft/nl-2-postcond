```java
// Postcondition checks if the returnValue is either 0 or 1, as specified in the method's behavior
assert returnValue == 0 || returnValue == 1;
```


