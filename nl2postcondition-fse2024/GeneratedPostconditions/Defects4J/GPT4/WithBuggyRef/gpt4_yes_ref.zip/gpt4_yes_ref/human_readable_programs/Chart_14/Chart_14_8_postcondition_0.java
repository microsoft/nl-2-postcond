// Checks if the marker is removed from the corresponding layer's markers list
assert (layer == Layer.FOREGROUND ? !((ArrayList) this.foregroundDomainMarkers.get(new Integer(index))).contains(marker) : !((ArrayList) this.backgroundDomainMarkers.get(new Integer(index))).contains(marker)) == returnValue;


