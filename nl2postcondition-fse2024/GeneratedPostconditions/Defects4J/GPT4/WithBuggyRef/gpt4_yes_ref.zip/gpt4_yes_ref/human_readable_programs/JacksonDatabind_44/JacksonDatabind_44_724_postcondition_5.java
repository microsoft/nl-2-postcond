// Check that the returned JavaType has the same class as the given subclass
assert (returnValue.getRawClass() == subclass) : "Returned JavaType should have the same class as the given subclass";


