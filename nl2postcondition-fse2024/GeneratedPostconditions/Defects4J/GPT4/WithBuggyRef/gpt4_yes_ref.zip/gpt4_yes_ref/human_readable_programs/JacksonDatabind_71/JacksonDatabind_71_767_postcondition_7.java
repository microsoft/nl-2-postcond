// Check if the returned StdKeyDeserializer has the same raw Class as the input parameter
assert returnValue == null || returnValue.getRawClass().equals(raw);


