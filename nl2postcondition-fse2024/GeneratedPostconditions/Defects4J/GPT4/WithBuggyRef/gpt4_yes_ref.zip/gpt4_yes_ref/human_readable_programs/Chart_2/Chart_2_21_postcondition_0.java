// Check if the returned range has minimum and maximum values within the dataset's Y values
assert returnValue == null || (returnValue.getLowerBound() <= returnValue.getUpperBound() && dataset.getSeriesCount() > 0 && IntStream.range(0, dataset.getSeriesCount()).flatMap(series -> IntStream.range(0, dataset.getItemCount(series))).allMatch(item -> Double.isNaN(dataset.getYValue(series, item)) || (dataset.getYValue(series, item) >= returnValue.getLowerBound() && dataset.getYValue(series, item) <= returnValue.getUpperBound())));


