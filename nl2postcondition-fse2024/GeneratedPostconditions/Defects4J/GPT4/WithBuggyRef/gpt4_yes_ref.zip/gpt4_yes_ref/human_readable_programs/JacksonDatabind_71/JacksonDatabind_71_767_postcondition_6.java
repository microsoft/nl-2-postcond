```java
// Postcondition: Checks if the returned StdKeyDeserializer's 'kind' field matches the input 'raw' type.
assert (returnValue == null) || (returnValue.getType().equals(raw));
```


