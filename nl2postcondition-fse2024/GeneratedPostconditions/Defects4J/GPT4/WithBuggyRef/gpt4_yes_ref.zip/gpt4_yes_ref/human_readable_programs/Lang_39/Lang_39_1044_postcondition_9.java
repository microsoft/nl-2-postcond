// Postcondition checks if the input text is null, the returned value is also null
assert (text == null) == (returnValue == null);


