// Check if the type of the node n is not null after executing visitGetProp
assert n.getJSType() != null;


