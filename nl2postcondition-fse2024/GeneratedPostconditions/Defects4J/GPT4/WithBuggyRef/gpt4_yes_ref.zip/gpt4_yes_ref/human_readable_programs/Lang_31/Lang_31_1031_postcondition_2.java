```java
// Postcondition: If the method returns true, there must exist at least one character from searchChars in cs
assert !returnValue || java.util.Arrays.stream(searchChars).anyMatch(ch -> cs.chars().anyMatch(c -> c == ch));
```


