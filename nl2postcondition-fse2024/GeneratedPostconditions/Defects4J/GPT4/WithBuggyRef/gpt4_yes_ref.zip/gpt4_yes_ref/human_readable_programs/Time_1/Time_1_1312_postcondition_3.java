```java
// Check that the constructed Partial has the same number of types and values as the input arrays
assert returnValue.iTypes.length == types.length && returnValue.iValues.length == values.length;
```


