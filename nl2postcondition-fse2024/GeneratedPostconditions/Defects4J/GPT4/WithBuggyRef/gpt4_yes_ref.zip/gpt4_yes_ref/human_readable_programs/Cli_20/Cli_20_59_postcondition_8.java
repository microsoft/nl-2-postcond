// Postcondition: Check if the size of the returned array is less than or equal to the size of the input arguments array
assert returnValue.length <= arguments.length;


