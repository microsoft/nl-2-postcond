// Postcondition checks if the input node n is of type GETPROP, the output type is assigned and not null
assert n.getType() == Token.GETPROP && n.getJSType() != null;


