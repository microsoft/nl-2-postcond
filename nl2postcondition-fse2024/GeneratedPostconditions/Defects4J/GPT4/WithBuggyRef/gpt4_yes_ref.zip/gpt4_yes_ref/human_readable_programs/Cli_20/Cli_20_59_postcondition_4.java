```java
// Postcondition: Checks if the length of the returnValue is less than or equal to the length of the input arguments array
assert returnValue.length <= arguments.length;
```


