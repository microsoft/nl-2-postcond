```java
// Check if the final string in accum has no consecutive whitespaces and starts with a non-whitespace character if stripLeading is true
assert accum.toString().matches((stripLeading ? "\\S" : "") + "(\\S|\\s\\S)*");
```


