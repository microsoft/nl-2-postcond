// Check if the return value is zero when the input durationField is not supported
assert (returnValue == 0) == !durationField.isSupported();


