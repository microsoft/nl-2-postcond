// Postcondition checks if the marker was removed, then notification flag should be the same as the return value
assert !(removed && notify) || (returnValue == notify);


