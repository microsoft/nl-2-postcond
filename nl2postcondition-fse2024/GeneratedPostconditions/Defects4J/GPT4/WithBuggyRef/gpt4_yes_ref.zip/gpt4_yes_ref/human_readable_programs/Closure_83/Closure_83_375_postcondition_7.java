```java
// Postcondition checks if the returnValue is a valid value based on the input param
assert (params.getParameter(0) == null && returnValue == 0) || (params.getParameter(0) != null && (TRUES.contains(params.getParameter(0).toLowerCase()) || FALSES.contains(params.getParameter(0).toLowerCase())) && returnValue == 1);
```


