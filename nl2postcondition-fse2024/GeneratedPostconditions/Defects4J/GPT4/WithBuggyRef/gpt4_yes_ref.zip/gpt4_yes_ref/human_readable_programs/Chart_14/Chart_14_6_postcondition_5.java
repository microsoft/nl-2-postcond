// Checks if the marker was removed from the specified layer and index
assert (returnValue == (layer == Layer.FOREGROUND ? this.foregroundDomainMarkers.get(index).contains(marker) : this.backgroundDomainMarkers.get(index).contains(marker)) == false;


