```java
// Checks if the returnValue is equal to the expected mean calculation based on the Javadoc
assert returnValue == (double) (getSampleSize() * getNumberOfSuccesses()) / (double) getPopulationSize();
```


