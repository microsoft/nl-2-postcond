```java
// Check if the returned value is either the given default value or the contents of _textBuffer when the current token is a value string
assert (returnValue.equals(defValue) || (_currToken == JsonToken.VALUE_STRING && returnValue.equals(_textBuffer.contentsAsString())));
```


