// Check if the resulting StringBuilder starts with the same content as the input StringBuilder and ends with a semicolon
assert returnValue.toString().startsWith(sb.toString()) && returnValue.charAt(returnValue.length() - 1) == ';';


