```java
// Check if the returnValue is the product of sample size and number of successes divided by population size
assert returnValue == (double) (getSampleSize() * getNumberOfSuccesses()) / (double) getPopulationSize();
```


