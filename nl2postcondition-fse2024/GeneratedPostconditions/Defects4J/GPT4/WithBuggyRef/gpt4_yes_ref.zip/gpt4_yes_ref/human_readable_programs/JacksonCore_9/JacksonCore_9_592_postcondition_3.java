```java
// Postcondition: If the current token is a VALUE_STRING, the returnValue is equal to getText()
assert (_currToken != JsonToken.VALUE_STRING || returnValue.equals(getText()));
```


