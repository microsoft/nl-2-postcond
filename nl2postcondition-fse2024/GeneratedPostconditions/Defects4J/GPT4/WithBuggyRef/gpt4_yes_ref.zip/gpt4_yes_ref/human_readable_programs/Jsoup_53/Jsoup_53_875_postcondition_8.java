```java
// Postcondition: The returned string should have balanced open and close characters
assert returnValue.chars().filter(c -> c == open).count() == returnValue.chars().filter(c -> c == close).count();
```


