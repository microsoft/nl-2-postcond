```java
// Checks that the solution's point has the same length as the original number of decision variables
assert returnValue.getPointRef().length == getOriginalNumDecisionVariables();
```


