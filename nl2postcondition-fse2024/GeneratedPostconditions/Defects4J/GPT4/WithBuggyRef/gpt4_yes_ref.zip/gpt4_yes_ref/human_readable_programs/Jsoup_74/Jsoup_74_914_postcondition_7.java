// Check if the accumulated string has no consecutive whitespace characters after normalizing and appending
assert !returnValue.matches(".*\\s{2,}.*");


