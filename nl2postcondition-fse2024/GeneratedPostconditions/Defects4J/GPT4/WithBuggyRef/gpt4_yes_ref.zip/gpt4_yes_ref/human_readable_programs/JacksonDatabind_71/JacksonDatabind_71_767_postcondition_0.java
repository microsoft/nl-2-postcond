// Check if the returnValue's type matches the input raw type
assert (returnValue == null) || raw.isAssignableFrom(returnValue.getClass());


