// Check if the returned range has minimum and maximum values within the dataset bounds
assert returnValue == null || (returnValue.getLowerBound() >= getMinimumValue(dataset, includeInterval) && returnValue.getUpperBound() <= getMaximumValue(dataset, includeInterval));

private static double getMinimumValue(XYDataset dataset, boolean includeInterval) {
    double minimum = Double.POSITIVE_INFINITY;
    int seriesCount = dataset.getSeriesCount();
    for (int series = 0; series < seriesCount; series++) {
        int itemCount = dataset.getItemCount(series);
        for (int item = 0; item < itemCount; item++) {
            double value = dataset.getYValue(series, item);
            if (includeInterval && dataset instanceof IntervalXYDataset) {
                value = Math.min(value, ((IntervalXYDataset) dataset).getStartYValue(series, item));
            }
            if (!Double.isNaN(value)) {
                minimum = Math.min(minimum, value);
            }
        }
    }
    return minimum;
}

private static double getMaximumValue(XYDataset dataset, boolean includeInterval) {
    double maximum = Double.NEGATIVE_INFINITY;
    int seriesCount = dataset.getSeriesCount();
    for (int series = 0; series < seriesCount; series++) {
        int itemCount = dataset.getItemCount(series);
        for (int item = 0; item < itemCount; item++) {
            double value = dataset.getYValue(series, item);
            if (includeInterval && dataset instanceof IntervalXYDataset) {
                value = Math.max(value, ((IntervalXYDataset) dataset).getEndYValue(series, item));
            }
            if (!Double.isNaN(value)) {
                maximum = Math.max(maximum, value);
            }
        }
    }
    return maximum;
}


