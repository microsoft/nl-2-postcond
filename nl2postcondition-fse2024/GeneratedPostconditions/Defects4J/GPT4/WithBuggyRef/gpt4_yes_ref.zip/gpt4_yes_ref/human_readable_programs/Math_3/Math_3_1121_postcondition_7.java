```java
import java.util.stream.IntStream;

// Checks if the arrays dimensions match in order to avoid DimensionMismatchException
assert a.length == b.length : "Arrays dimensions mismatch";
```


