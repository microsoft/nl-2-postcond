```java
// Postcondition: Check if the marker was removed from the correct layer, not affecting the other layer
assert (layer == Layer.FOREGROUND && !backgroundDomainMarkers.get(index).contains(marker)) 
    || (layer == Layer.BACKGROUND && !foregroundDomainMarkers.get(index).contains(marker));
```


