```java
// Check that the constructed Partial object has the same length for types and values arrays
assert (returnValue.iTypes.length == returnValue.iValues.length) : "Types and values arrays lengths do not match";
```


