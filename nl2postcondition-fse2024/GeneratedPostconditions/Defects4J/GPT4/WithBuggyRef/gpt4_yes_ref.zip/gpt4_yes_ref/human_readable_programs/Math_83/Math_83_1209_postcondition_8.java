// Checks if the returned row has value 1 in the given column and all other values in the same column are 0
assert returnValue == null || (MathUtils.equals(getEntry(returnValue, col), 1.0, epsilon) && IntStream.range(getNumObjectiveFunctions(), getHeight()).allMatch(i -> i == returnValue || MathUtils.equals(getEntry(i, col), 0.0, epsilon)));


