```java
// Ensure that the returned value is a string if the current token is VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING) || (returnValue instanceof String);
```


