// The postcondition checks if the returned range has the correct lower and upper bounds considering only valid (non-NaN) values in the dataset
assert returnValue == null || (
    Arrays.stream(dataset.getSeriesKeys())
        .flatMapToInt(seriesKey -> IntStream.range(0, dataset.getItemCount(dataset.indexOf(seriesKey))))
        .filter(i -> !Double.isNaN(dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .mapToDouble(i -> dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .min().orElse(Double.POSITIVE_INFINITY) == returnValue.getLowerBound() &&
    Arrays.stream(dataset.getSeriesKeys())
        .flatMapToInt(seriesKey -> IntStream.range(0, dataset.getItemCount(dataset.indexOf(seriesKey))))
        .filter(i -> !Double.isNaN(dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .mapToDouble(i -> dataset.getYValue(dataset.indexOf(seriesKey), i)))
        .max().orElse(Double.NEGATIVE_INFINITY) == returnValue.getUpperBound()
);


