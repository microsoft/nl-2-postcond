// Checks if the returnValue is true when the token type is not Doctype or Character with null data
assert (!((t.type == Token.TokenType.Doctype || (t.type == Token.TokenType.Character && t.asCharacter().getData().equals(nullString))) && returnValue));


