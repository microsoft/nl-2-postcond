// Postcondition checks if _hashShared is set to false after calling _verifySharing
assert (!_hashShared);


