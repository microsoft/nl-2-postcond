// Check if the returnValue is 0 or 1, representing the number of consumed parameters
assert returnValue == 0 || returnValue == 1;


