```
// Check if the returned value is either the default value or a non-empty string when the current token is not VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING) ? (returnValue.equals(defValue) || !returnValue.isEmpty()) : true;
```


