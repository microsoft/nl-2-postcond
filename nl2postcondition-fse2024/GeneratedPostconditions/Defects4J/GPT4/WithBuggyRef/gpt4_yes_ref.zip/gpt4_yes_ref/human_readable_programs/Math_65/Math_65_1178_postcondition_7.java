```java
// Check if the returned RMS value is non-negative
assert returnValue >= 0 : "The Root Mean Square value must be non-negative";
```


