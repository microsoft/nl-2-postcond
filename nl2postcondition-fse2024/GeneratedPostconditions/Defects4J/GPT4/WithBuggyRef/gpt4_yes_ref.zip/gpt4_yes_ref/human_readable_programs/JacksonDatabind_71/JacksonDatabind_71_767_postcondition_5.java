// Check if returnValue is either a StdKeyDeserializer for the given raw type or null
assert (returnValue == null) || (returnValue instanceof StdKeyDeserializer && raw.isAssignableFrom(((StdKeyDeserializer) returnValue).getRawType()));


