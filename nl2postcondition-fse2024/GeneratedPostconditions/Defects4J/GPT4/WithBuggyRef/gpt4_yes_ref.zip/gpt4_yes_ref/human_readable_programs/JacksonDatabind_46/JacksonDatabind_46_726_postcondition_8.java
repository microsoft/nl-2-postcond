// Check if the length of the returned StringBuilder is greater than the input StringBuilder
assert returnValue.length() > sb.length();


