```java
// Check if the returnValue has the same length as the input text when all replacements are done
import java.util.Arrays;

assert (text == null || Arrays.stream(searchList).allMatch(s -> s == null || !text.contains(s))) ? returnValue.length() == text.length() : true;
```


