// Checks if the returnValue is null when _currToken is not a VALUE_STRING
assert (_currToken == JsonToken.VALUE_STRING) || (returnValue == null);


