// Checks if the returned StdKeyDeserializer has the correct type and raw class
assert returnValue == null || (returnValue.getKind() == getKindForRawClass(raw) && returnValue.getRaw() == raw);


