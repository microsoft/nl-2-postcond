```
// Check if the returnValue is equal to defValue when the current token is not a value string
assert (_currToken != JsonToken.VALUE_STRING) ? returnValue.equals(defValue) : true;
```


