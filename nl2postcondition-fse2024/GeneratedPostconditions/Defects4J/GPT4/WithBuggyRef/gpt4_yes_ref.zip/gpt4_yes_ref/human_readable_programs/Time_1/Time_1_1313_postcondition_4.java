// Check if the returned value is zero when both duration fields are unsupported, and positive otherwise
assert (returnValue == 0 && !durationField.isSupported()) || (returnValue > 0 && durationField.isSupported());


