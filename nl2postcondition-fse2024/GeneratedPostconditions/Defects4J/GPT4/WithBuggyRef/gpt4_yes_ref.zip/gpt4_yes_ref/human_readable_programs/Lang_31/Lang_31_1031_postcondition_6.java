```java
// Checks if the returnValue is false when both cs and searchChars are empty or null
assert !(isEmpty(cs) && ArrayUtils.isEmpty(searchChars)) || !returnValue;
```


