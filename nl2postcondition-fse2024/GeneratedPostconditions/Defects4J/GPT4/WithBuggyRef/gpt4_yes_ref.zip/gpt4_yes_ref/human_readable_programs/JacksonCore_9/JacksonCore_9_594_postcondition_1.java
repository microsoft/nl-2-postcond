```java
// Ensure that the returned value is a string and not null when the current token is VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING) || (returnValue != null && returnValue instanceof String);
```


