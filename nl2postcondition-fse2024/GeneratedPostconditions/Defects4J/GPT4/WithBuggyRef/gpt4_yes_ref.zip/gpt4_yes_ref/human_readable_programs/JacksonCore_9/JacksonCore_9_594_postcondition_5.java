// Check if the return value is not null when _currToken is VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING || returnValue != null);


