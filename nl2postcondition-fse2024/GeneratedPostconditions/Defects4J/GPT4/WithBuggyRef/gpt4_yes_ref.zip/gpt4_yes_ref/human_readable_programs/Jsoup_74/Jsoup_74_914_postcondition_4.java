// Checks if the resulting accumulated string has no consecutive whitespaces and no leading whitespace if stripLeading is true
assert accum.toString().matches(stripLeading ? "^[^\\s].*?\\s{0,1}.*$" : ".*?\\s{0,1}.*$");


