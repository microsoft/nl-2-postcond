```
// Check if the returnValue is equal to the expected mean value calculated using sampleSize, numberOfSuccesses, and populationSize
assert returnValue == ((double) (getSampleSize() * getNumberOfSuccesses()) / (double) getPopulationSize());
```


