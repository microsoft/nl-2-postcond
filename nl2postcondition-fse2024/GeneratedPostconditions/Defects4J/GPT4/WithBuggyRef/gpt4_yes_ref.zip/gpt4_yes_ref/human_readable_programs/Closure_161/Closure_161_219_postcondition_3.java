```java
// Check if the method returned the original node when the right child is not a number
assert (right.getType() != Token.NUMBER) == (n == returnValue);
```


