// Checks if the returned range has minimum and maximum values within the dataset's x-values
assert returnValue == null || (dataset.getSeriesCount() == 0) || (returnValue.getLowerBound() <= dataset.getXValue(0, 0) && returnValue.getUpperBound() >= dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1));


