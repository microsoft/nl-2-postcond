```java
// Postcondition: Checks if the returned range has its lower bound less than or equal to its upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();
```


