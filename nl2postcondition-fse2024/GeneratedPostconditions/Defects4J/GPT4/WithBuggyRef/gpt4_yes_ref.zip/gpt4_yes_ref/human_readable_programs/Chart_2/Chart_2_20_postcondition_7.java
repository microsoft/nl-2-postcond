// Check if the returned range contains the valid minimum and maximum x-values considering the includeInterval flag
assert (returnValue == null) || ((includeInterval && dataset instanceof IntervalXYDataset)
        ? (returnValue.getLowerBound() <= dataset.getXValue(0, 0) && returnValue.getUpperBound() >= dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1))
        : (returnValue.getLowerBound() == dataset.getXValue(0, 0) && returnValue.getUpperBound() == dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)));


