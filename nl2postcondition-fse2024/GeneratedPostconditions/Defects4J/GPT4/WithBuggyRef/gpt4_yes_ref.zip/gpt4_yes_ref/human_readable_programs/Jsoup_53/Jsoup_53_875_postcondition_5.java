```java
// Postcondition: The returned string is either empty or starts with the open character and ends with the close character
assert returnValue.isEmpty() || (returnValue.charAt(0) == open && returnValue.charAt(returnValue.length() - 1) == close);
```


