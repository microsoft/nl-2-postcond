```java
import java.util.stream.IntStream;

// Check if the dimensions of input arrays match
assert a.length == b.length : "DimensionMismatchException: Input arrays dimensions do not match.";
```


