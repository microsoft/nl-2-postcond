```java
// Postcondition: Ensures that the return value is either 0 or 1
assert (returnValue == 0 || returnValue == 1);
```


