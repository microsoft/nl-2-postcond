```java
// Check whether the return value is true when there are side effects in a function call or constructor call
assert !(returnValue == false && ((n.isCall() && NodeUtil.functionCallHasSideEffects(n)) || (n.isNew() && NodeUtil.constructorCallHasSideEffects(n))));
```


