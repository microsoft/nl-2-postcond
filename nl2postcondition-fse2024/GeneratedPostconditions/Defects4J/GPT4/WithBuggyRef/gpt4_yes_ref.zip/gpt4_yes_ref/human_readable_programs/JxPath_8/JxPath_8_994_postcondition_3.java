```java
// Postcondition: The returnValue is a boolean value that indicates whether there is a match between the left and right arguments
assert returnValue == true || returnValue == false;
```


