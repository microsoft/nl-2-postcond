```java
// Check if the returned RMS value is non-negative, as it should be the root of the arithmetic mean of the square of all weighted residuals
assert returnValue >= 0;
```


