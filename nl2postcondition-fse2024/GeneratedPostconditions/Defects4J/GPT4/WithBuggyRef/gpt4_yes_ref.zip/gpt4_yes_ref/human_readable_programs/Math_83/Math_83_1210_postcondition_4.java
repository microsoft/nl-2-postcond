// The postcondition checks if the returned RealPointValuePair has the correct length of coefficients
assert returnValue.getPointRef().length == getOriginalNumDecisionVariables() : "Returned RealPointValuePair has incorrect length of coefficients";


