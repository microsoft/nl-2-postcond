```java
// The postcondition checks if the returned range has the correct lower and upper bounds according to the dataset and includeInterval flag
import org.jfree.data.Range;

assert returnValue == null || (
    (Double.compare(returnValue.getLowerBound(), Double.POSITIVE_INFINITY) != 0 && Double.compare(returnValue.getUpperBound(), Double.NEGATIVE_INFINITY) != 0) && 
    returnValue.getLowerBound() <= returnValue.getUpperBound()
);
```


