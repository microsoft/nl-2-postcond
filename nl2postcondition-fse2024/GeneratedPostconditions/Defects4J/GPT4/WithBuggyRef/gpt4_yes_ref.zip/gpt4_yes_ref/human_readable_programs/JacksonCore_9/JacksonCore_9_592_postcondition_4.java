```java
// Check if the returnValue is either the text representation of the current token or null
assert (_currToken == JsonToken.VALUE_STRING && returnValue.equals(getText())) || (_currToken != JsonToken.VALUE_STRING && returnValue == null);
```


