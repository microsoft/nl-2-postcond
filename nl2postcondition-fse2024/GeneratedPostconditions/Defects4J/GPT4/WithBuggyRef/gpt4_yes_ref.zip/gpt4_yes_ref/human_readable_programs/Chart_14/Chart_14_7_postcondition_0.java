// Postcondition checks if the marker was removed from the specified layer and index
assert (returnValue == true) == (layer == Layer.FOREGROUND ? !((ArrayList) this.foregroundRangeMarkers.get(new Integer(index))).contains(marker) : !((ArrayList) this.backgroundRangeMarkers.get(new Integer(index))).contains(marker));


