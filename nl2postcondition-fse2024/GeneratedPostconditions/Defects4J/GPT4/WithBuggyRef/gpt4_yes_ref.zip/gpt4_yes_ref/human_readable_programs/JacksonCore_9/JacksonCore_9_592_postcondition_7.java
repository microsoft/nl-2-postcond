```java
// Check if the returned value is either the text representation of the current token or null
assert (returnValue == null && (_currToken == null || _currToken == JsonToken.VALUE_NULL)) || returnValue.equals(getText());
```


