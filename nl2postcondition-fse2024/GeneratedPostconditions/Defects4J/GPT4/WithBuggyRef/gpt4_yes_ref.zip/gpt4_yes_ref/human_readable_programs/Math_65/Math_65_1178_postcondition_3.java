```java
// Check if the returned RMS value is non-negative
assert returnValue >= 0 : "Returned RMS value should be non-negative";
```


