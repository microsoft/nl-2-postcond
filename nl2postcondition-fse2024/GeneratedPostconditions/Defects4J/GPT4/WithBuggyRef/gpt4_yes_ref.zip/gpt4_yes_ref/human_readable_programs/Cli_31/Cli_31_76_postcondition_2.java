```java
// Check if the option is appended to the buffer with the correct format
assert (required && buff.toString().endsWith("-" + option.getOpt() + (option.hasArg() && option.hasArgName() ? " <" + option.getArgName() + ">" : ""))) || (!required && buff.toString().endsWith("[" + "-" + option.getOpt() + (option.hasArg() && option.hasArgName() ? " <" + option.getArgName() + ">" : "") + "]"));
```


