// Check if the returned StringBuilder is of the expected length after adding the referencedType signature and other characters
assert returnValue.length() == sb.length() + _referencedType.getGenericSignature(new StringBuilder()).length() + 2;


