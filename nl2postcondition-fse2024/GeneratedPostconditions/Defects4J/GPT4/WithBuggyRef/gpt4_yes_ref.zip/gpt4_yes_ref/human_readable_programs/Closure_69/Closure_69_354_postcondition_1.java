// Check that the return type of the visitCall is consistent with the child node's type
assert returnValue.getJSType().isSubtypeOf(getJSType(n.getFirstChild()).getReturnType());


