// Postcondition checks that the JsonGenerator has not written a field name since it should only output array elements
assert jgen.getOutputContext().inArray() : "JsonGenerator should be in array context after serializeAsColumn";


