// Check if the returnValue is either an instance of StdKeyDeserializer or a subclass, or null
assert (returnValue == null) || (returnValue instanceof StdKeyDeserializer);


