// Checks if the marker is removed from the correct layer's markers list
assert returnValue == (layer == Layer.FOREGROUND ? this.foregroundRangeMarkers.get(index).contains(marker) : this.backgroundRangeMarkers.get(index).contains(marker));


