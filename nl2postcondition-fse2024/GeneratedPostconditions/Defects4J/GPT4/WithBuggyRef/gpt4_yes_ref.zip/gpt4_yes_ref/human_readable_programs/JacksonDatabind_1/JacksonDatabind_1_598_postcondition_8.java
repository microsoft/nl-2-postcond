// Postcondition: Checks if the JsonGenerator's output buffer has increased after the method call
assert jgen.getOutputBuffer().length > 0;


