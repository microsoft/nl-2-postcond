// Postcondition: Checks if the returnValue is false when either cs or searchChars is null or empty
assert !(returnValue) || (!isEmpty(cs) && searchChars != null && searchChars.length > 0);


