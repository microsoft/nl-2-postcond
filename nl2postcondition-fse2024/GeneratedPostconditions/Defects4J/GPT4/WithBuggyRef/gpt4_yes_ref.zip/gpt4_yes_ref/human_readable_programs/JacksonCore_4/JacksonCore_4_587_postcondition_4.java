```java
// Check that the returned array is larger than the original array and not exceeding MAX_SEGMENT_LEN
assert returnValue.length > curr.length && returnValue.length <= MAX_SEGMENT_LEN;
```


