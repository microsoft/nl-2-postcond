// Check if the length of the appended normalised string is less than or equal to the original string length
assert accum.length() <= (stripLeading ? string.trim().length() : string.length()) : "The length of the appended normalised string should be less than or equal to the original string length";


