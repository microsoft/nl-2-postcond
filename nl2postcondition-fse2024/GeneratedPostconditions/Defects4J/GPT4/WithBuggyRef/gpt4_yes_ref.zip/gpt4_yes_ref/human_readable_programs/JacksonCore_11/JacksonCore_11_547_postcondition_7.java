```java
// Ensure that the _hashArea and _names are not shared after _verifySharing execution
assert !_hashShared;
```


