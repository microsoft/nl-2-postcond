// Check if the returnValue is of type Boolean
assert returnValue instanceof Boolean;


