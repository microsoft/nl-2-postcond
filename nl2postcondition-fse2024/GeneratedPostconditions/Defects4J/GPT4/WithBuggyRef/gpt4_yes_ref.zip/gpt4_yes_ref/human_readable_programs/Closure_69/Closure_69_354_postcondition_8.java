// Postcondition checks if the return value's type is either unknown or matches the expected return type of the functionType when it is present
assert (childType instanceof FunctionType && returnValue.getJSType().isSubtypeOf(((FunctionType) childType).getReturnType())) || returnValue.getJSType().isUnknownType();


