// Check if the returned node is either the original node or a valid folded result
assert returnValue == n || (returnValue != n && (returnValue.getType() == Token.EMPTY || returnValue.getType() == Token.UNDEFINED || returnValue.isNumber()));


