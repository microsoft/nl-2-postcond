// Postcondition: Check if the returned array has the same or fewer elements than the input arguments array
assert returnValue.length <= arguments.length;


