// Check that the length of the accumulated string is greater than or equal to the length of the input string
assert accum.length() >= (stripLeading ? string.trim().length() : string.length());


