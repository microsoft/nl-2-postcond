```java
// Check if the returned value is either the defaultValue or the text representation of _currToken
assert (returnValue == null && defaultValue == null) || (returnValue != null && (returnValue.equals(defaultValue) || returnValue.equals(getText())));
```


