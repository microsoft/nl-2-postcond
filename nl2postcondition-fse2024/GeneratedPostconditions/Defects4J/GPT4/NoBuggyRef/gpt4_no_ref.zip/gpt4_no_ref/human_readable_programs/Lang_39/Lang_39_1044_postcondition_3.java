```java
import java.util.Arrays;

// Checks if the length of the input text is equal to the length of the returnValue after performing the replacements
assert (text == null || Arrays.stream(searchList).anyMatch(s -> s == null) || Arrays.stream(replacementList).anyMatch(r -> r == null))
       ? text == returnValue
       : text.length() >= returnValue.length();
```


