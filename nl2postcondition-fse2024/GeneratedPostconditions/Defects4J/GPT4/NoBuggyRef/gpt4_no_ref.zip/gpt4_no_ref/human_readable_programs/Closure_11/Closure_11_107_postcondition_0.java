// Postcondition: Checks if the GETPROP node type is retained after visiting
assert n.getType() == Token.GETPROP;


