```java
// Check that the returned StdKeyDeserializer instance has the same raw class as the input parameter
assert returnValue.getKeyDeserializedClass().equals(raw);
```


