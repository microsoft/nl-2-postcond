// Check if the returned row is within the valid range or null
assert (returnValue == null) || (returnValue >= (ignoreObjectiveRows ? getNumObjectiveFunctions() : 0) && returnValue < getHeight());


