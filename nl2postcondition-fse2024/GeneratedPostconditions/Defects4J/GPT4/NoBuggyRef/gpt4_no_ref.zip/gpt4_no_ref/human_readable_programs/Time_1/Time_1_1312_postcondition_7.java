```java
// Check if the constructed Partial object has the same number of fields and values as the input arrays
assert returnValue.size() == types.length && returnValue.size() == values.length;
```


