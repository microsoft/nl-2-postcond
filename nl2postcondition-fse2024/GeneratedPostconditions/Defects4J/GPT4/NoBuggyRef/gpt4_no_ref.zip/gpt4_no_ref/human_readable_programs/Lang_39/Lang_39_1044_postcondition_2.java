```java
// Check if the lengths of searchList and replacementList match, or if any of them is null, the returnValue should be equal to the input text
assert (searchList == null || replacementList == null || searchList.length != replacementList.length) ? (returnValue != null && returnValue.equals(text)) : true;
```


