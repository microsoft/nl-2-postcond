// Check that the length of the accumulated string is greater than or equal to the input string length after normalizing whitespace
assert accum.length() >= (stripLeading ? string.trim().length() : string.length());


