// Postcondition checks that the length of the input arguments array is not less than the length of the returned array
assert arguments.length >= returnValue.length;


