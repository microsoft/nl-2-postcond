```java
// Postcondition: The size of the returnValue array is less than or equal to the size of the input arguments array
assert returnValue.length <= arguments.length;
```


