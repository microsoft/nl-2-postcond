```java
// Postcondition: Check if the number of fields in the constructed Partial object matches the input types length
assert returnValue.size() == types.length;
```


