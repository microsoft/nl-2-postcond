```java
// Postcondition: Checks if the returnValue has the same length as the initial StringBuilder plus the length of the referencedType's generic signature
assert returnValue.length() == sb.length() + _referencedType.getGenericSignature(new StringBuilder()).length();
```


