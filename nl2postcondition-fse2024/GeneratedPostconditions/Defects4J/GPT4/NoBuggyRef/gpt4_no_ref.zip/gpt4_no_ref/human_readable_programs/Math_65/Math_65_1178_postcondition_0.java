```java
// Check that the returnValue is non-negative, as the square root of a non-negative value should always be non-negative
assert returnValue >= 0;
```


