// Postcondition checks if the returnValue array starts with the same options as arguments array
assert Arrays.equals(Arrays.copyOfRange(arguments, 0, Math.min(arguments.length, returnValue.length)), Arrays.copyOfRange(returnValue, 0, Math.min(arguments.length, returnValue.length)));


