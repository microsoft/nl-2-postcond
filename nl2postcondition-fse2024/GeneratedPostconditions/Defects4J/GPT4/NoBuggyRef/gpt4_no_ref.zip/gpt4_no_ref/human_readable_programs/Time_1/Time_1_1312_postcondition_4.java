```java
// Checks that the types and values arrays have the same length after constructing the Partial object
assert types.length == values.length;
```


