// Postcondition checks if the returnValue is not null when defValue is provided
assert (defValue != null && returnValue != null);


