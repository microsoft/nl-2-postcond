// Postcondition: Ensure that the CharacterReader's position has advanced by at least 1 after calling read
assert r.getPosition() > r.getPositionBeforeRead();


