```java
// Postcondition: checks if the returnValue is either the original node or a folded array access node
assert returnValue == n || (returnValue.getType() == Token.ARRAYLIT && returnValue.getParent() == n.getParent());
```


