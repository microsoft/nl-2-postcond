```java
// Checks if the entry name ends with a '/' when returnValue is true, indicating it's a directory
assert (returnValue == true) == (name.endsWith("/"));
```


