// Check that the return value is always zero, as specified in the Javadoc
assert returnValue == 0 : "The return value should always be zero";


