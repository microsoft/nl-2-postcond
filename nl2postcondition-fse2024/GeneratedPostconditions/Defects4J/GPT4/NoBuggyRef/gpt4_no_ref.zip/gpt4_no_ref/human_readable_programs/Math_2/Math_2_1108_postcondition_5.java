```java
// Check if the returned mean value matches the formula n * m / N
assert returnValue == (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize();
```


