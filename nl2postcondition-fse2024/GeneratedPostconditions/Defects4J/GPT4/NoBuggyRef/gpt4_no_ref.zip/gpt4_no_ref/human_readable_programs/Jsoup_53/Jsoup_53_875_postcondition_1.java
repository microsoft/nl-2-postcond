```java
// Postcondition: The returnValue contains the same number of open and close characters, excluding escaped or quoted ones
assert returnValue.chars().filter(c -> c == open).count() == returnValue.chars().filter(c -> c == close).count();
```


