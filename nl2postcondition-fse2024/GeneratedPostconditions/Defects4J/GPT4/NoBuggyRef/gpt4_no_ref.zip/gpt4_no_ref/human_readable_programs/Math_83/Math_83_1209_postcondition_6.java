// Checks that if the returnValue is not null, it is within the valid row range
assert returnValue == null || (returnValue >= 0 && returnValue < getHeight());


