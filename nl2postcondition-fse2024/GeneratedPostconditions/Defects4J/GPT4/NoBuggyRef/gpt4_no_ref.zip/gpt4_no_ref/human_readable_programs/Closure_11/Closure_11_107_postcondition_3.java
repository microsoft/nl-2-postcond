// Postcondition: Check if the type of the GETPROP node is set and not null after the visitGetProp method is called
assert n.getJSType() != null;


