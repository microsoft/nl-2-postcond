// Assert that the return value is always zero, as specified in the Javadoc
assert returnValue == 0 : "Return value should always be zero";


