// Check if the return value is always zero, as specified in the Javadoc
assert returnValue == 0;


