```java
import java.util.Arrays;

// Check that the lengths of the input arrays are the same after ignoring null elements
assert searchList == null || replacementList == null || 
       Arrays.stream(searchList).filter(s -> s != null).count() ==
       Arrays.stream(replacementList).filter(r -> r != null).count();
```


