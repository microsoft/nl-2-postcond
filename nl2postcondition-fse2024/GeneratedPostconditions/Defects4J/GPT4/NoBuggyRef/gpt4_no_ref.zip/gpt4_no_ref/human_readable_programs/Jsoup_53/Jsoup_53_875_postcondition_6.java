```java
// Postcondition: The returnValue contains the same number of opening and closing characters
assert returnValue.chars().filter(ch -> ch == open).count() == returnValue.chars().filter(ch -> ch == close).count();
```


