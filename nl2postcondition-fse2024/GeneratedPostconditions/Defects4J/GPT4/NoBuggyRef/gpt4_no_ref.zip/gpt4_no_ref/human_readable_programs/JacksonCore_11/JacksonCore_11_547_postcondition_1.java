// Postcondition: Checks if the _hashShared variable is false after executing _verifySharing
assert !_hashShared;


