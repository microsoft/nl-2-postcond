// The postcondition checks if the method's return value is false when the marker is null, as it cannot be removed
assert (marker != null) || !returnValue;


