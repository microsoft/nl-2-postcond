// Check if the square of the returnValue is less than or equal to the minimized criterion
assert returnValue * returnValue <= getMinimizedCriterion();


