```java
// Check if the returned node is either unchanged or a folded array access
assert (returnValue == n) || (returnValue.getType() == Token.NUMBER && n.getType() == Token.GETELEM && left.getType() == Token.ARRAYLIT);
```


