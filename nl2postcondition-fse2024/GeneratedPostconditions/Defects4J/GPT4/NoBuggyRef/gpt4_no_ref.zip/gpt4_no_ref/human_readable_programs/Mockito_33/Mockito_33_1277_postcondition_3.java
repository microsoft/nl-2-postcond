// The postcondition checks if the returnValue is consistent with the equality of the candidate and invocation's methods
assert returnValue == (candidate.getMethod().equals(invocation.getMethod()));


