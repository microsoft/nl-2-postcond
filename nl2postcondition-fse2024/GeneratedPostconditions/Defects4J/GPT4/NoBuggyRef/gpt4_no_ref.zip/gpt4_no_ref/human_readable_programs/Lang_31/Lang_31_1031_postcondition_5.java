// Checks if the method returns false when the input CharSequence or searchChars are null or empty
assert (cs == null || searchChars == null || cs.length() == 0 || searchChars.length == 0) == !returnValue;


