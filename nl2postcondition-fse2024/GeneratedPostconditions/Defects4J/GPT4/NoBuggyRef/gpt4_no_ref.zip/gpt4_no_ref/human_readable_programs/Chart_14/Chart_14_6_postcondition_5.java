```java
// Checks if the marker was removed and notify is true, a PlotChangeEvent should be sent to registered listeners
assert !(returnValue && notify) || (getListenerCount(PlotChangeEvent.class) > 0);
```


