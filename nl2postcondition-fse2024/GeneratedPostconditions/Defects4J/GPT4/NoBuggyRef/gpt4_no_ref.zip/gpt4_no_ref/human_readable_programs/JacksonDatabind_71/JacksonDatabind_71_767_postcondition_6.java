// Check that the returnValue is either null or an instance of StdKeyDeserializer based on the raw class type
assert returnValue == null || (returnValue instanceof StdKeyDeserializer && raw.isAssignableFrom(returnValue.getClass()));


