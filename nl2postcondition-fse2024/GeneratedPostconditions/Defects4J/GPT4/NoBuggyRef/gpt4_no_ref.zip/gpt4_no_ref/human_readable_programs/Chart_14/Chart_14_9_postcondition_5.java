// Checks if the notify parameter is true, the returnValue should be the same as removeRangeMarker with notify set to true
assert !notify || returnValue == removeRangeMarker(index, marker, layer, true);


