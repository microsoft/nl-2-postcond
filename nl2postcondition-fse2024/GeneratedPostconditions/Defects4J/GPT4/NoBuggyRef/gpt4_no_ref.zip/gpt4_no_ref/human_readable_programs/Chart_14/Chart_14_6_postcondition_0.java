```java
// Asserts that if the marker has been removed successfully, the notify parameter is true
assert !(returnValue) || notify;
```


