// Postcondition: After calling _verifySharing, the _hashShared flag should be false
assert !_hashShared;


