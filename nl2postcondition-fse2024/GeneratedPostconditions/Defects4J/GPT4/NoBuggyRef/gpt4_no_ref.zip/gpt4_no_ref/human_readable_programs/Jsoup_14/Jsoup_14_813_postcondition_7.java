// Check if the input CharacterReader remains unchanged after read() execution
assert r.toString().equals(new CharacterReader(r.toString()).toString());


