```java
// Check if the returnValue of getChiSquare is non-negative, as chi-square values are always non-negative
assert returnValue >= 0 : "Chi-square value must be non-negative";
```


