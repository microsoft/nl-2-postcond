```java
// Check if the returned node is either the same as the input node or a STRING type node
assert returnValue == n || returnValue.getType() == Token.STRING;
```


