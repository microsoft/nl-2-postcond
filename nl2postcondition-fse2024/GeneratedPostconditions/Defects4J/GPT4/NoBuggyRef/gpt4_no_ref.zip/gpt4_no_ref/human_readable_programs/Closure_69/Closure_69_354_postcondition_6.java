// Postcondition checks that after visiting a CALL node, the node's type is not null
assert n.getJSType() != null;


