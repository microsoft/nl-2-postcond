```java
// Comment explaining what aspect of the method the symbolic postcondition checks
// The postcondition checks if the calculated range (returnValue) has lowerBound less than or equal to upperBound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();
```


