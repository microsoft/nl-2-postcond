// Postcondition checks if the CALL node's type is not null after visitCall execution
assert n.getJSType() != null;


