```java
// Postcondition for the `forType` method checks if the returned StdKeyDeserializer instance
// is not null when the input raw class is a recognized type.
assert (raw == java.net.URI.class || raw == java.net.URL.class || raw == java.util.Calendar.class || raw == java.util.Currency.class || raw == java.util.Date.class || raw == java.util.Locale.class || raw == java.util.UUID.class) ? returnValue != null : true;
```


