// Check if the returned range has the lower bound less than or equal to the upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();


