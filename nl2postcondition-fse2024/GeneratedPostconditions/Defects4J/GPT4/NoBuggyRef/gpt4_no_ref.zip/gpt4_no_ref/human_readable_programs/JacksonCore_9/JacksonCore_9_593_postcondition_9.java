```
// Check if the given default value is returned when _currToken is not VALUE_STRING
assert (_currToken != JsonToken.VALUE_STRING && returnValue.equals(defaultValue)) || (_currToken == JsonToken.VALUE_STRING && !returnValue.equals(defaultValue));
```


