// Check if the returned String is not null
assert returnValue != null;


