```
// Check if the return value is non-negative and less than or equal to the input params size
assert returnValue >= 0 && returnValue <= params.size();
```


