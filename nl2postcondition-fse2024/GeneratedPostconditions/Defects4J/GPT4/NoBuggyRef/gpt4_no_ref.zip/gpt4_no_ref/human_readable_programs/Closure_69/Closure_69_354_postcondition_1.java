```java
// Checks that the first child of the CALL node must be of type FUNCTION after visiting the CALL node
assert n.getFirstChild().getJSType() instanceof FunctionType;
```


