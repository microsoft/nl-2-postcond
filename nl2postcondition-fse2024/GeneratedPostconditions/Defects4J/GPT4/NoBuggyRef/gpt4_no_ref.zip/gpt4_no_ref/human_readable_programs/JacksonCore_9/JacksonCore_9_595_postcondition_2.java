```java
// Postcondition: Check if the returned value equals the default value when the given defValue is not null
assert (defValue != null && returnValue.equals(defValue)) || (defValue == null && returnValue != null);
```


