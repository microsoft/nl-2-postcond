// Postcondition: Ensures the node type is Token.GETPROP after visiting the node
assert n.getType() == Token.GETPROP;


