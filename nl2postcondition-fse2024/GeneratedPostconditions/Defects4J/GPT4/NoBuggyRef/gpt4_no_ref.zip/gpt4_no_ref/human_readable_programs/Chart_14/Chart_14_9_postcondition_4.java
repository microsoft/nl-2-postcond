// Postcondition checks if notify is true, then a PlotChangeEvent is sent to all registered listeners
assert !notify || (notify && returnValue == (getListenerList().getListenerCount(PlotChangeEvent.class) > 0));


