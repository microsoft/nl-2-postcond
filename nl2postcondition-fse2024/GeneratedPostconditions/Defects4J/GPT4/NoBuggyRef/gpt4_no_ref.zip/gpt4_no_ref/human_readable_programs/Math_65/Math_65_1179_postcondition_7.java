// Ensure the returnValue is non-negative, as Chi-Square value cannot be negative
assert returnValue >= 0;


