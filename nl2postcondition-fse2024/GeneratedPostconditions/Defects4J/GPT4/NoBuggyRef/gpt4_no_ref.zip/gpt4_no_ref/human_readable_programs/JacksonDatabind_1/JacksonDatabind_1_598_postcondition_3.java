// Check that the JsonGenerator output is not empty after the method execution
assert jgen.getOutputContext().getParent() != null;


