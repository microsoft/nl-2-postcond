```java
// Assert that the returnValue is the correct mean calculated using the formula n * m / N
assert returnValue == ((double) getSampleSize() * getNumberOfSuccesses()) / getPopulationSize();
```


