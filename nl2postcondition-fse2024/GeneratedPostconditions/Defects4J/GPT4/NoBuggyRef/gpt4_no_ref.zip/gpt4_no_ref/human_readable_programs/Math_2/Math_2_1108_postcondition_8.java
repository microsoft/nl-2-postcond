```java
// Checks if the returned mean is equal to the formula (n * m / N)
assert returnValue == (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize();
```


