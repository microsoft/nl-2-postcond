```java
// Check that the length of accum after the method call is greater or equal to the length of the original accum
assert accum.length() >= accum.length() - (stripLeading && StringUtil.isActuallyWhitespace(string.charAt(0)) ? 1 : 0);
```


