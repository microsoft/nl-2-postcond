// Check that the returnValue is either the same Node or a new folded string Node
assert returnValue == n || (returnValue.getType() == Token.STRING && returnValue.getParent() == n.getParent());


