```java
// Check if the returnValue is equal to defValue when the method doesn't throw an exception
assert !returnValue.equals(defValue) || !returnValue.isEmpty();
```


