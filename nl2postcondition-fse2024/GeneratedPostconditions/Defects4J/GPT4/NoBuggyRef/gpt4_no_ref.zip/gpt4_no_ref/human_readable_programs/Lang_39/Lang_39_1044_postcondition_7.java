```java
// Check if the length of the input text is the same as the length of the returnValue when there are no replacements made
assert (text == null || searchList == null || replacementList == null || searchList.length == 0 || replacementList.length == 0) ? text == returnValue : true;
```


