// Check if the returnValue of getChiSquare is non-negative
assert returnValue >= 0 : "The returned chi-square value should be non-negative";


