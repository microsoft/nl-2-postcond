```
// Check if the returnValue is consistent with the mean formula (n * m / N)
assert returnValue == (double)getSampleSize() * getNumberOfSuccesses() / getPopulationSize();
```


