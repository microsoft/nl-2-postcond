// Check that the returned range is either null or has a positive width (upper bound >= lower bound)
assert returnValue == null || returnValue.getUpperBound() >= returnValue.getLowerBound();


