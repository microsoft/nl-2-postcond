// Postcondition: Ensure the visited node is of type GETPROP
assert n.getType() == Token.GETPROP;


