// Check that if the marker was actually removed, notify is true and a PlotChangeEvent was sent
assert !(returnValue) || (notify && /* code to check if a PlotChangeEvent was sent to all registered listeners */);


