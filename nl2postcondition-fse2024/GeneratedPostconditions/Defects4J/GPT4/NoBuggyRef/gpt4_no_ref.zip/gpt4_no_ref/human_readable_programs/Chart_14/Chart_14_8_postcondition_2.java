// The postcondition checks if the 'notify' parameter is true, a PlotChangeEvent should be triggered
assert !(returnValue && notify) || (returnValue && notify && someConditionThatTracksPlotChangeEvent());


