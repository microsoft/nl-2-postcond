// Checks if the return value is consistent with the equality of the input objects
assert returnValue == left.equals(right);


