```java
// Postcondition checks that the length of accum has increased by at least the length of the input string minus the number of whitespace characters
assert accum.length() >= accum.length() - string.chars().filter(c -> StringUtil.isActuallyWhitespace(c)).count() + (stripLeading && StringUtil.isActuallyWhitespace(string.codePointAt(0)) ? -1 : 0);
```


