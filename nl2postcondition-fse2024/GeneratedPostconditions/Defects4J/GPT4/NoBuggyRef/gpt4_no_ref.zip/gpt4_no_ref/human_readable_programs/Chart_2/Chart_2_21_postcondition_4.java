```java
// Check if the returned range is null when the dataset is empty
assert (dataset.getSeriesCount() == 0 && dataset.getItemCount(0) == 0) ? returnValue == null : true;
```


