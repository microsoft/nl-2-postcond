// Check that the constructed Partial has the same length as the input types and values arrays
assert returnValue.size() == types.length && returnValue.size() == values.length;


