```java
// Postcondition: Check that the number of opening and closing characters in the returned string is balanced
import java.util.stream.IntStream;

assert IntStream.range(0, returnValue.length()).filter(i -> returnValue.charAt(i) == open).count() ==
       IntStream.range(0, returnValue.length()).filter(i -> returnValue.charAt(i) == close).count();
```


