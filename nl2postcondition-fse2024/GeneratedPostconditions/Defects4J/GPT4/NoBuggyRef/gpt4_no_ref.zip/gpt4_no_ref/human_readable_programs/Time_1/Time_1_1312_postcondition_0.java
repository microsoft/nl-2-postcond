// Check if the constructed Partial object has the same number of types and values as the input parameters
assert returnValue.size() == types.length && returnValue.size() == values.length;


