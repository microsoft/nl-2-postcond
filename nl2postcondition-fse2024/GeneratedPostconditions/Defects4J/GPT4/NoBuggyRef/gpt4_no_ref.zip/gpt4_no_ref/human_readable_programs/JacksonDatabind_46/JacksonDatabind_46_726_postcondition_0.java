// Check that the length of the returned StringBuilder is greater than the input StringBuilder's length
assert returnValue.length() > sb.length();


