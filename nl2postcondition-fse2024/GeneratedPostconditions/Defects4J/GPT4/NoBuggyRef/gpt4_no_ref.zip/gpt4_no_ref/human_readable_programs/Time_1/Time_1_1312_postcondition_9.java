```java
// Check that the returned Partial object has the same number of fields as the input types array
assert returnValue.size() == types.length;
```


