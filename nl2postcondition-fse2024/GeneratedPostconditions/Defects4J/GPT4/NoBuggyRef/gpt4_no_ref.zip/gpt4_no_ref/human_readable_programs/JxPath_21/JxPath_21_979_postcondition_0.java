```java
// Postcondition: Check if the returnValue is -1 when the property is not a collection
assert (returnValue == -1) == !(this.node instanceof Collection);
```


