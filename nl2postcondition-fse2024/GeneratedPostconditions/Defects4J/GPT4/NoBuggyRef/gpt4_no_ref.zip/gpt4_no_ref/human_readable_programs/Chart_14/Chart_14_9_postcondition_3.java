// Check if the notify parameter is true, then a PlotChangeEvent must be sent to listeners
assert !notify || (returnValue && listeners.size() > 0);


