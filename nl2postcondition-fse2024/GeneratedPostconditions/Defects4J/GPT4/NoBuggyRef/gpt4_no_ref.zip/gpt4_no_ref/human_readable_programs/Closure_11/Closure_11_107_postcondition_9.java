// Checks that after visitGetProp, the visited node n has a type assigned to it
assert n.getJSType() != null;


