// The postcondition checks if the marker was removed, then the notify flag should be true
assert !(returnValue == true && notify == false);


