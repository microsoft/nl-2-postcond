```
// Check if the length of input arrays a and b are the same, otherwise throw DimensionMismatchException
assert a.length == b.length : "DimensionMismatchException";
```


