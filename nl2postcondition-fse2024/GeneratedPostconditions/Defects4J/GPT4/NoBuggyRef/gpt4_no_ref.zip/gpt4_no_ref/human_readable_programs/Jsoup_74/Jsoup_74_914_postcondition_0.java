```java
// Postcondition: Asserts that the length of accum after appending the normalized string is greater than or equal to the length of accum before appending
int initialLength = accum.length();
appendNormalisedWhitespace(accum, string, stripLeading);
assert accum.length() >= initialLength;
```


