```java
// Postcondition: Checks if the return value is a boolean
assert returnValue == true || returnValue == false;
```


