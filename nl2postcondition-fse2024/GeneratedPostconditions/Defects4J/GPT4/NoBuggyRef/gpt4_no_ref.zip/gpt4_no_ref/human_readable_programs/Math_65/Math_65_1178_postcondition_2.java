// Check if the returnValue (RMS) is non-negative, as the square root of a non-negative value is non-negative
assert returnValue >= 0;


