// Check that all member variables are set to their default values after reset is called
assert returnValue == null && memberVariable1 == defaultValue1 && memberVariable2 == defaultValue2 && ... && memberVariableN == defaultValueN;


