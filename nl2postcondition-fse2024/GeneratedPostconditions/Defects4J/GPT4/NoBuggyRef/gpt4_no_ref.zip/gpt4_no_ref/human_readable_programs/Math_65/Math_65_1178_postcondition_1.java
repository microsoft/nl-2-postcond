```java
// Check that the returnValue is non-negative, since RMS is the square root of the mean of squares
assert returnValue >= 0;
```


