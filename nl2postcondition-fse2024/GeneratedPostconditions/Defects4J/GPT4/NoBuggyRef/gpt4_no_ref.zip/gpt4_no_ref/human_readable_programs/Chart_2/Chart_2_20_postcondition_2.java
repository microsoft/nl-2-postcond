```java
import java.util.Objects;

// Checks that the returned range is not null and has a lower bound less than or equal to the upper bound
assert Objects.nonNull(returnValue) && returnValue.getLowerBound() <= returnValue.getUpperBound();
```


