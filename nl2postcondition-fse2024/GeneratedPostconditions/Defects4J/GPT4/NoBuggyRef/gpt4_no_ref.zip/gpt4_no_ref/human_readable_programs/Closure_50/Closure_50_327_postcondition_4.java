```java
// Check that the returned node is either the original node or a new node of type STRING
assert returnValue == n || returnValue.getType() == Token.STRING;
```


