// Check that the length of the normalized string is less than or equal to the original string length
assert accum.length() <= (stripLeading ? string.trim().length() : string.length());


