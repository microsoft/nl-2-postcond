// Postcondition checks if the returned Node is the same as the input Node when left child is not an ARRAYLIT type
assert (left.getType() != Token.ARRAYLIT) == (returnValue == n);


