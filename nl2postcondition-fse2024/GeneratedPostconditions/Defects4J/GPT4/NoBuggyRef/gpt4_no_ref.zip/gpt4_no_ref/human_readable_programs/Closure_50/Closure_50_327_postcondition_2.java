```java
// Check if the returnValue is either the same input node or a new node with type Token.STRING
assert (returnValue == n) || (returnValue != n && returnValue.getType() == Token.STRING);
```


