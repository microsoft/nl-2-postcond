// Checks that the method returns false when the marker is null, since removing a null marker is not possible
assert (marker == null) == (returnValue == false);


