```
// Check if the length of the accum after appending normalized whitespace is greater than or equal to the original accum length
assert accum.length() >= accum.length() + (stripLeading ? string.trim().length() : string.length());
```


