```java
// Check if the lengths of searchList and replacementList are the same, or either is null or empty, and no IndexOutOfBoundsException is thrown
assert (searchList == null || replacementList == null || searchList.length == 0 || replacementList.length == 0 || searchList.length == replacementList.length) || !(returnValue instanceof IndexOutOfBoundsException);
```


