// Check if the returnValue is non-negative, as Chi-Square values cannot be negative
assert returnValue >= 0 : "Chi-Square value must be non-negative";


