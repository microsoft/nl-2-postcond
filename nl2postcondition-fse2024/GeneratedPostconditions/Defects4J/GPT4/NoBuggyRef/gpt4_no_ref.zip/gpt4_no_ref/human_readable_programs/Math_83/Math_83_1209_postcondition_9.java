```java
// Postcondition: Checks if the returnValue is either null or within the valid range of row indices, considering whether to ignore objective rows or not
assert returnValue == null || (ignoreObjectiveRows ? (returnValue >= getNumObjectiveFunctions() && returnValue < getHeight()) : (returnValue >= 0 && returnValue < getHeight()));
```


