```java
// Checks if the constructed Partial object has the specified types, values, and chronology
assert Arrays.equals(returnValue.getFieldTypes(), types) && Arrays.equals(returnValue.getValues(), values) && returnValue.getChronology().equals(chronology == null ? ISOChronology.getInstance() : chronology);
```


