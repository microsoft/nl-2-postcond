```java
// Check if the returned length is non-negative since the length of a collection cannot be negative
assert returnValue >= -1 : "The returned length should be non-negative or -1";
```


