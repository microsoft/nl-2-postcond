```java
// Postcondition: After _verifySharing is called, _hashShared should be false
assert (!_hashShared);
```


