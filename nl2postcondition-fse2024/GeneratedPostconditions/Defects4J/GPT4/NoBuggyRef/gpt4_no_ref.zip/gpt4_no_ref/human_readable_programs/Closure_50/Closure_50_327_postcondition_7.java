```java
// Checks if the return value is a constant string when the input node is an array join with a string delimiter
assert !(n.isCall() && n.hasOneChild() && n.getFirstChild().isGet() && n.getFirstChild().getString().equals("join")) || returnValue.isString() || returnValue == n;
```


