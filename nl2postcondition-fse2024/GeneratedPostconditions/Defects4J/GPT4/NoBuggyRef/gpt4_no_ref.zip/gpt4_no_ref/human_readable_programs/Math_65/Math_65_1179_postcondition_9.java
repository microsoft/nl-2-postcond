```java
// Postcondition: Ensure that the returnValue is non-negative, as it represents a chi-square value
assert returnValue >= 0 : "The chi-square value must be non-negative";
```


