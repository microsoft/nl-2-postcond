// Ensure the returnValue is non-negative, since chi-square values are always non-negative
assert returnValue >= 0 : "Chi-square value should be non-negative";


