// Check if the returned Node has the same type as the input Node
assert n.getType() == returnValue.getType();


