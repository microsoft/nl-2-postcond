```java
// Check that the member variables are set to their default values after reset
assert OptionBuilder.someMemberVariable1 == DefaultValue1 && OptionBuilder.someMemberVariable2 == DefaultValue2 && ... && OptionBuilder.someMemberVariableN == DefaultValueN;
```


