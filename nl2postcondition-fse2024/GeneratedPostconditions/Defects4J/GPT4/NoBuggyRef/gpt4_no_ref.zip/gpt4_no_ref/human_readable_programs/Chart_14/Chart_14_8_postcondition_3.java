```java
// Checks if the marker was removed when the returnValue is true, and that PlotChangeEvent was sent if notify is true
assert !returnValue || (layer == Layer.FOREGROUND ? !getDomainMarkers(index, layer).contains(marker) : !getDomainMarkers(index, layer).contains(marker)) && (!notify || getListeners(PlotChangeEvent.class).size() > 0);
```


