// Postcondition: Checks if the CALL node has a type assigned after visitCall execution
assert n.getJSType() != null;


