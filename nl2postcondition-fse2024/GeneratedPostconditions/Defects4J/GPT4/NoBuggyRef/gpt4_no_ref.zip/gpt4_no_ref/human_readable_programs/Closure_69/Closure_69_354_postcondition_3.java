// Postcondition: The number of children of the CALL node remains unchanged after visitCall is executed.
int initialChildrenCount = n.getChildCount();
// ... visitCall implementation
assert n.getChildCount() == initialChildrenCount;


