// Postcondition: Checks if the marker was removed according to the returnValue and if notify is true, sends a PlotChangeEvent
assert (!returnValue || (returnValue && notify)) : "Marker removal and notification status do not match";


