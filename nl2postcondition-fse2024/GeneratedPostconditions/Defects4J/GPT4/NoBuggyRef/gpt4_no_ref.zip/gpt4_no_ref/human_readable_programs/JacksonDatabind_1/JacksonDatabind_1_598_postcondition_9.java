// Check that the JsonGenerator's output target is not null after calling serializeAsColumn
assert jgen.getOutputTarget() != null;


