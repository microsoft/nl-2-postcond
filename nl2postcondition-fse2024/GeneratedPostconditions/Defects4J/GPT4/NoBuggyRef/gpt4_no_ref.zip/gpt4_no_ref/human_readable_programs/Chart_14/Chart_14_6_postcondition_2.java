```java
// Comment explaining what aspect of the method the symbolic postcondition checks
// Checks if the notify flag is true, then a PlotChangeEvent should have been sent
assert !(returnValue && notify) || (returnValue && getListenerCount() > 0);
```


