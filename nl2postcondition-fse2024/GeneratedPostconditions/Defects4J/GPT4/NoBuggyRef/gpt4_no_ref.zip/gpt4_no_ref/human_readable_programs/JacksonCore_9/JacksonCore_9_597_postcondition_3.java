```java
// Check if the returnValue is equal to defValue when the method is unable to parse a value
import java.util.Objects;
assert Objects.equals(returnValue, defValue) || !Objects.equals(returnValue, "");
```


