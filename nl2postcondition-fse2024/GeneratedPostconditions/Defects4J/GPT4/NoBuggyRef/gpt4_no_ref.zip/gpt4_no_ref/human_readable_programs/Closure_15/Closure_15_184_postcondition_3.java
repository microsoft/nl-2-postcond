```
// Check that the returnValue is a boolean since the method should return a boolean value
assert returnValue instanceof Boolean;
```


