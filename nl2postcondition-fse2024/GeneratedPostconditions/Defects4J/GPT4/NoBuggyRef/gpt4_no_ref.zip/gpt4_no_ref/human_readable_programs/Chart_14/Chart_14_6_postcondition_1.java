```java
// Checks if the PlotChangeEvent is sent only when the returnValue is true and notify is true
assert !notify || returnValue == false || (returnValue && getListeners(PlotChangeEvent.class).length > 0);
```


