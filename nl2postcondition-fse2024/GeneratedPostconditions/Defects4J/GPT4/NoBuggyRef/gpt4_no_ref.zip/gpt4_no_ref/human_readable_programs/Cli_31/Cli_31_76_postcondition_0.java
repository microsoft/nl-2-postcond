// Check if the buffer length has increased after appending the option
assert buff.length() < buff.length() + option.toString().length() + (required ? 0 : 2) : "Buffer length should increase after appending the option";


