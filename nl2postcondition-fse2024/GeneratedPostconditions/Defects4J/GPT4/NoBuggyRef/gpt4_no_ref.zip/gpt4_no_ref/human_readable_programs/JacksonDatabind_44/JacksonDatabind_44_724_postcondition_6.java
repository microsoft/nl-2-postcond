```java
// Check that the returned JavaType has the same raw class as the given subclass
assert returnValue.getRawClass().equals(subclass);
```


