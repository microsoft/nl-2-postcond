// Check that the returned solution has the same number of variables as the original number of decision variables
assert returnValue.getPointRef().length == getOriginalNumDecisionVariables();


