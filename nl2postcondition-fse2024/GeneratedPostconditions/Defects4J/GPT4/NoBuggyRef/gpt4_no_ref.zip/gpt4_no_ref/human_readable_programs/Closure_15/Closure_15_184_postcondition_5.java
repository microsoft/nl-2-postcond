```
// Check if the return value is a boolean, as specified by the method's return type
import java.lang.Boolean;
assert returnValue instanceof Boolean;
```


