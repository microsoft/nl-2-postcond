// Postcondition: If returnValue is true, the marker was actually removed
assert !(returnValue) || (returnValue && !getRangeMarkers(index, layer).contains(marker));


