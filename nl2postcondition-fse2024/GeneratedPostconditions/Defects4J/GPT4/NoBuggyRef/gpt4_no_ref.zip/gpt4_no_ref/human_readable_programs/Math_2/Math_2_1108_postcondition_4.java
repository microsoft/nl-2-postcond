```java
// Check if the returnValue is equal to the expected mean value calculated using the formula: n * m / N.
assert returnValue == ((double)getSampleSize() * getNumberOfSuccesses()) / getPopulationSize() : "The returned mean value doesn't match the expected value";
```


