```java
import java.lang.Math;

// Check that the returnValue is non-negative as the root of a non-negative value (RMS) should be non-negative
assert returnValue >= 0 && returnValue == Math.sqrt(getCriterion() / getMeasurements()) : "The returnValue must be the square root of the criterion divided by the number of measurements";
```


