```java
// Checks if the marker was removed when the return value is true
assert !(returnValue) || !((layer == Layer.FOREGROUND ? getDomainMarkers(index, layer) : getDomainMarkers(index, layer)).contains(marker));
```


