// Check if member variables are reset to their default values after calling the method
assert defaultValue1.equals(memberVariable1) && defaultValue2.equals(memberVariable2) && ... && defaultValueN.equals(memberVariableN) : "Member variables not reset to default values";


