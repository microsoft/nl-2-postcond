// Ensure the sharing status of the hash area is not shared after _verifySharing execution
assert !_hashShared;


