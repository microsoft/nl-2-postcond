// Check if the returned value is consistent with the entry name ending with a "/"
assert returnValue == (name.endsWith("/") && linkFlag != LF_LINK);


