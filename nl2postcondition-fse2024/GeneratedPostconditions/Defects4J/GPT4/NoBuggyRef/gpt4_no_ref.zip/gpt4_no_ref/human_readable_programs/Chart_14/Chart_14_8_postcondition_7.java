```java
// The postcondition checks that if the marker was actually removed, a PlotChangeEvent should be sent to all registered listeners when notify is true
assert !(returnValue && notify) || (returnValue && notify && someListenersReceivedEvent());
```


