```java
// Check if the returnValue is consistent with the size of the params list
import java.util.List;
assert returnValue >= 0 && returnValue <= params.size() : "returnValue should be between 0 and the size of the params list";
```


