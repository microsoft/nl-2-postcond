```java
// Check that the returned mean value is equal to the product of sample size and number of successes divided by population size
assert returnValue == (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize();
```


