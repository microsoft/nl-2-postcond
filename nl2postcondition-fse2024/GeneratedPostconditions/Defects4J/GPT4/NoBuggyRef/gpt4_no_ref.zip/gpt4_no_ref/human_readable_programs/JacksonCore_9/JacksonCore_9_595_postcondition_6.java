// Postcondition: Check if the returned value is either equal to the input defValue or not null
assert (returnValue != null && !returnValue.isEmpty()) || returnValue.equals(defValue);


