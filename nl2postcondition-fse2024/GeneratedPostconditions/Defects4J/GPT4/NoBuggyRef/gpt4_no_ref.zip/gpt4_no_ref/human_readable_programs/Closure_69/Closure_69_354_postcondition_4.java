// Postcondition: The CALL node has a JSType assigned to it after visitCall execution
assert n.getJSType() != null;


