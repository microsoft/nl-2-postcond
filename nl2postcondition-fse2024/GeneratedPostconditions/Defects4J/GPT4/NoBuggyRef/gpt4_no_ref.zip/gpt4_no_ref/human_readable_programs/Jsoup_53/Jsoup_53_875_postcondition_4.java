```java
// Check if the remaining queue after calling chompBalanced starts with the closing character
assert queue.substring(pos).startsWith(Character.toString(close));
```


