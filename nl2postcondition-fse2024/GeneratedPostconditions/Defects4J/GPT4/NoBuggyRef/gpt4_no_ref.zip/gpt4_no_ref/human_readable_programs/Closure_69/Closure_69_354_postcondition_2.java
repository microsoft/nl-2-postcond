// Postcondition checks that after visiting a CALL node, the node has a JSType assigned to it
assert n.getJSType() != null;


