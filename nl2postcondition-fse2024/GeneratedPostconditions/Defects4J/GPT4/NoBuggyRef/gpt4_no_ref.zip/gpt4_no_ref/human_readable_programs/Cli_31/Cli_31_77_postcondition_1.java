// Check if the member variables are set to their default values after reset() is called
assert (someMemberVariable1 == defaultValue1) && (someMemberVariable2 == defaultValue2) && (someMemberVariable3 == defaultValue3) : "Member variables should be reset to their default values";


