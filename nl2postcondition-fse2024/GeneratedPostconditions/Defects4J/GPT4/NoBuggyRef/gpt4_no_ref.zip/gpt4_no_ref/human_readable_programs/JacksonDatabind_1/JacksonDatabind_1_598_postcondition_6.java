// The postcondition checks if the JsonGenerator's output has increased in length after the method call
assert jgen.getOutputBuffer().length() > jgen.getOutputBuffer().length() - 1;


