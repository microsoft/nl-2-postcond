// Postcondition: Ensures that _hashShared is set to false after _verifySharing
assert !_hashShared;


