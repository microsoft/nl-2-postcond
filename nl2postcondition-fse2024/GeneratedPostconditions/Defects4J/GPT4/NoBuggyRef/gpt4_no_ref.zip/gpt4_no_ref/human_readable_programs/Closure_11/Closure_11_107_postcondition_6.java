// The postcondition checks that the node `n` has a JSType after the method visitGetProp is executed
assert n.getJSType() != null;


