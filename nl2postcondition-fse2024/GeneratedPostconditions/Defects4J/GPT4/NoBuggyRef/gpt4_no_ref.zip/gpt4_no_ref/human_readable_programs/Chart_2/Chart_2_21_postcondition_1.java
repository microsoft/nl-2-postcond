// Check if the returned range is null or includes all y-values (and y-intervals if includeInterval is true) of the dataset
assert returnValue == null || dataset.getSeriesCount() == 0 || IntStream.range(0, dataset.getSeriesCount()).allMatch(i -> IntStream.range(0, dataset.getItemCount(i)).allMatch(j -> (returnValue.getLowerBound() <= dataset.getYValue(i, j) && dataset.getYValue(i, j) <= returnValue.getUpperBound()) && (!includeInterval || !(dataset instanceof IntervalXYDataset) || (returnValue.getLowerBound() <= ((IntervalXYDataset) dataset).getStartYValue(i, j) && ((IntervalXYDataset) dataset).getEndYValue(i, j) <= returnValue.getUpperBound()))));


