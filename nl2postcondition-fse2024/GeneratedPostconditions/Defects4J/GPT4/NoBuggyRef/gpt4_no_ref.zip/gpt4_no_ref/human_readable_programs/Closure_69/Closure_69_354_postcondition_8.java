// Postcondition: checks if the last child of the CALL node has a JSType after visitCall is executed
assert n.getLastChild().getJSType() != null;


