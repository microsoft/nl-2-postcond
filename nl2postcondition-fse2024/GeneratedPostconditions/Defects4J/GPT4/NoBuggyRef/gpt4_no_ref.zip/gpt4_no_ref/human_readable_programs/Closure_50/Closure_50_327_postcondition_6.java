```java
// Check that the returned value is either a STRING node or the same node as input
assert returnValue == n || returnValue.getType() == Token.STRING;
```


