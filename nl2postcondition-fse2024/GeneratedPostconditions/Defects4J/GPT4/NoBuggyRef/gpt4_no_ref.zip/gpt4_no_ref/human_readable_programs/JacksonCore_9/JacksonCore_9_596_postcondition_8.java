```
// Check if the returned string is not null after successfully executing getValueAsString
assert returnValue != null;
```


