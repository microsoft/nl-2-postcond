```java
// Checks that the returnValue is either 0 or 1, reflecting the boolean option being set
assert returnValue == 0 || returnValue == 1;
```


