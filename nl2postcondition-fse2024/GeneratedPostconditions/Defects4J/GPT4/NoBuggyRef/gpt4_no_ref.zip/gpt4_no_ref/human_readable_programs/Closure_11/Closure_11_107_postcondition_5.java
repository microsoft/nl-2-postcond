// Postcondition: After visiting a GETPROP node, if the node is typed, its type is not null and it matches the type of its last child
assert !n.isTyped() || (n.getJSType() != null && n.getJSType().equals(n.getLastChild().getJSType()));


