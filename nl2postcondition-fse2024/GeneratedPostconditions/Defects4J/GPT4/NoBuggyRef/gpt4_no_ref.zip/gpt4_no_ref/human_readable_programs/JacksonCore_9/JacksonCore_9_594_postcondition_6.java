```java
// Check if the length of the returnValue is the same as the length of the textBuffer after calling _finishString()
assert returnValue.length() == _textBuffer.contentsAsArray().length;
```


