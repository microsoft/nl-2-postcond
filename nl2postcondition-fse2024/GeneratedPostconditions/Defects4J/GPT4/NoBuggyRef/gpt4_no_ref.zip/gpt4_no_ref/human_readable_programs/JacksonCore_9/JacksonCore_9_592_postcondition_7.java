// Check that returnValue is either null or a scalar value
assert returnValue == null || _currToken == JsonToken.VALUE_STRING || (_currToken != null && _currToken.isScalarValue());


