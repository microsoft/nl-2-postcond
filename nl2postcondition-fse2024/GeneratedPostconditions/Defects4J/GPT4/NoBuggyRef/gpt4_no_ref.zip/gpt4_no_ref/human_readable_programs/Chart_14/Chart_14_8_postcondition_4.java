// Check if the marker was actually removed based on the return value
assert (returnValue == true) == (getDomainMarkers(index, layer) == null || !getDomainMarkers(index, layer).contains(marker));


