```java
// Postcondition: The returnValue should be equal to the current value of _textBuffer as a String
assert returnValue.equals(_textBuffer.contentsAsString());
```


