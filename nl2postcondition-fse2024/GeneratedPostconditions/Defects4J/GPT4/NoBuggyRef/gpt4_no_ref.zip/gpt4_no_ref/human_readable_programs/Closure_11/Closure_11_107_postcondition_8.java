// Postcondition: Checks if the given GETPROP node's JSType is not null after the method execution
assert n.getJSType() != null;


