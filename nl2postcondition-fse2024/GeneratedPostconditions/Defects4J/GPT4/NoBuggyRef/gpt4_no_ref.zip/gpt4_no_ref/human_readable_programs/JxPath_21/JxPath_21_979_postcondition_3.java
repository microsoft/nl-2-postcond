```java
// Postcondition: Checks if the returned length is either -1 or non-negative (>= 0)
assert returnValue == -1 || returnValue >= 0 : "Invalid length, should be either -1 or non-negative";
```


