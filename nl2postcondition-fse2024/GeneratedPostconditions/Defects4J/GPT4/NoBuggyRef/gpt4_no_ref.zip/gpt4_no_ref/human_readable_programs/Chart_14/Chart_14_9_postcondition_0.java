// Check if the marker was removed when returnValue is true and notify is true
assert !(returnValue && notify) || (returnValue && !getRangeMarkers(index, layer).contains(marker));


