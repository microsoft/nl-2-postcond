```java
// Check if leading whitespace is removed when stripLeading is true
assert !(stripLeading && StringUtil.isActuallyWhitespace(accum.charAt(0)));
```


