// Checks if the return value is null or the node n has a valid JSType after visitGetProp
assert returnValue == null || n.getJSType() != null && n.getJSType().isValid();


