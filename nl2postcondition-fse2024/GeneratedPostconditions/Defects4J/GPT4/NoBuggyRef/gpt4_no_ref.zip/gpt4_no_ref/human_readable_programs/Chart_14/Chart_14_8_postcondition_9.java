// Check if the marker was removed from the specified layer when returnValue is true
assert !(returnValue && (layer == Layer.FOREGROUND ? getDomainForegroundMarkers(index).contains(marker) : getDomainBackgroundMarkers(index).contains(marker))) : "Marker not removed from the specified layer";


