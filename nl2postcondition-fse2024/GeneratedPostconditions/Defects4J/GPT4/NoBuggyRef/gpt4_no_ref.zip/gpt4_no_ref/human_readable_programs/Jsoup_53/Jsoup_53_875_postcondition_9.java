```java
// Check if the opened brackets are balanced with closed brackets in the returnValue
assert returnValue.chars().filter(c -> c == open).count() == returnValue.chars().filter(c -> c == close).count();
```


