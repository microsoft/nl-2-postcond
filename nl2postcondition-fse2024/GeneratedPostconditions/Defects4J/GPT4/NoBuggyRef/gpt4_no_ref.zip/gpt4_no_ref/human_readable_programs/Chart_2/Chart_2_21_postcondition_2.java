// Check if the returned range has the correct lower and upper bound considering the y-interval flag
assert (returnValue == null) || 
(dataset.getSeriesCount() == 0) || 
(includeInterval && (
    returnValue.getLowerBound() <= dataset.getYValue(0, 0) &&
    dataset.getYValue(0, 0) <= returnValue.getUpperBound() &&
    returnValue.getLowerBound() <= dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) &&
    dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) <= returnValue.getUpperBound())) || 
(!includeInterval && (
    returnValue.getLowerBound() <= dataset.getYValue(0, 0) &&
    dataset.getYValue(0, 0) <= returnValue.getUpperBound() &&
    returnValue.getLowerBound() <= dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) &&
    dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) <= returnValue.getUpperBound()));


