// Postcondition: Check that the returnValue is non-negative, as RMS value is the square root of a non-negative value
assert returnValue >= 0;


