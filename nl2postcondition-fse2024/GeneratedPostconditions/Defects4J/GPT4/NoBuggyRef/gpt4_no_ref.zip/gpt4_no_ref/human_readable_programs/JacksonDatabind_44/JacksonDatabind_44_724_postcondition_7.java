// Postcondition checks if the returnValue is an instance of SimpleType and has the same raw class as subclass
assert returnValue instanceof SimpleType && returnValue.getRawClass().equals(subclass) : "The return value should be an instance of SimpleType with same raw class as subclass";


