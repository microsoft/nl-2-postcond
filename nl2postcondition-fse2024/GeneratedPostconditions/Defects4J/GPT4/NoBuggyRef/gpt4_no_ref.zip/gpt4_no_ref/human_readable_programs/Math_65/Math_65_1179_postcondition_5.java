// Ensure that the returnValue is non-negative, as chi-square values are always non-negative
assert returnValue >= 0 : "Chi-square value must be non-negative";


