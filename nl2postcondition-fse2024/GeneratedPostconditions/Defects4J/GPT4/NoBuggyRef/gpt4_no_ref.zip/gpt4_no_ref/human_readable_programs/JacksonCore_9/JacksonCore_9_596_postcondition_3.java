```
// Postcondition: Check if the returned value is a String and not null
assert returnValue != null && returnValue instanceof String;
```


