// Check if the returnValue (chi-square value) is non-negative
assert returnValue >= 0.0 : "The chi-square value must be non-negative";


