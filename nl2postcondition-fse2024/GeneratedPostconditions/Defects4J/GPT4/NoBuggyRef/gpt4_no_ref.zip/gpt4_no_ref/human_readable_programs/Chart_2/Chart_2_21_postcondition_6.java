```java
// Postcondition: Checks if the returned range is non-negative and within the dataset's range
assert returnValue == null || (returnValue.getLowerBound() >= 0 && returnValue.getUpperBound() <= dataset.getSeriesCount());
```


