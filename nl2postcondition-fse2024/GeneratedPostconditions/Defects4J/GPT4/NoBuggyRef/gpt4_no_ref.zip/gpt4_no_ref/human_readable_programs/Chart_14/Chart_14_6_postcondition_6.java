```java
// Postcondition: If the returnValue is true, the marker has been removed from the specified layer
assert (returnValue == true) == (!getDomainMarkers(index, layer).contains(marker));
```


