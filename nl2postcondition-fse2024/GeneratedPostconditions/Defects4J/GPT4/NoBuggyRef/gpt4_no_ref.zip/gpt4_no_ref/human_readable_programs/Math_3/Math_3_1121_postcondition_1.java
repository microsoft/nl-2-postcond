// Check that the dimensions of input arrays a and b are the same
assert a.length == b.length : "Input arrays dimensions do not match";


