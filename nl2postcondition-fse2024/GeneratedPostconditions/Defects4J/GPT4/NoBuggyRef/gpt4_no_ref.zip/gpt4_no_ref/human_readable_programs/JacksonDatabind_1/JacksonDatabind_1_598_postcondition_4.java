// Check that the JsonGenerator's output buffer does not contain field names after the method execution
assert jgen.getOutputContext().getCurrentName() == null;


