// Check if the returnValue is true, then the marker must be removed from the specified layer
assert !returnValue || (layer == Layer.FOREGROUND ? !getRangeMarkers(Layer.FOREGROUND).contains(marker) : !getRangeMarkers(Layer.BACKGROUND).contains(marker));


