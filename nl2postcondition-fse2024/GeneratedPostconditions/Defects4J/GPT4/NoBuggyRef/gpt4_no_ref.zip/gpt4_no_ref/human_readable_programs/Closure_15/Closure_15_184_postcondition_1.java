```java
// Checks if the returnValue is a boolean
assert returnValue instanceof Boolean;
```


