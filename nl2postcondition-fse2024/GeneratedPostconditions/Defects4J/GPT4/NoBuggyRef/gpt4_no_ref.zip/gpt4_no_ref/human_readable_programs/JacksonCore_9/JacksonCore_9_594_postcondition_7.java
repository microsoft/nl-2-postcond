// Postcondition: Check if the returnValue is not null and not empty
assert returnValue != null && !returnValue.isEmpty();


