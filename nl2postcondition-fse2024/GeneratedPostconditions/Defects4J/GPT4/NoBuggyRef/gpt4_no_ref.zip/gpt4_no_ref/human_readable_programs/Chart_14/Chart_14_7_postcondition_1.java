// Postcondition: Checks if the returnValue is consistent with the notify parameter
assert (returnValue == true && notify == true) || (returnValue == false) : "Return value is inconsistent with the notify parameter";


