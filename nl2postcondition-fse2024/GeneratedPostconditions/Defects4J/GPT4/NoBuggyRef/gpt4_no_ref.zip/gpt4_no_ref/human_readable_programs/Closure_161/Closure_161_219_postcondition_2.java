// Check if the returned node has the same type as the input node 'n' when folding is not possible
assert (returnValue == n) || (left.getType() == Token.ARRAYLIT && returnValue.getType() == Token.NUMBER);


