```java
// Checks if the returned row value is either null or within the valid range of tableau rows, ignoring objective rows if specified
assert returnValue == null || (returnValue >= (ignoreObjectiveRows ? getNumObjectiveFunctions() : 0) && returnValue < getHeight());
```


