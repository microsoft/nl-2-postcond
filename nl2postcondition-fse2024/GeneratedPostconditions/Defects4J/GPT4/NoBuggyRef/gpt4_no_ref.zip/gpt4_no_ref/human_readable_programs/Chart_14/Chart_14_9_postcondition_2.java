```java
// Postcondition: Check if the notify parameter is true, then a PlotChangeEvent should be fired
assert !(returnValue && notify) || (returnValue && this.listenerList.getListenerCount(PlotChangeEvent.class) > 0);
```


