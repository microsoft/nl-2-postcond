// Postcondition: Checks if the returnValue is either equal to defValue or not null
assert returnValue == null || returnValue.equals(defValue) || !returnValue.isEmpty();


