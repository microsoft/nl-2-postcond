```
// Checks if the returnValue is either the same as the default value or is a non-null, scalar value
assert returnValue.equals(getValueAsString(null)) || (_currToken != null && _currToken.isScalarValue() && returnValue != null);
```


