```java
// Postcondition: Ensures that the range returned is non-negative and not null if the dataset is not empty
assert returnValue != null && returnValue.getLength() >= 0 && (dataset.getItemCount(0) > 0 || returnValue.getLength() == 0);
```


