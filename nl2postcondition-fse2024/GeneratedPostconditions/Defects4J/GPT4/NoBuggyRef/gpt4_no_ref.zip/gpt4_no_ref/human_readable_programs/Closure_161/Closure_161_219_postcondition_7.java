```java
// Postcondition: Ensures the returned value is either n or a folded array access
assert returnValue == n || (returnValue.getType() == Token.ARRAYLIT && returnValue.getParent() == n.getParent());
```


