```java
// Check if the mean value is equal to n * m / N
assert returnValue == (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize() : "Mean value does not match the expected value";
```


