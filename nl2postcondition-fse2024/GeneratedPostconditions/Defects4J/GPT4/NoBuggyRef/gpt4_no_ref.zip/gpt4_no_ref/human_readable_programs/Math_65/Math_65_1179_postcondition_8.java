```java
// Check if the returned chi-square value is non-negative, as it represents a squared quantity
assert returnValue >= 0 : "Chi-square value must be non-negative";
```


