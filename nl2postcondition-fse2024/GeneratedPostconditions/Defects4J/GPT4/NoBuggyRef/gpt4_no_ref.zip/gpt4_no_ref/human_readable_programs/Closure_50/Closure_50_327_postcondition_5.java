// Check if the returnValue has the same number of elements as the input Node n when not joining arrays
assert !(n.isArrayLit() && n.getChildCount() > 1) || returnValue.getChildCount() == n.getChildCount();


