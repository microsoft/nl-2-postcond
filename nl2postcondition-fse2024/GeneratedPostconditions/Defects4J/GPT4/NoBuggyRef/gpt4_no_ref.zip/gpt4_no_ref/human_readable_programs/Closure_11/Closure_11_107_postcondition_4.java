// Postcondition: The node n is of type GETPROP and has at least one child
assert n.getType() == Token.GETPROP && n.hasChildren();


