// Postcondition: Ensure that the _hashShared variable is false after _verifySharing is executed
assert !_hashShared;


