// Check if the length of the accumulated string builder is greater than or equal to the input string length after normalizing whitespace
assert accum.length() >= string.replaceAll("\\s+", " ").trim().length();


