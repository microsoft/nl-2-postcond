// Postcondition checks that the JsonGenerator's output mode is set to non-pretty (since it is used for column serialization)
assert jgen.getOutputContext().inArray() && !jgen.getPrettyPrinter().isEnabled(jgen);


