```java
// Check that if the returnValue is not null, then the column is basic in the returned row and ignores objective rows if ignoreObjectiveRows is true
assert (returnValue == null) || (tableau.getEntry(returnValue, col) == 1 && (!ignoreObjectiveRows || returnValue >= getNumObjectiveFunctions()));
```


