// Check if the marker was actually removed and notify status is consistent with the return value
assert (returnValue == false && notify == true) || (returnValue == true && notify == false) || (returnValue == false && notify == false);


