```
// Asserts that the return value is of type boolean since the compute method should return a boolean result
assert returnValue instanceof Boolean;
```


