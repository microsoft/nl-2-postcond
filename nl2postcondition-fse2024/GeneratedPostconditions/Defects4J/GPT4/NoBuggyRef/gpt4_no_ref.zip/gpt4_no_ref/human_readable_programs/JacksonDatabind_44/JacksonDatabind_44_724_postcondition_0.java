```java
// Check if the returnValue's raw class is a subclass of the input subclass
import java.lang.Class;
assert returnValue.getRawClass().isAssignableFrom(subclass);
```


