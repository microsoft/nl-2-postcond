// Check that the derived fields have been initialized after calling init
assert formatPattern != null && tzsCache != null : "Derived fields are not initialized";


