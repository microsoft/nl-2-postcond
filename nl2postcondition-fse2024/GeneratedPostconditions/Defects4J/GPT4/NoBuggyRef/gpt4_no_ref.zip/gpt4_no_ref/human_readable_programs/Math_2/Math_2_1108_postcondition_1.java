```java
// Check if the returned mean value is equal to the expected value based on the formula n * m / N
assert returnValue == (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize();
```


