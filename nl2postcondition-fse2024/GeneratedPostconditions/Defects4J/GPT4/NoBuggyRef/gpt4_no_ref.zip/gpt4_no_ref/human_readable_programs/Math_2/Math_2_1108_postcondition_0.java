```java
// Check if the returnValue is equal to the expected mean value (n * m / N)
assert returnValue == (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize();
```


