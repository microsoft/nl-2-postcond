```java
// Postcondition: The returned StdKeyDeserializer should have the same raw type as the input raw
assert returnValue.getDeserializedType().equals(raw);
```


