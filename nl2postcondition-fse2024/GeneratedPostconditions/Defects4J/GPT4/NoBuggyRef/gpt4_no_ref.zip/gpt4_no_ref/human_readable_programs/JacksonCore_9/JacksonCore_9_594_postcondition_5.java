// Check if the returned string has the same length as the content in the _textBuffer
assert returnValue.length() == _textBuffer.contentsAsArray().length;


