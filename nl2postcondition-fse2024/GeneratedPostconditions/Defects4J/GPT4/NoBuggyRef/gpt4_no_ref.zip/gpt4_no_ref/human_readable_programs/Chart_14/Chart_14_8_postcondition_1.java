// Check if the marker was removed from either foreground or background domain markers
assert (returnValue == (!getDomainMarkers(index, Layer.FOREGROUND).contains(marker) && !getDomainMarkers(index, Layer.BACKGROUND).contains(marker)));


