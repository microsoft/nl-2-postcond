// Postcondition checks if the CALL node type has a JSType assigned after calling visitCall
assert n.getType() == Token.CALL && n.getJSType() != null;


