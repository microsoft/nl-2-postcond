// Check if the returned value is either defValue or a non-empty string
assert returnValue.equals(defValue) || !returnValue.isEmpty();


