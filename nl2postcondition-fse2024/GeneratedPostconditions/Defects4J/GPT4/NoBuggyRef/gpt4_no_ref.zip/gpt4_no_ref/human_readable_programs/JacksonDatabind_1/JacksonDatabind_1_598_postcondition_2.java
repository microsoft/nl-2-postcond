// Postcondition checks that the JsonGenerator's output mode is non-structured
assert jgen.getOutputContext().inNonArray(): "JsonGenerator should be in non-array output mode after serializeAsColumn";


