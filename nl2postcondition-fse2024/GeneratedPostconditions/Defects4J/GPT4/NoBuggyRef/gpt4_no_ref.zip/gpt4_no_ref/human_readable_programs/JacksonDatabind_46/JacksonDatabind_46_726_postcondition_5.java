// Check that the input StringBuilder has the same length before and after the method call
assert sb.length() + returnValue.length() == sb.length() + _referencedType.getGenericSignature(new StringBuilder()).length();


