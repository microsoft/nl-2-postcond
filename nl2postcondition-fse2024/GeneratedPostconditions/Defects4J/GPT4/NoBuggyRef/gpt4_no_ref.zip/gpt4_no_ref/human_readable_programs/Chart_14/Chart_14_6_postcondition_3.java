```java
// Postcondition: If the method returns true, the marker is removed from the relevant layer
assert !(returnValue && (layer == Layer.FOREGROUND ? getDomainMarkers(index, Layer.FOREGROUND).contains(marker) : getDomainMarkers(index, Layer.BACKGROUND).contains(marker)));
```


