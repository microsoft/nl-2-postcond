// Postcondition checks if the returned array's length is equal to or less than the input arguments array's length
assert returnValue.length <= arguments.length;


