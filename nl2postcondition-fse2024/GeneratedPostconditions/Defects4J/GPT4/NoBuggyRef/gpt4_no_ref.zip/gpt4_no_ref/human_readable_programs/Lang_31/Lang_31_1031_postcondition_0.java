// Check that returnValue is true if there is a match between cs and searchChars, and false otherwise
assert (returnValue == true && !Collections.disjoint(cs.chars().boxed().collect(Collectors.toList()), IntStream.of(searchChars).boxed().collect(Collectors.toList())))
        || (returnValue == false && Collections.disjoint(cs.chars().boxed().collect(Collectors.toList()), IntStream.of(searchChars).boxed().collect(Collectors.toList())));


