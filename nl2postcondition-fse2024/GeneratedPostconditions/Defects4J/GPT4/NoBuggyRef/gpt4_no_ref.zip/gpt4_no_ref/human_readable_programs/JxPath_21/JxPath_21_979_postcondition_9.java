```java
// Checks if the returnValue of getLength is either -1 or non-negative (greater than or equal to 0)
assert returnValue == -1 || returnValue >= 0 : "Invalid return value for getLength, must be -1 or non-negative";
```


