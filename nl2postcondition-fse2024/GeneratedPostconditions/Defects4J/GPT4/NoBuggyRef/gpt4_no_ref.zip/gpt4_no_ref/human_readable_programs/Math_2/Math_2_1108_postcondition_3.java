// Checks if the returned mean value is consistent with the specified formula n * m / N
assert returnValue == (double) getSampleSize() * getNumberOfSuccesses() / getPopulationSize();


