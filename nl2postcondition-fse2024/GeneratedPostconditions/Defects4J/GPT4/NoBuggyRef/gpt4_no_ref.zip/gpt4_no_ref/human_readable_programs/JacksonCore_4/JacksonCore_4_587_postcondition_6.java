// Check if the returned array is larger than the initial current segment
assert returnValue.length > this.currentSegment.length;


