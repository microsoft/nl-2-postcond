```java
import java.util.Set;
import java.util.stream.Collectors;

// Postcondition: The returnValue should be equal to the number of arguments consumed by the parseArguments method.
assert returnValue == params.getArguments().stream().filter(arg -> TRUES.contains(arg.toLowerCase()) || FALSES.contains(arg.toLowerCase())).collect(Collectors.toSet()).size();
```


