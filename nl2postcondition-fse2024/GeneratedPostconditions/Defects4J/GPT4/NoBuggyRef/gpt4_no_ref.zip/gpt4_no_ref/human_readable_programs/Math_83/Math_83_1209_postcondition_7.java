```java
// Check that if the returnValue is not null, the col value at the returnValue row is 1
assert returnValue == null || (returnValue >= 0 && returnValue < getHeight() && tableau.getEntry(returnValue, col) == 1);
```


