```java
// Postcondition: checks if the returnValue is of type boolean
assert returnValue instanceof Boolean;
```


