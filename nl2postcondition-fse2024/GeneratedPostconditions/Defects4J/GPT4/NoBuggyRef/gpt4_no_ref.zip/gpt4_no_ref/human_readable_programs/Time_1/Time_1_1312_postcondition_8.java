```java
// Check if the length of types array is equal to the length of values array in the constructed Partial object
assert returnValue.getTypes().length == types.length && returnValue.getValues().length == values.length;
```


