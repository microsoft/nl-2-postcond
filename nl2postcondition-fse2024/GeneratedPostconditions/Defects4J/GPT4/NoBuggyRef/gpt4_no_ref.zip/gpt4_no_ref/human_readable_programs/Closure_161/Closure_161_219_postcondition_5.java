```java
// Check if the returned Node is either the original node 'n' or a folded constant node
assert returnValue == n || (returnValue.getType() == Token.NUMBER && returnValue.isConstant());
```


