// Check that the returnValue is false when cs or searchChars is null or empty
assert (!(returnValue) || (cs != null && searchChars != null && cs.length() > 0 && searchChars.length > 0));


