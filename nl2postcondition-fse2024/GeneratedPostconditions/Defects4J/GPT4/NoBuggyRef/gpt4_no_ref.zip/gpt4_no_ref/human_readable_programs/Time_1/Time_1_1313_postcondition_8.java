// Check if the returned value is always zero, indicating sort order is not relevant
assert returnValue == 0;


