// Postcondition checks if the notify parameter is true, then the returnValue should also be true
assert !notify || returnValue;


