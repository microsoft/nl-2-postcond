// Check that the returnValue is either the defaultValue or a non-empty string
assert returnValue == defaultValue || !returnValue.isEmpty();


