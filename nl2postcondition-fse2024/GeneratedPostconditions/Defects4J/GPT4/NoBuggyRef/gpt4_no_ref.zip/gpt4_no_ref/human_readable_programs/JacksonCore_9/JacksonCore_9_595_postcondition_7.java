// Check if the returned value equals the default value when the default value is not null
assert (defValue != null) ? returnValue.equals(defValue) : true;


