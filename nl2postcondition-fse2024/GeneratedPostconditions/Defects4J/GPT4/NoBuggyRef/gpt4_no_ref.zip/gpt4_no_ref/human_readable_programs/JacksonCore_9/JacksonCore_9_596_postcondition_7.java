// Check if the returned value is not null and is a string
assert returnValue != null && returnValue instanceof String;


