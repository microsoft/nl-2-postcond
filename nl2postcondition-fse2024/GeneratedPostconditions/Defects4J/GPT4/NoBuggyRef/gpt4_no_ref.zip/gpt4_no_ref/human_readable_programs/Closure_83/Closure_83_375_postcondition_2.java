```java
// Postcondition: The returnValue, representing the number of arguments consumed, should be non-negative
assert returnValue >= 0;
```


