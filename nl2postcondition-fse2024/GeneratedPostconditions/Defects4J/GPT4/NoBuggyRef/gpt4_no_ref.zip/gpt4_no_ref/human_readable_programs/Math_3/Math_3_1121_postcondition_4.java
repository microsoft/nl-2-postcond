// Check if the dimensions of both input arrays are equal
assert a.length == b.length : "DimensionMismatchException: Arrays a and b must have the same length";


