```java
// Check if the constructed Partial object has the same field types and values as the input parameters
assert Arrays.equals(returnValue.getFieldTypes(), types) && Arrays.equals(returnValue.getValues(), values);
```


