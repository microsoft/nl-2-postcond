// Check whether the returnValue is true if the entry name ends with a '/'
assert (returnValue == name.endsWith("/"));


