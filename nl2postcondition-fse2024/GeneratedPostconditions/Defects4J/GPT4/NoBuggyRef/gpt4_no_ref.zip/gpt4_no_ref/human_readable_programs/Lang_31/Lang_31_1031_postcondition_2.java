```java
// Check if the returnValue is false when the input CharSequence is null or empty, or the searchChars array is null or empty
assert (cs == null || cs.length() == 0 || searchChars == null || searchChars.length == 0) ? !returnValue : true;
```


