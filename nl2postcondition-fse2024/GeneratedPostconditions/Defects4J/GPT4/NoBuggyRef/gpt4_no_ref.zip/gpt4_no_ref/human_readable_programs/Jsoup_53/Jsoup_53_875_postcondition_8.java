```java
// Check if the returned balanced string has equal number of opening and closing characters
assert returnValue.chars().filter(ch -> ch == open).count() == returnValue.chars().filter(ch -> ch == close).count();
```


