// Check that the range includes the dataset's x-values with or without the intervals
assert returnValue == null || (dataset.getSeriesCount() == 0 || (returnValue.getLowerBound() <= (includeInterval && dataset instanceof IntervalXYDataset ? ((IntervalXYDataset) dataset).getStartXValue(0, 0) : dataset.getXValue(0, 0)) && returnValue.getUpperBound() >= (includeInterval && dataset instanceof IntervalXYDataset ? ((IntervalXYDataset) dataset).getEndXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) : dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1))));


