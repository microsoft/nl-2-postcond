```java
// Assert that the range is non-negative and includes the lower and upper bounds of x-values in the dataset
assert returnValue == null || (returnValue.getLowerBound() <= dataset.getXValue(0, 0) && returnValue.getUpperBound() >= dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) && returnValue.getLength() >= 0);
```


