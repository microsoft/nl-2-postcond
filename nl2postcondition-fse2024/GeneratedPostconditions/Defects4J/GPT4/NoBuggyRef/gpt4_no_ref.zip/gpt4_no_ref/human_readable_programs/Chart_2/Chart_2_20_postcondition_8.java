```java
// Check that the returned range includes all x-values from the dataset, considering the includeInterval flag
import org.jfree.data.Range;
assert returnValue == null || dataset.getSeriesCount() == 0 || (includeInterval && dataset instanceof IntervalXYDataset
        ? Range.include(Range.combine(returnValue, new Range(dataset.getXValue(0, 0) - ((IntervalXYDataset) dataset).getStartXValue(0, 0),
                                      dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)
                                      + ((IntervalXYDataset) dataset).getEndXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)), returnValue).contains(dataset.getXValue(0, 0) - ((IntervalXYDataset) dataset).getStartXValue(0, 0))
                 && Range.combine(returnValue, new Range(dataset.getXValue(0, 0) - ((IntervalXYDataset) dataset).getStartXValue(0, 0),
                                      dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)
                                      + ((IntervalXYDataset) dataset).getEndXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)), returnValue).contains(dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)
                    + ((IntervalXYDataset) dataset).getEndXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1))
        : returnValue.contains(dataset.getXValue(0, 0)) && returnValue.contains(dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)));
```


