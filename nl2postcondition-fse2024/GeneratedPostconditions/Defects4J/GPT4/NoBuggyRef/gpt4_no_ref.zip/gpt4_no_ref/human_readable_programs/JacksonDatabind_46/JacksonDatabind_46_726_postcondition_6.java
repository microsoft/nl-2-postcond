```java
// Check if the returnValue has the same length as the input StringBuilder sb after appending the referencedType's generic signature
assert returnValue.length() == sb.length() + _referencedType.getGenericSignature().length();
```


