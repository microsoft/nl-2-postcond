// Checks that if the method returns true, the marker is removed from the specified layer
assert !(returnValue) || !((layer == Layer.FOREGROUND ? getDomainMarkers(index, Layer.FOREGROUND) : getDomainMarkers(index, Layer.BACKGROUND)).contains(marker));


