```java
// Check that the returnValue (RMS value) is non-negative
assert returnValue >= 0.0 : "RMS value must be non-negative";
```


