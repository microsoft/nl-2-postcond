// Checks if the returnValue is true when the methods of both Invocations are equal
assert !(returnValue) || (candidate.getMethod().equals(invocation.getMethod()));


