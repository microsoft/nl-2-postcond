// Check if the output buffer of JsonGenerator has increased in size after calling serializeAsColumn
long initialOutputSize = jgen.getOutputContext().getOutputBuffered();
serializeAsColumn(bean, jgen, prov);
long finalOutputSize = jgen.getOutputContext().getOutputBuffered();
assert finalOutputSize > initialOutputSize;


