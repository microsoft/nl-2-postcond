```java
// Postcondition: Asserts that if the marker was actually removed, the 'notify' flag should be true for a plot change event to be sent
assert !returnValue || (returnValue && notify);
```


