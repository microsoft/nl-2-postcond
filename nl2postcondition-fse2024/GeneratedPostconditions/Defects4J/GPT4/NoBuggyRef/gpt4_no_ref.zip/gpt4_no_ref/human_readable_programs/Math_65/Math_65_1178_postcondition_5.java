```java
// Postcondition: Check if the returnValue (RMS) is non-negative
assert returnValue >= 0.0 : "Root Mean Square value cannot be negative";
```


