// Ensure that the process method returns true only if the input Token is not null
assert (t != null) == returnValue;


