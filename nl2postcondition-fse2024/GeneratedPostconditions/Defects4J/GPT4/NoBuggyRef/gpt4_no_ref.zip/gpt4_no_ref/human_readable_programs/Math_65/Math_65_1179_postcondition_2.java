```java
// Check if the returnValue is a non-negative value, as chi-square values are always non-negative
assert returnValue >= 0 : "Chi-square value should be non-negative";
```


