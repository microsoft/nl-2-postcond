```java
// Check if the returned range (if not null) has lower bound less than or equal to upper bound
import org.jfree.data.Range;

assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();
```



