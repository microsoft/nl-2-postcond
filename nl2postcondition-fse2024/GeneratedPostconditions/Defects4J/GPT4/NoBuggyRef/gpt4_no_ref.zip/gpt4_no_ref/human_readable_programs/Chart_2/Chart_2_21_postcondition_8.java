// Check that the returned range is not null and its lower bound is less than or equal to the upper bound
assert returnValue != null && returnValue.getLowerBound() <= returnValue.getUpperBound();


