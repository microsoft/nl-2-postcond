// Check if the returned row is within the valid range of the tableau or null
assert (returnValue == null) || (returnValue >= (ignoreObjectiveRows ? getNumObjectiveFunctions() : 0) && returnValue < getHeight());


