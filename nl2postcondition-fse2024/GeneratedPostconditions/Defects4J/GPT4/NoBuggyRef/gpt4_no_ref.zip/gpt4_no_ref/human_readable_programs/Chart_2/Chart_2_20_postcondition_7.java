// Check if the returned range has the correct lower and upper bounds based on the dataset and includeInterval flag
assert (returnValue == null) || (includeInterval && dataset instanceof IntervalXYDataset
        ? (returnValue.getLowerBound() == ((IntervalXYDataset) dataset).getStartXValue(0, 0)
            && returnValue.getUpperBound() == ((IntervalXYDataset) dataset).getEndXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1))
        : (returnValue.getLowerBound() == dataset.getXValue(0, 0)
            && returnValue.getUpperBound() == dataset.getXValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1)));


