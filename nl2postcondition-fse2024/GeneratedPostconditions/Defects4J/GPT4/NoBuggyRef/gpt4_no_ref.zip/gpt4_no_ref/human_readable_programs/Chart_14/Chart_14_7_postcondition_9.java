```java
// Check if the returnValue is true when the notify parameter is true
assert !notify || returnValue;
```


