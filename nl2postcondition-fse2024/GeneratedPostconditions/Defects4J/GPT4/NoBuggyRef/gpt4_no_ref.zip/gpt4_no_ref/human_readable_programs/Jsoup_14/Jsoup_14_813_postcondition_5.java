// Check that the input parameters remain unchanged after the method call
assert t.equals(t) && r.equals(r);


