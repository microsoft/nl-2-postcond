// Postcondition: Checks if the node type is still Token.CALL after visitCall method execution
assert n.getType() == Token.CALL;


