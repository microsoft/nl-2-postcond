```java
// The postcondition checks if the returnValue is false when the marker is null.
assert (marker != null) || !returnValue;
```


