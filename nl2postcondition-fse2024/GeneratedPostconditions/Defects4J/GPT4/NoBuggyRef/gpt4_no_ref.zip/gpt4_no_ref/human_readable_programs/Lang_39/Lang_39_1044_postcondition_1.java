```java
import java.util.Objects;

// Postcondition checks that the length of the returnValue is the same as the input text when neither searchList nor replacementList have non-null elements
assert text == null || ((searchList == null || searchList.length == 0 || searchList[0] == null) && (replacementList == null || replacementList.length == 0 || replacementList[0] == null)) ? Objects.equals(returnValue, text) : true;
```


