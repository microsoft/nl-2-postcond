// The postcondition checks if the return value is true when the input Node n is not null, otherwise false
assert (returnValue == (n != null));


