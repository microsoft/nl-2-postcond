// Check if the entry name ends with a "/" and if it corresponds to the returnValue being a directory
assert (name.endsWith("/") == returnValue);


