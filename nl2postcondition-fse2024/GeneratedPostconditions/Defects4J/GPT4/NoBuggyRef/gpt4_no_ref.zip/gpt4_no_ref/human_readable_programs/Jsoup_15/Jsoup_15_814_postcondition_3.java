// Check if the returnValue is true, then the input Token t should not be null
assert !(returnValue == true && t == null);


