```java
import java.util.Arrays;

// Checks that the length of the input text is unchanged after the replaceEach operation
assert text == null || returnValue.length() == text.length();
```


