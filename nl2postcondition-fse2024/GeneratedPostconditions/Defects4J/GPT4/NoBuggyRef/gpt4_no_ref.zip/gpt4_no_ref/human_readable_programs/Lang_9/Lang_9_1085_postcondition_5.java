// Checks that the tzsCache is not null after the init method is called
assert tzsCache != null;


