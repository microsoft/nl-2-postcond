// Check if the marker was actually removed and notify listeners based on the return value
assert !returnValue || (returnValue && notify);


