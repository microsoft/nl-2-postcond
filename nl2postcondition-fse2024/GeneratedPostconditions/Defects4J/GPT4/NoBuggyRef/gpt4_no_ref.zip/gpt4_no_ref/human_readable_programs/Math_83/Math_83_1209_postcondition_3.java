```java
// Postcondition: Checks whether the returnValue is either null or within the valid range of rows in the tableau
assert returnValue == null || (returnValue >= (ignoreObjectiveRows ? getNumObjectiveFunctions() : 0) && returnValue < getHeight());
```


