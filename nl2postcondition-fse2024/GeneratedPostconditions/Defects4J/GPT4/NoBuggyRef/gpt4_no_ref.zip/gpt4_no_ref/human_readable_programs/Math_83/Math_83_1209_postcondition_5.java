// Check if the returned row index is within the valid range of rows or null
assert (returnValue == null) || (returnValue >= 0 && returnValue < getHeight());


