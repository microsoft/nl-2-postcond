```java
import java.util.Arrays;

// Check if the length of the returnValue is less than or equal to the length of the input text
assert returnValue == null || text == null || returnValue.length() <= text.length() : "Length of the replaced text should be less than or equal to the length of the input text";
```


