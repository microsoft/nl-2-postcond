// Check that if the marker is removed, the notify flag is set to true
assert !(returnValue) || notify;


