```java
// Check that the return value is true if the Node type is a variable declaration, false otherwise
assert returnValue == (n.getToken() == com.google.javascript.rhino.Token.VAR);
```


