// Check that the default values of member variables are set after reset method is called
assert (variable1 == defaultValue1) && (variable2 == defaultValue2) && (variable3 == defaultValue3);


