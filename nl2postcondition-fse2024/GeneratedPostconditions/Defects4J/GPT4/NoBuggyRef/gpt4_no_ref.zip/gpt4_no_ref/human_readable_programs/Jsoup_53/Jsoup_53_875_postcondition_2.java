```java
// Postcondition: Check if the returnValue contains the balanced open and close characters
assert returnValue.chars().filter(ch -> ch == open).count() == returnValue.chars().filter(ch -> ch == close).count();
```


