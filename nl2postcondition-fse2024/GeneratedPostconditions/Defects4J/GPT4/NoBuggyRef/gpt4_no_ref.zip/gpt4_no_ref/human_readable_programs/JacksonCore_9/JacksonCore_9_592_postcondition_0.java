```java
// Check if the returned value is a String or null
assert returnValue == null || returnValue instanceof String;
```


