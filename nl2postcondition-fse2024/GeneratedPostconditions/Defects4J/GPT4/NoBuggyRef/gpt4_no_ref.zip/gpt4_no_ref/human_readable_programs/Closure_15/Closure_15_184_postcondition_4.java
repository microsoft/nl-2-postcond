// Check that the return value of apply is a boolean
assert returnValue instanceof Boolean;


