```
// Check if the returned value is either a non-empty string or null (when no value is present)
assert returnValue == null || !returnValue.isEmpty();
```


