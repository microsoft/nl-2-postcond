```java
import java.util.Objects;

// Asserts that if text is non-null, the returnValue is also non-null
assert text == null || Objects.nonNull(returnValue);
```


