
# Response 0
// Check that the returned range is either null or has a positive width (upper bound >= lower bound)
assert returnValue == null || returnValue.getUpperBound() >= returnValue.getLowerBound();



# Response 1
// Check if the returned range is null or includes all y-values (and y-intervals if includeInterval is true) of the dataset
assert returnValue == null || dataset.getSeriesCount() == 0 || IntStream.range(0, dataset.getSeriesCount()).allMatch(i -> IntStream.range(0, dataset.getItemCount(i)).allMatch(j -> (returnValue.getLowerBound() <= dataset.getYValue(i, j) && dataset.getYValue(i, j) <= returnValue.getUpperBound()) && (!includeInterval || !(dataset instanceof IntervalXYDataset) || (returnValue.getLowerBound() <= ((IntervalXYDataset) dataset).getStartYValue(i, j) && ((IntervalXYDataset) dataset).getEndYValue(i, j) <= returnValue.getUpperBound()))));



# Response 2
// Check if the returned range has the correct lower and upper bound considering the y-interval flag
assert (returnValue == null) || 
(dataset.getSeriesCount() == 0) || 
(includeInterval && (
    returnValue.getLowerBound() <= dataset.getYValue(0, 0) &&
    dataset.getYValue(0, 0) <= returnValue.getUpperBound() &&
    returnValue.getLowerBound() <= dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) &&
    dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) <= returnValue.getUpperBound())) || 
(!includeInterval && (
    returnValue.getLowerBound() <= dataset.getYValue(0, 0) &&
    dataset.getYValue(0, 0) <= returnValue.getUpperBound() &&
    returnValue.getLowerBound() <= dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) &&
    dataset.getYValue(dataset.getSeriesCount() - 1, dataset.getItemCount(dataset.getSeriesCount() - 1) - 1) <= returnValue.getUpperBound()));



# Response 3
// Check if the returned range has the lower bound less than or equal to the upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();



# Response 4
```java
// Check if the returned range is null when the dataset is empty
assert (dataset.getSeriesCount() == 0 && dataset.getItemCount(0) == 0) ? returnValue == null : true;
```



# Response 5
// Postcondition checks if the returned range has a lower bound less than or equal to the upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();



# Response 6
```java
// Postcondition: Checks if the returned range is non-negative and within the dataset's range
assert returnValue == null || (returnValue.getLowerBound() >= 0 && returnValue.getUpperBound() <= dataset.getSeriesCount());
```



# Response 7
// Checks that the returned range has a lower bound less than or equal to the upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();



# Response 8
// Check that the returned range is not null and its lower bound is less than or equal to the upper bound
assert returnValue != null && returnValue.getLowerBound() <= returnValue.getUpperBound();



# Response 9
// Check that the returned range has a lower bound less than or equal to the upper bound
assert returnValue == null || returnValue.getLowerBound() <= returnValue.getUpperBound();


