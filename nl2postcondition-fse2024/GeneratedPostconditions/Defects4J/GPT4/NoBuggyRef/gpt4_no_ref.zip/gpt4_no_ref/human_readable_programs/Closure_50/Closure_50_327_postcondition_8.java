```java
// Checks if the returnValue is a string when the input node represents an array join operation
assert !(n.isCall() && "join".equals(n.getFirstChild().getString()) && n.getLastChild().isString()) || returnValue.isString();
```


