// Check if the returned length is in the valid range (either -1 or non-negative)
assert returnValue == -1 || returnValue >= 0 : "Invalid length returned by getLength";


