// Postcondition:

// Add the special token "--" and the current value to the processed tokens list.
// Then add all the remaining argument values to the processed tokens list.
assert (tokens.contains("--") && tokens.contains(value)) == (returnValue.equals(tokens));


