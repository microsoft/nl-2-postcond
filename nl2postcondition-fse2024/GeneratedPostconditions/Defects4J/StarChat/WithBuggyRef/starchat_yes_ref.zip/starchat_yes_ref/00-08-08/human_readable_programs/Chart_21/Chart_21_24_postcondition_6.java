// Check that the bounds are reset to NaN
assert Double.isNaN(returnValue.minimumRangeValue)
    : "The minimumRangeValue in the returned value should be reset to NaN";
assert Double.isNaN(returnValue.maximumRangeValue)
    : "The maximumRangeValue in the returned value should be reset to NaN";


