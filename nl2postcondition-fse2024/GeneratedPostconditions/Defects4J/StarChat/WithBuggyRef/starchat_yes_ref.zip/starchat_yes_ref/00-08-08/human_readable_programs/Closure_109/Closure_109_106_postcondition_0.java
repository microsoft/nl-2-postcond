assert (
    // BasicTypeExpression:
    parseTypeName(token) == returnValue
    // OptionalTypeExpression:
    || (token == JsDocToken.OPTIONAL &&
        parseContextTypeExpression(next()) == returnValue)
    // UnionTypeExpression:
    || (token == JsDocToken.UNION &&
        parseContextTypeExpression(next()) == returnValue
        // Recursively check the rest of the union type expression
        && parseContextTypeExpression(next()) == returnValue)
);


