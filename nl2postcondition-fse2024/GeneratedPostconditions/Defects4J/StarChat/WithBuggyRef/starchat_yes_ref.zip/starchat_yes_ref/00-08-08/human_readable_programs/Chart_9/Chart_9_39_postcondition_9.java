assert:
// Postcondition: After createCopy is executed, the TimeSeries copy contains
// a subset of the data in the original TimeSeries that falls within the
// specified time period (start, end).


