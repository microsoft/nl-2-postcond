// The returned TimeSeries should be a copy of the original series, but only
// containing data items within the specified start and end time periods.
// The start and end periods are inclusive.
assert createCopy(start, end).getData().stream()
       .allMatch(item -> within(item.getPeriod(), start, end)) : "All copied "
        + "data items should be within the specified time range";

// Utility function to check if a period falls within a given start and end
// period (inclusive).
private boolean within(RegularTimePeriod period, RegularTimePeriod start,
        RegularTimePeriod end) {
    return period.compareTo(start) >= 0 && period.compareTo(end) <= 0;
}


