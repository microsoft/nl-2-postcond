// Postcondition: If the method processOptionToken executes successfully, then the currentOption field will contain the Option object associated with the option token passed into the method.
assert (currentOption!= null) == options.hasOption(token);


