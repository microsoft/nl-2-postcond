// Check that the options in requiredOptions are present in the command line
assert cmd.hasOptions(requiredOptions) : "Options " + requiredOptions + " are required but not present";


