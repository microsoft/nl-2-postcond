assert (width >= nextLineTabStop) : "The total width of the text is less than the width of the argument and the indent, so there's no room for the description";


