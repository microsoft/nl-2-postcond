assert (returnValue == null || returnValue.isSubtypeOf(type)) : "The return value is either null or it is a subtype of the input type.";


