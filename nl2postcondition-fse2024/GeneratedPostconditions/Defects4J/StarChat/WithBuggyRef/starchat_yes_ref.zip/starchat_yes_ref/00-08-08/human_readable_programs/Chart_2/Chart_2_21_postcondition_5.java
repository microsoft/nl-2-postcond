// This postcondition asserts that the return value of iterateRangeBounds() is
// equal to the sum of the minimum and maximum values in the input dataset.
assert (returnValue.getLowerBound() + returnValue.getUpperBound())
== (Math.min(...)) + (Math.max(...));


