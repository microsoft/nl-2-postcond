//Check that the returned string array contains the same number of elements as the input argument array
assert returnValue.length == arguments.length;

//Check that the returned string array contains the same elements as the input argument array
for(int i = 0; i < arguments.length; i++)
    assert returnValue[i].equals(arguments[i]);


