// Ensures that all aliases in the current scope are valid and don't conflict with any other locals.
assert(forbiddenLocals.isEmpty() && aliases.keySet().containsAll(scopedAliasNames));


