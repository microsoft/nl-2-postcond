import java.util.List;

// Postcondition: Ensure that when the canCollapseUnannotatedChildNames() method is called,
// the following conditions are all met:
// 1. If the method returns true, then the following conditions must also be met:
// a. The totalGets field in the Name class is 0.
// b. If the props field in the Name class is not null, then for each Name object in the props field,
//     the canCollapse() method must return true.
// 2. If the method returns false, then none of the above conditions must be met.
public static boolean canCollapseUnannotatedChildNames(Name name, List<Name> props) {
    boolean result = false;

    // Check condition 1
    if (canCollapseUnannotatedChildNames(name)) {
        // Check condition 1a
        assert name.totalGets == 0;

        // Check condition 1b
        if (props!= null) {
            for (Name prop : props) {
                assert canCollapse(prop) : "Can't collapse " + prop.name;
                result = result || canCollapse(prop);
            }
        }

        // Set result to true if all conditions were met
        result = result && (name.totalGets == 0 || props == null || result);
    }

    // Check condition 2
    assert!(result && (name.totalGets > 0 || (props!= null &&!result))) :
        "Invalid collapse state";

    return result;
}


