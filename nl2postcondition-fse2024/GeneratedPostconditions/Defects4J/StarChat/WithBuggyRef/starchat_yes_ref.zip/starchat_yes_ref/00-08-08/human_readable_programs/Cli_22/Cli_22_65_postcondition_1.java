// The list of processed tokens should be the same as the input list
assert (new ArrayList(Arrays.asList(token))).equals(tokens);


