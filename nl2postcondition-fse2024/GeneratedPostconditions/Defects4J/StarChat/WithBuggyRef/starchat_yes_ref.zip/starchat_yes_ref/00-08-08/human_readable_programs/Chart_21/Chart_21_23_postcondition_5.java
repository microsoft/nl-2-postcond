// Postcondition: checks that the list of values is sorted in ascending order
assert sorted(list) : "List of values is not sorted in ascending order";


