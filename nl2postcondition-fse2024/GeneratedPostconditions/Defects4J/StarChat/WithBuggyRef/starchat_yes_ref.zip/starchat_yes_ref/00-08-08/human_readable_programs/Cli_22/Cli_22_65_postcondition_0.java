// Ensures that when burstToken is executed, it produces a list of tokens that
// follows the specifications in PosixParser's Javadoc.
assert returnValue!= null : "The return value must not be null";

String[] splitToken = returnValue.split("\\s+");
assert splitToken!= null : "The return value must be split into tokens";
assert splitToken.length > 0 : "The return value must be split into tokens";

String firstToken = splitToken[0];
assert firstToken!= null : "The first token must not be null";

if (firstToken.startsWith("--")) {
    // Ensures that if the first token is "--", the remaining tokens are added to the list of tokens.
    for (int i = 1; i < splitToken.length; i++) {
        assert splitToken[i]!= null : "The remaining tokens must not be null";
        tokens.add(splitToken[i]);
    }
} else if (firstToken.startsWith("-")) {
    // Ensures that if the first token is "-", the first token is added to the list of tokens.
    tokens.add(firstToken);
    
    // Ensures that if the first token is "-", the remaining tokens are burst into individual options.
    for (int i = 1; i < splitToken.length; i++) {
        String token = splitToken[i];
        assert token!= null : "The remaining tokens must not be null";
        burstToken(token, false);
    }
} else {
    // Ensures that if the first token is not "--" or "-", it is added to the list of tokens.
    tokens.add(firstToken);
    
    // Ensures that if the first token is not "--" or "-", the remaining tokens are added to the list of tokens.
    for (int i = 1; i < splitToken.length; i++) {
        String token = splitToken[i];
        assert token!= null : "The remaining tokens must not be null";
        tokens.add(token);
    }
}


