// Check that the specified column has been removed
assert!this.columnKeys.contains(columnKey);


