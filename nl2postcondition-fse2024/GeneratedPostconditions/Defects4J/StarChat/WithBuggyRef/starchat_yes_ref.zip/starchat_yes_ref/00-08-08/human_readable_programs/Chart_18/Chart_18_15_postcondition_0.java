// Ensures that when removeValue is executed, the list is modified as expected.
assert keys.get(index) == oldValue // Checks that the correct value is removed.
&& values.get(index) == returnValue // Checks that the correct value is returned.
&& indexMap.get(key) == null // Checks that the index map is updated correctly.
&& keys.indexOf(key) == -1 // Checks that the key is removed from the list of keys.
&& values.indexOf(value) == -1 // Checks that the value is removed from the list of values.


