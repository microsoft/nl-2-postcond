assert (/*postcondition goes here*/);


