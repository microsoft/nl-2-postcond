// Check that the method preserves the ordering of the input data
assert(new TimeSeries(data).equals(returnValue));


