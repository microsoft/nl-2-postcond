assert(
  // If the method was called with a string token
  (token == JsDocToken.STRING)
  // Then the result is not null
  && (returnValue!= null)
  // And the result is a string node
  && (returnValue instanceof StringNode)
);


