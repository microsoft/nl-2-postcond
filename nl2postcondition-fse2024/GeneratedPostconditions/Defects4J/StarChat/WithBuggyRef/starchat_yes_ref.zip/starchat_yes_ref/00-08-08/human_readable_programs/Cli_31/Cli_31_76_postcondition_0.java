// Ensures that, when the method is implemented, it appends the correct usage clause for an Option
assert (
// Input parameters
buff.toString().equals(defaultSyntaxPrefix + app + " ") &&
// Hypothetical return value
returnValue.equals(buff.toString() + (i.hasNext()? " " : ""))
// The implementation of the method
&& option.getOpt()!= null
&& option.getLongOpt()!= null
&& option.hasArg() == (option.getArgName()!= null)
// The postcondition
)


