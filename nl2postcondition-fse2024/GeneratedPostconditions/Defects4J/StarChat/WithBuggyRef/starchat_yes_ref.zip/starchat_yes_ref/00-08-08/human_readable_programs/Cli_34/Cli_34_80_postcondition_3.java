// Postcondition: asserts that the member variables have been reset to their default values
assert description == null;
assert argName == null;
assert longopt == null;
assert type == null;
assert!required;
assert numberOfArgs == Option.UNINITIALIZED;
assert!optionalArg;
assert valuesep == (char) 0;


