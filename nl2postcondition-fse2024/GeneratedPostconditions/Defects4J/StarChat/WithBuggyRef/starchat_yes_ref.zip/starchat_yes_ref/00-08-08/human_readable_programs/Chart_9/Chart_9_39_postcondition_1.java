// Ensures that the returned TimeSeries is a copy of this TimeSeries from
// start to end inclusive (i.e., end is included in the copy). Also checks that
// start and end are valid time periods in this TimeSeries.
assert(new TimeSeries(this.data.subList(0, start), this.data.subList(start, end + 1))
   .equals(returnValue));


