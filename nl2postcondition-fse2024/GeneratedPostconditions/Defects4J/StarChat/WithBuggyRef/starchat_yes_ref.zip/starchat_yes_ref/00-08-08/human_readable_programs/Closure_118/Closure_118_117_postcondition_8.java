assert (new FindRenameableProperties()).handleObjectLit(null, null) == null;


