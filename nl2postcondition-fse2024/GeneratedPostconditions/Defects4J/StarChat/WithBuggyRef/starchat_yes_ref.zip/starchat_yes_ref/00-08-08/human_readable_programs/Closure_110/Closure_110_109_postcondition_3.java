Here is the symbolic postcondition for getChildBefore:

assert (returnValue == null || returnValue.parent == this) : "The return value is either null or has the correct parent.";


