assert (
    // Ensures that the method returns false if the marker is not found
   !domainMarkers.getOrDefault(index, new ArrayList<>()).contains(marker)
    ||
    // If the marker is found, ensures that the marker is removed from the list
    domainMarkers.get(index).remove(marker)
    // And that the change is reflected in the plot, since notify is true
    && notify
);


