// The label is rotated by the label angle around its center point
assert (edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM)?
    // If the axis is horizontal, the label is aligned with the center of the data area
    (Math.abs(dataArea.getCenterY() - hotspot.getCenterY()) < EPSILON &&
    // And its left or right edge is aligned with the left or right edge of the data area
    (edge == RectangleEdge.LEFT? dataArea.getMinX() - EPSILON <= hotspot.getMinX() :
        dataArea.getMaxX() + EPSILON >= hotspot.getMaxX())) :
    // If the axis is vertical, the label is aligned with the center of the data area
    (Math.abs(dataArea.getCenterX() - hotspot.getCenterX()) < EPSILON &&
    // And its top or bottom edge is aligned with the top or bottom edge of the data area
    (edge == RectangleEdge.TOP? dataArea.getMinY() - EPSILON <= hotspot.getMinY() :
        dataArea.getMaxY() + EPSILON >= hotspot.getMaxY()));


