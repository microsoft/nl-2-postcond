// Check that for each property declared in the object literal, the property's
// name is in the set of valid property names and the property's value is of a
// valid type for the property.
assert(
    all(
        for each declared property in the object literal:
            name of property is a valid property name in the object and
            value of property is of a valid type for the property
    )
);


