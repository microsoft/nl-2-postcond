// Postcondition for appendOption: Ensures that when the method is implemented, it
// behaves as specified in the Javadoc:

assert (
    // Relevant Class Context:
    returnValue.length() <= buff.length() + app.length() + 1 + option.getOpt().length() +
        (option.getArgName() == null? 0 : 2 + option.getArgName().length()) +
        (required? 0 : 2) + (option.getLongOpt() == null? 0 : 3 + option.getLongOpt().length())
    );


