// Postcondition describing the relationship between the input parameters and the return value:

assert (
    // For each input parameter:
    (inputParam1 == "value1" && inputParam2 == 123)
    // The following condition is true:
    && (
        ( // If the method returns normally:
        returnValue == null
        // And the following condition is also true:
        && (
            // For each element in the return value array:
            for (int i = 0; i < returnValue.length; i++) {
                // The following condition is true:
                returnValue[i] == inputParam3[i]
            }
        )
    )
);

// Method implementation:
protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
    //...
    // Code for method implementation
    //...
    return returnValue;
}


