// Check that the specified column has been removed from the table
assert!this.columnKeys.contains(columnKey) : "The column " + columnKey + " should have been removed";


