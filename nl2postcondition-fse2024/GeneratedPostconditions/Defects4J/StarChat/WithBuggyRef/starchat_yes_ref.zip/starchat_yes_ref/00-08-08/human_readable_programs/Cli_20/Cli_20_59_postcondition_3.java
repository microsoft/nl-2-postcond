// Check that the output array has the same length as the input array
assert returnValue.length == arguments.length;


