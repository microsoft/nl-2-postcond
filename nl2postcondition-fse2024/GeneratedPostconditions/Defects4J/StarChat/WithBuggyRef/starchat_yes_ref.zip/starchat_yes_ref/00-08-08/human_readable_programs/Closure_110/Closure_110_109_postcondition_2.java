// Symbolic postcondition for getChildBefore
// Ensures that if child is a direct child of the current node, then the method returns the previous child node
// Otherwise, the method throws an exception
assert (
    child.parent == this &&
    first!= null &&
    (child == first || getChildBefore(child)!= null) &&
    (child == last || getChildBefore(child).next == child)
) : "In the case where child is a direct child of the current node, the method must return the previous child node. Otherwise, the method throws an exception.";


