// The postcondition asserts that if the method add executes successfully, the
// following condition will be true:
assert this.data.getObject(rowKey, columnKey) instanceof BoxAndWhiskerItem;


