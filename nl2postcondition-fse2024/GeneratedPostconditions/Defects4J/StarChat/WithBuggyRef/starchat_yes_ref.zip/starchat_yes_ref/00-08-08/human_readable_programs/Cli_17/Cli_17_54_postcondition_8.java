//The postcondition checks that the elements in the list are in sorted order
assert(java.util.Arrays.toString(PosixParser.burstToken("abc",true)).equals("[a, b, c]"));


