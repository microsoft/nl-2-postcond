// Postcondition for flatten method when stopAtNonOption is true
assert returnValue == null || Arrays.asList(returnValue).containsAll(tokens);


