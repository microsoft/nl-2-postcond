// Check that the returned value indicates whether or not the marker was removed
assert returnValue == (markers.remove(marker) && notify);


