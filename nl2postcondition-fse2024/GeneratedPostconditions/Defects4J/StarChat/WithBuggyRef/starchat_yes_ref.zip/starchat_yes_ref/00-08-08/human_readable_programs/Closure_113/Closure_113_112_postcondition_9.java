assert sort(unrecognizedRequires).equals(
    unrecognizedRequires) : "Unrecognized requires do not change order";


