// Check that the column is in the table
assert columnKeys.contains(columnKey);

// Check that the column has no values in any row
for (DefaultKeyedValues row : rows) {
    assert!row.containsValue(columnKey);
}

// Check that the column has been removed from the columnKeys list
assert!columnKeys.contains(columnKey);


