// Postcondition: check that the output array only contains
// options, "--", or "-"
assert (returnValue!= null &&
        returnValue.length == arguments.length + 1 &&
        Arrays.stream(returnValue).allMatch(s ->
                options.hasOption(s) || s.equals("--") || s.equals("-")));


