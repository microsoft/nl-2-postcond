// Check that the returned set contains only non-null values, i.e., that it is a set of potentially null values
assert!returnValue.contains(null);

// Check that the transformation object is not null
assert transformation!= null;

// For each Var in the scope, check that it represents an alias, i.e., that it is a reference to another variable
for (Var v : scope.getVarIterable()) {
    assert v.isAlias();
}

// For each Var in the scope, check that if it represents an alias, it is a unique alias, i.e., that no other Var in the scope aliases the same variable
Set<String> aliasNames = new HashSet<>();
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        String name = v.getName();
        assert!aliasNames.contains(name);
        aliasNames.add(name);
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not null
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        assert v.getInitialValue()!= null;
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not a property access or element access
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        assert!initialValue.isGetProp() &&!initialValue.isGetElem();
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is the value of another Var in the scope
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        for (Var otherVar : scope.getVarIterable()) {
            if (otherVar.isVar() && otherVar.getInitialValue() == initialValue) {
                break;
            }
        }
        assert otherVar.isVar();
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not re-assigned
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        for (Node assignment : NodeUtil.findLhsAssignments(initialValue)) {
            assert assignment!= initialValue;
        }
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not used as a function or method call argument
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        for (Node use : Node


