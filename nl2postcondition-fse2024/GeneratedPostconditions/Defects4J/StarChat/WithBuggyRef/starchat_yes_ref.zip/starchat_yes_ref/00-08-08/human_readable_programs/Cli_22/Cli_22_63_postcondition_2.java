// The token passed to processNonOptionToken should be added to the list of processed tokens
assert tokens.contains(value);


