import java.util.Set;

import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.StaticTypedScope;
import com.google.javascript.rhino.jstype.StaticTypedSlot;

public class CanInlineResult {
  private final boolean yes;

  private CanInlineResult(boolean yes) {
    this.yes = yes;
  }

  public static CanInlineResult YES = new CanInlineResult(true);
  public static CanInlineResult NO = new CanInlineResult(false);

  public boolean isYes() {
    return yes;
  }
}

public class CanInline {
  private final Node callNode;
  private final Node fnNode;
  private final StaticTypedScope scope;
  private final JSType thisType;
  private final InliningMode mode;

  public CanInline(
      Node callNode, Node fnNode, StaticTypedScope scope, JSType thisType, InliningMode mode) {
    this.callNode = callNode;
    this.fnNode = fnNode;
    this.scope = scope;
    this.thisType = thisType;
    this.mode = mode;
  }

  public CanInlineResult check() {
    if (!isSupportedCallType(callNode)) {
      return CanInlineResult.NO;
    }

    boolean containsFunctions = fnNode.hasChildren();
    if (containsFunctions) {
      if (!assumeMinimumCapture &&!scope.isGlobal()) {
        return CanInlineResult.NO;
      } else if (NodeUtil.isWithinLoop(callNode)) {
        return CanInlineResult.NO;
      }
    }

    boolean referencesThis = fnNode.hasThis();
    if (referencesThis &&!NodeUtil.isFunctionObjectCall(callNode)) {
      return CanInlineResult.NO;
    }

    if (mode == InliningMode.DIRECT) {
      return canInlineReferenceDirectly();
    } else {
      return canInlineReferenceAsStatementBlock();
    }
  }

  private CanInlineResult canInlineReferenceDirectly() {
    if (!isDirectCallNodeReplacementPossible()) {
      return CanInlineResult.NO;
    }

    Node block = NodeUtil.getFunctionBody(fnNode);
    if (!block.hasChildren()) {
      return CanInlineResult.YES;
    } else if (block.hasOneChild()) {
      if (block.getFirstChild().isReturn()
          && block.getFirstChild().getFirstChild()!= null) {
        return CanInlineResult.YES;
      }
    }

    return CanInlineResult.NO;
  }

  private boolean isSupportedCallType(Node callNode) {
    //...
  }

  private boolean isDirectCallNodeReplacementPossible() {
    //...
  }

  private CanInlineResult canInlineReferenceAsStatementBlock() {
    //...
  }

  private boolean assumeMinimumCapture = true;
  private boolean containsFunctions = false;
  private boolean referencesThis = false;
}

public enum InliningMode {
  DIRECT,
  AS_STATEMENT_BLOCK
}

public class NodeUtil {
  //...

  public static boolean mayEffectMutableState(Node node, Compiler compiler) {
    //...
  }

  public static boolean mayHaveSideEffects(Node node, Compiler compiler) {
    //...
  }

  public static int getNameReferenceCount(Node n, String name) {
    //...
  }

  public static boolean is


