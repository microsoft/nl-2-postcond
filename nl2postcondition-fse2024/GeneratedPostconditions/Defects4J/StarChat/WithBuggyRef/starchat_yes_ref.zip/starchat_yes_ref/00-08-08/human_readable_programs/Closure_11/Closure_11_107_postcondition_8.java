assert (returnValue.isEquivalentTo(n.getJSType())
        || returnValue.isSubtypeOf(n.getJSType()));


