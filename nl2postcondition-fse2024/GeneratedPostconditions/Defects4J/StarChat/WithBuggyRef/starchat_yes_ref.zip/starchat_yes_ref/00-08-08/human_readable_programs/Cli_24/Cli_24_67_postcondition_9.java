assert (returnValue!= null): "The return value must not be null";


