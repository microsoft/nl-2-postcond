import java.util.Objects;

public class GenerateToolTipFragment {
    public String generateToolTipFragment(String toolTipText) {
        Objects.requireNonNull(toolTipText, "The tooltip text cannot be null.");

        return " title=\"" + toolTipText + "\" alt=\"\"";
    }
}


