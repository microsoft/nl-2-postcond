// Postcondition: The output is either the index of the specified axis in the list of domain axes, or -1 if the axis is not found.
assert (returnValue == -1 || (returnValue >= 0 && returnValue < this.domainAxes.size() && this.domainAxes.get(returnValue).equals(axis)));


