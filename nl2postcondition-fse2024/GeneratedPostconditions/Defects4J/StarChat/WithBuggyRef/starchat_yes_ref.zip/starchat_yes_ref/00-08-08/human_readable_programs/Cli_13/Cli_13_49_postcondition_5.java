// Ensures that if the method returns without throwing an OptionException,
// then the list iterator will be pointing to the next element after the last
// element added by this method.
assert arguments.hasNext() == (returnValue == null);


