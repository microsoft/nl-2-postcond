The original method looks to have been written by Mike A. King.

public boolean canCollapseUnannotatedChildNames() {
    if (type == Type.OTHER || globalSets!= 1 || localSets!= 0) {
        return false;
    }

    if (isClassOrEnum) {
        return true;
    }
    return (type == Type.FUNCTION || aliasingGets == 0) &&
        (parent == null || parent.canCollapseUnannotatedChildNames());
}

The original intent seems to have been for the method to be called in this context:

if (name.canCollapseUnannotatedChildNames() && name.canEliminate()) {
    return true;
}

The intent seems to be that the method will determine if the name can be eliminated based on information about whether it is an enum or function, and based on whether it has any properties or a parent that can be collapsed.


