// The return value of the flatten method is the list of tokens
List<String> returnValue = flatten(options, arguments, stopAtNonOption);

// Check that the length of the return value is equal to the length of the input arguments list
assert returnValue.size() == arguments.length;


