// The postcondition ensures that the method behaves as specified in its Javadoc,
// specifically that it returns true if the input node contains a call, getprop,
// getelem, throw, new, assign, inc, or dec operation, and false otherwise.
assert returnValue == (n.getType() == Token.CALL ||
                         n.getType() == Token.GETPROP ||
                         n.getType() == Token.GETELEM ||
                         n.getType() == Token.THROW ||
                         n.getType() == Token.NEW ||
                         n.getType() == Token.ASSIGN ||
                         n.getType() == Token.INC ||
                         n.getType() == Token.DEC);


