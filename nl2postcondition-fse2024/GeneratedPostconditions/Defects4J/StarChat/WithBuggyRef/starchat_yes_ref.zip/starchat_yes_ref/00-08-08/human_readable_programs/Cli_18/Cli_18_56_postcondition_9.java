// The postcondition checks that if an option exists for the given token,
// then the currentOption variable is set to that option. If the given
// token does not correspond to an option and stopAtNonOption is true,
// then the eatTheRest variable is set to true.
assert post: (options.hasOption(token)) ==> (currentOption == options.getOption(token))
            && (eatTheRest == (stopAtNonOption &&!options.hasOption(token)));


