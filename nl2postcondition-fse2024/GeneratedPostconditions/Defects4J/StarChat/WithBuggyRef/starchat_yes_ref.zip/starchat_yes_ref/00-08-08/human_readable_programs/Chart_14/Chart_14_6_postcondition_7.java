// The postcondition ensures that the method:
// 1. Returns true if the marker is removed from the correct layer and
// dataset index
// 2. If the notify flag is set to true, a PlotChangeEvent is fired
// 3. The return value is the same as the return value of the method
assert(returnValue == true);


