// The set of all variables declared in the current scope
Set<Var> allVars = t.getScope().getVarIterable();

// The set of all qualified names declared in the current scope
Set<String> allQualifiedNames = new HashSet<>();
for (Var v : allVars) {
  if (v.getNode().getParent().isQualifiedName()) {
    allQualifiedNames.add(v.getNode().getString());
  }
}

// For each variable in the scope, check that its qualified name is in the set of all qualified names
for (Var v : allVars) {
  if (v.getNode().getParent().isVar()) {
    String qualifiedName = v.getNode().getFirstChild().getQualifiedName();
    assert allQualifiedNames.contains(qualifiedName) : "The qualified name of a variable declared in the current scope must be in the set of all qualified names";
  }
}


