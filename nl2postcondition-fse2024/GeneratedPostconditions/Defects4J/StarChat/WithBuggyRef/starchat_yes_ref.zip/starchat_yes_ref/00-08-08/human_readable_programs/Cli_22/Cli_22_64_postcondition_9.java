// Postcondition: token is added to the processed tokens list if an Option exists for it
assert (options!= null && returnValue!= null)? (options.hasOption(token)? tokens.contains(token) :!eatTheRest) : true;


