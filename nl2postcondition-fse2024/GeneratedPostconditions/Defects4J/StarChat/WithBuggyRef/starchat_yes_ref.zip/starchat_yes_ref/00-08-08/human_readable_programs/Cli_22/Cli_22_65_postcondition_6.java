// Check that the return value is correct for all possible inputs
assert (
    // Replace this with the actual method call for the given inputs
    burstToken(token, stopAtNonOption) == returnValue
    // Replace this with the expected return value for the given inputs
    && (
        // Check that all options are added
        (token.startsWith("--") && options.hasOption(token))
        || token.equals("-")
        || (token.startsWith("-") && (token.length() == 2 || options.hasOption(token)))
        || (stopAtNonOption &&!options.hasOption(token))
    )
);


