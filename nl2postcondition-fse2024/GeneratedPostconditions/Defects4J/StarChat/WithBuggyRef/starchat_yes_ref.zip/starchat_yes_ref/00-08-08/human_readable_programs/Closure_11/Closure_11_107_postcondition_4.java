// Ensures that the result of getProp is of the correct type
assert returnValue.isSubtypeOf(getType(n));


