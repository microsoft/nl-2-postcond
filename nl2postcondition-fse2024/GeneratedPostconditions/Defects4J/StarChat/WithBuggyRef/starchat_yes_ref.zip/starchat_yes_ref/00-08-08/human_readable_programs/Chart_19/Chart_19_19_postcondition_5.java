Here is the symbolic postcondition:

// Check that if the input axis is not assigned to the plot, then the return value is -1
assert (axis!= null && this.rangeAxes.contains(axis)) ==> returnValue == -1;

This postcondition states that if the input axis is not assigned to the plot, then the return value of the method getRangeAxisIndex is -1.


