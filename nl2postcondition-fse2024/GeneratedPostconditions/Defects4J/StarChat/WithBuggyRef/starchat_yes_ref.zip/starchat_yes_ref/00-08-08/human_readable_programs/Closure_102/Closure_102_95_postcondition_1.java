// The method preserves the order of the input nodes.
assert (NodeUtil.isEquivalent(root, NodeUtil.cloneTree(root)));


