//The postcondition checks that when the inlining mode is DIRECT,
//the method canInlineReferenceDirectly always returns YES
//after the method has finished executing
assert(canInlineReferenceDirectly(callNode, fnNode) == CanInlineResult.YES);


