// Postcondition: checks that the list is sorted in descending order
assert (returnValue.size() == keys.size());
for(int i = 0; i < returnValue.size() - 1; i++) {
    assert (returnValue.get(i).compareTo(returnValue.get(i+1)) <= 0);
}


