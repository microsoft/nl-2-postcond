// The returned time series is a copy of the original time series, but with the 
 // data filtered to contain only items within the specified range.
assert returnValue.equals(createCopy(start, end))


