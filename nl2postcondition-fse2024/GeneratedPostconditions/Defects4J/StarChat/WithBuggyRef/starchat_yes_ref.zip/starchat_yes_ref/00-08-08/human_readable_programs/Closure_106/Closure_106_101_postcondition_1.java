// Check that the method returns true if the description was recorded
assert (returnValue == true);


