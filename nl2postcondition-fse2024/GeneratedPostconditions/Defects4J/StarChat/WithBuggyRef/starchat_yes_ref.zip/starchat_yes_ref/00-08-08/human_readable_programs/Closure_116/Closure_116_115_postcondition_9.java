// The inlined function body contains no function definitions or variables
// that are not defined in the method parameters or return value.
assert NodeUtil.getFunctionBody(fnNode).isEquivalentTo(
  NodeUtil.getFunctionBody(inlinedFunctionBody));


