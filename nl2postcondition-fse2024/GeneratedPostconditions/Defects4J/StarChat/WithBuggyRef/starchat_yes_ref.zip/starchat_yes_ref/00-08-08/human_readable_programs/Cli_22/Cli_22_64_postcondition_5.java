// Symbolic Postcondition for the method processOptionToken

// Check that the list of tokens contains the input token
assert tokens.contains(token);

// Check that if the token is an option, the return value is true
if (options.hasOption(token)) {
    assert returnValue == true;
}

// Check that if the token is not an option, the return value is false
else {
    assert returnValue == false;
}

// Check that the size of the list of tokens remains the same
assert tokens.size() == originalSize;


