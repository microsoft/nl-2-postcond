assert RangeInfo.equals(returnValue, findDomainBounds(dataset, includeInterval));


