assert (returnValue == null || returnValue.startsWith(" title=\"") || returnValue.endsWith("\"")) : 
    "The return value should start with 'title=\"' and end with '\"'.";


