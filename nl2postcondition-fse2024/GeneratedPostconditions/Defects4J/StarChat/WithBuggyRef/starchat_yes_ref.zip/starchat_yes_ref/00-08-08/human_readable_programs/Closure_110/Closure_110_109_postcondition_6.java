// Postcondition: Ensures that the child node appears before the specified child node in the list.
assert (getChildBefore(child) == null || getChildBefore(child).next == child);


