//Check that require statements are added to the providedNames map
assert(providedNames.containsKey(ns) && providedNames.get(ns).isExplicitlyProvided());

//Check that the moduleGraph contains a dependency edge between the current module and the module associated with the provided namespace
JSModule providedModule = providedNames.get(ns).explicitModule;
assert(moduleGraph == null || moduleGraph.dependsOn(t.getModule(), providedModule));

//Check that the provided namespace has not already been added to the unrecognizedRequires list
assert(!unrecognizedRequires.contains(new UnrecognizedRequire(n, ns, t.getSourceName())));


