// Check that all of the required options are present
assert returnValue.stream()
       .allMatch(opt -> cmd.hasOption(opt.getLongOpt())
                || cmd.hasOption(opt.getOpt()));


