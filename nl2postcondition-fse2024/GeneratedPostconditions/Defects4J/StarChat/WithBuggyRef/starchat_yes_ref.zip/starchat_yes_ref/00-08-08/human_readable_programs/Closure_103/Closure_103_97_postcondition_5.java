// The return type of this method should be an object type
// with the given property, or null if no such type exists
assert (JSType result = getTypeWithProperty(field, type)) == null || result.hasProperty(field);


