//The postcondition asserts that the returned array is sorted
assert(isSorted(returnValue));


