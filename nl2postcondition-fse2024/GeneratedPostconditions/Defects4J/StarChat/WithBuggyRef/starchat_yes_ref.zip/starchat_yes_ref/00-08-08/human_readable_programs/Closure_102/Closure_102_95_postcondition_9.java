assert (new HashSet<>(Arrays.asList(externs, root)).size() == 
    NodeUtil.getTopLevelFunctions(root).size() + 1);


