// Check that the specified marker is removed from the domain axis and that a
// PlotChangeEvent is fired if the notify parameter is true
assert (removeDomainMarker(0, marker, Layer.FOREGROUND, false) == false &&
       marker.getLayer() == Layer.FOREGROUND &&
       marker.getPlot() == this &&
       this.foregroundDomainMarkers.get(0).contains(marker) == true) ||
       (removeDomainMarker(0, marker, Layer.FOREGROUND, false) == true &&
       marker.getLayer() == Layer.FOREGROUND &&
       marker.getPlot() == this &&
       this.foregroundDomainMarkers.get(0).contains(marker) == false) &&
       (removeDomainMarker(0, marker, Layer.BACKGROUND, false) == false &&
       marker.getLayer() == Layer.BACKGROUND &&
       marker.getPlot() == this &&
       this.backgroundDomainMarkers.get(0).contains(marker) == true) ||
       (removeDomainMarker(0, marker, Layer.BACKGROUND, false) == true &&
       marker.getLayer() == Layer.BACKGROUND &&
       marker.getPlot() == this &&
       this.backgroundDomainMarkers.get(0).contains(marker) == false);


