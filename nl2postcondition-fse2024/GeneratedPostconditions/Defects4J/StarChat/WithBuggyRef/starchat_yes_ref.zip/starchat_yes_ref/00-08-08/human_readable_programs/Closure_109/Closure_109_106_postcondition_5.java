// Postcondition: Checks that the input token is a valid JsDoc token for the
// "ContextTypeExpression" production in the Javadoc of parseContextTypeExpression.
assert parseContextTypeExpression(token) == null ||
    (EnumSet.of(JsDocToken.EOF, JsDocToken.STRING, JsDocToken.QUESTION)
       .contains(token) && parseContextTypeExpression(token) instanceof Node);


