// Check that the collection is in sorted order after the removal.
assert(isSorted());


