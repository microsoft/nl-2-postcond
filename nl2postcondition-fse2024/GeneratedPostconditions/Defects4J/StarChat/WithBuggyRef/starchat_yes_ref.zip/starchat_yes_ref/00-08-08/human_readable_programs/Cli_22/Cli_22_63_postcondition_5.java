// Postcondition: Adds the special token "--" and the current value to the processed tokens list.
// Then, adds all remaining argument values to the processed tokens list.
assert (tokens.add("--") && tokens.add(value) && returnValue ==...) : "Invalid postcondition: processNonOptionToken(...) did not behave as specified in the Javadoc.";


