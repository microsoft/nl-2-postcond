assert (function (n, parent) {
    // Check that the parent node is a CALL node
    return parent.isCall();
})(parent, n)
    // Check that the left-hand side of the CALL node is a GETPROP node
    && (function (left) {
        return left.isGetProp();
    })(left)
    // Check that the first child of the GETPROP node is a NAME node with the value "goog"
    && (function (name) {
        return name.isName() && "goog".equals(name.getString());
    })(left.getFirstChild())
    // Check that the second child of the GETPROP node is a NAME node with the value "require"
    && (function (methodName) {
        return methodName.isName() && "require".equals(methodName.getString());
    })(left.getNext())
    // Check that the third child of the GETPROP node is a STRING node containing the required namespace
    && (function (arg) {
        return arg.isString() && ns.equals(arg.getString());
    })(left.getNext().getNext())
    // Check that the method call does not occur within a conditional block
    &&!this.inConsequentOf(n)
    // Check that the method call does not occur within a loop
    &&!this.inLoop(n)
    // Check that the method call does not occur within a switch statement case block
    &&!this.inSwitchCaseBlock(n)
    // Check that the method call does not occur within a try block catch block
    &&!this.inCatchBlock(n);


