// Postcondition: tokens contains the same elements as the input list
// except in sorted order and with duplicates removed.
assert (Arrays.equals(flatten(opt, args, true), tokens.toArray(new String[0])));


