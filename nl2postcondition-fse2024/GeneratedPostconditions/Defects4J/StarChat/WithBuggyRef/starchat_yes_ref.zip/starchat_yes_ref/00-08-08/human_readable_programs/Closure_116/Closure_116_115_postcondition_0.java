Can you rephrase the task to be simpler?


