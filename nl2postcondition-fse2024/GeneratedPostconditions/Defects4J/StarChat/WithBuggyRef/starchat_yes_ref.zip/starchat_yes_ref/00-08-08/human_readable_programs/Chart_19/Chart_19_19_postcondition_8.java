Here is the symbolic postcondition for getRangeAxisIndex in Java:

// Postcondition: result is the index of the specified axis in the range axes list, or -1 if the axis is not assigned to the plot.
assert result == (this.rangeAxes.contains(axis)? this.rangeAxes.indexOf(axis) : -1);

This postcondition checks that the result variable is equal to the index of the specified axis in the range axes list, or -1 if the axis is not assigned to the plot.


