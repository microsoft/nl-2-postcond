import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.Queue;
import java.util.Iterator;

public final class OptionBuilder {

    // method you are writing a postcondition for
    /**
     * Resets the member variables to their default values.
     */
    private static void reset() {
        description = null;
        argName = null;
        longopt = null;
        type = null;
        required = false;
        numberOfArgs = Option.UNINITIALIZED;
        optionalArg = false;
        valuesep = (char) 0;
    }

    public static Option create(String opt) {
        reset();
        if (opt.startsWith("--")) {
            longopt = opt.substring(2);
        } else if (opt.startsWith("-")) {
            argName = opt.substring(1);
        } else {
            throw new IllegalArgumentException("Invalid option format: " + opt);
        }
        return new Option(opt, description, argName, longopt, type, required, numberOfArgs, optionalArg, valuesep);
    }

    private static String description;
    private static String argName;
    private static String longopt;
    private static Class type;
    private static boolean required;
    private static int numberOfArgs;
    private static boolean optionalArg;
    private static char valuesep;
}


