// Postcondition: The set of forbidden local variables is the same as the set of
//                all non-local variables declared in the method.
assert forbiddenLocals.equals(scope.getOwnVarNames());


