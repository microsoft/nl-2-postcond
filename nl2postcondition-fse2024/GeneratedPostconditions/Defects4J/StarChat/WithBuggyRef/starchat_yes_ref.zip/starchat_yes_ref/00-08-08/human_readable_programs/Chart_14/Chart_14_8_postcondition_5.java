import java.util.ArrayList;

public class RemoveDomainMarker {
    public static boolean removeDomainMarker(ArrayList<Marker> markers, Marker marker) { // assert: markers.contains(marker) == true
        markers.remove(marker);
        assert markers.contains(marker) == false;
        return true;
    }
}


