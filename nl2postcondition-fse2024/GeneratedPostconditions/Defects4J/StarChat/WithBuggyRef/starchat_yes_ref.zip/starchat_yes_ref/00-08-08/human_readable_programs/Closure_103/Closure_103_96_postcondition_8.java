// The method mayThrowException returns true if and only if the input node is a CALL, GETPROP, GETELEM,
// THROW, NEW, ASSIGN, INC, or DEC node and none of its child nodes are FUNCTION nodes.
assert (returnValue == true && (n.getType() == Token.CALL || n.getType() == Token.GETPROP ||
    n.getType() == Token.GETELEM || n.getType() == Token.THROW || n.getType() == Token.NEW ||
    n.getType() == Token.ASSIGN || n.getType() == Token.INC || n.getType() == Token.DEC)) ||
    (returnValue == false && NodeUtil.hasFunction(n)) :
    "The postcondition for mayThrowException is incorrect. Please check your work.";


