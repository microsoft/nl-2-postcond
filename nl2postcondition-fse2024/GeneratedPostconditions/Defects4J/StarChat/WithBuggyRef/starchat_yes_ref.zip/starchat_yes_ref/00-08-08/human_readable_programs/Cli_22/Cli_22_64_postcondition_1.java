// Check that the current option token is a valid option
assert options.hasOption(token) ||!options.hasOption(token) && stopAtNonOption:
    "Option token " + token + " is not a valid option";


