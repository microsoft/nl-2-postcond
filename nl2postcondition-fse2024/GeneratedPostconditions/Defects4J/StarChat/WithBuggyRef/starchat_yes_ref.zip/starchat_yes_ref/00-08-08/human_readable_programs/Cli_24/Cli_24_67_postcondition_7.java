//The return value is equal to the input parameter sb
assert sb.equals(returnValue);


