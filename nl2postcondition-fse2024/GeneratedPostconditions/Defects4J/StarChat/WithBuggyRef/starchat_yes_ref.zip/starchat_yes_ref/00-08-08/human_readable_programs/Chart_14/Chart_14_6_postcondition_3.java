assert (returnValue == markers.remove(marker)) :
    "When removing the marker " + marker + ", the return value should be " +
    "the same as whether the marker was removed from the list of markers";


