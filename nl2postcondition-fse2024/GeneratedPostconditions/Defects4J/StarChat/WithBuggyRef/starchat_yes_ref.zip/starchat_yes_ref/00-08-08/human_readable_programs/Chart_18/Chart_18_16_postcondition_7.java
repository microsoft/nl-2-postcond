// Ensures that the removed value is the correct one
assert(returnValue.equals(this.values.get(index)));


