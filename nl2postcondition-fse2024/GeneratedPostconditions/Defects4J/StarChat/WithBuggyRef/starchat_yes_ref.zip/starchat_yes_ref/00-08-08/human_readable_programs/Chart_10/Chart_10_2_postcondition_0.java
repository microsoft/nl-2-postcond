// Postcondition: generateToolTipFragment generates the correct HTML image map attribute string
// when given an input parameter "toolTipText"
assert (toolTipText!= null &&!toolTipText.trim().isEmpty())
   ? generateToolTipFragment(toolTipText).equals(" title=\"" + toolTipText + "\" alt=\"\"")
    : generateToolTipFragment(toolTipText).equals(" title=\"\" alt=\"\"");


