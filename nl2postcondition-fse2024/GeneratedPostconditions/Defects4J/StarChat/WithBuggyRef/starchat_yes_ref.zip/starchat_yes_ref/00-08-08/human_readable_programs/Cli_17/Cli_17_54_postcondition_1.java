// The tokens list should contain all the tokens in the original input array, preserving the order.
assert (Arrays.asList(arguments).equals(tokens));


