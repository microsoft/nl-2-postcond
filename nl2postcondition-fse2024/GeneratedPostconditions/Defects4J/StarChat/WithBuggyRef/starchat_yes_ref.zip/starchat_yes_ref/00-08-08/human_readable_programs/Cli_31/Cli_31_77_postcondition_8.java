// Postcondition: The description field is set to null.
assert(description == null);


