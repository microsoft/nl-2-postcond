// Postcondition: return value is the result of calling meet on the input types, 
// and the result is a union type containing the same elements as the input types
assert meet(that).equals(that.meet(this));


