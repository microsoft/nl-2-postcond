// The method sorts the input list in place.
void sort(List<Integer> list) {
    // INSERT YOUR SYMBOLIC POSTCONDITION HERE
}


