// The marker at the specified index in the specified layer is removed from the plot,
// and the marker's remove() method is called. If the marker is successfully removed,
// the plot is notified, and the method returns true. If the marker is not removed,
// the method returns false.
assert (returnValue == true && marker.remove() && this.fireChangeEvent()) ||
       (returnValue == false &&!marker.remove() &&!this.fireChangeEvent());


