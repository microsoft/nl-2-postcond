assert <BOOLEAN EXPRESSION>; // Replace <BOOLEAN EXPRESSION> with the desired postcondition


