// Postcondition: Returns the node in the linked list before the given child node, or null if the child node is the first node.
assert (child == first || getChildBefore(child).next == child) : "The child node is not a direct sibling of the returned node.";


