assert (new ArrayList<>(Arrays.asList(1, 2, 3))).equals(returnValue) ||
        (new ArrayList<>(Arrays.asList(1, 3))).equals(returnValue) ||
        (new ArrayList<>(Arrays.asList(2, 3))).equals(returnValue) ||
        (new ArrayList<>(Collections.singletonList(3))).equals(returnValue) ||
        (new ArrayList<>()).equals(returnValue) :
        "This is a postcondition for the removeRangeMarker method. " +
        "returnValue is a list of Integers, and the postcondition checks that " +
        "the list contains the correct elements after deletion of the given marker" +
        "from the specified layer of the plot." +
        "The possible return values are: " +
        "The list [1, 2, 3], [1, 3], [2, 3], [3], and []. " +
        "If the given marker is not present in the specified layer or index, the " +
        "input list is returned unchanged.";


