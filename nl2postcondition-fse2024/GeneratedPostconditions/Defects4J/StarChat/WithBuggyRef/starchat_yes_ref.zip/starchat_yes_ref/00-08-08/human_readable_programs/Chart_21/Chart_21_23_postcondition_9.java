// Ensures that when add() is called, it sets the minimum and maximum values of the dataset appropriately
assert (this.minimumRangeValue == minval && this.maximumRangeValue == maxval) || (rowKey.compareTo(this.data.getRowKey(this.minimumRangeValueRow)) < 0 && rowKey.compareTo(this.data.getRowKey(this.maximumRangeValueRow)) < 0 && columnKey.compareTo(this.data.getColumnKey(this.minimumRangeValueColumn)) < 0 && columnKey.compareTo(this.data.getColumnKey(this.maximumRangeValueColumn)) < 0) : "When add() is called, the dataset's minimum and maximum values are set appropriately";


