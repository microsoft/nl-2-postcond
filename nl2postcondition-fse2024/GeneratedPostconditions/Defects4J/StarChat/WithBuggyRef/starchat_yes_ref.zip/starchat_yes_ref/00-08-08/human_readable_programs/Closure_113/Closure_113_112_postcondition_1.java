assert (
  (
    // Check that the method call has the expected number of arguments
    (parent.isCall() && n.hasXChildren(2)) ||
    // Or that it has the expected structure if it's a property assignment
    ((parent.isAssign() || parent.isName()) && n.hasXChildren(3))
  ) &&
  // Check that the method name is'require'
  n.getFirstChild().isGetProp() &&
  n.getFirstChild().getFirstChild().isName() &&
  "require".equals(n.getFirstChild().getFirstChild().getString()) &&
  // Check that the argument is a string literal
  n.getFirstChild().getNext().isString() &&
  // Check that the namespace argument is provided and recognized
  providedNames.containsKey(n.getFirstChild().getNext().getString())
);


