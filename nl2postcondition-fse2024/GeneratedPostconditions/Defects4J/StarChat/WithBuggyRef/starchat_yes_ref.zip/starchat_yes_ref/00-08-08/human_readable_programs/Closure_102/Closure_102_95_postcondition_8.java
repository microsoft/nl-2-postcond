// Check that the list is sorted according to the compare function
assert(java.util.Collections.sort(list, compare) == list);


