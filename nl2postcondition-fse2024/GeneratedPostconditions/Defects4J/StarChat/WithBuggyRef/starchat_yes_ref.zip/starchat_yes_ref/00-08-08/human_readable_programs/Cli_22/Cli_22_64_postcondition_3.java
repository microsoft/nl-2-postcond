// Ensures that if the method processOptionToken is called, the token parameter is added to the processed tokens if an Option exists for it
assert (options.hasOption(token) && returnValue.contains(token)) || (!options.hasOption(token) &&!eatTheRest && returnValue.contains(token));


