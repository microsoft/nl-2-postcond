// Postcondition: All elements in the list have been added to the command line
assert all(v -> commandLine.getValues(this).contains(v), arguments);


