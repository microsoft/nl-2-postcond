assert (returnValue!= null); // Postcondition: Non-null return value


