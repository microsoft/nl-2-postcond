// Check that the value at the specified index is removed
assert(this.values.get(index).equals(returnValue));


