// Check that the return value represents the correct range of values in the domain (x-values) of the input dataset.
assert (returnValue == null || (returnValue.getLowerBound() <= minValue && maxValue <= returnValue.getUpperBound())):
  "The return value does not match the range of values in the domain of the input dataset.";


