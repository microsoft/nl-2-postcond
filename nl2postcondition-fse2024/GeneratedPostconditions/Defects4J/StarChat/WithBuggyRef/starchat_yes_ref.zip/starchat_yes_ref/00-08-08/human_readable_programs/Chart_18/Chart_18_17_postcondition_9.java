import java.util.Iterator;

public class DefaultKeyedValues2D implements KeyedValues2D, PublicCloneable, Cloneable, Serializable {
    public void removeColumn(int columnIndex) {
        Comparable columnKey = getColumnKey(columnIndex);
        removeColumn(columnKey);
    }

    // postcondition for the method removeColumn
    // Comment explaining what aspect of the method the symbolic postcondition checks
    assert this.columnKeys.contains(columnKey) : "After calling removeColumn with columnIndex " + columnIndex + ", the columnKeys set no longer contains the removed column's key";

    Iterator iterator = this.rows.iterator();
    while (iterator.hasNext()) {
        DefaultKeyedValues rowData = (DefaultKeyedValues) iterator.next();
        rowData.removeValue(columnKey);
    }
    this.columnKeys.remove(columnKey);
}


