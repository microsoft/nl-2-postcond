// Check that the output array contains the same number of elements as the input array
assert returnValue.length == arguments.length;


