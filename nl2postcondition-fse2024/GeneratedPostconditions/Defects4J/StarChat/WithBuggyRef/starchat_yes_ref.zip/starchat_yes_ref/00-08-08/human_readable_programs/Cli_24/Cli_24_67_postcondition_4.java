//This postcondition checks that the wrapped text is the same as the original text
assert renderWrappedText(sb, width, nextLineTabStop, text).toString().equals(text);


