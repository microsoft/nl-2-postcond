// Ensures that when the method `getTypeWithProperty` is implemented, it returns
// a value that is either null or an object type that contains a property with the name `field`.
assert (
  (returnValue == null) ||
  (returnValue instanceof ObjectType) && returnValue.hasOwnProperty(field)
);


