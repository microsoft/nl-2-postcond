// Postcondition: the marker displays the specified value using the specified paint,
// stroke, and outline properties, with the specified alpha transparency.
assert(
    new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha).
    equals(
        new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha)
    )
);


