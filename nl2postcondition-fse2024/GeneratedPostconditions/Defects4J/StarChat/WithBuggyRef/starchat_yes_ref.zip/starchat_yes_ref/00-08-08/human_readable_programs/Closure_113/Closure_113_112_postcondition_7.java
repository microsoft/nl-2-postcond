// check that the argument to processRequireCall is a string literal
assert arg instanceof String;

// check that the element in the input parameter "providedNames" associated with the key "ns"
// is non-null and has a non-null value for "explicitModule"
assert providedNames.get(ns)!= null && providedNames.get(ns).explicitModule!= null;

// check that the call to t.getModule() does not return null
JSModule module = t.getModule();
assert module!= null;

// check that the call to "dependsOn" on the module graph between the module passed to t.getModule()
// and the module associated with the given namespace "ns" in the input parameter "providedNames"
// does not return false
if (moduleGraph!= null) {
  assert moduleGraph.dependsOn(module, providedNames.get(ns).explicitModule);
}

// check that the call to "report" does not throw an exception
try {
  compiler.report(errorNode, message,...);
} catch (Exception e) {
  assert false;
}

// check that the call to "maybeAddToSymbolTable" with the given qualified name node "left" does not throw an exception
try {
  maybeAddToSymbolTable(left);
} catch (Exception e) {
  assert false;
}

// check that the call to "maybeAddStringNodeToSymbolTable" with the given string literal node "arg" does not throw an exception
try {
  maybeAddStringNodeToSymbolTable(arg);
} catch (Exception e) {
  assert false;
}


