import java.util.Iterator;

// Postcondition:
// The output array contains only valid options, in the same order
// as they appear in the input array. If stopAtNonOption is true, the
// output array contains only options and no non-options.
public static String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
    // Hypothetical return value (not used by the method)
    String[] returnValue = new String[0];

    // Check the postcondition:
    assert (containsOnlyValidOptions(options, returnValue, arguments, stopAtNonOption));

    // Return the hypothetical return value
    return returnValue;
}

// Checks that the output array contains only valid options.
private static boolean containsOnlyValidOptions(Options options, String[] returnValue, String[] arguments, boolean stopAtNonOption) {
    // Iterate over each element in the output array
    for (int i = 0; i < returnValue.length; i++) {
        // Check if the option is in the list of options
        if (!options.hasOption(returnValue[i])) {
            // If not, return false
            return false;
        }
    }

    // Iterate over each element in the input array
    for (int i = 0; i < arguments.length; i++) {
        // If stopAtNonOption is true, check if the element is an option
        if (stopAtNonOption &&!options.hasOption(arguments[i])) {
            // If not, return false
            return false;
        }

        // Check if the element is an option
        if (options.hasOption(arguments[i])) {
            // If so, add it to the output array
            returnValue[returnValue.length] = arguments[i];
        }
    }

    // Return true if all elements in the input array were options
    return true;
}


