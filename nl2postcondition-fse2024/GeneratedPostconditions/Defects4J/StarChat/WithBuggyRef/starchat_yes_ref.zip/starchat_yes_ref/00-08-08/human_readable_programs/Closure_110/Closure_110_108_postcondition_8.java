// Ensures that the set of forbidden local variables in the scope of the findAliases method does not change
assert forbiddenLocals.equals(getForbiddenLocalsBeforeFindAliases(root));


