// The return value of the method is stored in a variable `returnValue`.
assert returnValue!= null;


