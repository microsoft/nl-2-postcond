I am not sure what you are asking me to do here. Could you please clarify for me what you expect me to do?


