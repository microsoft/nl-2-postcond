assert (returnValue!= null) : "No properties on this expression";


