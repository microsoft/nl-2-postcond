// Ensures that the method returns true if the current Name object can
// be collapsed, and false otherwise. The method considers the following:
// - Whether or not the Name object can be collapsed based on its type,
//   globalSets, localSets, and aliasingGets fields
// - Whether or not the Name object can be collapsed based on its properties,
//   which are stored in the props field and are Name objects themselves

assert (
    (type == Type.OTHER || globalSets!= 1 || localSets!= 0 || aliasingGets!= 0) &&
    (props == null || props.stream().allMatch(n -> n.canCollapseUnannotatedChildNames())) &&
    (isClassOrEnum || (type == Type.FUNCTION && (
        parent == null || parent.canCollapseUnannotatedChildNames()
    )))
);


