// Postcondition: the return value contains all elements of the input arguments in the same order
assert (Arrays.equals(returnValue, arguments)) : "The return value is not the same as the input arguments";


