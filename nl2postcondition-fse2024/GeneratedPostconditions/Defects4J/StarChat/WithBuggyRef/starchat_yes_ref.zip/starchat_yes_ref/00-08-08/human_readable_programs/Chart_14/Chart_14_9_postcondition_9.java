assert: // Postcondition: When removeRangeMarker is called with the specified parameters, 
// the return value (i.e., returnValue) is true if and only if the marker was removed 
// from the specified layer (i.e., layer) and the layer's list of markers is now empty 
// (i.e., markers.size() == 0).

// Import statements
import java.util.ArrayList;
import org.jfree.chart.util.Layer;

// Method signature
public boolean removeRangeMarker(int index, Marker marker, Layer layer)

{
// Precondition: The input parameters are valid (i.e., index >= 0, layer!= null, 
// and marker!= null).

	// Local variables
	ArrayList<Marker> markers;

	// If the specified layer is Layer.FOREGROUND, get the markers from the 
	// foregroundRangeMarkers map. Else, get them from the backgroundRangeMarkers map.
	if (layer == Layer.FOREGROUND) {
		markers = foregroundRangeMarkers.get(index);
	}
	else {
		markers = backgroundRangeMarkers.get(index);
	}

	// If the marker was found in the layer's list of markers, remove it and 
	// return true. Else, return false.
	if (markers.remove(marker)) {
		return true;
	}
	else {
		return false;
	}
}


