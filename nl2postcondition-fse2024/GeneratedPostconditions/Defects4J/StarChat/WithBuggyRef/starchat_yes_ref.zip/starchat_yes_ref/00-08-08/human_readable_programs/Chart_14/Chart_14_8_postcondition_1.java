import java.util.List;

// The input parameters are:
// index: an integer that is used to index a list
// marker: a Marker object that is being removed
// layer: a Layer enum that determines which marker list to remove the marker from
// notify: a boolean that determines whether or not to send a PlotChangeEvent to listeners

public boolean removeDomainMarker(int index, Marker marker, Layer layer, boolean notify) {
    // The postcondition checks if the marker was removed successfully
    assert markerRemoved = removeDomainMarkerHelper(index, marker, layer)
    
    // The helper method returns a boolean indicating whether or not the marker was removed
    public boolean removeDomainMarkerHelper(int index, Marker marker, Layer layer) {
        // The helper method checks if the input parameters are valid
        assert index >= 0 && layer == Layer.FOREGROUND || layer == Layer.BACKGROUND;
        assert marker!= null;
        
        // The helper method removes the marker from the specified layer and index
        List<Marker> markers = (layer == Layer.FOREGROUND)? this.foregroundDomainMarkers.get(index) : this.backgroundDomainMarkers.get(index);
        boolean removed = markers.remove(marker);
        
        // The helper method returns a boolean indicating whether or not the marker was removed
        return removed;
    }
}


