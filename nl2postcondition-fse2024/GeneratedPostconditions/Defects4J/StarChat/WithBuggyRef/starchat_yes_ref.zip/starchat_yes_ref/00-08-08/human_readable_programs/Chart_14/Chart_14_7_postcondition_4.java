// Postcondition: The marker is removed if and only if it exists in the specified layer and index
assert (marker!= null && (layer == Layer.FOREGROUND? foregroundRangeMarkers.get(index).contains(marker) : backgroundRangeMarkers.get(index).contains(marker)) == returnValue);


