assert: The return value of the method is false if the input marker is null.


