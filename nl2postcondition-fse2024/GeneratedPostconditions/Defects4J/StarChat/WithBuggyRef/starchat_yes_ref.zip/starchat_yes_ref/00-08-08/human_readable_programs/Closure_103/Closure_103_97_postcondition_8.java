// Check that the return value is not null
assert (returnValue!= null);


