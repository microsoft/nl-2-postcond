assert (returnValue!= null) : "The return value of meet() cannot be null";


