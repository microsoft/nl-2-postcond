// Postcondition: Throws a MissingOptionException if the required Options are not present.
assert (requiredOptions.stream().allMatch(opt -> cmd.hasOption(opt))) : "All required options must be present";


