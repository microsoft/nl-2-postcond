// Check that the removed marker is no longer in the list of range markers
ArrayList<Marker> markers = (layer == Layer.FOREGROUND)?
    this.foregroundRangeMarkers.get(index) : this.backgroundRangeMarkers.get(index);
assert!markers.contains(marker);


