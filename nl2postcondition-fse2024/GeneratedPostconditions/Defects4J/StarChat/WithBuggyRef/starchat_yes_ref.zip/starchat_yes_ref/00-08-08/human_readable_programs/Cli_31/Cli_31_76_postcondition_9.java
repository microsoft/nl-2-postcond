assert post:
// The StringBuffer object 'buff' contains the resulting usage message
// The Option object 'option' is the current Option being processed
// The boolean value'required' indicates whether the Option is required or not
(buff.toString().indexOf(' ') + 1 == buff.length() ||
 // The Option is not required and the resulting usage message is not empty
 buff.toString().indexOf(' ') + 1 < buff.length() && required)
&&
// The resulting usage message does not contain a string of the form '--' followed by the long option name
!buff.toString().contains(" --" + option.getLongOpt());


