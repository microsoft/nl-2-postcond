// Check that the input axis is non-null and assigned to the plot
assert (axis!= null && this.domainAxes.contains(axis)) : 
    "The input axis must be non-null and assigned to the plot.";

// Check that the plot contains the input axis
int axisIndex = this.domainAxes.indexOf(axis);
assert (axisIndex!= -1) : "The input axis must be assigned to the plot.";

// Check that the axis is assigned to the correct plot
CategoryPlot axisPlot = axis.getPlot();
assert (axisPlot!= null && axisPlot.equals(this)) : 
    "The input axis must be assigned to this plot.";

// Return the index of the input axis
int returnValue = axisIndex;
return returnValue;


