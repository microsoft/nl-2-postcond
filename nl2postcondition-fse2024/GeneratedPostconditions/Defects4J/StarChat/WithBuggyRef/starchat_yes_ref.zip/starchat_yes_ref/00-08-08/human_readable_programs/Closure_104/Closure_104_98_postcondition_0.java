// The postcondition checks that the return value is the same as the input value
// if the input value is a subtype of the return value
assert (this.isSubtype(input)) == (returnValue.isSubtype(input));


