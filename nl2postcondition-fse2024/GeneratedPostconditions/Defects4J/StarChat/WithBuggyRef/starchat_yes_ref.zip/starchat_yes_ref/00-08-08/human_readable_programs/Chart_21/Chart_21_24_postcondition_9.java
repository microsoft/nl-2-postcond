// Postcondition: Ensures that the cached bounds are updated correctly after
// the list of box and whisker items is updated with a new item.
assert(returnValue == null ||
        (minval == Double.NaN && maxval == Double.NaN &&
        this.minimumRangeValue == minval && this.maximumRangeValue == maxval));


