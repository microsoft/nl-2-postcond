Here is the symbolic postcondition for the drawLabel method:

// Check that the label is correctly drawn, aligned with the edge, rotated by the correct angle, and clipped to the plot area
assert (edge == RectangleEdge.TOP && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight()) ||
    (edge == RectangleEdge.BOTTOM && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight()) ||
    (edge == RectangleEdge.LEFT && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight()) ||
    (edge == RectangleEdge.RIGHT && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight())

If the method drawLabel is called with the specified parameters, the postcondition will hold true and no error will be thrown.


