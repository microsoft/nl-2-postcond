import java.util.ArrayList;

public class Postcondition {
  public static void removeRangeMarker(ArrayList markers, int index, 
      Marker marker, Layer layer, boolean notify) {
    // Remove the marker
    boolean removed = markers.remove(marker);

    // Check that the marker was correctly removed
    assert removed == true : "The marker was not removed";

    // Check that the event was fired correctly
    assert notify == true : "The event was not fired correctly";
  }
}


