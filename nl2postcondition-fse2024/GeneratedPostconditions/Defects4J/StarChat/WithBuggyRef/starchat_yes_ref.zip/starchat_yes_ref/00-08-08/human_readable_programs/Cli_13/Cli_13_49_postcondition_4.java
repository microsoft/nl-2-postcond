import java.util.ListIterator;
import java.util.StringTokenizer;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;

public class ArgumentImpl extends OptionImpl implements Argument {

    public void process(WriteableCommandLine commandLine, ListIterator args)
            throws OptionException {
        processValues(commandLine, args, this);
    }

    /**
     * If there are any leading or trailing quotes remove them from the specified token.
     *
     * @param token the token to strip leading and trailing quotes
     *
     * @return String the possibly modified token
     */
    public String stripBoundaryQuotes(String token) {
        if (!token.startsWith("\"") ||!token.endsWith("\"")) {
            return token;
        }

        token = token.substring(1, token.length() - 1);

        return token;
    }

    // postcondition:
    // ensures the result of the split operation is a List of strings
    // where each string does not include quotes.
    public void processValues(final WriteableCommandLine commandLine,
                              final ListIterator arguments,
                              final Option option)
            throws OptionException {
        int argumentCount = 0;

        while (arguments.hasNext() && (argumentCount < maximum)) {
            final String allValuesQuoted = (String) arguments.next();
            final String allValues = stripBoundaryQuotes(allValuesQuoted);
            if (allValuesQuoted.equals(consumeRemaining)) {
                while (arguments.hasNext() && (argumentCount < maximum)) {
                    ++argumentCount;
                    commandLine.addValue(option, arguments.next());
                }
            }
            else if (commandLine.looksLikeOption(allValuesQuoted)) {
                arguments.previous();

                break;
            }
            else if (subsequentSplit) {
                final StringTokenizer values =
                        new StringTokenizer(allValues, String.valueOf(subsequentSeparator));

                arguments.remove();

                while (values.hasMoreTokens() && (argumentCount < maximum)) {
                    ++argumentCount;

                    final String token = values.nextToken();
                    commandLine.addValue(option, token);
                    arguments.add(token);
                }

                if (values.hasMoreTokens()) {
                    throw new OptionException(option, ResourceConstants.ARGUMENT_UNEXPECTED_VALUE,
                                              values.nextToken());
                }
            }
            else {
                ++argumentCount;
                commandLine.addValue(option, allValues);
            }


