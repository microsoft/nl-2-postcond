// Check that the method returns true if the description is recorded.
assert returnValue == true;


