// Ensure that when processValues is called, the values are added in order

import java.util.ListIterator;
import java.util.StringTokenizer;
import org.apache.commons.cli2.Option;
import org.apache.commons.cli2.OptionException;
import org.apache.commons.cli2.WriteableCommandLine;
import org.apache.commons.cli2.resource.ResourceConstants;

public class ArgumentImpl
    extends OptionImpl implements Argument {
    
    public void process(WriteableCommandLine commandLine,
                            ListIterator args)
            throws OptionException {
            processValues(commandLine, args, this);
        }
       
    public void processValues(final WriteableCommandLine commandLine,
                                  final ListIterator arguments,
                                  final Option option)
            throws OptionException {
            int argumentCount = 0;
            Object returnValue;
    
            while (arguments.hasNext() && (argumentCount < maximum)) {
                final String allValuesQuoted = (String) arguments.next();
                final String allValues = stripBoundaryQuotes(allValuesQuoted);
                if (allValuesQuoted.equals(consumeRemaining)) {
                    while (arguments.hasNext() && (argumentCount < maximum)) {
                        ++argumentCount;
                        commandLine.addValue(option, arguments.next());
                    }
                }
                else if (commandLine.looksLikeOption(allValuesQuoted)) {
                    arguments.previous();
    
                    break;
                }
                else if (subsequentSplit) {
                    final StringTokenizer values =
                        new StringTokenizer(allValues, String.valueOf(subsequentSeparator));
    
                    arguments.remove();
    
                    while (values.hasMoreTokens() && (argumentCount < maximum)) {
                        ++argumentCount;
    
                        final String token = values.nextToken();
                        commandLine.addValue(option, token);
                        assert arguments.hasNext() : "next token exists but iterator does not";
                        assert arguments.next().equals(token) : "next token does not match";
                    }
    
                    if (values.hasMoreTokens()) {
                        throw new OptionException(option, ResourceConstants.ARGUMENT_UNEXPECTED_VALUE,
                                                  values.nextToken());
                    }
                }
                else {
                    ++argumentCount;
                    commandLine.addValue(option, allValues);
                }
            }
        }
        
In this hypothetical postcondition, we ensure that the values are added to the command line in order, by iterating through the values and checking that each value is added after the previous one. If a value was added to the command line in a previous iteration,


