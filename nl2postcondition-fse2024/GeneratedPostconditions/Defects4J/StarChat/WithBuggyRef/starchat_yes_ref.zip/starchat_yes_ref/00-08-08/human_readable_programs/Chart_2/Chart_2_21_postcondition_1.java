// Postcondition:
assert returnValue!= null : "The returned range should not be null";


