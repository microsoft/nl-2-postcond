// Postcondition: If an Option exists for token, set the current option and add the token to the processed list.
assert (options.hasOption(token) && (currentOption == options.getOption(token))) == (token.equals(currentOption.getOpt()));


