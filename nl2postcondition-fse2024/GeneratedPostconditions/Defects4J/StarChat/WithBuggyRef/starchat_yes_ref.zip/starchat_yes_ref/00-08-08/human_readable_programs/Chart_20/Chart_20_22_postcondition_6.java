//The elements in the list are in sorted order
assert java.util.Arrays.equals(java.util.Arrays.sort(inputList), inputList);


