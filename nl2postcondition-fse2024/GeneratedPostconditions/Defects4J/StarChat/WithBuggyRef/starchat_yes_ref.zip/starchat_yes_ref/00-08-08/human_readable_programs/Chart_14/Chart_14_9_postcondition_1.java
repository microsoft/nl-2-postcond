Sure, here's a possible symbolic postcondition for the removeRangeMarker method:

// Postcondition: the marker is in the specified layer and the index is valid
assert marker.getLayer() == layer && index >= 0 && index < this.datasetCount;


