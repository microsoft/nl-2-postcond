import java.util.Arrays;

public class SymbolicPostcondition {
  public static void main(String[] args) {
    double[] values = new double[] {1, 2, 3};
    double[] sortedValues = sort(values);
    assert isSorted(sortedValues);
  }

  public static double[] sort(double[] input) {
    double[] output = input.clone();
    Arrays.sort(output);
    return output;
  }

  private static boolean isSorted(double[] values) {
    for (int i = 1; i < values.length; i++) {
      if (values[i - 1] > values[i]) {
        return false;
      }
    }
    return true;
  }
}


