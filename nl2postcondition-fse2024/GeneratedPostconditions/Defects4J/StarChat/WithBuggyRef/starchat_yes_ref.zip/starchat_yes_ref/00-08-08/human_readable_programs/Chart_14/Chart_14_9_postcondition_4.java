import java.util.ArrayList;

// [...]

// Postcondition:
// Ensures that the marker is removed from the list of range markers for the
// specified layer and dataset, and that the change is notified to registered
// listeners if specified.
assert(this.foregroundRangeMarkers.get(new Integer(index)) == null ||
   !this.foregroundRangeMarkers.get(new Integer(index)).contains(marker)) &&
(this.backgroundRangeMarkers.get(new Integer(index)) == null ||
   !this.backgroundRangeMarkers.get(new Integer(index)).contains(marker)) &&
(returnValue == true);


