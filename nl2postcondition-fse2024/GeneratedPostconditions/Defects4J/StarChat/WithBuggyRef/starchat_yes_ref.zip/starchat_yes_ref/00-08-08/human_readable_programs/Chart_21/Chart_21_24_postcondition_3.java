// Symbolic postcondition for updateBounds method:
    assert(this.minimumRangeValue == Double.NaN ||
           (returnValue.getRangeBounds().getLowerBound() == this.minimumRangeValue));
    assert(this.maximumRangeValue == Double.NaN ||
           (returnValue.getRangeBounds().getUpperBound() == this.maximumRangeValue));


