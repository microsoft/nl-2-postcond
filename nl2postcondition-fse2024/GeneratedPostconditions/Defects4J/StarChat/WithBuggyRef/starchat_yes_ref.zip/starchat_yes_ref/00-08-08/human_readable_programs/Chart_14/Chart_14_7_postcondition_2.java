assert (List<Marker> markers = this.foregroundRangeMarkers.get(index))!= null;
assert!markers.contains(marker);
assert (List<Marker> markers = this.backgroundRangeMarkers.get(index))!= null;
assert!markers.contains(marker);


