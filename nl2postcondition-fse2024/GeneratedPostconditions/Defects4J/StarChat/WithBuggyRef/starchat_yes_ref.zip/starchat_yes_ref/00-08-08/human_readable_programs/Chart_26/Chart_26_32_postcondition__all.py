
# Response 0
assert (
    //Check that if the edge parameter is set to top, the code inside the if-statement is executed.
    (edge == RectangleEdge.TOP)?
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font.
    returnValue.getFontMetrics().getFont().equals(labelFont) &&
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font size.
    returnValue.getFontMetrics().getHeight() == labelFont.getSize() &&
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font style.
    returnValue.getFontMetrics().getStyle() == labelFont.getStyle() &&
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font color.
    returnValue.getFontMetrics().getColor() == labelPaint &&
    //Check that the String returned by TextUtilities.getTextBounds() is equal to the input label parameter.
    returnValue.getText().equals(label) &&
    //Check that the Rectangle2D object returned by getTextBounds() has the correct width.
    returnValue.getWidth() == returnValue.getFontMetrics().stringWidth(label) &&
    //Check that the Rectangle2D object returned by getTextBounds() has the correct height.
    returnValue.getHeight() == returnValue.getFontMetrics().getHeight() &&
    //Check that the Rectangle2D object returned by getTextBounds() has the correct x-coordinate.
    (edge == RectangleEdge.TOP)? returnValue.getX() == dataArea.getX() + dataArea.getWidth() / 2.0 - returnValue.getWidth() / 2.0 :
    (edge == RectangleEdge.BOTTOM)? returnValue.getX() == dataArea.getX() + dataArea.getWidth() / 2.0 - returnValue.getWidth() / 2.0 :
    (edge == RectangleEdge.LEFT)? returnValue.getY() == dataArea.getY() + dataArea.getHeight() / 2.0 - returnValue.getHeight() / 2.0 :
    (edge == RectangleEdge.RIGHT)? returnValue.getY() == dataArea.getY() + dataArea.getHeight() / 2.0 - returnValue.getHeight() / 2.0 :
    false
) : "Invalid edge parameter";



# Response 1
// Check that the label's horizontal alignment is correct:
assert(edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
        && labelBounds.getY() == dataArea.getY() + (edge == RectangleEdge.TOP? 0 : dataArea.getHeight())
        && labelBounds.getX() + (edge == RectangleEdge.TOP? 0 : labelBounds.getWidth()) <= dataArea.getX() + dataArea.getWidth());
// Check that the label's vertical alignment is correct:
assert(edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
        && labelBounds.getX() == dataArea.getX() + (edge == RectangleEdge.LEFT? 0 : dataArea.getWidth())
        && labelBounds.getY() + (edge == RectangleEdge.LEFT? 0 : labelBounds.getHeight()) <= dataArea.getY() + dataArea.getHeight());
// Check that the label's angle is correct:
assert(Math.abs(getLabelAngle()) <= Math.PI / 2.0);
// Check that the label's insets are correct:
assert(getLabelInsets().equals(new RectangleInsets(edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
               ? dataArea.getY() - labelBounds.getY()
                : edge == RectangleEdge.LEFT? dataArea.getX() - labelBounds.getX()
                : labelBounds.getY() - dataArea.getY(), edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
               ? dataArea.getY() + dataArea.getHeight() - labelBounds.getY() - labelBounds.getHeight()
                : edge == RectangleEdge.LEFT? dataArea.getX() + dataArea.getWidth() - labelBounds.getX() - labelBounds.getWidth()
                : dataArea.getY() + dataArea.getHeight() - labelBounds.getY(), edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
               ? dataArea.getX() - labelBounds.getX()
                : dataArea.getX() + dataArea.getWidth() - labelBounds.getX() - labelBounds.getWidth(), edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
               ? labelBounds.getY() - dataArea.getY()
                : labelBounds.getY() - dataArea.getY() + labelBounds.getHeight(), edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
               ? dataArea.getY()
                : dataArea.getY() + dataArea.getHeight(), edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
               ? dataArea.getX() + dataArea.getWidth()
                : dataArea.getX())));
// Check that the label's font is correct:
assert(getLabelFont().equals(new Font("SansSerif", Font.PLAIN, 12)));
// Check that the label's paint is correct:
assert(getLabelPaint().equals(Color.BLACK));
// Check that the label is drawn correctly:
assert(TextUtilities.drawRotatedString("Label", g2, 10, 20, TextAnchor.BASELINE_LEFT, 0, TextAnchor.BASELINE_LEFT) == new Rectangle2D.Float(10, 20, 60, 15));



# Response 2
Here is the symbolic postcondition for the drawLabel method:

// Check that the label is correctly drawn, aligned with the edge, rotated by the correct angle, and clipped to the plot area
assert (edge == RectangleEdge.TOP && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight()) ||
    (edge == RectangleEdge.BOTTOM && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight()) ||
    (edge == RectangleEdge.LEFT && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight()) ||
    (edge == RectangleEdge.RIGHT && 
    g2.getFont() == getLabelFont() &&
    g2.getPaint() == getLabelPaint() &&
    g2.getFontMetrics() == fm &&
    labelBounds.getWidth() == TextUtilities.getTextBounds(label, g2, fm).getWidth()
    labelBounds.getHeight() == TextUtilities.getTextBounds(label, g2, fm).getHeight())

If the method drawLabel is called with the specified parameters, the postcondition will hold true and no error will be thrown.



# Response 3
Here's a symbolic postcondition for drawLabel:

// Check that the hotspot for the axis label is not null
assert (hotspot!= null);

Note that this is just an example and not a complete, executable postcondition. You would need to modify it to work with the other input parameters and method behavior.



# Response 4
// Ensures the label is drawn correctly when edge is TOP
assert(g2.getFontMetrics().stringWidth(label) <= dataArea.getWidth() - 2 * insets.getLeft()
&& g2.getFontMetrics().getHeight() <= dataArea.getHeight() - 2 * insets.getTop() 
&& g2.getFontMetrics().stringWidth(label) >= 0 
&& g2.getFontMetrics().getHeight() >= 0);



# Response 5
// The label is rotated by the label angle around its center point
assert (edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM)?
    // If the axis is horizontal, the label is aligned with the center of the data area
    (Math.abs(dataArea.getCenterY() - hotspot.getCenterY()) < EPSILON &&
    // And its left or right edge is aligned with the left or right edge of the data area
    (edge == RectangleEdge.LEFT? dataArea.getMinX() - EPSILON <= hotspot.getMinX() :
        dataArea.getMaxX() + EPSILON >= hotspot.getMaxX())) :
    // If the axis is vertical, the label is aligned with the center of the data area
    (Math.abs(dataArea.getCenterX() - hotspot.getCenterX()) < EPSILON &&
    // And its top or bottom edge is aligned with the top or bottom edge of the data area
    (edge == RectangleEdge.TOP? dataArea.getMinY() - EPSILON <= hotspot.getMinY() :
        dataArea.getMaxY() + EPSILON >= hotspot.getMaxY()));



# Response 6
// Postcondition: Ensures that the label is drawn with the correct properties
assert (



# Response 7
// The method draws the axis label and returns the updated axis state.
assert(
    // If the edge is top:
    (edge == RectangleEdge.TOP)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the center of the data area:
        dataArea.getCenterX(), 
        // With a vertical offset that is equal to the cursor position minus the insets top:
        state.getCursor() - insets.getTop(), 
        // With horizontal and vertical alignment both set to CENTER:
        TextAnchor.CENTER, TextAnchor.CENTER, 
        // And the label rotated by the angle specified by getLabelAngle:
        getLabelAngle())
    // And the hotspot for the axis label should be a rectangle with the following dimensions:
    && (hotspot.equals(
        new Rectangle2D.Float(
            // With a left edge equal to the data area center minus half the width of the label:
            dataArea.getCenterX() - (labelBounds.getWidth() / 2.0), 
            // With a top edge equal to the cursor position minus half the height of the label:
            state.getCursor() - (labelBounds.getHeight() / 2.0), 
            // And a width equal to the width of the label:
            labelBounds.getWidth(), 
            // And a height equal to the height of the label:
            labelBounds.getHeight()
        )
    ))
    // If the edge is bottom:
    || (edge == RectangleEdge.BOTTOM)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the center of the data area:
        dataArea.getCenterX(), 
        // With a vertical offset that is equal to the cursor position plus the insets bottom:
        state.getCursor() + insets.getBottom(), 
        // With horizontal and vertical alignment both set to CENTER:
        TextAnchor.CENTER, TextAnchor.CENTER, 
        // And the label rotated by the angle specified by getLabelAngle:
        getLabelAngle())
    // And the hotspot for the axis label should be a rectangle with the following dimensions:
    && (hotspot.equals(
        new Rectangle2D.Float(
            // With a left edge equal to the data area center minus half the width of the label:
            dataArea.getCenterX() - (labelBounds.getWidth() / 2.0), 
            // With a top edge equal to the cursor position minus half the height of the label:
            state.getCursor() - (labelBounds.getHeight() / 2.0), 
            // And a width equal to the width of the label:
            labelBounds.getWidth(), 
            // And a height equal to the height of the label:
            labelBounds.getHeight()
        )
    ))
    // If the edge is left:
    || (edge == RectangleEdge.LEFT)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the cursor position minus the insets right:
        state.getCursor() - insets.getRight(), 
        // With a vertical offset that is equal to the data area center:
        dataArea.getCenterY(), 
        // With horizontal alignment set to CENTER and vertical alignment set to CENTER:
        TextAnchor.CENTER, TextAnchor.CENTER, 
        // And the label rotated by the angle specified by getLabelAngle minus Math.PI / 2.0:
        getLabelAngle() - Math.PI / 2.0)
    // And the hotspot for the axis label should be a rectangle with the following dimensions:
    && (hotspot.equals(
        new Rectangle2D.Float(
            // With a left edge equal to the cursor position minus half the width of the label:
            state.getCursor() - (labelBounds.getWidth() / 2.0), 
            // With a top edge equal to the data area center minus half the height of the label:
            dataArea.getCenterY() - (labelBounds.getHeight() / 2.0), 
            // And a width equal to the width of the label:
            labelBounds.getWidth(), 
            // And a height equal to the height of the label:
            labelBounds.getHeight()
        )
    ))
    // If the edge is right:
    || (edge == RectangleEdge.RIGHT)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the cursor position plus the insets left:
        state.getCursor() + insets.



# Response 8
// assert that the output of drawLabel is correct when the specified edge is RectangleEdge.TOP
assert(
    // the return value of the method
    returnValue = 
    // the implementation of the method, where edge is replaced with RectangleEdge.TOP
    drawLabel(
        // the input parameter label
        label, 
        // the input parameter g2
        g2, 
        // the input parameter plotArea
        plotArea, 
        // the input parameter dataArea
        dataArea, 
        // the input parameter edge, replaced with RectangleEdge.TOP
        RectangleEdge.TOP, 
        // the input parameter state
        state, 
        // the input parameter plotState
        plotState
    )
);



# Response 9
// The input list is sorted according to the comparator
assert inputList.equals(inputList.stream().sorted(comparator).collect(Collectors.toList()));


