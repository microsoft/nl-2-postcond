// Ensure that the current block description is recorded in the JSDocInfo object
assert currentInfo.documentBlock(description) :
  "The block description was not recorded correctly in the JSDocInfo object";


