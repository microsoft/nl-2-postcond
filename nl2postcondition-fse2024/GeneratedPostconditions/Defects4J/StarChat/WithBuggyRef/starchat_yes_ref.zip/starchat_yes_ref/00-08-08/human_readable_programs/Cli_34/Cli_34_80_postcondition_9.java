// The reset method resets the member variables to their default values.
assert: // Postcondition: After reset is called, all member variables are set to their default values.
(description == null && argName == null && longopt == null && type == null && required == false
&& numberOfArgs == UNINITIALIZED && optionalArg == false && valuesep == (char) 0)


