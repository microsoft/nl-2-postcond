// The return value of the method mayThrowException is stored in the "returnValue" variable.
assert returnValue == (n.getType() == Token.CALL || n.getType() == Token.GETPROP || n.getType() == Token.GETELEM || n.getType() == Token.THROW || n.getType() == Token.NEW || n.getType() == Token.ASSIGN || n.getType() == Token.INC || n.getType() == Token.DEC) || (n.getType() == Token.FUNCTION &&!mayThrowException(n.getLastChild()));


