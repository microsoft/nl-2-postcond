I'm sorry, I don't understand the question, could you please clarify?


