// Postcondition: removes the specified marker from the range axis for the given layer,
// and notifies registered listeners if the notify parameter is true.
assert removeRangeMarker(marker, layer, notify) == (
    // Remove the marker
    removeRangeMarker(marker, layer, false) &&
    // If we want to notify listeners, do so
    (notify? fireChangeEvent() : true)
);


