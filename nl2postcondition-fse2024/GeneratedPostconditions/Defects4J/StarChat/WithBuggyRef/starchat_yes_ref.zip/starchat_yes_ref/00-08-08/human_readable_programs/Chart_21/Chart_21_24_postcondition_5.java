// Postcondition for updateBounds:
assert (returnValue!= null);


