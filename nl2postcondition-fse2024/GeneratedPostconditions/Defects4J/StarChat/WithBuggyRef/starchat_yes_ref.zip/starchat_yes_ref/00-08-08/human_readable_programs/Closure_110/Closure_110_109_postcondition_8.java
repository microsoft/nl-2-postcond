assert ( // Comment explaining what aspect of the method the symbolic postcondition checks
// Postcondition code here)


