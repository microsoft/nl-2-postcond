// Postcondition:
assert returnValue == // The hypothetical return value of the method
&& tokens.containsAll(Arrays.asList("--", value)) // -- and the value were added to the list of processed tokens
&& tokens.size() == // The size of the processed tokens list is
// 1 more than the size of the original argument list
originalArgList.size() + 1;


