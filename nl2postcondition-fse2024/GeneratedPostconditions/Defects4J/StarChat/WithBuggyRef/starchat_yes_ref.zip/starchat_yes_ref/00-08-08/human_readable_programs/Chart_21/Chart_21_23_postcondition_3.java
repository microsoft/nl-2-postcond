// Ensures that if the add method is called, the range of values for the row and column keys is updated correctly
assert (this.rangeBounds.contains(item.getMean()) && this.rangeBounds.contains(item.getQ1()) && this.rangeBounds.contains(item.getQ2()) && this.rangeBounds.contains(item.getQ3()) && this.rangeBounds.contains(item.getMin()) && this.rangeBounds.contains(item.getMax()));


