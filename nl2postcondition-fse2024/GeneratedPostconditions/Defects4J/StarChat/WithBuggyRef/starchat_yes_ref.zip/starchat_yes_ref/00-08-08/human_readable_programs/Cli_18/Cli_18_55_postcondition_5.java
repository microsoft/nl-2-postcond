// Checks that the output list contains the same number of elements as the input list
assert returnValue.length == arguments.length;


