import java.util.Arrays;
import org.jfree.data.Range;
import org.jfree.data.xy.XYDataset;

public class MyClass {
    public static Range iterateDomainBounds(XYDataset dataset, boolean includeInterval) {
        // Precondition: dataset is non-null
        assert dataset!= null;
        
        // Hypothetical return value
        Range returnValue;
        
        // If the dataset is an instance of DomainInfo, use its getDomainBounds method
        if (dataset instanceof DomainInfo) {
            returnValue = ((DomainInfo) dataset).getDomainBounds(includeInterval);
        }
        // Otherwise, use the helper method calculateDomainBounds
        else {
            returnValue = calculateDomainBounds(dataset, includeInterval);
        }
        
        // Postcondition: the return value is either null or a valid Range object
        assert returnValue == null || (returnValue.getLength() >= 0.0 && Double.isFinite(returnValue.getLength()));
        
        // Return value
        return returnValue;
    }
    
    // A helper method for calculating the domain bounds
    private static Range calculateDomainBounds(XYDataset dataset, boolean includeInterval) {
        // Hypothetical variables
        double minimum = Double.POSITIVE_INFINITY;
        double maximum = Double.NEGATIVE_INFINITY;
        int seriesCount = dataset.getSeriesCount();
        double lvalue;
        double uvalue;
        
        // If the includeInterval flag is true and the dataset is an IntervalXYDataset,
        // iterate over the interval data
        if (includeInterval && dataset instanceof IntervalXYDataset) {
            IntervalXYDataset intervalXYData = (IntervalXYDataset) dataset;
            for (int series = 0; series < seriesCount; series++) {
                int itemCount = dataset.getItemCount(series);
                for (int item = 0; item < itemCount; item++) {
                    lvalue = intervalXYData.getStartXValue(series, item);
                    uvalue = intervalXYData.getEndXValue(series, item);
                    if (!Double.isNaN(lvalue)) {
                        minimum = Math.min(minimum, lvalue);
                    }
                    if (!Double.isNaN(uvalue)) {
                        maximum = Math.max(maximum, uvalue);
                    }
                }
            }
        }
        // Otherwise, if the includeInterval flag is false or the dataset is not an IntervalXYDataset,
        // iterate over the point data
        else {
            for (int series = 0; series < seriesCount; series++) {
                int itemCount = dataset.getItemCount(series);
                for (int item = 0; item < itemCount; item++) {
                    lvalue = dataset.getXValue(series, item);
                    uvalue = lvalue;
                    if (!Double.isNaN(lvalue)) {
                        minimum = Math.min(minimum, lvalue);
                        maximum = Math.max(maximum, uvalue);
                    }
                }
            }
        }
        
        // If the minimum and maximum values are not equal, return a Range object containing them
        if (minimum!= maximum) {
            return new Range(minimum, maximum);
        }
        // Otherwise, return null
        else {
            return null;
        }
    }
}


