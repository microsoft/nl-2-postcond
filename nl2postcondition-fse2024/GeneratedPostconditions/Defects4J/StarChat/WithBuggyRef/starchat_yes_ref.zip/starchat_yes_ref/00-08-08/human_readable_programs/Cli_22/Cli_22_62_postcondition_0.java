// Postcondition: The return value is an array containing the same elements as the input array,
// in the same order. If the input array contains duplicate option names, the corresponding values
// are concatenated into a single element in the return value array in the order they appear in the input array.
assert (Arrays.equals(returnValue, expectedReturnValue)) : "Invalid return value";


