// Symbolic postcondition for arrangeFF
// Verifies that the arrangement is in the expected position and size
assert returnValue.equals(arrangeFF(container, g2, constraint));


