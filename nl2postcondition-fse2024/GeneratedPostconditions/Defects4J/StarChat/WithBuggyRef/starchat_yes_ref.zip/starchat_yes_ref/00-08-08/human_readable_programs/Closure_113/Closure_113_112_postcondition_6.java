assert (
    (
        (
            // If the provided namespace is not already present in the map,
            // add the namespace and set isExplicitlyProvided to true
            (providedNames.get(ns) == null) &&
            (returnValue!= null)
        ) || (
            // Otherwise, if the provided namespace is already present in the map,
            // leave the map unchanged and set isExplicitlyProvided to the
            // existing value
            (providedNames.get(ns)!= null) &&
            (returnValue!= providedNames.get(ns))
        )
    ) && (
        // Check that the moduleGraph is not null
        (moduleGraph!= null) &&
        // Check that the provided module is not the current module
        (!moduleGraph.dependsOn(module, providedModule)) &&
        // Report an error if the provided module is not the current module
        (compiler.report(
            t.makeError(n, XMODULE_REQUIRE_ERROR, ns,
                providedModule.getName(),
                module.getName()
            ))
        )
    )
);


