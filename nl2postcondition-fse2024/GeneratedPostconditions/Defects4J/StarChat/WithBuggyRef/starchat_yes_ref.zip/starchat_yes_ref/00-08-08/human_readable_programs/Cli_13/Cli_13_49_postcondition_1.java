// Postcondition: If the method processValues terminates successfully, the list of option values in the command line will have been updated with the values from the list of arguments.
assert commandLine.getValues(option).containsAll(arguments.subList(0, argumentCount));


