// Check that the method returns true if all of the following conditions are met:
// - The method canCollapseUnannotatedChildNames returns true
// - There are no calls to the canCollapse method on any of the elements in the props list
assert (canCollapseUnannotatedChildNames() && props.stream().allMatch(Name::canCollapse)) ==> returnValue;


