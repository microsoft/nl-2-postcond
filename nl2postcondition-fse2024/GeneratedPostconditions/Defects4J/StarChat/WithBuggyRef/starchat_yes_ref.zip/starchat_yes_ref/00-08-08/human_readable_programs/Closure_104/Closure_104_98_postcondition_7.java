// Ensures that the return value is non-null and
// represents the least upper bound of the input types
assert (returnValue!= null && returnValue.isSubtype(this) && returnValue.isSubtype(that))
    : "Invalid return value for JSType#meet";


