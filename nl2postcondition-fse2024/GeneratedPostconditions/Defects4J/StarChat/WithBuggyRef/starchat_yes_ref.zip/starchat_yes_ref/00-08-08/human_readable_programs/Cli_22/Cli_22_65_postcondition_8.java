String[] input = {"-a", "--b", "c", "-d=e", "f", "g"};
String[] result = burstToken(input, false);
assert Arrays.equals(result, new String[] {"-a", "--", "b", "-d", "e", "--", "f", "g"});


