public static void main(String[] args) {
    //The first line in the method
    ArrayList<String> tokens = new ArrayList<>();
    //The second line in the method
    Options options = new Options();
    //The rest of the method
    //The method body, with the commented out code
}


