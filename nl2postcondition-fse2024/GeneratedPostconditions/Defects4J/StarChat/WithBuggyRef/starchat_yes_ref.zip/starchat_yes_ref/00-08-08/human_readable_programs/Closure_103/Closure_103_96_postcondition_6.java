public static boolean mayThrowException(Node n) {
    // TODO: Implement the symbolic postcondition
    assert returnValue;
    return true;
}


