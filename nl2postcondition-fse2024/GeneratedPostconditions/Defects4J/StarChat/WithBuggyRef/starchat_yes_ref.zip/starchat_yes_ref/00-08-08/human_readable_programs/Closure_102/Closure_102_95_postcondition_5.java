// The list of variable names in the root scope (excluding parameters)
List<String> rootScopeNames = new ArrayList<>();
for (String name : compiler.getRootScope().getVarNames()) {
    if (!name.startsWith("param")) {
        rootScopeNames.add(name);
    }
}

// The list of all variable names in the root scope and all nested scopes,
// sorted in alphabetical order
List<String> allScopeNames = new ArrayList<>();
for (String name : compiler.getAllScope().getVarNames()) {
    allScopeNames.add(name);
}
allScopeNames.sort(String::compareTo);

// For each variable in the root scope and all nested scopes, check that:
// (1) it is in either the root scope names or all scope names list, and
// (2) it appears in the correct scope in the AST
for (String name : rootScopeNames) {
    boolean foundInRootScope = false;
    boolean foundInAllScope = false;
    Node scopeRoot = root;
    while (!foundInRootScope ||!foundInAllScope) {
        if (scopeRoot.isScope() && scopeRoot.getString().equals(name)) {
            foundInRootScope = true;
            if (allScopeNames.contains(name)) {
                foundInAllScope = true;
            }
        } else if (foundInRootScope &&!foundInAllScope) {
            if (allScopeNames.contains(name)) {
                foundInAllScope = true;
            } else {
                break;
            }
        }
        if (scopeRoot.getParent()!= null) {
            scopeRoot = scopeRoot.getParent();
        } else {
            break;
        }
    }
    assert foundInRoot


