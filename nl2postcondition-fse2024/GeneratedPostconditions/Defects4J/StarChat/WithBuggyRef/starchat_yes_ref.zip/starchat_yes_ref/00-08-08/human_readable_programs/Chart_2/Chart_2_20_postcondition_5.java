assert (returnValue == null) || (returnValue.getLength() >= 0);


