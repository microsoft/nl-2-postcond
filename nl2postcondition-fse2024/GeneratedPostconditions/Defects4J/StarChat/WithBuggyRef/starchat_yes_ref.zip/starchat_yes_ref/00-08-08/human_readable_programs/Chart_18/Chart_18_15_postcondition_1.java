// Postcondition: Ensures that the list is sorted according to the natural order of the values
assert (new ArrayList<>(this.values)).equals(new TreeSet<>(this.values));


