import java.util.Arrays;
public final class DatasetUtilities {

//...

public static Range iterateDomainBounds(XYDataset dataset, boolean includeInterval) {
  double minimum = Double.POSITIVE_INFINITY;
  double maximum = Double.NEGATIVE_INFINITY;
  int seriesCount = dataset.getSeriesCount();
  double lvalue;
  double uvalue;
  if (includeInterval && dataset instanceof IntervalXYDataset) {
    IntervalXYDataset intervalXYData = (IntervalXYDataset) dataset;
    for (int series = 0; series < seriesCount; series++) {
      int itemCount = dataset.getItemCount(series);
      for (int item = 0; item < itemCount; item++) {
        lvalue = intervalXYData.getStartXValue(series, item);
        uvalue = intervalXYData.getEndXValue(series, item);
        if (!Double.isNaN(lvalue)) {
          minimum = Math.min(minimum, lvalue);
        }
        if (!Double.isNaN(uvalue)) {
          maximum = Math.max(maximum, uvalue);
        }
      }
    }
  } else {
    for (int series = 0; series < seriesCount; series++) {
      int itemCount = dataset.getItemCount(series);
      for (int item = 0; item < itemCount; item++) {
        lvalue = dataset.getXValue(series, item);
        uvalue = lvalue;
        if (!Double.isNaN(lvalue)) {
          minimum = Math.min(minimum, lvalue);
          maximum = Math.max(maximum, uvalue);
        }
      }
    }
  }
  if (minimum > maximum) {
    return null;
  } else {
    assert (minimum == Double.POSITIVE_INFINITY) || (minimum == Double.NEGATIVE_INFINITY) || (Arrays.binarySearch(new double[] {minimum, maximum}, 0, 2, Double.NaN) < 0) : "the minimum value must be finite and non-NaN";
    assert (maximum == Double.POSITIVE_INFINITY) || (maximum == Double.NEGATIVE_INFINITY) || (Arrays.binarySearch(new double[] {minimum, maximum}, 0, 2, Double.NaN) < 0) : "the maximum value must be finite and non-NaN";
    return new Range(minimum, maximum);
  }
}

//...

}


