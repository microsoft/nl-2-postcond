// This postcondition checks that the list of processed tokens
// is the same as the list of input tokens when the method
// is called with the same arguments.
assert tokens.equals(Arrays.asList(arguments));


