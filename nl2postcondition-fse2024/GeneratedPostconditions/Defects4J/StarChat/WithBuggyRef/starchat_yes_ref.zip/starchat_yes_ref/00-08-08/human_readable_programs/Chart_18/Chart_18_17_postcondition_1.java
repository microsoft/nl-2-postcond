// Ensures that the column with the given key is removed from the table
assert (columnKey!= null && this.columnKeys.contains(columnKey))
    || this.columnKeys.size() == getColumnCount()
    || throws (IllegalArgumentException e)
    || throws (UnknownKeyException e);


