// Postcondition: if the method call succeeds, the key is in the map.
assert (contains(key)) : "The key must be in the map";


