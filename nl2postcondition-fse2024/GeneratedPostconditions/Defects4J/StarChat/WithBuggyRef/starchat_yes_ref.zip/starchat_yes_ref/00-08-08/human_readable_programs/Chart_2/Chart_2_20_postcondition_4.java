// Symbolic postcondition for the iterateDomainBounds method
assert (returnValue == null) || (returnValue.getLength() >= 0);


