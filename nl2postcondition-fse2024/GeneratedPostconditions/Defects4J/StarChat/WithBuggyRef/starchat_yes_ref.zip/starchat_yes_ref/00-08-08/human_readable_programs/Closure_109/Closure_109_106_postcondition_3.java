// Check that the method returns a non-null value.
assert returnValue!= null;

// Check that the method returns a node of the correct type.
assert returnValue.getClass().equals(Node.class);


