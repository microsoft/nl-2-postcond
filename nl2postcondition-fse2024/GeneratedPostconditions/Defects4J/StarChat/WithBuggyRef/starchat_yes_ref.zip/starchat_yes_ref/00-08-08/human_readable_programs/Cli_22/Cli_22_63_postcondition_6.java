// Checks that the method adds "--" and the input value as two separate tokens
assert tokens.equals(new ArrayList<String>() {
    {
        add("--");
        add(value);
    }
});


