// Check that the output JavaScript program is valid and well-formed
assert (new NodeValidator(compiler).validate(outputJsRoot).isEmpty());


