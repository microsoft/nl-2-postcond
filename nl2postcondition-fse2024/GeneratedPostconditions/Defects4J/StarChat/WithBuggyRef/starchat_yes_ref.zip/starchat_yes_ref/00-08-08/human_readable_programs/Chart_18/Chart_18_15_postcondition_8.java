// ensures the postcondition of the removeValue method
// that the value at the given index is removed from the collection
assert (returnValue!= null && returnValue.equals(this.values.get(index)) &&
        this.keys.get(index).equals(key) && this.indexMap.get(key).equals(new Integer(index)));


