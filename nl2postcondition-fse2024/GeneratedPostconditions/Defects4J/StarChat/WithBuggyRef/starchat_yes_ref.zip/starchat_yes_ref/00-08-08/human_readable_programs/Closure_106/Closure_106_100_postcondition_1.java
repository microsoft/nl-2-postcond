assert (/*postcondition goes here*/) : "Explanation of why the postcondition holds";


