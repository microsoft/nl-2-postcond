// Check that the method returns true if and only if the subtree may throw an exception
assert (returnValue == true) == mayThrowException(n);


