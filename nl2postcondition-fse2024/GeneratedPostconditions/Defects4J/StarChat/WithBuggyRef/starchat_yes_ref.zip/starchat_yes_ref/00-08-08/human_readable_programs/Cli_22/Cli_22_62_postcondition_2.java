// This postcondition checks that the return value of flatten is sorted.
assert (Arrays.equals(returnValue, Arrays.sort(returnValue)));


