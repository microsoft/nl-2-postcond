// Postcondition:
    // assert returnValue!= null;
    assert postconditionHolds(returnValue, options, arguments, stopAtNonOption);


