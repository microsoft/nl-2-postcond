import java.util.List;
import java.util.ArrayList;

public int getDomainAxisIndex(CategoryAxis axis) {
    int returnValue = this.domainAxes.indexOf(axis);
    assert returnValue!= -1 : "If axis is not null, it must be assigned to the plot.";
    return returnValue;
}


