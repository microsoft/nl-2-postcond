import java.util.Objects;

class OptionBuilder {
    private static String description;
    private static String argName;
    private static String longopt;
    private static Class<?> type;
    private static boolean required;
    private static int numberOfArgs;
    private static boolean optionalArg;
    private static char valuesep;

    public static void setDescription(String description) {
        OptionBuilder.description = description;
    }

    public static void setArgName(String argName) {
        OptionBuilder.argName = argName;
    }

    public static void setLongopt(String longopt) {
        OptionBuilder.longopt = longopt;
    }

    public static void setType(Class<?> type) {
        OptionBuilder.type = type;
    }

    public static void setRequired(boolean required) {
        OptionBuilder.required = required;
    }

    public static void setNumberOfArgs(int numberOfArgs) {
        OptionBuilder.numberOfArgs = numberOfArgs;
    }

    public static void setOptionalArg(boolean optionalArg) {
        OptionBuilder.optionalArg = optionalArg;
    }

    public static void setValuesep(char valuesep) {
        OptionBuilder.valuesep = valuesep;
    }

    public static Option build() {
        assert description!= null : "The description cannot be null";
        assert argName!= null : "The argName cannot be null";
        assert longopt!= null : "


