// The input list is sorted according to the comparator
assert inputList.equals(inputList.stream().sorted(comparator).collect(Collectors.toList()));


