assert returnValue instanceof JSType
        : "The return value of visitGetProp should be of type JSType";


