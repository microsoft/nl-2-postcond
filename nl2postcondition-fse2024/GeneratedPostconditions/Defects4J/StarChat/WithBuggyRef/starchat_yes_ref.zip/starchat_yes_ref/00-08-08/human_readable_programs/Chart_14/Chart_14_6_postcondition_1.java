*
 * Comment explaining what aspect of the method the symbolic postcondition checks
 *
 * assert returnValue == expectedReturnValue : "This postcondition should hold true
 * if the method removeDomainMarker executes successfully, regardless of the actual
 * implementation of the method";


