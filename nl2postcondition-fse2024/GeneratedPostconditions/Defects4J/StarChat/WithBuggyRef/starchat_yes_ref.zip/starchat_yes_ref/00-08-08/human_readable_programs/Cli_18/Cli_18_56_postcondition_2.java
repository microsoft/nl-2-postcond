// The postcondition for the method processOptionToken checks that:
// 1. If an Option exists for token, then the currentOption variable is set to that Option.
// 2. If an Option does not exist and stopAtNonOption is set to true, then the remaining
//    tokens are added to the processed tokens list directly without any further processing.

assert (options.hasOption(token) && (currentOption == options.getOption(token))
     || (!options.hasOption(token) && stopAtNonOption))


