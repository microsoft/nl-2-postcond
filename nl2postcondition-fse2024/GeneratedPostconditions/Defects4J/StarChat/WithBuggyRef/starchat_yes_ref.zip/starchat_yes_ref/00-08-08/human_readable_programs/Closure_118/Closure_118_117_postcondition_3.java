// Postcondition: Ensures that the properties of an object literal are
// renamed, if necessary.
private void handleObjectLit(NodeTraversal t, Node n) {
  assert (new SymbolicPostcondition() {
    Set<String> renamedProperties = new HashSet<>();
    Set<String> properties = new HashSet<>();
    // Collect all of the properties in the object literal
    for (Node child : n.children()) {
      if (child.isMember()) {
        properties.add(child.getString());
      }
    }
    // Get the type of the object literal
    JSType type = typeRegistry.getType(n);
    // For each property in the object literal, check if it needs to be renamed
    for (String property : properties) {
      // Get the type of the property
      T actualType = type.findPropertyType(property);
      // Check if the property needs to be renamed
      if (!renamedProperties.contains(property) &&
         !property.equals(actualType.toString()) &&
         !propertiesToErrorFor.containsKey(property)) {
        // Add the property to the renamed properties set
        renamedProperties.add(property);
        // Rename the property
        processProperty(t, getProperty(property), actualType, null);
      }
    }
    return true;
  }).check(getCompiler());
}


