// Check if the method returns true if n is a CALL, GETPROP, GETELEM, THROW, NEW, ASSIGN, INC, or DEC node
assert (returnValue == true) == (n.getType() == Token.CALL || n.getType() == Token.GETPROP || n.getType() == Token.GETELEM || n.getType() == Token.THROW || n.getType() == Token.NEW || n.getType() == Token.ASSIGN || n.getType() == Token.INC || n.getType() == Token.DEC);


