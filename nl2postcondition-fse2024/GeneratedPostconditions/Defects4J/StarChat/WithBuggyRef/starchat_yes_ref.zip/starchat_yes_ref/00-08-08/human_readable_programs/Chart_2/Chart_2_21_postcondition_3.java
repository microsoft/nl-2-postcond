assert (returnValue == null || (returnValue.getLowerBound() <= returnValue.getUpperBound())) : "Return value is not null and lower bound is greater than upper bound";


