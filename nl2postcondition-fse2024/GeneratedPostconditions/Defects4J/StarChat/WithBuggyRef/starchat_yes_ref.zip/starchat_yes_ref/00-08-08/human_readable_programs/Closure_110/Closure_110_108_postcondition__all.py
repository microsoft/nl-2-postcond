
# Response 0
// The postcondition checks that for each alias variable in the scope, the alias is recorded in the
// transformation object and in the aliases map, and the alias variable's qualified name is added to the
// log transformation object.
assert transformation!= null;
assert aliases!= null;
assert forbiddenLocals!= null;
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        String alias = v.getName();
        assert transformation.getAliasNames().contains(alias);
        assert aliases.containsKey(alias);
        assert transformation.getAliasQualifiedNames().contains(v.getInitialValue().getQualifiedName());
    }
}



# Response 1
// The set of all variables declared in the current scope
Set<Var> allVars = t.getScope().getVarIterable();

// The set of all qualified names declared in the current scope
Set<String> allQualifiedNames = new HashSet<>();
for (Var v : allVars) {
  if (v.getNode().getParent().isQualifiedName()) {
    allQualifiedNames.add(v.getNode().getString());
  }
}

// For each variable in the scope, check that its qualified name is in the set of all qualified names
for (Var v : allVars) {
  if (v.getNode().getParent().isVar()) {
    String qualifiedName = v.getNode().getFirstChild().getQualifiedName();
    assert allQualifiedNames.contains(qualifiedName) : "The qualified name of a variable declared in the current scope must be in the set of all qualified names";
  }
}



# Response 2
// Check that the returned set contains only non-null values, i.e., that it is a set of potentially null values
assert!returnValue.contains(null);

// Check that the transformation object is not null
assert transformation!= null;

// For each Var in the scope, check that it represents an alias, i.e., that it is a reference to another variable
for (Var v : scope.getVarIterable()) {
    assert v.isAlias();
}

// For each Var in the scope, check that if it represents an alias, it is a unique alias, i.e., that no other Var in the scope aliases the same variable
Set<String> aliasNames = new HashSet<>();
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        String name = v.getName();
        assert!aliasNames.contains(name);
        aliasNames.add(name);
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not null
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        assert v.getInitialValue()!= null;
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not a property access or element access
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        assert!initialValue.isGetProp() &&!initialValue.isGetElem();
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is the value of another Var in the scope
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        for (Var otherVar : scope.getVarIterable()) {
            if (otherVar.isVar() && otherVar.getInitialValue() == initialValue) {
                break;
            }
        }
        assert otherVar.isVar();
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not re-assigned
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        for (Node assignment : NodeUtil.findLhsAssignments(initialValue)) {
            assert assignment!= initialValue;
        }
    }
}

// For each Var in the scope, check that if it represents an alias, its initial value is not used as a function or method call argument
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        Node initialValue = v.getInitialValue();
        for (Node use : Node



# Response 3
// The method sorts the input list in place.
void sort(List<Integer> list) {
    // INSERT YOUR SYMBOLIC POSTCONDITION HERE
}



# Response 4
// Ensures that all aliases in the current scope are valid and don't conflict with any other locals.
assert(forbiddenLocals.isEmpty() && aliases.keySet().containsAll(scopedAliasNames));



# Response 5
// Ensures that the returned map contains only variables that are aliases
assert Stream.of(returnValue.values().toArray())
   .allMatch(v -> v instanceof com.google.javascript.jscomp.Scope.Var &&
        ((com.google.javascript.jscomp.Scope.Var) v).isAlias());



# Response 6
// Postcondition: The set of forbidden local variables is the same as the set of
//                all non-local variables declared in the method.
assert forbiddenLocals.equals(scope.getOwnVarNames());



# Response 7
// Ensures that all aliased variables are declared in the same scope as the original variable
assert(forbiddenLocals.isEmpty());



# Response 8
// Ensures that the set of forbidden local variables in the scope of the findAliases method does not change
assert forbiddenLocals.equals(getForbiddenLocalsBeforeFindAliases(root));



# Response 9
private void findAliases(NodeTraversal t) {
    Scope scope = t.getScope();
    for (Var v : scope.getVarIterable()) {
        Node n = v.getNode();
        Node parent = n.getParent();
        boolean isVar = parent.isVar();
        if (isVar && n.getFirstChild()!= null && n.getFirstChild().isQualifiedName()) {
            recordAlias(v);
        } else if (v.isBleedingFunction()) {
        } else if (parent.getType() == Token.LP) {
        } else if (isVar) {
            Node grandparent = parent.getParent();
            Node value = n.hasChildren()?
                v.getInitialValue().detachFromParent() :
                null;
            Node varNode = parent;

            String name = n.getString();
            int nameCount = scopedAliasNames.count(name);
            scopedAliasNames.add(name);
            String globalName =
                "$jscomp.scope." + name + (nameCount == 0? "" : ("$" + nameCount));

            compiler.ensureLibraryInjected("base");
            if (value!= null || v.getJSDocInfo()!= null) {
                Node newDecl = NodeUtil.newQualifiedNameNodeDeclaration(
                    compiler.getCodingConvention(),
                    globalName,
                    value,
                    v.getJSDocInfo())
                   .useSourceInfoIfMissingFromForTree(n);
                NodeUtil.setDebugInformation(
                    newDecl.getFirstChild().getFirstChild(), n, name);

                grandparent.addChildBefore(newDecl, varNode);
            }
            v.getNameNode().addChildToFront(
                NodeUtil.newQualifiedNameNode(
                    compiler.getCodingConvention(), globalName, n, name));

            recordAlias(v);
        } else {
            report(t, n, GOOG_SCOPE_NON_ALIAS_LOCAL, n.getString());
        }
        assert(returnValue.getAliases().size()
                == scopedAliasNames.size());
        assert(returnValue.getForbiddenLocals().size()
                == forbiddenLocals.size());
    }
}

This code contains a natural language comment before findAliases that describes its behavior. The postcondition checks that the size of the output Aliases and ForbiddenLocals collections are equal.


