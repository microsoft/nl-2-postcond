assert (returnValue < this.rangeAxes.size() && returnValue >= -1) :
    "The return value must be -1 or a valid index in the range [0, " + (this.rangeAxes.size() - 1) + "].";


