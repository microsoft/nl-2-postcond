// Postcondition: Throws a MissingOptionException if any of the
// required options are missing.
assert (requiredOptions.isEmpty() ||!throw new MissingOptionException(buff.toString());


