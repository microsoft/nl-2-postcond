I have a hard time understanding. Can you provide more detail?


