public class CategoryPlot extends Plot implements ValueAxisPlot, Zoomable, RendererChangeListener, Cloneable, PublicCloneable, Serializable {
    public int getRangeAxisIndex(ValueAxis axis) {        int result = this.rangeAxes.indexOf(axis);        if (result < 0) {            Plot parent = getParent();            if (parent instanceof CategoryPlot) {                CategoryPlot p = (CategoryPlot) parent;                result = p.getRangeAxisIndex(axis);            }        }        return result;    }

/* 
The postcondition for getRangeAxisIndex in this Java class is:

    // Postcondition for getRangeAxisIndex:
    //   axis is a ValueAxis object assigned to this CategoryPlot object
    //   or is a parent of this CategoryPlot object
    //   or has not been assigned to this CategoryPlot object
    //   returns the index of the given axis in the rangeAxes list
    assert (axis!= null) ==> (this.rangeAxes.contains(axis) || this.getParent() instanceof CategoryPlot && ((CategoryPlot) this.getParent()).getRangeAxisIndex(axis)!= -1 ||!this.rangeAxes.contains(axis));

This postcondition checks three conditions:

- If axis is null, the method returns without doing anything further. This is because the method's behavior for null inputs is well-defined and does not require any additional conditions.
- If axis is not null, the method checks if it is in the rangeAxes list. If not, the method checks if the parent of this CategoryPlot object is a CategoryPlot object. If so, the method calls getRangeAxisIndex on the parent CategoryPlot object, with the same axis argument. This is because the parent plot may also be responsible for displaying the axis, so we need to check if the parent plot is responsible for the axis index. If the parent plot is not


