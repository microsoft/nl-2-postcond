// Ensures that the output list of tokens contains the "--" token and the input value
assert (new ArrayList<>(Arrays.asList(tokens)).equals(new ArrayList<>(Arrays.asList("--", value)) || new ArrayList<>(Arrays.asList(tokens)).equals(new ArrayList<>(Arrays.asList(value, "--"))));


