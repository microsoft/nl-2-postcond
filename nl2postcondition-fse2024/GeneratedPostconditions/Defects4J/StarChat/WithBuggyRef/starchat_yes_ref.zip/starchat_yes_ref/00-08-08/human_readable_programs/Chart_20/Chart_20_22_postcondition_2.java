import java.awt.Paint;
import java.awt.Stroke;

//postcondition: checks that the value is equal to the input value
assert value == inputValue;


