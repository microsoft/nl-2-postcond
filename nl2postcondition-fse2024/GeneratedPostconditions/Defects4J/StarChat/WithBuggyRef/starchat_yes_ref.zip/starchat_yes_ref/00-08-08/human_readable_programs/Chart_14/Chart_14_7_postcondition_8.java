assert (
// If the marker being removed is in the foreground layer for the given index, then the marker is not present in the list of foreground markers for that index
(layer == Layer.FOREGROUND &&!this.foregroundRangeMarkers.get(index).contains(marker))
// If the marker being removed is in the background layer for the given index, then the marker is not present in the list of background markers for that index
|| (layer == Layer.BACKGROUND &&!this.backgroundRangeMarkers.get(index).contains(marker))
// The marker is not present in the list of shared markers
||!this.sharedRangeMarkers.contains(marker)
// The layer argument is either foreground or background
|| layer!= Layer.FOREGROUND && layer!= Layer.BACKGROUND
// And the index is non-negative
&& index >= 0
) : "The preconditions of removeRangeMarker were not met: marker is not in the plot, layer is either foreground or background, and index is non-negative";


