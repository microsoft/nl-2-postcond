import java.util.List;
import org.apache.commons.cli.Option; // assume this import exists

public class HelpFormatter {

	private static final String defaultOptPrefix = "-";
	private static final String defaultLongOptPrefix = "--";
	private static final String defaultNewLine = System.lineSeparator();

	public void printWrapped(PrintWriter pw, int width, int nextLineTabStop, String text) {
		StringBuffer sb = new StringBuffer(text.length());

		renderWrappedText(sb, width, nextLineTabStop, text);
		pw.println(sb.toString());
	}

	protected StringBuffer renderOptions(StringBuffer sb, int width, Options options, int leftPad, int descPad) {
		final String lpad = createPadding(leftPad);
		final String dpad = createPadding(descPad);
		int max = 0;
		StringBuffer optBuf;
		List<Option> optList = options.helpOptions();

		// sort options by opt and then longOpt if they exist in order to get a consistent order in the help text
		// note: this may not be the order in which the options are recognized by the program, but it is
		// close enough for the purposes of the help text
		optList.sort(Comparator.comparing(Option::getOpt)
			.thenComparing(opt -> opt.hasLongOpt()? opt.getLongOpt() : ""));

		for (Option option : optList) {
			optBuf = new StringBuffer(8);

			if (option.getOpt() == null) {
				optBuf.append(lpad).append("   " + defaultLongOptPrefix).append(option.getLongOpt());
			} else {
				optBuf.append(lpad).append(defaultOptPrefix).append(option.getOpt());
				if (option.hasLongOpt()) {
					optBuf.append(',').append(defaultLongOptPrefix).append(option.getLongOpt());
				}
			}

			if (option.hasArg()) {
				if (option.hasArgName()) {
					optBuf.append(" <").append(option.getArgName()).append(">");
				} else {
					optBuf.append(' ');
				}
			}

			max = Math.max(max, optBuf.length());
			prefixList.add(optBuf);
		}

		int x = 0;

		for (Option option : optList) {
			optBuf = new StringBuffer(prefixList.get(x++).toString());

			if (optBuf.length() < max) {
				optBuf.append(createPadding(max - optBuf.length()));
			}

			optBuf.append(dpad);

			int nextLineTabStop = max + descPad;

			if (option.getDescription()!= null) {
				optBuf.append(option.getDescription());
			}

			renderWrappedText(sb, width, nextLineTabStop, optBuf.toString());

			if (i.hasNext()) {
				sb.append(defaultNewLine);
			}
		}

		return sb;
	}

	protected int findWrapPos(String text, int width, int startPos) {
		int pos = -1;
		if (((pos = text.indexOf('\n', startPos))!= -1 && pos <= width)
				|| ((pos = text.indexOf('\t', startPos))!= -1 && pos <= width)) {
			return pos + 1;
		} else if (startPos + width >= text.length()) {
			return -1;
		}
		pos = startPos + width;

		char c;

		while ((pos >= startPos) && ((c = text.charAt(pos))!='')
				&& (c!= '\n') && (c!= '\r')) {
			--pos;
		}
		if (pos > startPos) {
			return pos;
		}
		pos = startPos + width;

		while ((pos <= text.length()) && ((c = text.charAt(pos))!='')
				&& (c!= '\n') && (c!= '\r')) {
			++pos;
		}

		return (pos == text.length())? (-1) : pos;
	}

	protected String createPadding(int len) {
		StringBuffer sb = new StringBuffer(len);

		for (int i = 0; i < len; ++i) {
			sb.append(' ');
		}

		return sb.toString();
	}

	protected StringBuffer renderWrappedText(StringBuffer sb, int width, int nextLineTabStop, String text) {
		int


