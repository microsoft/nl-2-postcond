// Check that the list of domain markers for the specified layer is updated correctly
assert getDomainMarkers(layer).contains(marker) ==!removed;


