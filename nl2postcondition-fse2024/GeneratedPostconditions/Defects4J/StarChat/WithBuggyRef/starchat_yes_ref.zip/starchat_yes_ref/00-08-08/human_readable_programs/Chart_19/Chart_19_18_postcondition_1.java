// Postcondition: assert that the method returns the correct index when the axis is assigned to the plot
assert(returnValue >= 0 && returnValue < this.domainAxes.size());


