public class PosixParser {

/**
 * A symbolic postcondition for the method flatten that checks that the list
 * returned is in sorted order.
 */
public void flatten_postcondition_checks_sorted_order(Options options, String[] arguments, boolean stopAtNonOption) {
    String[] returnValue = flatten(options, arguments, stopAtNonOption);
    assert isSorted(returnValue) : "The list returned is not in sorted order";
}

private boolean isSorted(String[] list) {
  // TODO: Implement an efficient sorting algorithm and check that the list is sorted.
  return true;
}

}


