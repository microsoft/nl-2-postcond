// Postcondition for canInlineReferenceDirectly: checks that the function
// body is a single return statement that returns a single expression
// that is a reference to the function object.
assert (returnValue == NodeUtil.getFunctionObject(fnNode)) :
    "For the function call " + callNode.toStringTree() + ", the " +
    "inlined function body " + block.toStringTree() + " must consist of a " +
    "single return statement that returns a reference to the function object.";


