//The sorted list is the same size as the input list
assert input.size() == sorted.size();

//All elements in the sorted list are less than those in the input list
for (int i = 1; i < sorted.size(); i++) {
    assert sorted.get(i - 1) < sorted.get(i);
}


