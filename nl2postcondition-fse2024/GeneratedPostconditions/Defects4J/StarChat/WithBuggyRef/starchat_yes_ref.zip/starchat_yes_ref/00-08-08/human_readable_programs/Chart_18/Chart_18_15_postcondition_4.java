// Ensures that when removeValue is executed, the list remains sorted in ascending order
// by the value of the removed element
assert isSorted(keys) : "After removing a value, the list is no longer sorted";


