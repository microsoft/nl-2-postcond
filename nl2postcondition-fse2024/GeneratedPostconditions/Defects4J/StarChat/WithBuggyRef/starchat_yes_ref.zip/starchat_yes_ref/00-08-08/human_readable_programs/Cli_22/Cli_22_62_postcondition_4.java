// Postcondition: Sorting the return value should be equivalent to sorting the input list
assert Arrays.equals(returnValue, returnValue.clone());
Arrays.sort(returnValue);


