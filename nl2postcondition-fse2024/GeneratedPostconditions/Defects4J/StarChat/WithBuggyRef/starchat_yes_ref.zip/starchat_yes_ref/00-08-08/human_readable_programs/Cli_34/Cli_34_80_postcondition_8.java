import java.util.Objects;

public final class OptionBuilder {
    private String description;
    private String argName;
    private String longopt;
    private Class<?> type;
    private boolean required;
    private int numberOfArgs = Option.UNINITIALIZED;
    private boolean optionalArg;
    private char valuesep;

    void setDescription(String description) {
        this.description = description;
    }

    void setArgName(String argName) {
        this.argName = argName;
    }

    void setLongOpt(String longopt) {
        this.longopt = longopt;
    }

    void setType(Class<?> type) {
        this.type = type;
    }

    void setRequired(boolean required) {
        this.required = required;
    }

    void setNumberOfArgs(int numberOfArgs) {
        this.numberOfArgs = numberOfArgs;
    }

    void setOptionalArg(boolean optionalArg) {
        this.optionalArg = optionalArg;
    }

    void setValuesep(char valuesep) {
        this.valuesep = valuesep;
    }

    String getDescription() {
        return description;
    }

    String getArgName() {
        return argName;
    }

    String getLongOpt() {
        return longopt;
    }

    Class<?> getType() {
        return type;
    }

    boolean isRequired() {
        return required;
    }

    int getNumberOfArgs()


