// Check that the list of tokens after bursting is in the same order as the original list of tokens
assert (Arrays.equals(tokens.toArray(new String[tokens.size()]), returnValue));


