private void processOptionToken(String token, boolean stopAtNonOption) {
    if (options.hasOption(token)) {
        currentOption = options.getOption(token);
        tokens.add(token);
        // Postcondition: The current option has been set to the option associated with token
    } else if (stopAtNonOption) {
        eatTheRest = true;
        // Postcondition: eatTheRest is set to true if stopAtNonOption is true
    }
}


