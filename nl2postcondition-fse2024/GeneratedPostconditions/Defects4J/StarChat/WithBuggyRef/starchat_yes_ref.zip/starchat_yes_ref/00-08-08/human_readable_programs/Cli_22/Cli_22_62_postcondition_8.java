// Postcondition: the flattened array contains at most one instance of each option
assert (Set.of(returnValue).size() == returnValue.length);


