public class ValueMarker extends Marker {
  // Method you are writing a postcondition for:
  /**
   * Creates a new value marker.
   * 
   * @param value the value.
   * @param paint the paint (null not permitted).
   * @param stroke the stroke (null not permitted).
   * @param outlinePaint the outline paint (null permitted).
   * @param outlineStroke the outline stroke (null permitted).
   * @param alpha the alpha transparency (in the range 0.0f to 1.0f).
   */
  public ValueMarker(double value, Paint paint, Stroke stroke, Paint outlinePaint, Stroke outlineStroke, float alpha) {
    super(paint, stroke, paint, stroke, alpha);
    this.value = value;
  }
  // Comment explaining what aspect of the method the symbolic postcondition checks
  // Postcondition: assert(this.paint == paint);
  // Imports: None
  // No method calls allowed
}


