// Check that the index returned is valid (i.e., in the range [0, getRangeAxisCount() - 1])
    assert (0 <= returnValue && returnValue < getRangeAxisCount()) : "Invalid range axis index: " + returnValue;


