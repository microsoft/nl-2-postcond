// The return value of processRequireCall is that the Node given by n and the
// Node given by arg are detached from their parents and added to the symbol
// table, if they aren't already there. Additionally, if the namespace in arg
// is provided, the module containing the provided namespace is added to the
// dependency graph of the current module.

assert (
    (n.getNext() == arg && n.hasParent() && arg.hasParent()) ||
    (n.getNext() == arg &&!n.hasParent() &&!arg.hasParent()) ||
    (!n.getNext().hasParent() && n.hasParent()) ||
    (!arg.hasParent() && n.hasParent()));


