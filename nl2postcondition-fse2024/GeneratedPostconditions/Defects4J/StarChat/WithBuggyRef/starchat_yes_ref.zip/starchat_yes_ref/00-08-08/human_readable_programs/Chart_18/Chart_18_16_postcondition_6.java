// Ensures that the correct value is removed from the collection
assert (this.keys.get(index).equals(key)) && (this.values.get(index).equals(returnValue)) :
"Value was not removed from the collection. Keys: " + this.keys.toString() +
"Values: " + this.values.toString() + ". Attempted to remove key: " + key;


