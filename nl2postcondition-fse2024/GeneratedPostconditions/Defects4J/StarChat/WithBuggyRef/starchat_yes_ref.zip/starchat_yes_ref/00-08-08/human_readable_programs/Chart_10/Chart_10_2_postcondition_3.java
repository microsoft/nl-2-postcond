// The postcondition checks that the title attribute that is generated has
// the correct value.
assert returnValue.contains("title=\"" + toolTipText + "\" alt=\"\"");


