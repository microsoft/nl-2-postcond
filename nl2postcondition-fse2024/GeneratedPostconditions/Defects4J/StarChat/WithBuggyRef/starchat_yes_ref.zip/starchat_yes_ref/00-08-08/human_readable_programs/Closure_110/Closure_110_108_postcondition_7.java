// Ensures that all aliased variables are declared in the same scope as the original variable
assert(forbiddenLocals.isEmpty());


