import java.util.*;

public TimeSeries createCopy(RegularTimePeriod start, RegularTimePeriod end) throws CloneNotSupportedException {
    // The postcondition should hold true when the method is implemented correctly
    assert this.equals(new TimeSeries(start, end));
    // The return value should be a copy of the current object
    TimeSeries copy = (TimeSeries) super.clone();
    // The data attribute should be a deep copy of the current object's data attribute
    copy.data = (ArrayList<TimeSeriesDataItem>) ObjectUtilities.deepClone(this.data);
    return copy;
}


