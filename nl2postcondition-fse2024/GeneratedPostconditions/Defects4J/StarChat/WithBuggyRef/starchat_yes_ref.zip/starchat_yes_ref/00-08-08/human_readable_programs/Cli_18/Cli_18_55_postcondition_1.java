// Ensures that when flatten is called with its boolean parameter set to true, the output contains no non-options
assert new HashSet(Arrays.asList(flatten(options, arguments, true))).equals(new HashSet(Arrays.asList(arguments)));


