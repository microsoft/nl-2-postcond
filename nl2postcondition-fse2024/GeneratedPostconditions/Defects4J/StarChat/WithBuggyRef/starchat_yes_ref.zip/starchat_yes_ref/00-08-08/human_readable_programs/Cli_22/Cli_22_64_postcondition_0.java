// The token is a valid option token if:
// - It is a valid option id
// - Or stopAtNonOption is true and it is not a valid option id

assert (options.hasOption(token) || (stopAtNonOption &&!options.hasOption(token)));


