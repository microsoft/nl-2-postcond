// Check that the elements in the returned array are in the order they appear in the input array
String[] flattened = flatten(options, input, stopAtNonOption);
for (int i = 1; i < flattened.length; i++) {
    assert flattened[i - 1].compareTo(flattened[i]) <= 0;
}


