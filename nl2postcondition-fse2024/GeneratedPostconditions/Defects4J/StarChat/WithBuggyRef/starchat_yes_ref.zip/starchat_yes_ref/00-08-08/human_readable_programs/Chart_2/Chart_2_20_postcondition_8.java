// Check that the return value is null if the input dataset is empty
assert(returnValue == null) || (dataset.getItemCount() > 0);


