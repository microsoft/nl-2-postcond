assert (Node callNode, Node fnNode) -> {
    // Check that the function body contains only a single return statement
    Node block = NodeUtil.getFunctionBody(fnNode);
    if (block.hasChildren() && block.hasOneChild()) {
        Node singleReturn = block.getFirstChild();
        if (!singleReturn.isReturn()) {
            return false;
        }
    } else {
        return false;
    }
    
    // Check that each argument of the call site is passed to the function
    Node callArg = callNode.getFirstChild().getNext();
    Node fnParam = NodeUtil.getFunctionParameters(fnNode).getFirstChild();
    while (callArg!= null || fnParam!= null) {
        if (fnParam == null) {
            return false;
        }
        if (callArg!= null) {
            fnParam = fnParam.getNext();
            callArg = callArg.getNext();
        }
    }
    
    // Check that the function does not have any side effects
    return!NodeUtil.mayHaveSideEffects(fnNode, compiler);
};


