import java.util.Objects;

public class JSDocInfoBuilder {
    private JSDocInfo currentInfo;
    
    public boolean recordBlockDescription(String description) {
        Objects.requireNonNull(description, "description is null");
        
        if (parseDocumentation) {
            populated = true;
        }
        
        boolean result = currentInfo.documentBlock(description);
        assert result : "Description was not recorded";
        
        return result;
    }
}


