import java.util.regex.Pattern;
import static org.junit.Assert.assertNull;

...

// Postcondition: reset() should reset all member variables to their default values.
assertPattern: Pattern.compile("(?s).*").matcher(
    new StringBuilder().append("//Method you are writing a postcondition for:\n")
   .append("/**\n")
   .append(" * Resets the member variables to their default values.\n")
   .append(" */\n")
   .append("private static void reset() {\n")
   .append("    description = null;\n")
   .append("    argName = null;\n")
   .append("    longopt = null;\n")
   .append("    type = null;\n")
   .append("    required = false;\n")
   .append("    numberOfArgs = Option.UNINITIALIZED;\n")
   .append("    optionalArg = false;\n")
   .append("    valuesep = (char) 0;\n")
   .append("}\n")
   .toString()).find();


