import java.util.ArrayList;

public class MyXYPlot extends XYPlot {
    public boolean removeDomainMarker(Marker marker) {
        ArrayList<Marker> markers = this.getForegroundDomainMarkers();
        boolean removed = markers.remove(marker);
        assert (removed == true) : "When removeDomainMarker is called, the marker should be removed if it exists in the plot.";
        return removed;
    }
}


