// Check that the item added is not null
assert item!= null;
// Check that the row key added is not null
assert rowKey!= null;
// Check that the column key added is not null
assert columnKey!= null;
// Check that the row key added is not already in the dataset
assert!this.data.getRowKeys().contains(rowKey);
// Check that the column key added is not already in the dataset
assert!this.data.getColumnKeys().contains(columnKey);
// Check that the item added is added to the dataset correctly
assert item.equals(this.data.getObject(rowKey, columnKey));


