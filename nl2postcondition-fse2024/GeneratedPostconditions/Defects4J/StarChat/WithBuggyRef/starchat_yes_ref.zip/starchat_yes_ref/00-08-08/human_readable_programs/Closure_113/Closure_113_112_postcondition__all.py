
# Response 0
assert returnValue!= null; // required by Javadoc
if (left.getNext()!= arg) { // required by Javadoc
    assert false;
}



# Response 1
assert (
  (
    // Check that the method call has the expected number of arguments
    (parent.isCall() && n.hasXChildren(2)) ||
    // Or that it has the expected structure if it's a property assignment
    ((parent.isAssign() || parent.isName()) && n.hasXChildren(3))
  ) &&
  // Check that the method name is'require'
  n.getFirstChild().isGetProp() &&
  n.getFirstChild().getFirstChild().isName() &&
  "require".equals(n.getFirstChild().getFirstChild().getString()) &&
  // Check that the argument is a string literal
  n.getFirstChild().getNext().isString() &&
  // Check that the namespace argument is provided and recognized
  providedNames.containsKey(n.getFirstChild().getNext().getString())
);



# Response 2
// The return value of processRequireCall is that the Node given by n and the
// Node given by arg are detached from their parents and added to the symbol
// table, if they aren't already there. Additionally, if the namespace in arg
// is provided, the module containing the provided namespace is added to the
// dependency graph of the current module.

assert (
    (n.getNext() == arg && n.hasParent() && arg.hasParent()) ||
    (n.getNext() == arg &&!n.hasParent() &&!arg.hasParent()) ||
    (!n.getNext().hasParent() && n.hasParent()) ||
    (!arg.hasParent() && n.hasParent()));



# Response 3
assert (function (n, parent) {
    // Check that the parent node is a CALL node
    return parent.isCall();
})(parent, n)
    // Check that the left-hand side of the CALL node is a GETPROP node
    && (function (left) {
        return left.isGetProp();
    })(left)
    // Check that the first child of the GETPROP node is a NAME node with the value "goog"
    && (function (name) {
        return name.isName() && "goog".equals(name.getString());
    })(left.getFirstChild())
    // Check that the second child of the GETPROP node is a NAME node with the value "require"
    && (function (methodName) {
        return methodName.isName() && "require".equals(methodName.getString());
    })(left.getNext())
    // Check that the third child of the GETPROP node is a STRING node containing the required namespace
    && (function (arg) {
        return arg.isString() && ns.equals(arg.getString());
    })(left.getNext().getNext())
    // Check that the method call does not occur within a conditional block
    &&!this.inConsequentOf(n)
    // Check that the method call does not occur within a loop
    &&!this.inLoop(n)
    // Check that the method call does not occur within a switch statement case block
    &&!this.inSwitchCaseBlock(n)
    // Check that the method call does not occur within a try block catch block
    &&!this.inCatchBlock(n);



# Response 4
assert (provided!= null) && provided.isExplicitlyProvided()
      && (moduleGraph == null || moduleGraph.dependsOn(t.getModule(), provided.explicitModule))
      : "Invalid require in " + t.getSourceName() + ": module " + provided.explicitModule + " must be explicitly provided";



# Response 5
assert (
    // Ensure that a goog.require call is made for an explicitly provided namespace
    (left.isGetProp() && left.getLastChild().getString().equals("require")) &&
    (arg.isString() && providedNames.containsKey(arg.getString()) && providedNames.get(arg.getString()).isExplicitlyProvided()) &&
    // Ensure that the provided namespace is defined in the current module or a dependency
    (t.getModule().getDependencies().contains(providedNames.get(arg.getString()).explicitModule) || (moduleGraph!= null && moduleGraph.dependsOn(t.getModule(), providedNames.get(arg.getString()).explicitModule)))
);



# Response 6
assert (
    (
        (
            // If the provided namespace is not already present in the map,
            // add the namespace and set isExplicitlyProvided to true
            (providedNames.get(ns) == null) &&
            (returnValue!= null)
        ) || (
            // Otherwise, if the provided namespace is already present in the map,
            // leave the map unchanged and set isExplicitlyProvided to the
            // existing value
            (providedNames.get(ns)!= null) &&
            (returnValue!= providedNames.get(ns))
        )
    ) && (
        // Check that the moduleGraph is not null
        (moduleGraph!= null) &&
        // Check that the provided module is not the current module
        (!moduleGraph.dependsOn(module, providedModule)) &&
        // Report an error if the provided module is not the current module
        (compiler.report(
            t.makeError(n, XMODULE_REQUIRE_ERROR, ns,
                providedModule.getName(),
                module.getName()
            ))
        )
    )
);



# Response 7
// check that the argument to processRequireCall is a string literal
assert arg instanceof String;

// check that the element in the input parameter "providedNames" associated with the key "ns"
// is non-null and has a non-null value for "explicitModule"
assert providedNames.get(ns)!= null && providedNames.get(ns).explicitModule!= null;

// check that the call to t.getModule() does not return null
JSModule module = t.getModule();
assert module!= null;

// check that the call to "dependsOn" on the module graph between the module passed to t.getModule()
// and the module associated with the given namespace "ns" in the input parameter "providedNames"
// does not return false
if (moduleGraph!= null) {
  assert moduleGraph.dependsOn(module, providedNames.get(ns).explicitModule);
}

// check that the call to "report" does not throw an exception
try {
  compiler.report(errorNode, message,...);
} catch (Exception e) {
  assert false;
}

// check that the call to "maybeAddToSymbolTable" with the given qualified name node "left" does not throw an exception
try {
  maybeAddToSymbolTable(left);
} catch (Exception e) {
  assert false;
}

// check that the call to "maybeAddStringNodeToSymbolTable" with the given string literal node "arg" does not throw an exception
try {
  maybeAddStringNodeToSymbolTable(arg);
} catch (Exception e) {
  assert false;
}



# Response 8
//Check that require statements are added to the providedNames map
assert(providedNames.containsKey(ns) && providedNames.get(ns).isExplicitlyProvided());

//Check that the moduleGraph contains a dependency edge between the current module and the module associated with the provided namespace
JSModule providedModule = providedNames.get(ns).explicitModule;
assert(moduleGraph == null || moduleGraph.dependsOn(t.getModule(), providedModule));

//Check that the provided namespace has not already been added to the unrecognizedRequires list
assert(!unrecognizedRequires.contains(new UnrecognizedRequire(n, ns, t.getSourceName())));



# Response 9
assert sort(unrecognizedRequires).equals(
    unrecognizedRequires) : "Unrecognized requires do not change order";


