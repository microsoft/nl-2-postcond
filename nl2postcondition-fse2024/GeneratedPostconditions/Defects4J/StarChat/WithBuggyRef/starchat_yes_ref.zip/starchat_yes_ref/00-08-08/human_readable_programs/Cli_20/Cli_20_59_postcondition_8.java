assert (new HashSet<String>(Arrays.asList(flatten(options, arguments, false))))
   .equals(new HashSet<String>(Arrays.asList(arguments)));


