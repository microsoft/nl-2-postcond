// Check that the specified axis is assigned to the plot and return its index
int result = this.rangeAxes.indexOf(axis);
assert result >= 0 : "The specified axis is not assigned to the plot";


