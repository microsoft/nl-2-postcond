// Check that the postcondition holds true after reset
assert description == null : "Expected description to be null after reset";
assert argName == null : "Expected argName to be null after reset";
assert longopt == null : "Expected longopt to be null after reset";
assert type == null : "Expected type to be null after reset";
assert!required : "Expected required to be false after reset";
assert numberOfArgs == Option.UNINITIALIZED : "Expected numberOfArgs to be " + Option.UNINITIALIZED + " after reset";
assert!optionalArg : "Expected optionalArg to be false after reset";
assert valuesep == (char) 0 : "Expected valuesep to be (char) 0 after reset";


