Here is my symbolic postcondition for the flatten method:

// Check that the returned array contains only strings
assert (returnValue!= null && returnValue.length > 0) && (returnValue[0] instanceof String);

// Check that every element in the returned array is a string
for (String s : returnValue) {
    assert s instanceof String;
}

// Check that the returned array does not contain empty strings
for (String s : returnValue) {
    assert!s.isEmpty();
}

// Check that the returned array does not contain two consecutive hyphens
for (int i = 0; i < returnValue.length - 1; i++) {
    assert!(returnValue[i].equals("--"));
}

// Check that the returned array contains the same number of elements as the input array
assert returnValue.length == arguments.length;


