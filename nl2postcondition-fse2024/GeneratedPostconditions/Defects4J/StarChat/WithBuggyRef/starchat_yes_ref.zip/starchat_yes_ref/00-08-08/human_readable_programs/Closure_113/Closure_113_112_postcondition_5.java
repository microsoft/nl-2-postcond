assert (
    // Ensure that a goog.require call is made for an explicitly provided namespace
    (left.isGetProp() && left.getLastChild().getString().equals("require")) &&
    (arg.isString() && providedNames.containsKey(arg.getString()) && providedNames.get(arg.getString()).isExplicitlyProvided()) &&
    // Ensure that the provided namespace is defined in the current module or a dependency
    (t.getModule().getDependencies().contains(providedNames.get(arg.getString()).explicitModule) || (moduleGraph!= null && moduleGraph.dependsOn(t.getModule(), providedNames.get(arg.getString()).explicitModule)))
);


