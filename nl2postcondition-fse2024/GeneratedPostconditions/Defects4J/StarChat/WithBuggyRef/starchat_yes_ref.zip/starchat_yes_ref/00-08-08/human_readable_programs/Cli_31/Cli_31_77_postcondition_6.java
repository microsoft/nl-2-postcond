// Postcondition: Resets the member variables to their default values
assert (
    // If description is not null, then it contains the default value
    (description == null)? (description == null) : (description.equals(DEFAULT_DESCRIPTION))
    // If argName is not null, then it contains the default value
    && (argName == null)? (argName == null) : (argName.equals(DEFAULT_ARG_NAME))
    // If longopt is not null, then it contains the default value
    && (longopt == null)? (longopt == null) : (longopt.equals(DEFAULT_LONGOPT))
    // If type is not null, then it contains the default value
    && (type == null)? (type == null) : (type.equals(DEFAULT_TYPE))
    // If required is not true, then it is false
    && (required == true)
    // If numberOfArgs is not UNINITIALIZED, then it is 1
    && (numberOfArgs == UNINITIALIZED)
    // If optionalArg is not false, then it is true
    && (optionalArg == false)
    // If valuesep is not 0, then it is''
    && (valuesep == 0)
) : "Postcondition failed: reset() did not reset all member


