assert (new TimeSeries(null, null)).equals(returnValue) || // Check that returnValue is null if both input parameters are null
    (new TimeSeries(start, end)).equals(returnValue) || // Check that the elements copied from the original series are equal to the elements in the returned series
    (new TimeSeries(start, end)).size() == ((new TimeSeries(null, null)).size() - 1) || // Check that the size of the returned series is 1 less than the size of the original series if the start and end parameters are not equal
    (new TimeSeries(start, end)).size() == ((new TimeSeries(null, null)).size()) || // Check that the size of the returned series is the same as the size of the original series if the start and end parameters are equal
    (new TimeSeries(start, end)).getDomainLowerBound() == ((new TimeSeries(null, null)).getDomainLowerBound()) || // Check that the domain lower bound of the returned series is the same as the domain lower bound of the original series if the start and end parameters are equal
    (new TimeSeries(start, end)).getDomainLowerBound() == ((new TimeSeries(null, null)).getDomainLowerBound() + 1) || // Check that the domain lower bound of the returned series is 1 greater than the domain lower bound of the original series if the start and end parameters are not equal
    (new TimeSeries(start, end)).getDomainUpperBound() == ((new TimeSeries(null, null)).getDomainUpperBound()) || // Check that the domain upper bound of the returned series is the same as the domain upper bound of the original series if the start and end parameters are equal
    (new TimeSeries(start, end)).getDomainUpperBound() == ((new TimeSeries(null, null)).getDomainUpperBound() - 1) // Check that the domain upper bound of the returned series is 1 less than the domain upper bound of the original series if the start and end parameters are not equal


