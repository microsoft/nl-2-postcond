assert returnValue.isSubtype(this) && returnValue.isSubtype(that)
    : "The return value of meet() must be a subtype of both this type and the given type";


