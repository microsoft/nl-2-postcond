// Check that the return value is in the range 0 to getDomainAxisCount() - 1
assert(0 <= returnValue && returnValue < getDomainAxisCount());


