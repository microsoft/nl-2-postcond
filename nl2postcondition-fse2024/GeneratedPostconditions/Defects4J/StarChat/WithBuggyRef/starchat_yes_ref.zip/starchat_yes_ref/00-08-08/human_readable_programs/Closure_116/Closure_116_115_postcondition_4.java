// Postcondition: Checks that the inlining is possible when the inlining mode is InliningMode.DIRECT.
    assert canInlineReferenceDirectly(callNode, fnNode) == CanInlineResult.YES :
        "The inlining is only possible when the inlining mode is InliningMode.DIRECT.";


