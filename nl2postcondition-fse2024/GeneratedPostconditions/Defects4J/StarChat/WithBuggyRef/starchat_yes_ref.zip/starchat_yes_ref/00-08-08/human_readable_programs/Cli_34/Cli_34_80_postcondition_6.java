import java.util.*;

public class OptionBuilder {

    private static String description;
    private static String argName;
    private static String longopt;
    private static Class<?> type;
    private static boolean required;
    private static int numberOfArgs;
    private static boolean optionalArg;
    private static char valuesep;

    //Relevant Class Context:
    /**
     * Resets the member variables to their default values.
     */
    private static void reset() {
        description = null;
        argName = null;
        longopt = null;
        type = null;
        required = false;
        numberOfArgs = Option.UNINITIALIZED;
        optionalArg = false;
        valuesep = (char) 0;
    }

    public static Option create() {
        reset();
        return new Option(description, argName, longopt, type, required, numberOfArgs, optionalArg, valuesep);
    }

    public static OptionBuilder withDescription(String description) {
        OptionBuilder.description = description;
        return this;
    }

    public static OptionBuilder withArgName(String argName) {
        OptionBuilder.argName = argName;
        return this;
    }

    public static OptionBuilder withLongOpt(String longopt) {
        OptionBuilder.longopt = longopt;
        return this;
    }

    public static OptionBuilder withType(Class<?> type) {
        OptionBuilder.type = type;
        return this;
    }

    public static OptionBuilder isRequired() {
        Option


