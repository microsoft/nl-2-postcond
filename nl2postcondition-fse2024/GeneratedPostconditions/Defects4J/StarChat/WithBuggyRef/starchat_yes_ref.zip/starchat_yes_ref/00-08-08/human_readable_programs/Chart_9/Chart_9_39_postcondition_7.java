assert (start!= null) && (end!= null) -> {
  TimeSeries copy = (TimeSeries) super.clone();
  copy.data = new ArrayList<>();
  boolean emptyRange = false;
  int startIndex = getIndex(start);
  if (startIndex < 0) {
    startIndex = -(startIndex + 1);
    if (startIndex == this.data.size()) {
      emptyRange = true;
    }
  }
  int endIndex = getIndex(end);
  if (endIndex < 0) {
    endIndex = -(endIndex + 1);
    endIndex = endIndex - 1;
  }
  if (endIndex < 0) {
    emptyRange = true;
  }
  if (!emptyRange) {
    for (int i = startIndex; i <= endIndex; i++) {
      TimeSeriesDataItem item = (TimeSeriesDataItem) this.data.get(i);
      TimeSeriesDataItem clone = (TimeSeriesDataItem) item.clone();
      try {
        copy.add(clone);
      } catch (SeriesException e) {
        e.printStackTrace();
      }
    }
  }
  return copy;
};


