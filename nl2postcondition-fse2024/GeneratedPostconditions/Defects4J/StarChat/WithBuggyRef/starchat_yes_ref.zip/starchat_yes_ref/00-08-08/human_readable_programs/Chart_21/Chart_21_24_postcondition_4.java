// Postcondition: updateBounds's postcondition checks that:
// 1. The cached maximumRangeValue and minimumRangeValue fields maintain their
//    original values (or have never been set) if the input item's max or min
//    outlier is null, respectively.
// 2. The cached maximumRangeValue and minimumRangeValue fields are updated
//    correctly if the input item's max or min outlier is non-null and the
//    corresponding field is not already updated to a greater or lesser value.
//
// Note: This postcondition assumes that the input item is not null.
public void updateBounds(BoxAndWhiskerItem item) {
    // Precondition: The input item must not be null.
    assert item!= null;

    // Hypothetical return value: We assume that the method updates the bounds
    // based on the input item and stores the result in these fields.
    double maxVal = Double.NaN;
    double minVal = Double.NaN;

    // Check if the input item's max outlier is non-null and greater than the
    // current cached maximum value.
    if (item.getMaxOutlier()!= null
        && (Double.isNaN(maxVal) || item.getMaxOutlier() > maxVal)) {
        maxVal = item.getMaxOutlier();
    }

    // Check if the input item's min outlier is non-null and less than the
    // current cached minimum value.
    if (item.getMinOutlier()!= null
        && (Double.isNaN(minVal) || item.getMinOutlier() < minVal)) {
        minVal = item.getMinOutlier();
    }

    // Check if the input item's max outlier is null and the cached maximum
    // value needs to be updated.
    if (Double.isNaN(maxVal) &&!Double.isNaN(this.maximumRangeValue)) {
        maxVal = this.maximumRangeValue;
    }

    // Check if the input item's min outlier is null and the cached minimum
    // value needs to be updated.
    if (Double.isNaN(minVal) &&!Double.isNaN(this.minimumRangeValue)) {
        minVal = this.minimumRangeValue;
    }

    // Update the cached maximum and minimum values if necessary.
    if (!Double.isNaN(maxVal)) {
        this.maximumRangeValue = maxVal;
    }
    if (!Double.isNaN(minVal)) {
        this.minimumRangeValue = minVal;
    }
}


