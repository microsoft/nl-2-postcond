// Postcondition: Resets the member variables to their default values and returns the default value for the method.
assert reset() == new OptionBuilder();


