// Postcondition: the currentOption member variable is set to the Option associated with token if it exists, and otherwise remains unchanged
assert (
    (options.hasOption(token) && (currentOption == options.getOption(token)))
    || (!options.hasOption(token) && (currentOption == null))
);


