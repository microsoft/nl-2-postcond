I'm sorry, but I do not understand what you mean by "symbolic postcondition." Could you please clarify?


