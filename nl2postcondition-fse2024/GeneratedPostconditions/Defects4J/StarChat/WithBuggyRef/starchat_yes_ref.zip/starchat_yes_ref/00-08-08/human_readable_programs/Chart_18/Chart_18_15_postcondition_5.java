public class DefaultKeyedValues implements KeyedValues, Cloneable, PublicCloneable, Serializable {
    private List keys;
    private List values;
    private Map indexMap;
    
    public DefaultKeyedValues() {
        this.keys = new ArrayList();
        this.values = new ArrayList();
        this.indexMap = new HashMap();
    }
    
    public int getIndex(final Object key) {
        final Integer index = (Integer) this.indexMap.get(key);
        if (index == null) {
            return -1;
        }
        return index.intValue();
    }
    
    public void addValue(final Object key, final Object value) {
        final int index = getIndex(key);
        if (index >= 0) {
            this.values.set(index, value);
        }
        else {
            this.keys.add(key);
            this.values.add(value);
            this.indexMap.put(key, new Integer(this.keys.size() - 1));
        }
    }
    
    public Object getValue(final Object key) {
        final int index = getIndex(key);
        if (index < 0) {
            return null;
        }
        return this.values.get(index);
    }
    
    public void clear() {
        this.keys.clear();
        this.values.clear();
        this.indexMap.clear();
    }
    
    public int getItemCount() {
        return this.keys.size();
    }
    
    public List getKeys() {
        return Collections.unmodifiableList(this.keys);
    }
    
    public List getValues() {
        return Collections.unmodifiableList(this.values);
    }
    
    /**
     * Rebuilds the key to indexed-position mapping after an positioned insert
     * or a remove operation.
     */
    private void rebuildIndex() {
        this.indexMap.clear();
        for (int i = 0; i < this.keys.size(); i++) {
            final Object key = this.keys.get(i);
            this.indexMap.put(key, new Integer(i));
        }
    }
    
    /**


