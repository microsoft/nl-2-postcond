// Postcondition: currentOption is set if token is a valid option id
assert (options.hasOption(token) && (currentOption == options.getOption(token)) ||
        (!options.hasOption(token) &&!stopAtNonOption)) :
        "The current option id is set if token is a valid option id and is not set otherwise";


