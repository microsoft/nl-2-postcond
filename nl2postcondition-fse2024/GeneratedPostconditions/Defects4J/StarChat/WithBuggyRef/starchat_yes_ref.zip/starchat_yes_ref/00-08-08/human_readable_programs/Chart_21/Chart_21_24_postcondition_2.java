// Ensures that the maximum and minimum range values are properly updated
assert returnValue!= null;
if (returnValue.size() > 0) {
    // Find the maximum and minimum range values in the updated dataset
    double max = Double.MIN_VALUE;
    double min = Double.MAX_VALUE;
    for (BoxAndWhiskerItem item : returnValue) {
        if (item.getMedian()!= null) {
            double median = item.getMedian().doubleValue();
            max = Math.max(max, median);
            min = Math.min(min, median);
        }
        if (item.getMinOutlier()!= null) {
            double minOutlier = item.getMinOutlier().doubleValue();
            max = Math.max(max, minOutlier);
        }
        if (item.getMaxOutlier()!= null) {
            double maxOutlier = item.getMaxOutlier().doubleValue();
            min = Math.min(min, maxOutlier);
        }
    }
    // Update the cached minimum and maximum range values
    if (Double.isNaN(this.maximumRangeValue)) {
        this.maximumRangeValue = max;
    } else {
        this.maximumRangeValue = Math.max(this.maximumRangeValue, max);
    }
    if (Double.isNaN(this.minimumRangeValue)) {
        this.minimumRangeValue = min;
    } else {
        this.minimumRangeValue = Math.min(this.minimumRangeValue, min);
    }
    // Update the cached range bounds
    this.rangeBounds = new Range(this.minimumRangeValue, this.maximumRangeValue);
}


