// Ensures that the specified index is a valid index into the collection,
// and throws an IndexOutOfBoundsException if it is not.
assert index >= 0 && index < getItemCount() : "Index out of bounds";

// Rebuilds the key to indexed-position mapping after an positioned insert
// or a remove operation, and ensures that the mapping is correct.
rebuildIndex();

// Replaces the removed value with the last value in the collection and
// shrinks the collection's size by 1.
int lastIndex = getItemCount() - 1;
keys.set(index, keys.get(lastIndex));
values.set(index, values.get(lastIndex));
keys.remove(lastIndex);
values.remove(lastIndex);


