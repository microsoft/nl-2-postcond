// Ensures that when the method removeRangeMarker executes successfully, the
// markers for the range axis in the specified layer are updated correctly.
assert (returnValue == (boolean) markers.remove(marker));


