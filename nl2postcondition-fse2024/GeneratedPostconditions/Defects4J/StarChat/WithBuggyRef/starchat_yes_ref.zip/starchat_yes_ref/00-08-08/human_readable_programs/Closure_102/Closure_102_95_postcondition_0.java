// Check that the result of the method is a valid AST
assert isValidAST(returnValue);


