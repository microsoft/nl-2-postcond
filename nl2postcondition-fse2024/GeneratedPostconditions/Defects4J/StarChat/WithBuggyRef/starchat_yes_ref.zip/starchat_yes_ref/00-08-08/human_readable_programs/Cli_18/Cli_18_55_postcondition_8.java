assert (
// The resulting array contains no duplicates
new HashSet<>(Arrays.asList(returnValue)).size() == returnValue.length
);


