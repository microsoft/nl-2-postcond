// Postcondition:
assert (options!= null); // `options` isn't null
assert (tokens!= null); // `tokens` isn't null
assert (currentOption == null); // `currentOption` is null
assert (value!= null); // `value` isn't null


