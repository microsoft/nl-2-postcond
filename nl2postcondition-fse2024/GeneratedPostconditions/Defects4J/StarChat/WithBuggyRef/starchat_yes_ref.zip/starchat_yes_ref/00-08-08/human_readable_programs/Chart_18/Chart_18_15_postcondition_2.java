assert (keys.size() == values.size()) : "keys and values arrays must have the same length";
assert (index >= 0 && index < keys.size()) : "index must be a valid index into keys and values arrays";
int removedKey = keys.remove(index);
T removedValue = values.remove(index);
assert (indexMap.get(removedKey) == Integer.valueOf(index)) : "indexMap must be updated correctly";
indexMap.remove(removedKey);


