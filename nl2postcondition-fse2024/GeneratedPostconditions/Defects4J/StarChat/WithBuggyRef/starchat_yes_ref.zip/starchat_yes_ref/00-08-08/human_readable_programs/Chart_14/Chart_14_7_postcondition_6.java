assert removeRangeMarker(marker, layer, notify) == (
    // Check that the marker is present in the specified layer
    (layer == Layer.FOREGROUND? foregroundRangeMarkers.get(index) : backgroundRangeMarkers.get(index)).contains(marker)
    // Check that the marker has the correct index
    && marker.getStart() == index
    // Check that the marker is in the plot area
    && marker.getStart() >= 0 && marker.getStart() <= getDataRange(false).getLength()
    // Check that the notify parameter is true
    && notify
);


