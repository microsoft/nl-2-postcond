import java.util.List;

public class PosixParser {
    private List tokens;
    private Options options;
    private boolean eatTheRest;

    public String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
        init();
        this.options = options;
        Iterator iter = Arrays.asList(arguments).iterator();
        while (iter.hasNext()) {
            String token = (String) iter.next();
            if (token.startsWith("--")) {
                int pos = token.indexOf('=');
                String opt = pos == -1? token : token.substring(0, pos);

                if (!options.hasOption(opt)) {
                    processNonOptionToken(token);
                } else {
                    tokens.add(opt);
                    if (pos!= -1) {
                        tokens.add(token.substring(pos + 1));
                    }
                }
            } else if ("-".equals(token)) {
                tokens.add(token);
            } else if (token.startsWith("-")) {
                if (token.length() == 2 || options.hasOption(token)) {
                    processOptionToken(token, stopAtNonOption);
                } else {
                    burstToken(token, stopAtNonOption);
                }
            } else if (stopAtNonOption) {
                processNonOptionToken(token);
            } else {
                tokens.add(token);
            }

            gobble(iter);
        }

        return (String[]) tokens.toArray(new String[tokens.size()]);
    }

    public void burstToken(String token, boolean stopAtNonOption) {
        Option currentOption;
        for (int i = 1; i < token.length(); i++) {
            String ch = String.valueOf(token.charAt(i));

            if (options.hasOption(ch)) {
                tokens.add("-" + ch);
                currentOption = options.getOption(ch);

                if (currentOption.hasArg() && (token.length()!= (i + 1))) {
                    tokens.add(token.substring(i + 1));

                    break;
                }
            } else if (stopAtNonOption) {
                processNonOptionToken(token.substring(i));
                break;
            } else {
                tokens.add(token);
                break;
            }
        }
    }

    private void processNonOptionToken(String value) {
        assert tokens.contains("--") && tokens.indexOf("--") + 1 == tokens.indexOf(value);
        eatTheRest = true;
        tokens.add("--");
        tokens.add(value);
    }
}


