// Check that the length of the returned array is equal to the length of the input array
assert returnValue.length == arguments.length;


