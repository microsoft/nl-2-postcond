// The marker is removed from the plot if it exists
assert (returnValue == true) == (Arrays.asList(plot.getRangeMarkers(index, layer)).contains(marker));


