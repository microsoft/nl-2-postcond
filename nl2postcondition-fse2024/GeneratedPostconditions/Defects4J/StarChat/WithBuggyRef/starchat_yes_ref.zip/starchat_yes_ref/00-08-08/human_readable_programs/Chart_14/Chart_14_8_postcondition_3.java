import static org.junit.jupiter.api.Assertions.*;

...

// Comment explaining what aspect of the method the symbolic postcondition checks
assert (returnValue == true || returnValue == false);


