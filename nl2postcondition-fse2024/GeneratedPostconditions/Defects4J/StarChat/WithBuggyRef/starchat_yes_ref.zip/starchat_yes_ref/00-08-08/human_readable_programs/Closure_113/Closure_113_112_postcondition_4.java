assert (provided!= null) && provided.isExplicitlyProvided()
      && (moduleGraph == null || moduleGraph.dependsOn(t.getModule(), provided.explicitModule))
      : "Invalid require in " + t.getSourceName() + ": module " + provided.explicitModule + " must be explicitly provided";


