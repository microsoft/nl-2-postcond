assert (/* Postcondition goes here */);


