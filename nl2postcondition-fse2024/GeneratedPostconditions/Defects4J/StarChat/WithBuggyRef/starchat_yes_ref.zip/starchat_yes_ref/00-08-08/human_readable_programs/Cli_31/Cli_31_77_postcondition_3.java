// Postcondition: Resets the member variables to their default values.
assert (
    // This implies that the description variable is set to null
    description == null
    // This implies that the argName variable is set to "arg"
    && argName == "arg"
    // This implies that the longopt variable is set to null
    && longopt == null
    // This implies that the type variable is set to null
    && type == null
    // This implies that the required variable is set to false
    &&!required
    // This implies that the numberOfArgs variable is set to Option.UNINITIALIZED
    && numberOfArgs == Option.UNINITIALIZED
    // This implies that the optionalArg variable is set to false
    &&!optionalArg
    // This implies that the valuesep variable is set to zero (0)
    && valuesep == 0
);


