// Postcondition: Ensures that the label is drawn with the correct properties
assert (


