// Check that the label's horizontal alignment is correct:
assert(edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
        && labelBounds.getY() == dataArea.getY() + (edge == RectangleEdge.TOP? 0 : dataArea.getHeight())
        && labelBounds.getX() + (edge == RectangleEdge.TOP? 0 : labelBounds.getWidth()) <= dataArea.getX() + dataArea.getWidth());
// Check that the label's vertical alignment is correct:
assert(edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
        && labelBounds.getX() == dataArea.getX() + (edge == RectangleEdge.LEFT? 0 : dataArea.getWidth())
        && labelBounds.getY() + (edge == RectangleEdge.LEFT? 0 : labelBounds.getHeight()) <= dataArea.getY() + dataArea.getHeight());
// Check that the label's angle is correct:
assert(Math.abs(getLabelAngle()) <= Math.PI / 2.0);
// Check that the label's insets are correct:
assert(getLabelInsets().equals(new RectangleInsets(edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
               ? dataArea.getY() - labelBounds.getY()
                : edge == RectangleEdge.LEFT? dataArea.getX() - labelBounds.getX()
                : labelBounds.getY() - dataArea.getY(), edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
               ? dataArea.getY() + dataArea.getHeight() - labelBounds.getY() - labelBounds.getHeight()
                : edge == RectangleEdge.LEFT? dataArea.getX() + dataArea.getWidth() - labelBounds.getX() - labelBounds.getWidth()
                : dataArea.getY() + dataArea.getHeight() - labelBounds.getY(), edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
               ? dataArea.getX() - labelBounds.getX()
                : dataArea.getX() + dataArea.getWidth() - labelBounds.getX() - labelBounds.getWidth(), edge == RectangleEdge.TOP || edge == RectangleEdge.BOTTOM
               ? labelBounds.getY() - dataArea.getY()
                : labelBounds.getY() - dataArea.getY() + labelBounds.getHeight(), edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
               ? dataArea.getY()
                : dataArea.getY() + dataArea.getHeight(), edge == RectangleEdge.LEFT || edge == RectangleEdge.RIGHT
               ? dataArea.getX() + dataArea.getWidth()
                : dataArea.getX())));
// Check that the label's font is correct:
assert(getLabelFont().equals(new Font("SansSerif", Font.PLAIN, 12)));
// Check that the label's paint is correct:
assert(getLabelPaint().equals(Color.BLACK));
// Check that the label is drawn correctly:
assert(TextUtilities.drawRotatedString("Label", g2, 10, 20, TextAnchor.BASELINE_LEFT, 0, TextAnchor.BASELINE_LEFT) == new Rectangle2D.Float(10, 20, 60, 15));


