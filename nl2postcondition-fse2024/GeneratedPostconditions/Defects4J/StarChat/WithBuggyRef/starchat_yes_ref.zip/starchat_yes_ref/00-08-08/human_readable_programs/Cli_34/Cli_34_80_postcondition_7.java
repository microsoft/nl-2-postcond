So, should I use 'List' objects in my examples?


