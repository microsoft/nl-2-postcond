assert (
    //Check that if the edge parameter is set to top, the code inside the if-statement is executed.
    (edge == RectangleEdge.TOP)?
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font.
    returnValue.getFontMetrics().getFont().equals(labelFont) &&
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font size.
    returnValue.getFontMetrics().getHeight() == labelFont.getSize() &&
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font style.
    returnValue.getFontMetrics().getStyle() == labelFont.getStyle() &&
    //Check that the FontMetrics object returned by getFontMetrics() has the correct font color.
    returnValue.getFontMetrics().getColor() == labelPaint &&
    //Check that the String returned by TextUtilities.getTextBounds() is equal to the input label parameter.
    returnValue.getText().equals(label) &&
    //Check that the Rectangle2D object returned by getTextBounds() has the correct width.
    returnValue.getWidth() == returnValue.getFontMetrics().stringWidth(label) &&
    //Check that the Rectangle2D object returned by getTextBounds() has the correct height.
    returnValue.getHeight() == returnValue.getFontMetrics().getHeight() &&
    //Check that the Rectangle2D object returned by getTextBounds() has the correct x-coordinate.
    (edge == RectangleEdge.TOP)? returnValue.getX() == dataArea.getX() + dataArea.getWidth() / 2.0 - returnValue.getWidth() / 2.0 :
    (edge == RectangleEdge.BOTTOM)? returnValue.getX() == dataArea.getX() + dataArea.getWidth() / 2.0 - returnValue.getWidth() / 2.0 :
    (edge == RectangleEdge.LEFT)? returnValue.getY() == dataArea.getY() + dataArea.getHeight() / 2.0 - returnValue.getHeight() / 2.0 :
    (edge == RectangleEdge.RIGHT)? returnValue.getY() == dataArea.getY() + dataArea.getHeight() / 2.0 - returnValue.getHeight() / 2.0 :
    false
) : "Invalid edge parameter";


