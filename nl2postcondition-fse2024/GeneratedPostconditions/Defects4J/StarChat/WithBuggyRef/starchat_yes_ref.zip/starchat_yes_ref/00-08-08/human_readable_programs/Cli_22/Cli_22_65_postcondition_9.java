// Symbolic postcondition for the burstToken method
// Ensures that the return value is equal to the input token
String inputToken = token;
String returnValue = burstToken(inputToken, stopAtNonOption);
assert (returnValue.equals(inputToken));


