assert (String.class.isAssignableFrom(className.getType().getClassName()) || returnValue); // Ensures that if the method returns true, then the class name is a string


