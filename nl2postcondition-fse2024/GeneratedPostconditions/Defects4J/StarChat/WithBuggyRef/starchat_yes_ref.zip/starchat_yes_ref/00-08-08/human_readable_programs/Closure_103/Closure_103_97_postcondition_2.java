public static ObjectType getTypeWithProperty(String field, JSType type) {
     assert type instanceof ObjectType; // type is not an object type, cannot have properties
     assert!"prototype".equals(field); // "prototype" is a reserved property name for objects
     assert returnValue!= null; // the return value may be null, but it is not assigned within the method

     // perform other checks as necessary

     return returnValue;
}


