// Ensures that adding the special token "--" and the current value to the processed
// tokens list results in the same list as adding each individual token in the value.
assert Arrays.asList("--", value).equals(Arrays.asList(value.split("\\s+")));


