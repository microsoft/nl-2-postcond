import java.util.Objects;

// The following import is only needed if the postcondition calls the contains method
// on the String class
import java.lang.String;

public final class OptionBuilder {

    private static String description;
    private static String argName;
    private static String longopt;
    private static Character type;
    private static boolean required;
    private static int numberOfArgs;
    private static boolean optionalArg;
    private static char valuesep;

    public static Option.Builder builder() {
        reset();
        return new Option.Builder();
    }

    private static void reset() {
        description = null;
        argName = "arg";
        longopt = null;
        type = null;
        required = false;
        numberOfArgs = Option.UNINITIALIZED;
        optionalArg = false;
        valuesep = (char) 0;
        assert description == null;
        assert argName.equals("arg");
        assert longopt == null;
        assert type == null;
        assert!required;
        assert numberOfArgs == Option.UNINITIALIZED;
        assert!optionalArg;
        assert valuesep == 0;
    }
}


