Here's the symbolic postcondition for the getChildBefore method:

assert: //Check that the input child node is indeed a child of this node

(getChildBefore(child) == null) || (getChildBefore(child).next == child);


