// Ensures that the column with the specified key is removed from the table
assert this.columnKeys.contains(columnKey) :
    "The column key (" + columnKey + ") is not present in the table";


