// The postcondition checks that the return value of the method is either a Node with type
// Node.TYPE_NAME or Node.TYPE_UNKNOWN
assert (returnValue instanceof Node) && ((Node) returnValue).getType() == Node.TYPE_NAME || ((Node) returnValue).getType() == Node.TYPE_UNKNOWN;


