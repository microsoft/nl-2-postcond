public static Range iterateRangeBounds(XYDataset dataset) {
    assert findRangeBounds(dataset) == null || findRangeBounds(dataset).getLength() >= 0;
    return findRangeBounds(dataset);
}


