//Postcondition: iterateDomainBounds returns the range of x-values in the dataset,
//taking into account the includeInterval flag.
assert (returnValue!= null && returnValue.getLength() == 2) == (dataset!= null && (includeInterval == true) == (dataset instanceof IntervalXYDataset));


