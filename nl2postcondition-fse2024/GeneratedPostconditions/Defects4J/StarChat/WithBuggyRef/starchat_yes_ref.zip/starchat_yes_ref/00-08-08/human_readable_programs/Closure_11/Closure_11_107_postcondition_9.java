assert (returnValue!= null && returnValue.isEquivalentTo(getNativeType(UNKNOWN_TYPE)) 
        &&


