assert (returnValue!= null); // postcondition for processValues


