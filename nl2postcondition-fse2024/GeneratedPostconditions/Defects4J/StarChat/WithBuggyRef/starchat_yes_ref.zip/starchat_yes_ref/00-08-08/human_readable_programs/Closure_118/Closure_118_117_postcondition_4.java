// Ensures that the postcondition holds for all possible inputs to handleObjectLit
assert (propertiesToErrorFor.isEmpty() || propertiesToErrorFor.keySet().containsAll(n.getObjectLitProperties())):
    "propertiesToErrorFor is a subset of the object literal properties";


