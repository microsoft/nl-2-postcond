assert (returnValue!= null); // postcondition for parseContextTypeExpression


