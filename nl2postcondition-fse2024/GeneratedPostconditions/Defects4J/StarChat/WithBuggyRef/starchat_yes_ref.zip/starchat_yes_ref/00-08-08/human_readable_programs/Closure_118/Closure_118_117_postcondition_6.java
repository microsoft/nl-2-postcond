void handleObjectLit(NodeTraversal t, Node n) {
    // Precondition: n is an object literal node
    assert n.isObjectLit();
    
    // Initialize a list to store the properties in the object literal
    List<String> properties = new ArrayList<>();
    
    // Add the names of all properties in the object literal to the list
    for (Node child = n.getFirstChild(); child!= null; child = child.getNext()) {
        properties.add(child.getString());
    }
    
    // Sort the list of properties
    Collections.sort(properties);
    
    // For each property in the sorted list, check if the property has already been renamed
    for (String property : properties) {
        Property p = getProperty(property);
        
        // If the property has not been renamed, check if the property type is valid
        if (!p.isRenamed()) {
            T type = typeSystem.getType(getScope(), n, property);
            
            // If the property type is valid, check if the property value is valid
            if (isValidPropertyValue(t, p, type, child)) {
                // Mark the property as renamed and record the rename in the log
                p.markAsRenamed();
                log.recordRename(n, property, child.getString());
            }
        }
    }
}


