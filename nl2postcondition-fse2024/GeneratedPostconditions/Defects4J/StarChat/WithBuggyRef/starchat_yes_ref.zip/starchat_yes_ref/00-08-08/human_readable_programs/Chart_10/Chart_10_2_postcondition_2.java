// Check that the return value contains the alt attribute with an empty value
assert returnValue.contains(" alt=\"\"");


