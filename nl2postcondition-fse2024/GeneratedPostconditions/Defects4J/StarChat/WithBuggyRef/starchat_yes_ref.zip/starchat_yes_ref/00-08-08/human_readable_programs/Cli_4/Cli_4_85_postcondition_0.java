// Postcondition:
// - Throws a MissingOptionException if any of the required options are not present
assert (
    // If any required options are missing
   !Collections.disjoint(
        // the set of required options specified in the Options object
        this.options.getRequiredOptions(),
        // the set of options present in the CommandLine object
        cmd.getOptions()
    )
);


