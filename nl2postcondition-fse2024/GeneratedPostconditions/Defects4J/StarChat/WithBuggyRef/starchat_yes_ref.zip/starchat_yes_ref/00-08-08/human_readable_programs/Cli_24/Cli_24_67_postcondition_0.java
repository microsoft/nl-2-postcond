// The rendered text should contain the original text with line breaks inserted at appropriate places
// such that the text fits within the specified width.
assert (renderWrappedText(new StringBuffer(), 10, 0, originalText).toString().equals(expectedText));


