import java.awt.geom.Rectangle2D;
import org.jfree.chart.util.LengthConstraintType;
import org.jfree.chart.util.RectangleConstraint;
import org.jfree.chart.util.Size2D;

public class BorderArrangement {
    //...

    public Size2D arrange(BlockContainer container, Graphics2D g2, RectangleConstraint constraint) {
        //...
        return new Size2D(container.calculateTotalWidth(contentSize.getWidth()),
                           container.calculateTotalHeight(contentSize.getHeight()));
    }

    // Postcondition:
    // Ensures that the return value is correct by checking the contentSize variable
    // and the width and height constraints of the constraint object.
    public Size2D arrangeFF(BlockContainer container, Graphics2D g2, RectangleConstraint constraint) {
        // Declare local variables to hold the width, height, and widthRange constraints.
        double width = constraint.getWidth();
        double height = constraint.getHeight();
        Range widthRange = constraint.getWidthRange();
        // Check that the width and height constraints are both exact or both ranges.
        assert ((widthConstraintType == LengthConstraintType.FIXED && heightConstraintType == LengthConstraintType.FIXED)
               || (widthConstraintType == LengthConstraintType.RANGE && heightConstraintType == LengthConstraintType.RANGE))
               : "Invalid length constraints. Width and height must both be exact or both ranges.";
        // Check that the width and height values are correct based on the length constraints.
        if (widthConstraintType == LengthConstraintType.FIXED) {
            assert width == contentSize.getWidth() : "Invalid width constraint.";
        } else if (widthConstraintType == LengthConstraintType.RANGE) {
            assert widthRange.contains(contentSize.getWidth()) : "Invalid width range constraint.";
        }
        if (heightConstraintType == LengthConstraintType.FIXED) {
            assert height == contentSize.getHeight() : "Invalid height constraint.";
        } else if (heightConstraintType == LengthConstraintType.RANGE) {
            assert heightRange.contains(contentSize.getHeight()) : "Invalid height range constraint.";
        }
        // Return the correct return value.
        return new Size2D(width, height);
    }
}


