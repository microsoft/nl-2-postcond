// Check that the returned range contains the minimum and maximum values from the dataset
assert returnValue.contains(dataset.getMinYValue()) && returnValue.contains(dataset.getMaxYValue());


