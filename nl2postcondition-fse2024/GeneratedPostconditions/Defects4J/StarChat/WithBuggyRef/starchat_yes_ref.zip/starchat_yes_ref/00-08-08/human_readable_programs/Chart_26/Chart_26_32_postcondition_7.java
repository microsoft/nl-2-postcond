// The method draws the axis label and returns the updated axis state.
assert(
    // If the edge is top:
    (edge == RectangleEdge.TOP)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the center of the data area:
        dataArea.getCenterX(), 
        // With a vertical offset that is equal to the cursor position minus the insets top:
        state.getCursor() - insets.getTop(), 
        // With horizontal and vertical alignment both set to CENTER:
        TextAnchor.CENTER, TextAnchor.CENTER, 
        // And the label rotated by the angle specified by getLabelAngle:
        getLabelAngle())
    // And the hotspot for the axis label should be a rectangle with the following dimensions:
    && (hotspot.equals(
        new Rectangle2D.Float(
            // With a left edge equal to the data area center minus half the width of the label:
            dataArea.getCenterX() - (labelBounds.getWidth() / 2.0), 
            // With a top edge equal to the cursor position minus half the height of the label:
            state.getCursor() - (labelBounds.getHeight() / 2.0), 
            // And a width equal to the width of the label:
            labelBounds.getWidth(), 
            // And a height equal to the height of the label:
            labelBounds.getHeight()
        )
    ))
    // If the edge is bottom:
    || (edge == RectangleEdge.BOTTOM)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the center of the data area:
        dataArea.getCenterX(), 
        // With a vertical offset that is equal to the cursor position plus the insets bottom:
        state.getCursor() + insets.getBottom(), 
        // With horizontal and vertical alignment both set to CENTER:
        TextAnchor.CENTER, TextAnchor.CENTER, 
        // And the label rotated by the angle specified by getLabelAngle:
        getLabelAngle())
    // And the hotspot for the axis label should be a rectangle with the following dimensions:
    && (hotspot.equals(
        new Rectangle2D.Float(
            // With a left edge equal to the data area center minus half the width of the label:
            dataArea.getCenterX() - (labelBounds.getWidth() / 2.0), 
            // With a top edge equal to the cursor position minus half the height of the label:
            state.getCursor() - (labelBounds.getHeight() / 2.0), 
            // And a width equal to the width of the label:
            labelBounds.getWidth(), 
            // And a height equal to the height of the label:
            labelBounds.getHeight()
        )
    ))
    // If the edge is left:
    || (edge == RectangleEdge.LEFT)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the cursor position minus the insets right:
        state.getCursor() - insets.getRight(), 
        // With a vertical offset that is equal to the data area center:
        dataArea.getCenterY(), 
        // With horizontal alignment set to CENTER and vertical alignment set to CENTER:
        TextAnchor.CENTER, TextAnchor.CENTER, 
        // And the label rotated by the angle specified by getLabelAngle minus Math.PI / 2.0:
        getLabelAngle() - Math.PI / 2.0)
    // And the hotspot for the axis label should be a rectangle with the following dimensions:
    && (hotspot.equals(
        new Rectangle2D.Float(
            // With a left edge equal to the cursor position minus half the width of the label:
            state.getCursor() - (labelBounds.getWidth() / 2.0), 
            // With a top edge equal to the data area center minus half the height of the label:
            dataArea.getCenterY() - (labelBounds.getHeight() / 2.0), 
            // And a width equal to the width of the label:
            labelBounds.getWidth(), 
            // And a height equal to the height of the label:
            labelBounds.getHeight()
        )
    ))
    // If the edge is right:
    || (edge == RectangleEdge.RIGHT)
    // Then the label should be drawn with a call to drawRotatedString:
    && (drawRotatedString(
        // With the provided parameters, including the label and the Graphics2D object:
        label, g2, 
        // Where the label is positioned at the cursor position plus the insets left:
        state.getCursor() + insets.


