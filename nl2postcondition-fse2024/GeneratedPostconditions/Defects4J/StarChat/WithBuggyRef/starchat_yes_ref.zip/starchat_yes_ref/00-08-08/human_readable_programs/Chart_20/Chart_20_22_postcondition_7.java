import java.awt.Paint;
import java.awt.Stroke;

public class ValueMarker extends Marker {

//Method you are writing a postcondition for:
/**
* Creates a new value marker.
* 
* @param value  the value.
* @param paint  the paint (null not permitted).
* @param stroke  the stroke (null not permitted).
* @param outlinePaint  the outline paint (null permitted).
* @param outlineStroke  the outline stroke (null permitted).
* @param alpha  the alpha transparency (in the range 0.0f to 1.0f).
*/
public ValueMarker(double value, Paint paint, Stroke stroke, 
                           Paint outlinePaint, Stroke outlineStroke, float alpha) {
        super(paint, stroke, paint, stroke, alpha);
        this.value = value;
    }

// Postcondition: assert that the outline paint and stroke are never used, since
// the value marker does not display an outline.
assert outlinePaint == null && outlineStroke == null : "The outline paint and stroke should be null for value markers.";

// No additional code required.
}


