Here's a possible symbolic postcondition for the method flatten:

// Check that the order of the processed tokens matches the order of the input arguments
assert Arrays.equals(flatten(options, arguments, stopAtNonOption), arguments);

This postcondition asserts that the order of the processed tokens in the method output matches the order of the input arguments.


