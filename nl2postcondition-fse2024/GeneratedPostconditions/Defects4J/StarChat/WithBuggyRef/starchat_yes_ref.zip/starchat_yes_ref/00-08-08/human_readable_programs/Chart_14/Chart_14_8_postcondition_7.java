Here are the symbolic postconditions for the removeDomainMarker method:

// Postcondition: Ensures that the returned value is true if the marker is removed
assert(returnValue);

// Postcondition: Ensures that the marker is not present in the list of markers
assert(!markers.contains(marker));

// Postcondition: Ensures that the marker is removed from the correct layer
assert(layer == Layer.FOREGROUND?
        this.foregroundDomainMarkers.get(new Integer(index))!= markers :
        this.backgroundDomainMarkers.get(new Integer(index))!= markers);

// Postcondition: Ensures that the plot is updated if the marker is removed
assert(notify? fireChangeEvent() : true);

// Postcondition: Ensures that the marker is removed from the collection of markers
assert(removed);


