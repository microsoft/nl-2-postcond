assert burstToken(token, stopAtNonOption) = returnValue


