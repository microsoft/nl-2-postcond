// Postcondition: The return value of iterateRangeBounds is the range
    // that encompasses all of the data values in the input dataset,
    // where "data values" means the y-values from each series in the dataset.
    // The input parameters of the method are:
    // dataset: the dataset whose data values will be used to determine the range
    // includeInterval: a boolean that determines whether or not the y-interval
    // is used instead of just the y-values in determining the range
    assert (returnValue!= null) : "The return value of iterateRangeBounds should never be null";
    double minimum = returnValue.getLowerBound();
    double maximum = returnValue.getUpperBound();
    double yValue;
    for (int seriesIndex = 0; seriesIndex < dataset.getSeriesCount(); seriesIndex++) {
        for (int itemIndex = 0; itemIndex < dataset.getItemCount(seriesIndex); itemIndex++) {
            yValue = dataset.getYValue(seriesIndex, itemIndex);
            if (!Double.isNaN(yValue)) {
                minimum = Math.min(minimum, yValue);
                maximum = Math.max(maximum, yValue);
            }
        }
    }
    if (includeInterval && dataset instanceof IntervalXYDataset) {
        IntervalXYDataset intervalDataset = (IntervalXYDataset) dataset;
        for (int seriesIndex = 0; seriesIndex < dataset.getSeriesCount(); seriesIndex++) {
            for (int itemIndex = 0; itemIndex < dataset.getItemCount(seriesIndex); itemIndex++) {
                yValue = intervalDataset.getStartYValue(seriesIndex, itemIndex);
                if (!Double.isNaN(yValue)) {
                    minimum = Math.min(minimum, yValue);
                }
                yValue = intervalDataset.getEndYValue(seriesIndex, itemIndex);
                if (!Double.isNaN(yValue)) {
                    maximum = Math.max(maximum, yValue);
                }
            }
        }
    }
    double rangeMinimum = returnValue.getLowerBound();
    double rangeMaximum = returnValue.getUpperBound();
    assert (rangeMinimum == minimum && rangeMaximum == maximum) :
        "The range calculated by iterateRangeBounds should be equal to the range calculated in the loop";


