public boolean removeRangeMarker(int index, Marker marker, Layer layer, boolean notify) {
	assert (notify == true) ==> (returnValue == true);
	return false; 
}


