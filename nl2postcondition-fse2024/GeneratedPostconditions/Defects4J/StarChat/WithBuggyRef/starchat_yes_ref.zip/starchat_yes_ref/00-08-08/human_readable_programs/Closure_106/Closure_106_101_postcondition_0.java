// Ensures that the JSDocInfo object contains a block-level description
assert currentInfo.getBlockDescription().equals(description);


