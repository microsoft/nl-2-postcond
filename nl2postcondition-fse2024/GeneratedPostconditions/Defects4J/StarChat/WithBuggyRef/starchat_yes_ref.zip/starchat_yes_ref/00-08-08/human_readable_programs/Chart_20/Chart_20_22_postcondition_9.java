// Check that the returned ValueMarker has the correct properties
assert returnValue!= null;
assert returnValue instanceof ValueMarker;
assert returnValue.value == value;
assert returnValue.paint == paint;
assert returnValue.stroke == stroke;
assert returnValue.outlinePaint == outlinePaint;
assert returnValue.outlineStroke == outlineStroke;
assert returnValue.alpha == alpha;


