Here is my response to your prompt:

// Check that the values returned from the method follow the contract specified in the Javadoc
assert (returnValue!= null && returnValue.length > 0);

// Check that the first element of the returned array is --
assert ("--".equals(returnValue[0]));

// Check that all other elements of the returned array are options or arguments
for (String s : returnValue) {
    assert (s.startsWith("-") || options.hasOption(s));
}


