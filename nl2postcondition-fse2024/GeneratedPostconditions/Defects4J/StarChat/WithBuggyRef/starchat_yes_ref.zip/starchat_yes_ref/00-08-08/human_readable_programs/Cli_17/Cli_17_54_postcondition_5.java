// The length of the returned array is equal to the number of tokens added to the list
assert returnValue.length == tokens.size();


