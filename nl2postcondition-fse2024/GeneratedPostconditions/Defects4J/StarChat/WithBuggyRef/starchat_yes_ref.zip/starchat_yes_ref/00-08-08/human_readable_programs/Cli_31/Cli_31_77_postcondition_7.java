assert ( // Description of the postcondition
    argName == "arg" &&
    longopt == null &&
    type == null &&
   !required &&
    numberOfArgs == Option.UNINITIALIZED &&
   !optionalArg &&
    valuesep == (char) 0
);


