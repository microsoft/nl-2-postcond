// Ensures that the member variables are set to their default values after reset() is called
assert (description == null && argName == null && longopt == null && type == null
        && required == false && numberOfArgs == Option.UNINITIALIZED
        && optionalArg == false && valuesep == (char) 0);


