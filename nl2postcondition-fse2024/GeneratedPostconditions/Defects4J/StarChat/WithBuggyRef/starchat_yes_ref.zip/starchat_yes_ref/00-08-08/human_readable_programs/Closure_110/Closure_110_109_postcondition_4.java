assert (
  // If the input child is the first child, then the method should return null
  (child == first)? (returnValue == null) :
   // Otherwise, the method should return the node before the input child
  (returnValue.next == child)? (returnValue.parent == this) : false
);


