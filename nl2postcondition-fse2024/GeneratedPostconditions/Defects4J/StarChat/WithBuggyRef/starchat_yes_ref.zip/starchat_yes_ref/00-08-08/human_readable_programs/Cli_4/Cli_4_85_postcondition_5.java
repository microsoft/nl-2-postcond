assert (returnValue == null || returnValue.containsAll(requiredOptions)) : "Not all required options specified";


