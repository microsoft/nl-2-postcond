assert (returnValue == null) || (returnValue.getLength() > 0) : "The return value must be null or have non-zero length";


