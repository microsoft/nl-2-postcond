// Check that the input object literal is a valid JavaScript object.
assert Object.prototype.toString.call(n) === "[object Object]" : "Input must be an object";

// Loop through each property in the object literal.
for (Node child = n.getFirstChild(); child!= null; child = child.getNext()) {
    // Get the name of the current property.
    String name = child.getString();

    // Get the type of the current property based on the current scope and parent node.
    T type = typeSystem.getType(getScope(), n, name);

    // Get the corresponding property in the type.
    Property prop = getProperty(name);

    // Check that the property exists in the type.
    assert prop!= null : "Property " + name + " does not exist in " + n.toString();

    // Check that the type of the property is valid for the given object literal.
    assert typeSystem.isSubtype(type, prop.getType()) :
        "Invalid type for property " + name + ": " + type.toString() + " is not a subtype of " + prop.getType().toString();

    // Check that the property has not already been scheduled for renaming.
    assert!prop.isRenamed() : "Property " + name + " has already been scheduled for renaming";

    // Schedule the property for renaming.
    prop.scheduleRenaming(child, processProperty(t, prop, type, null));
}


