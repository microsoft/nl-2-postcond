// The requiredOptions list should contain all options that are required.
assert (new HashSet(requiredOptions)).equals(new HashSet(options.getRequiredOptions()));


