// The function can be inlined if:
//   1. It is a direct call node replacement
//   2. All arguments and parameters do not have side effects
//   3. No aliases are required

assert canInlineReferenceDirectly(callNode, fnNode) == CanInlineResult.YES
    || canInlineReferenceDirectly(callNode, fnNode) == CanInlineResult.MAY_INLINE;


