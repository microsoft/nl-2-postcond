// Check that the specified index is valid, that is, in the range 0 to
// the number of items in the collection.
assert ( index >= 0 && index < this.keys.size() );

// Check that the specified index points to the specified key in the
// key array, and that the keys and values arrays are in sync.
assert ( index == this.indexMap.get(key).intValue() );

// Check that the key at the specified index is the same as the key
// specified.
assert ( this.keys.get(index).equals(key) );

// Check that the value at the specified index has been removed from
// the values array.
assert ( this.values.get(index) == null );

// Check that the key-to-index mapping has been updated to account for the
// removed item.
assert ( this.indexMap.values().contains(index) );

// Check that the keys and values arrays are now in sync.
assert ( this.keys.size() == this.values.size() );

// Check that the collection size has been updated correctly.
assert ( this.size() == this.keys.size() );


