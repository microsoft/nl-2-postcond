// Ensures that the list of externs does not contain any duplicate variable declarations
assert!NodeTraversal.traverse(compiler, externs, new DuplicateDeclarationCheck()).hasDuplicateDeclarations();

// Ensures that the list of root nodes contains no duplicate variable declarations
assert!NodeTraversal.traverse(compiler, root, new DuplicateDeclarationCheck()).hasDuplicateDeclarations();

// Ensures that the list of externs and root nodes do not contain any duplicate variable declarations
assert!NodeTraversal.traverse(compiler, externs, root, new DuplicateDeclarationCheck()).hasDuplicateDeclarations();

// Ensures that the list of externs and root nodes do not contain any duplicate variable declarations
// and that the traversal does not modify the AST
Node originalExterns = externs.cloneTree();
Node originalRoot = root.cloneTree();
NodeTraversal.traverse(compiler, externs, root, new DuplicateDeclarationCheck());
assert NodeUtil.isEquivalent(externs, originalExterns) && NodeUtil.isEquivalent(root, originalRoot);

// Ensures that the traversal does not modify the AST
NodeTraversal.traverse(compiler, externs, root, new Foo());
assert NodeUtil.isEquivalent(externs, originalExterns) && NodeUtil.isEquivalent(root, originalRoot);


