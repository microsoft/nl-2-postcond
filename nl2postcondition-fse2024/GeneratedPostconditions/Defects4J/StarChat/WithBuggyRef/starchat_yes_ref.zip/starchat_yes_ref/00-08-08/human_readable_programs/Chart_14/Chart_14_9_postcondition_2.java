import java.util.ArrayList;

// The parameter "notify" determines whether or not listeners are notified
public void removeRangeMarker(int index, Marker marker, Layer layer, boolean notify) {
    assert (layer == Layer.FOREGROUND? this.foregroundRangeMarkers : this.backgroundRangeMarkers).get(index).remove(marker) == notify;
}


