// The elements in the list returned by the method should be in sorted order.
assert (Arrays.equals(new String[] { "a", "b", "c", "d", "e" }, returnValue));


