// Postcondition: checks that the return value is null or a property of the input type
assert (returnValue == null || returnValue.isPropertyType(field)) : "Invalid postcondition for getTypeWithProperty";


