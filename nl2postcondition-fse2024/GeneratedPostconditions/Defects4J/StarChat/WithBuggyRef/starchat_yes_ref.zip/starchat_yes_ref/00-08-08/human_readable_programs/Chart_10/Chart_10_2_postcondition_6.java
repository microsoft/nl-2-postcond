// Check that the method returns a string with the title attribute set to the input tooltip text
assert " title=\"" + toolTipText + "\" alt=\"\"".equals(returnValue);


