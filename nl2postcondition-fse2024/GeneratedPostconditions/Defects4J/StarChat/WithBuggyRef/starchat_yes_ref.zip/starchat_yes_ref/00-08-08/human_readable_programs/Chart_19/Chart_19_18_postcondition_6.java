public class JFreeChartExample {

    //Relevant Class Context:
    //    org.jfree.chart.axis.CategoryAxis
    //    org.jfree.chart.plot.CategoryPlot
    //    org.jfree.chart.JFreeChart
    public static void createChart() {
        CategoryDataset dataset = createDataSet();
        JFreeChart chart = createChart(dataset);
        //...
    }

    private static CategoryDataset createDataSet() {
        // Code to create a dataset
        return dataset;
    }

    private static JFreeChart createChart(CategoryDataset dataset) {
        // Code to create a chart from the dataset
        return chart;
    }
}

public class SymbolicPostconditionExample {
    public static void main(String[] args) {
        JFreeChartExample.createChart();
        // Postcondition for getDomainAxisIndex:
        assert getDomainAxisIndex(chart.getCategoryPlot().getDomainAxis()) == 0;
        //...
    }

    // Method you are writing a postcondition for:
    private static int getDomainAxisIndex(CategoryAxis axis) {
        return axis.getParent().indexOf(axis);
    }
}


