private void findAliases(NodeTraversal t) {
    Scope scope = t.getScope();
    for (Var v : scope.getVarIterable()) {
        Node n = v.getNode();
        Node parent = n.getParent();
        boolean isVar = parent.isVar();
        if (isVar && n.getFirstChild()!= null && n.getFirstChild().isQualifiedName()) {
            recordAlias(v);
        } else if (v.isBleedingFunction()) {
        } else if (parent.getType() == Token.LP) {
        } else if (isVar) {
            Node grandparent = parent.getParent();
            Node value = n.hasChildren()?
                v.getInitialValue().detachFromParent() :
                null;
            Node varNode = parent;

            String name = n.getString();
            int nameCount = scopedAliasNames.count(name);
            scopedAliasNames.add(name);
            String globalName =
                "$jscomp.scope." + name + (nameCount == 0? "" : ("$" + nameCount));

            compiler.ensureLibraryInjected("base");
            if (value!= null || v.getJSDocInfo()!= null) {
                Node newDecl = NodeUtil.newQualifiedNameNodeDeclaration(
                    compiler.getCodingConvention(),
                    globalName,
                    value,
                    v.getJSDocInfo())
                   .useSourceInfoIfMissingFromForTree(n);
                NodeUtil.setDebugInformation(
                    newDecl.getFirstChild().getFirstChild(), n, name);

                grandparent.addChildBefore(newDecl, varNode);
            }
            v.getNameNode().addChildToFront(
                NodeUtil.newQualifiedNameNode(
                    compiler.getCodingConvention(), globalName, n, name));

            recordAlias(v);
        } else {
            report(t, n, GOOG_SCOPE_NON_ALIAS_LOCAL, n.getString());
        }
        assert(returnValue.getAliases().size()
                == scopedAliasNames.size());
        assert(returnValue.getForbiddenLocals().size()
                == forbiddenLocals.size());
    }
}

This code contains a natural language comment before findAliases that describes its behavior. The postcondition checks that the size of the output Aliases and ForbiddenLocals collections are equal.


