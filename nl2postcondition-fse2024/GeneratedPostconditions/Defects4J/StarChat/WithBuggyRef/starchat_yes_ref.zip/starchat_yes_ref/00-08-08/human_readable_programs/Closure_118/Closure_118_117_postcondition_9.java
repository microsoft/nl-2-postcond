// Check that the handleObjectLit method processes the object literal correctly.
assert post: (returnValue!= null) &&
                (returnValue instanceof ConcreteType) &&
                (((ConcreteType) returnValue).isFunctionType() ||
                ((ConcreteType) returnValue).isInstanceType() ||
                ((ConcreteType) returnValue).isUnionType() ||
                ((ConcreteType) returnValue).isUniqueType());


