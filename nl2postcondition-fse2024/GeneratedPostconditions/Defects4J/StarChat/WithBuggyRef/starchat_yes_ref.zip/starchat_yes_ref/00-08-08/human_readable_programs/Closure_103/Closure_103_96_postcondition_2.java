assert (returnValue == true) || (returnValue == false) // postcondition for mayThrowException


