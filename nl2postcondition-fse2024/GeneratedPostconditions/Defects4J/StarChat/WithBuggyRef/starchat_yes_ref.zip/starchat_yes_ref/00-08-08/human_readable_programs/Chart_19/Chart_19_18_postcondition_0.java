Here is a possible postcondition for getDomainAxisIndex:

assert ( //Code for checking that the method returns the correct value
    (axis == null && returnValue == -1)
    || (axis!= null && this.domainAxes.indexOf(axis) == returnValue)
);

This postcondition checks that if the input parameter axis is null, the return value is -1. If axis is not null, the method should return the index of axis in the list of domain axes. Note that this postcondition assumes that the method correctly returns -1 if the input parameter is null and the index of the input axis in the list if it's not null.


