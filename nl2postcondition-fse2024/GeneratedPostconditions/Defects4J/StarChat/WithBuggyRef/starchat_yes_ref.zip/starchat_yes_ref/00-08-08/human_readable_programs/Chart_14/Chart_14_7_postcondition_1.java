import java.util.ArrayList;

public class Test {
    public boolean removeRangeMarker(int index, Marker marker, Layer layer, boolean notify) {
        // Remove the marker from the specified layer of the range markers for the specified dataset.
        // If notify is true, fire a PlotChangeEvent.
        // Return true if the marker was found and removed, otherwise return false.
        assert marker!= null;
        ArrayList markers;
        if (layer == Layer.FOREGROUND) {
            markers = (ArrayList) this.foregroundRangeMarkers.get(new Integer(index));
        } else {
            markers = (ArrayList) this.backgroundRangeMarkers.get(new Integer(index));
        }
        boolean removed = markers.remove(marker);
        if (removed && notify) {
            fireChangeEvent();
        }
        return removed;
    }
}


