// Ensures that the returned map contains only variables that are aliases
assert Stream.of(returnValue.values().toArray())
   .allMatch(v -> v instanceof com.google.javascript.jscomp.Scope.Var &&
        ((com.google.javascript.jscomp.Scope.Var) v).isAlias());


