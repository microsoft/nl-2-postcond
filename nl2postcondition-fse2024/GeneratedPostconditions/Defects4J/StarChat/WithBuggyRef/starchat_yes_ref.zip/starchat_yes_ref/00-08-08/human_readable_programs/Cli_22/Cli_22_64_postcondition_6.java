// Check if the token is a valid option
assert(options.hasOption(token) ||!stopAtNonOption) : "If the token is not a valid option, stopAtNonOption must be true";


