assert returnValue!= null; // required by Javadoc
if (left.getNext()!= arg) { // required by Javadoc
    assert false;
}


