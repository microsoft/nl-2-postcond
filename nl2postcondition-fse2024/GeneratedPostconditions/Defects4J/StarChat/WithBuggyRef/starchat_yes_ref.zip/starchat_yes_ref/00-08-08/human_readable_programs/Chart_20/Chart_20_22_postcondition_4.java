symbolic postcondition for ValueMarker:

import static java.lang.Math.max;
import static java.lang.Math.min;

// if paint is non-null, then it must be of type Color
assert (paint == null) || (paint instanceof Color);

// if stroke is non-null, then it must be of type BasicStroke
assert (stroke == null) || (stroke instanceof BasicStroke);

// if outlinePaint is non-null, then it must be of type Color
assert (outlinePaint == null) || (outlinePaint instanceof Color);

// if outlineStroke is non-null, then it must be of type BasicStroke
assert (outlineStroke == null) || (outlineStroke instanceof BasicStroke);

// alpha must be in range [0.0, 1.0]
assert (alpha >= 0.0f) && (alpha <= 1.0f);

// value cannot be NaN or infinite
assert!Double.isNaN(value) &&!Double.isInfinite(value);

// result of method must be non-null
ValueMarker result = new ValueMarker(value, paint, stroke, outlinePaint, outlineStroke, alpha);

// result.getValue() must return the input value
assert result.getValue() == value;

// result.getPaint() must return the input paint, or the paint used to draw the lines/text
assert result.getPaint() == paint || result.getPaint() == outlinePaint;

// result.getStroke() must return the input stroke, or the stroke used to draw the lines
assert result.getStroke() == stroke || result.getStroke() == outlineStroke;

// result.getOutlinePaint() must return the


