// Ensures that the ArrayList returned by the method contains only the marker
// that was removed
assert (List.of(returnValue).contains(marker)) : "The ArrayList returned by the method did not contain the marker that was removed";


