assert (
    // If this is a union type, then the result is also a union type
    (this instanceof UnionType) == (returnValue instanceof UnionType)
    // If this or the other type is a union type, then the result contains all
    // of the alternate types from both this and the other type
    || (this instanceof UnionType)
    || (that instanceof UnionType)
    // If this is an object type and the other type is also an object type,
    // then the result is also an object type
    || (this.isObject() && that.isObject())
    // If this is a primitive type or the other type is a primitive type, then the
    // result is also a primitive type
    || (this.isPrimitive() && that.isPrimitive())
    // Otherwise, the result is a non-union type
    || (returnValue.isSubtype(this) && returnValue.isSubtype(that))
);


