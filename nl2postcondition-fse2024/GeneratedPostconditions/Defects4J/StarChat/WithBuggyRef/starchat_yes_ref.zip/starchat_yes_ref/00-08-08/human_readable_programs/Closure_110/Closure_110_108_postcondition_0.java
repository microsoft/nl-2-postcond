// The postcondition checks that for each alias variable in the scope, the alias is recorded in the
// transformation object and in the aliases map, and the alias variable's qualified name is added to the
// log transformation object.
assert transformation!= null;
assert aliases!= null;
assert forbiddenLocals!= null;
for (Var v : scope.getVarIterable()) {
    if (v.isAlias()) {
        String alias = v.getName();
        assert transformation.getAliasNames().contains(alias);
        assert aliases.containsKey(alias);
        assert transformation.getAliasQualifiedNames().contains(v.getInitialValue().getQualifiedName());
    }
}


