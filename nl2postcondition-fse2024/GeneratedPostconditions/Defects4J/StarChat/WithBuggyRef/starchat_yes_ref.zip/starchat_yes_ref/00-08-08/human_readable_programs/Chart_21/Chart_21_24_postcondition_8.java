Here is the symbolic postcondition for the updateBounds() method:

// Ensures that the cached bounds are up-to-date by iterating over the entire dataset
for (int r = 0; r < getRowCount(); r++) {
    for (int c = 0; c < getColumnCount(); c++) {
        BoxAndWhiskerItem item = data.getItem(r, c);
        double minValue = Double.NaN;
        if (item.getMinOutlier()!= null) {
            minValue = item.getMinOutlier().doubleValue();
        }
        double maxValue = Double.NaN;
        if (item.getMaxOutlier()!= null) {
            maxValue = item.getMaxOutlier().doubleValue();
        }
        if (Double.isNaN(minimumRangeValue)) {
            minimumRangeValue = minValue;
            minimumRangeValueRow = r;
            minimumRangeValueColumn = c;
        } else if (minValue < minimumRangeValue) {
            minimumRangeValue = minValue;
            minimumRangeValueRow = r;
            minimumRangeValueColumn = c;
        }
        if (Double.isNaN(maximumRangeValue)) {
            maximumRangeValue = maxValue;
            maximumRangeValueRow = r;
            maximumRangeValueColumn = c;
        } else if (maxValue > maximumRangeValue) {
            maximumRangeValue = maxValue;
            maximumRangeValueRow = r;
            maximumRangeValueColumn = c;
        }
    }
}
assert minimumRangeValueRow >= 0 && minimumRangeValueRow < getRowCount() : "Minimum range value row index is out of bounds";
assert minimumRangeValueColumn >= 0 && minimumRangeValueColumn < getColumnCount() : "Minimum range value column index is out of bounds";
assert maximumRangeValueRow >= 0 && maximumRangeValueRow < getRowCount() : "Maximum range value row index is out of bounds";
assert maximumRangeValueColumn >= 0 && maximumRangeValueColumn < getColumnCount() : "Maximum range value column index is out of bounds";

The postcondition checks that the minimum and maximum range values are set correctly based on the input data and that the row and column indices are within the bounds of the data.


