/**
 * Checks that none of the child names can be eliminated if the parent name is not eliminated.
 *
 * @param parent the parent name
 * @param names the child names
 * @return true if none of the child names can be eliminated, otherwise false
 */
public static boolean canCollapseUnannotatedChildNames(Name parent, List<Name> names) {
    boolean canCollapse = true;
    for (Name child : names) {
        canCollapse &=!child.canEliminate(parent);
    }
    return canCollapse;
}


