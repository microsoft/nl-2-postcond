// Postcondition: The cached minimum and maximum range values are set to Double.NaN.
assert Double.isNaN(this.minimumRangeValue) && Double.isNaN(this.maximumRangeValue);


