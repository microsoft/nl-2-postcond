// Ensures that the function can be inlined if it is called directly.
assert canInlineReferenceDirectly(callNode, fnNode) == CanInlineResult.YES
    || (canInlineReferenceDirectly(callNode, fnNode) == CanInlineResult.MAYBE
        // If the function can be inlined as a statement block, check if the
        // function can be inlined directly.
        && canInlineReferenceAsStatementBlock(
            t, callNode, fnNode, needAliases) == CanInlineResult.YES);


