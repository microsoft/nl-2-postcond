Here is the symbolic postcondition for canInlineReferenceDirectly:

// Postcondition: Ensures that if the method canInlineReferenceDirectly executes
// successfully as specified in the Javadoc, then the behavior of the code that
// follows it matches the documented behavior.
public void canInlineReferenceDirectly_postcondition() {
    final boolean callResult = canInlineReferenceDirectly(callNode, fnNode);
    assert (callResult == CanInlineResult.YES) == isDirectCallNodeReplacementPossible(fnNode);
}

This postcondition asserts that if canInlineReferenceDirectly returns CanInlineResult.YES, it is guaranteed that isDirectCallNodeReplacementPossible would also return true.


