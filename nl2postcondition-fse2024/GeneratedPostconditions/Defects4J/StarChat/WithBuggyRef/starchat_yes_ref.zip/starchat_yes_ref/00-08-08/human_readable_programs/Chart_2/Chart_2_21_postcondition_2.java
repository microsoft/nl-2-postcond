// The returned range should include both the lower and upper bounds of all
// values in the dataset, including y-intervals if the dataset is an
// IntervalXYDataset.
Range returnValue = iterateRangeBounds(dataset, true);
assert (returnValue.contains(dataset.getMinY()) &&
        returnValue.contains(dataset.getMaxY()));


