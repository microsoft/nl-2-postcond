// Ensures the label is drawn correctly when edge is TOP
assert(g2.getFontMetrics().stringWidth(label) <= dataArea.getWidth() - 2 * insets.getLeft()
&& g2.getFontMetrics().getHeight() <= dataArea.getHeight() - 2 * insets.getTop() 
&& g2.getFontMetrics().stringWidth(label) >= 0 
&& g2.getFontMetrics().getHeight() >= 0);


