// Postcondition: reset resets all member variables to their default values
assert (
    description == null &&
    argName == "arg" &&
    longopt == null &&
    type == null &&
    required == false &&
    numberOfArgs == Option.UNINITIALIZED &&
    optionalArg == false &&
    valuesep == (char) 0
);


