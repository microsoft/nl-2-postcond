import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Symbolic postcondition for the getChildBefore method of Node.java
 *
 * @param child The child node whose predecessor is being sought.
 * @return The node before child in the linked list, or null if child is the first node.
 */
public Node getChildBefore(Node child) {
    // Create a symbolic integer variable "index" to represent the index of child in the linked list.
    int index = 0;

    // If child is the first node, return null.
    if (child == first) {
        return null;
    }

    // Create a symbolic reference variable "n" to represent the current node in the linked list traversal.
    Node n = first;

    // Traverse the linked list until n references child.
    while (n.next!= child) {
        index++;
        n = n.next;
        // If n references the last node in the linked list, throw an exception.
        if (n == null) {
            throw new RuntimeException("node is not a child");
        }
    }

    // Create a symbolic boolean variable "found" to represent whether child was found in the linked list.
    boolean found = false;

    // Traverse the linked list again, setting found to true if we reach the node before child.
    while (n.next!= null) {
        if (n == child) {
            found = true;
        }
        n = n.next;
        index++;
    }

    // If child was not found, throw an exception.
    if (!found) {
        throw new RuntimeException("node is not a child");
    }

    // Create a symbolic reference variable "result" to represent the node before child in the linked list.
    Node result = null;

    // If child is not the first node, set result to the node before child.
    if (index > 0) {
        n = first;
        for (int i = 0; i < index - 1; i++) {
            n = n.next;
        }
        result = n;
    }

    // If result is null, return null. Otherwise, return result.
    if (result == null) {
        return null;
    } else {
        return result;
    }
}


