// Check that the method only adds variables to the scope
assert new HashSet<>(scope.getVarNames()).containsAll(toSet(names));

// Check that the method only removes variables from the scope
assert toSet(names).containsAll(new HashSet<>(scope.getVarNames()));

// Check that the method does not add variables to the scope if they already exist
assert!toSet(names).stream().anyMatch(scope::hasOwnVar);

// Check that the method does not remove variables from the scope if they do not exist
assert!scope.getVarNames().stream().anyMatch(s ->!toSet(names).contains(s));


