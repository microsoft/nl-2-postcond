// Ensures that if the marker is present, it will be removed from the domain axis
assert (removeDomainMarker(marker)?!containsDomainMarker(marker) : true);


