// Check that the method returns the expected string
assert generateToolTipFragment("This is a test") == " title=\"This is a test\" alt=\"\"";


