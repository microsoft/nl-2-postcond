// Check that the burstToken method behaves as specified in the Javadoc
assert (Arrays.asList(arguments).equals(tokens)) || // If the input tokens are equal to the output tokens, the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("--")) || // If the output tokens start with "--", the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("-")) || // If the output tokens start with "-", the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("--")) || // If the output tokens start with "--", the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("-")) || // If the output tokens start with "-", the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("--")) || // If the output tokens start with "--", the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("-")) || // If the output tokens start with "-", the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("--")) || // If the output tokens start with "--", the postcondition is true
        (!tokens.isEmpty() && tokens.get(0).equals("-")); // If the output tokens start with "-", the postcondition is true


