assert (returnValue!= null); // Postcondition: The method should always return a Node object


