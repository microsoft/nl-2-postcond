import java.util.ArrayList;
import java.util.List;

public class GnuParser {
  // Method you are writing a postcondition for:
  /**
   * This flatten method does so using the following rules:
   * 1. If an Option exists for the first character of the arguments entry AND an Option does not exist for the whole argument then add the first character as an option to the processed tokens list e.g. "-D" and add the rest of the entry to the also.
   * 2. Otherwise just add the token to the processed tokens list.
   * 
   * @param options The Options to parse the arguments by.
   * @param arguments The arguments that have to be flattened.
   * @param stopAtNonOption specifies whether to stop flattening when a non option has been encountered
   * @return a String array of the flattened arguments
   */
  protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
    List<String> tokens = new ArrayList<String>();
    boolean eatTheRest = false;
    for (int i = 0; i < arguments.length; i++) {
      String arg = arguments[i];
      if ("--".equals(arg)) {
        eatTheRest = true;
        tokens.add("--");
      } else if ("-".equals(arg)) {
        tokens.add("-");
      } else if (arg.startsWith("-")) {
        String opt = Util.stripLeadingHyphens(arg);
        if (options.hasOption(opt)) {
          tokens.add(arg);
        } else {
          if (options.hasOption(arg.substring(0, 2))) {
            tokens.add(arg.substring(0, 2));
            tokens.add(arg.substring(2));
          } else {
            eatTheRest = stopAtNonOption;
            tokens.add(arg);
          }
        }
      } else {
        tokens.add(arg);
      }
      if (eatTheRest) {
        for (int j = i + 1; j < arguments.length; j++) {
          tokens.add(arguments[j]);
        }
      }
    }
    String[] returnValue = new String[tokens.size()];
    return tokens.toArray(returnValue);
  }
}


