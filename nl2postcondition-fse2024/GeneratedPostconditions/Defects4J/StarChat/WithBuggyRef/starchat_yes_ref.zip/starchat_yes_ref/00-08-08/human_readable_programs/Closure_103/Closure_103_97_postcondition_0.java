import java.util.Map;

public class Test {
    private static class Example {
        private int a;
        private String b;
    }

    private static class TypeWithProperty {
        private boolean found;
        private String field;
        private JSType type;
        private JSType relatedType;
        private DisambiguateProperties.Property p;
        private JSTypeSystem jsTypeSystem;
        private Map<JSType, Map<String, JSType>> map;
    }

    public static void main(String[] args) {
        Example e = new Example();
        e.a = 5;
        e.b = "hello";
        TypeWithProperty twp = new TypeWithProperty();
        twp.found = false;
        twp.field = "a";
        twp.type = null;
        twp.relatedType = null;
        twp.p = null;
        twp.jsTypeSystem = null;
        twp.map = null;
        twp.jsTypeSystem.getTypeWithProperty(twp.field, twp.type);
        assert twp.found;
    }
}


