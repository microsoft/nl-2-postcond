import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class PosixParser {
    private List tokens = new ArrayList();
    private Options options;

    // Relevant context for the method:

    /**
     * An implementation of the method flatten.
     *
     * This method implements the flatten method from the Parser super class. It follows the same rules as the original
     * flatten method, with the following exceptions:
     *  - If the current arguments entry is "--", just add the entry to the list of processed tokens.
     *  - If the current arguments entry is "-", just add the entry to the list of processed tokens.
     *  - If the current arguments entry is two characters in length and the first character is "-", check if this is a
     *    valid Option id. If it is a valid id, then add the entry to the list of processed tokens and set the current
     *    Option member. If it is not a valid id and stopAtNonOption is true, then the remaining entries are copied to the
     *    list of processed tokens. Otherwise, the current entry is ignored.
     *  - If the current arguments entry is more than two characters in length and the first character is "-", then we need
     *    to burst the entry to determine its constituents. For more information on the bursting algorithm, see
     *    burstToken.
     *  - If the current arguments entry is not handled by any of the previous rules, then the entry is added to the list of
     *    processed tokens.
     * The method also has some other instance fields and methods, but they are not relevant for this postcondition.
     *
     * @param options The command line Options
     * @param arguments The command line arguments to be parsed
     * @param stopAtNonOption Specifies whether to stop flattening when an non option is found.
     * @return The flattened arguments String array.
     */
    protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
        init();
        this.options = options;
        Iterator iter = Arrays.asList(arguments).iterator();
        while (iter.hasNext()) {
            String token = (String) iter.next();
            if (token.startsWith("--")) {
                int pos = token.indexOf('=');
                String opt = pos == -1? token : token.substring(0, pos);

                // Check if the token is an option
                assert (options.hasOption(opt)) : "The option " + opt + " does not exist in the Options object";

                tokens.add(opt);
                if (pos!= -1) {
                    tokens.add(token.substring(pos + 1));
                }
            } else if ("-".equals(token)) {
                tokens.add(token);
            } else if (token.startsWith("-")) {
                if (token.length() == 2 || options.hasOption(token)) {
                    processOptionToken(token, stopAtNonOption);
                } else {
                    burstToken(token, stopAtNonOption);
                }
            } else if (stopAtNonOption) {
                processNonOptionToken(token);
            } else {
                tokens.add(token);
            }

            gobble(iter);
        }

        return (String[]) tokens.toArray(new String[tokens.size()]);
    }

    // Method you are writing a postcondition for:

    /**
     * If an Option exists for token, then add the token to the processed list.
     *
     * If an Option does not exist and stopAtNonOption is set, then add the remaining tokens to the processed tokens list
     * directly.
     *
     * @param token The current option token
     *


