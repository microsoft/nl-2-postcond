// Postcondition: Checks that the collection remains unchanged if the specified
// index is out of bounds or if the specified key is not present in the collection.
assert (index < 0 || index >= this.keys.size() ||!this.indexMap.containsKey(key)) 
    || returnValue == null;


