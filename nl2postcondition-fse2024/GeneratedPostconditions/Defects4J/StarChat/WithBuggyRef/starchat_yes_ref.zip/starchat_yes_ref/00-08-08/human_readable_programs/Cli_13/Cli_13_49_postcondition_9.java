// Ensures that the output command line contains all of the arguments from the input arguments list
assert commandLine.getValues(this).containsAll(arguments.stream().collect(Collectors.toList()));


