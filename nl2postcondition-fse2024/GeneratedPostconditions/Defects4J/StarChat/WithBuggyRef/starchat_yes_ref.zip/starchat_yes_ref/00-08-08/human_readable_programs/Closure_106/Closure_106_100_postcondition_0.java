assert canCollapseUnannotatedChildNames() == (
    (type == Type.OTHER || globalSets!= 1 || localSets!= 0)
    &&
    (
        (isClassOrEnum)
        ||
        (
            (type == Type.FUNCTION || aliasingGets == 0)
            &&
            (parent == null || parent.canCollapseUnannotatedChildNames())
        )
    )
);


