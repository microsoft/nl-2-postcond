// Ensures that the list of processed tokens contains the token "--" if
// the method burstToken adds any tokens to the list
assert (eatTheRest && tokens.contains("--")) || (!eatTheRest &&!tokens.contains("--"));


