// The postcondition states that the return value of the method should be a string buffer containing
// the rendered text, which is the original input text with line breaks inserted at the appropriate
// positions so that it fits within the specified width.
assert renderWrappedText(new StringBuffer(), 80, 0, "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")
   .equals(new StringBuffer("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt\n" +
                              "ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation\n" +
                              "ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in\n" +
                              "reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur\n" +
                              "sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit\n" +
                              "anim id est laborum."));


