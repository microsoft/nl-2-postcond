// Check that the normalized AST satisfies the invariants specified in the Javadoc
assert (returnValue!= null && returnValue.getType() == NodeType.ROOT && returnValue.hasOneChild() &&
        returnValue.getFirstChild().getType() == NodeType.BLOCK &&
        returnValue.getFirstChild().hasOneChild() &&
        returnValue.getFirstChild().getFirstChild().getType() == NodeType.VAR);


