// Postcondition: after calling flatten with the given arguments, the returned array should be sorted in alphabetical order.
assert (Arrays.equals(sortedArray, flatten(options, originalArray, false)));


