// Checks that when the method is called, the StringBuffer object buff contains a string that is a valid
// usage clause for the specified Option object. If the Option object is required, it should be enclosed
// in square brackets. The argument required is true if the Option object is required, and false otherwise.
assert (required? buff.toString().matches("\\[[-][-][A-Za-z0-9]*[ ]{0,2}<.*>\\]")) :
            buff.toString().matches("\\[-][-][A-Za-z0-9]*[ ]{0,2}<.*>");


