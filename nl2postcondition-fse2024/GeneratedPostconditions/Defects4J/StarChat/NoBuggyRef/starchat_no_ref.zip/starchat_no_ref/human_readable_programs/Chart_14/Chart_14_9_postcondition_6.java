public class XYPlot extends Plot implements ValueAxisPlot, Zoomable, RendererChangeListener, Cloneable, PublicCloneable, Serializable {

/*
 * The removeRangeMarker(int index, Marker marker, Layer layer, boolean notify) method removes a range marker for a specific dataset/renderer and sends a PlotChangeEvent to all registered listeners.
 *
 * Preconditions:
 *      index >= 0
 *      marker!= null
 *      layer!= null
 *      notify is a boolean
 *
 * Postcondition:
 *      If the method completes successfully, the following will be true:
 *          The range marker will be removed from the plot
 *          The PlotChangeEvent will be sent to all listeners
 *          The return value will be true
 *      Else, the following will be true:
 *          The PlotChangeEvent will not be sent to all listeners
 *          The return value will be false
 *
 */
public boolean removeRangeMarker ( int index, Marker marker, Layer layer, boolean notify ) {
    assert index >= 0 : "Index must be non-negative";
    assert marker!= null : "Marker cannot be null";
    assert layer!= null : "Layer cannot be null";
    assert notify!= null : "Notify cannot be null";
    if (... ) {
        // Code to remove the range marker and send the PlotChangeEvent
    } else {
        // Code to not remove the range marker and not send the PlotChangeEvent
    }
    return returnValue;
}
}


