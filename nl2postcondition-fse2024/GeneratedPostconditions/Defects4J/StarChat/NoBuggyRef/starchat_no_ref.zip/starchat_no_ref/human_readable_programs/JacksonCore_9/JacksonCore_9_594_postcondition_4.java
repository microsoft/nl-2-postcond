// Check that the input string value is a valid JSON string.
assert isValidJsonString(returnValue);


