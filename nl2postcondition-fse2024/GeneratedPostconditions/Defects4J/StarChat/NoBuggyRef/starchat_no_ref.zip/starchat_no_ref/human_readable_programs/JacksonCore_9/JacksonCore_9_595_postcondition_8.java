//The postcondition checks that the return value of this method is equal
//to the string passed in as the argument to the method
assert returnValue.equals(defValue);


