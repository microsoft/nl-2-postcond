// Postcondition:
// If the method call succeeds, then the return value is a type that represents the given class.
JavaType narrowedType = _narrow(SomeClass.class);
assert narrowedType.isTypeOrSubTypeOf(SomeClass.class);


