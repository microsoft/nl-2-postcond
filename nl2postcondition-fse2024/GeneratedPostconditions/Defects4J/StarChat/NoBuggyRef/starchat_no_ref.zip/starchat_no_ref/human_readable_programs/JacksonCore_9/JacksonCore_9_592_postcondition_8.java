// If the current token is a string token, then the return value is equal to the result of calling getText()
assert (_currToken == JsonToken.VALUE_STRING)? returnValue.equals(getText()) : true;


