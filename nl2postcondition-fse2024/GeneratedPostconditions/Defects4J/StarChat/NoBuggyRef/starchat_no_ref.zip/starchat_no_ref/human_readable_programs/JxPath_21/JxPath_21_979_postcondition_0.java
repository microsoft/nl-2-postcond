// Verify that if the property contains a collection, then the length of that
// collection is greater than or equal to 0.
assert (returnValue >= 0) : "If the property contains a collection, then its length must be non-negative.";


