// Check that the serialized form of the bean is a JSON object
assert (jgen.writeObject(returnValue) instanceof ObjectNode);


