// Check that the return value is equal to the input value
assert returnValue.equals(defValue);


