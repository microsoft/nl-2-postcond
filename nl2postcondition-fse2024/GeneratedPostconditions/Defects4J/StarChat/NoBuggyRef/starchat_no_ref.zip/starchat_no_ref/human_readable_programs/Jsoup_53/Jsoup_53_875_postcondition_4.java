import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class StringUtil {
    private static char[] specials = "{}[]().,;:-_!?@#$%^&*+=/\\|\"'";
    private static String[] specialStrings = {"{", "}", "[", "]", "(", ")", ".", ",", ";", ":", "-", "_", "!",
            "?", "@", "#", "$", "%", "^", "&", "*", "+", "=", "/", "\\", "|", "\"", "'", ""};

    private static int[] specialsInt = new int[specials.length];
    private static int[] specialStringsInt = new int[specialStrings.length];

    static {
        for (int i = 0; i < specials.length; i++) {
            specialsInt[i] = specials[i];
        }
        for (int i = 0; i < specialStrings.length; i++) {
            specialStringsInt[i] = specialStrings[i].charAt(0);
        }
    }

    public static boolean containsSpecial(String input) {
        for (int i : specialsInt) {
            if (input.indexOf((char) i)!= -1) {
                return true;
            }
        }
        for (int i : specialStringsInt) {
            if (input.indexOf((char) i)!= -1) {
                return true;
            }
        }
        return false;
    }

    private static boolean isBalanced(String input, char open, char close) {
        int count = 0;
        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == open) {
                count++;
            } else if (input.charAt(i) == close) {
                count--;
            }
            if (count < 0) {
                return false;
            }
        }
        return count == 0;
    }

    public static String chompBalanced(String input, char opener, char closer) {
        if (!isBalanced(input, opener, closer)) {
            return null;
        }
        int pos = 0;
        int depth = 0;
        while (pos < input


