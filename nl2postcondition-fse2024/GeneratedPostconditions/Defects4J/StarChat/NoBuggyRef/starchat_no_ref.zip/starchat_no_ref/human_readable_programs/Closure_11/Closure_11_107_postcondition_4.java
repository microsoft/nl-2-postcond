// Check that the value returned by visitGetProp is not null
assert returnValue!= null;


