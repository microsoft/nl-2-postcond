// Check that the returned value is either true or false
assert returnValue == true || returnValue == false;


