// Postcondition: The output tokens list contains the same elements as the input tokens list
assert(new ArrayList<String>(Arrays.asList(returnValue)).equals(tokens));


