// Check that the input parameter is the same as the field's type
assert durationField == this;


