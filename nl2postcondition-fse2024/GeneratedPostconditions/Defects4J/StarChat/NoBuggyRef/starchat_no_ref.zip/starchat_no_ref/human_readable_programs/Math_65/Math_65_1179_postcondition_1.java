// Check that the sum of the squares of the residuals equals the return value
assert Math.pow(residuals.stream().mapToDouble(r -> r*r).sum(), 0.5) == returnValue;


