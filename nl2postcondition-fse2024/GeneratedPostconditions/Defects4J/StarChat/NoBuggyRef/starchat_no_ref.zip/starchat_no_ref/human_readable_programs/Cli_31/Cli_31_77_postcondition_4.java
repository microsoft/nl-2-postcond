// Reset the member variables to their default values
assert returnValue == new OptionBuilder( );


