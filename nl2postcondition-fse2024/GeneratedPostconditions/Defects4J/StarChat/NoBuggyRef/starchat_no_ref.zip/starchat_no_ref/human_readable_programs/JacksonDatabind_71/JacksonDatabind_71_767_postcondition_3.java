// the method should return a StdKeyDeserializer for the provided class
assert StdKeyDeserializer.forType(Date.class) instanceof StdKeyDeserializer;


