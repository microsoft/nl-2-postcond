// Check that the specified marker is removed from the plot's range markers
assert!this.rangeMarkers.contains(new RangeMarkerEntry(index, marker, layer));


