// Postcondition: Returns the String value of the current token if the current token is a string,
// or the default value if the current token is null, JsonToken.VALUE_NULL, or not a scalar value.
assert (String) _currToken == JsonToken.VALUE_STRING || ((String) _currToken == null ||!_currToken.isScalarValue())?
    (String) _currToken : defaultValue;


