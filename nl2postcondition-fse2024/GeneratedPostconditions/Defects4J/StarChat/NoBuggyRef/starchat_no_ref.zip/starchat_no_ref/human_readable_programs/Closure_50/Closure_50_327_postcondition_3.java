assert (n.getType() == Token.CALL) ==> (returnValue.getType() == Token.STRING) && (returnValue.getString().equals(n.getFirstChild().getString()));


