// Ensures that the root mean square (RMS) value is always positive.
assert (returnValue >= 0);


