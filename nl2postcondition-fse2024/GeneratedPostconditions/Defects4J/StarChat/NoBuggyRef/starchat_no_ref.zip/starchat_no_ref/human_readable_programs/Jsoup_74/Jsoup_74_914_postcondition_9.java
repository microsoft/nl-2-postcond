// Ensures that the method appends the normalised whitespace correctly
assert (
    // Initial input string
    string!= null &&!string.isEmpty() &&
    // Whether to strip leading whitespace
    stripLeading!= null &&
    // Final output string
    (
        // If the stripLeading parameter is true, the leading whitespace should be removed
        (stripLeading && string.charAt(0) =='') ||
        // Otherwise, the leading whitespace should not be removed
        (!stripLeading && string.charAt(0)!='')
    ) &&
    // The output string should be appended to the StringBuilder correctly
    (
        // If the stripLeading parameter is true, the rest of the input string should be appended
        (stripLeading && accum.toString().endsWith(string.substring(1))) ||
        // Otherwise, the input string should be appended
        (!stripLeading && accum.toString().equals(string))
    )
);


