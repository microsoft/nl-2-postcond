// Ensures that when the removeRangeMarker method is called with the specified marker,
// the layer parameter is equal to the specified layer.
assert layer == marker.getLayer();


