// Find the min and max values in the range for the dataset.
Range range = findRangeBounds(dataset, includeInterval);
double minValue = range.getLowerBound();
double maxValue = range.getUpperBound();

// Check that the min and max values are equal.
assert minValue == maxValue : "The min and max values in the range are not equal.";

// Check that the min and max values are equal to the first data item in the dataset.
Comparable minValueFromData = dataset.getValue(0, 0);
Comparable maxValueFromData = dataset.getValue(0, dataset.getColumnCount() - 1);
assert minValueFromData.equals(maxValueFromData) : "The min and max values are not equal to the first data item in the dataset.";


