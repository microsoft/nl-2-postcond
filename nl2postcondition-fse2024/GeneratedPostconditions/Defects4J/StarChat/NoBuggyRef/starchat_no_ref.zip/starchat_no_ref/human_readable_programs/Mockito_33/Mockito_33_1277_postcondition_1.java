// The hasSameMethod method checks that the candidate method has the same name,
// and that the arguments passed to the method are equal to the arguments of the
// current method. It does not check whether the candidate method belongs to the
// same mock object or whether it has been verified.

assert hasSameMethod(candidate) == (getMethod().getName().equals(candidate.getMethod().getName()) &&
Arrays.equals(getArguments(), candidate.getArguments()));


