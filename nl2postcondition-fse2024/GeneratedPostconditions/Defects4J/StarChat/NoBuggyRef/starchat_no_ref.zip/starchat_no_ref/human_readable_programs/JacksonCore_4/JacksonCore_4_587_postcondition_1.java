import java.util.Arrays;

public final class TextBuffer {
    private final StringBuilder stringBuilder;
    private int currentSegmentLength;

    public TextBuffer() {
        this.stringBuilder = new StringBuilder();
        this.currentSegmentLength = 0;
    }

    public int getCurrentSegmentLength() {
        return this.currentSegmentLength;
    }

    public String toString() {
        return this.stringBuilder.toString();
    }

    /**
     * Method called to append a character to the current segment.
     *
     * @param character the character to append
     */
    public void append(char character) {
        this.stringBuilder.append(character);
        this.currentSegmentLength++;
    }

    /**
     * Method called to expand size of the current segment, to accommodate for more contiguous content. Usually only used when parsing tokens like names if even then.
     */
    public char[] expandCurrentSegment() {
        char[] currentSegment = this.stringBuilder.toString().toCharArray();
        this.stringBuilder.setLength(0);
        this.stringBuilder.append(currentSegment);
        // Double the current segment capacity
        this.stringBuilder.ensureCapacity(this.stringBuilder.capacity() * 2);
        // Update the current segment length
        this.currentSegmentLength = currentSegment.length;
        // Return the old segment
        return currentSegment;
    }

    // Your postcondition goes here
}


