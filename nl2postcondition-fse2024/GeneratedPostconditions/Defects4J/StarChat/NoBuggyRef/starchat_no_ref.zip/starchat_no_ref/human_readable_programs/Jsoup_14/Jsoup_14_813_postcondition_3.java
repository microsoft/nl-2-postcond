import java.util.ArrayList;
import org.jsoup.helper.Validate;

public class Read {
    public static ArrayList<String> read (Tokeniser t, CharacterReader r) {
        Validate.notNull(t);
        Validate.notNull(r);
        
        //Postcondition: The ArrayList returned by read() will not contain any null elements.
        ArrayList<String> output = new ArrayList<String>();
        while (true) {
            String token = t.read(r);
            if (token.equals("")) break;
            output.add(token);
        }
        return output;
    }
}


