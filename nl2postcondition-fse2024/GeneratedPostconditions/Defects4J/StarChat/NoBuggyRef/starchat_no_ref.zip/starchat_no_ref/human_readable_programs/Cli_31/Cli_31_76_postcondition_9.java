symbolic postcondition for appendOption

// Ensures that the string buffer is long enough to add the option string
assert buff.length() + option.getOpt().length() + option.getLongOpt().length() + 4 <= buff.capacity();

// If the option has a value, ensures that the string buffer is long enough to add the value string
if (option.hasArg()) {
    assert buff.length() + getArgName(option).length() + 2 <= buff.capacity();
}


