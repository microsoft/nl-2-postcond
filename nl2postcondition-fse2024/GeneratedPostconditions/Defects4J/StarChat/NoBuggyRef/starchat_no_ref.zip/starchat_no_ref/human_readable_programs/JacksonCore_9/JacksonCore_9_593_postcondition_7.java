assert _currToken == JsonToken.VALUE_STRING?
    // if token is a string, then getText() should never return null
    assertObjectsNotNull(getText()) :
    // otherwise, if token is not a string, then default value should be returned
    assertObjectsNotNull(defaultValue);


