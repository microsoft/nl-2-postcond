// Check that the objective function value is less than or equal to the value in the objective function row of the tableau
assert(returnValue.getValue() <= getEntry(getNumObjectiveFunctions(), 0));

In this example, the postcondition checks that the objective function value of the `returnValue` variable is less than or equal to the value in the first column of the objective function row of the tableau.


