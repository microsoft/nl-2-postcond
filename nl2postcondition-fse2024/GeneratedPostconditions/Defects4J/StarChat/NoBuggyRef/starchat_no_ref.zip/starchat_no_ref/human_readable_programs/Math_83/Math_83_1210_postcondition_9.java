Here is the symbolic postcondition:

assert ( ( getSolution()!= null ) && ( getSolution().getPoint()!= null ) ) : "Solution must have a non-null point";


