// Check that a marker is removed from the range axis and that the PlotChangeEvent is fired
assert removeRangeMarker(someMarker, someLayer, true) == true &&
       (someMarker.getAxis()!= getRangeAxis() ||
       !getRangeMarkers(someLayer).contains(someMarker)) &&
       fireChangeEvent() == true :
       "The range marker is not removed or the PlotChangeEvent is not fired";


