public int compareTo(DurationField durationField) {
    //Check if other object is an UnsupportedDurationField
    if(!(durationField instanceof UnsupportedDurationField)) {
        return 1;
    }
    
    //Otherwise return 0
    return 0;
}


