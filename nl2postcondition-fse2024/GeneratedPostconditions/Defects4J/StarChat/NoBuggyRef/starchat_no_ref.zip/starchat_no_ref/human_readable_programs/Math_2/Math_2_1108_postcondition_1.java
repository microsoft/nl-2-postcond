I would like to use the following as a starting point:

` // Check that the number of successes is greater than or equal to zero and less than or
            // equal to the population size.
            assert (numberOfSuccesses >= 0 && numberOfSuccesses <= populationSize);`

Can you please provide me with a symbolic postcondition that checks these conditions?


