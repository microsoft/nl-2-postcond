assert (subclass.isAssignableFrom(this.getRawClass())
        || this.getRawClass().isAssignableFrom(subclass)) :
        "Incompatible class types: " + this.getRawClass() + " and " + subclass;


