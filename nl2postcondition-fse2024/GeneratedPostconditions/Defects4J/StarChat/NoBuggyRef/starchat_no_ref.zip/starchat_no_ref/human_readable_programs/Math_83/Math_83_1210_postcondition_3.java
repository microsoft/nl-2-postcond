// Check that the solution is optimal and feasible
assert(Math.min(getDual(SimplexTableau.BASIC), 0.0) >= getObjectiveValue() - epsilon);


