// Check that the returned range contains all x-values in the dataset
assert RangeUtilities.containsAll(returnValue, getAllXValues(dataset, includeInterval));


