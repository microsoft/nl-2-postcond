private Node tryFoldArrayAccess(Node n, Node left, Node right) {
    // Precondition: left is an array literal
    Preconditions.checkArgument(left.getType() == Token.ARRAYLIT);
    
    // Postcondition: The array literal in left is not modified by this operation
    Node leftCopy = left.cloneTree();
    
    // Code that implements the operation
    Node result =...;
    
    // Check that the result is still an array literal
    Preconditions.checkArgument(result.getType() == Token.ARRAYLIT);
    
    // Check that the result is the same as the original array literal
    Preconditions.checkArgument(result.equals(leftCopy));
    
    // Return the result
    return result;
}


