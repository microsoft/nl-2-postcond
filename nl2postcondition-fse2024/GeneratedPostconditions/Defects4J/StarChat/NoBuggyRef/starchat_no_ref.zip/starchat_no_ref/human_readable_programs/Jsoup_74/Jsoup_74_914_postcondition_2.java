// Ensures that the output string contains no more than one consecutive space character
assert(returnValue.matches("(?<= ).*(?=$| )"));


