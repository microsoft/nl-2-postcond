// Check that if the property exists on the object, then the resulting type is
// the property's type
assert (childType.hasProperty(propName)? getJSType(n) == childType.getPropertyType(propName) : true);


