// Check that the string returned by getValueAsString() is a valid JSON string
assert isValidJsonString(returnValue);


