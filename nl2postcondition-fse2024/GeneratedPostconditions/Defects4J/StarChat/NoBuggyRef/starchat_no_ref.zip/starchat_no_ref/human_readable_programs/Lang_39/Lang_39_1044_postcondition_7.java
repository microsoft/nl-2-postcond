// Replaces all occurrences of Strings within another String.
// A null reference passed to this method is a no-op, or if any "search string" or "string to replace" is null, that replace will be ignored. 
// This will not repeat. For repeating replaces, call the overloaded method.

import java.util.Arrays;

public class Example {
    public static void main(String[] args) {
        String text = "abcabc";
        String[] searchList = {"a", "b"};
        String[] replacementList = {"d", "e"};
        
        String result = replaceEach(text, searchList, replacementList);
        System.out.println(result); // ddecebc
    }
    
    private static String replaceEach ( String text, String [ ] searchList, String [ ] replacementList )
    {
        assert (text!= null);
        assert (searchList!= null);
        assert (replacementList!= null);
        assert (searchList.length == replacementList.length);
        
        String result = text;
        for (int i = 0; i < searchList.length; i++) {
            String searchString = searchList[i];
            String replacement = replacementList[i];
            if (searchString!= null && replacement!= null) {
                result = result.replace(searchString, replacement);
            }
        }
        return result;
    }
}


