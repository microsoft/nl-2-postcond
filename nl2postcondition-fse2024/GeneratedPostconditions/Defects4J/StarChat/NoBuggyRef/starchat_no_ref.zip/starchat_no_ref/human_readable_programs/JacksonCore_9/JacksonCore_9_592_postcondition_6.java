import java.io.IOException;

public String getValueAsString() throws IOException {
    // Precondition: The current token is JsonToken.VALUE_STRING or a valid scalar value
    String result = getText();
    assert result == null || result.equals(getText()); // Postcondition: The result is equal to the result of calling getText()
    return result;
}


