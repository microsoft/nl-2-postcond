// the input list contains only string literals
assert (returnValue!= null && returnValue.getType() == Token.STRINGLIT)
    || (n.getType() == Token.ARRAYLIT
        && n.hasChildren()
        && NodeUtil.isStringNode(n.getFirstChild()));


