// The postcondition for getValueAsString checks that if the previous token is a token of type VALUE_STRING, the method returns the value of the corresponding text.
assert ((_currToken == JsonToken.VALUE_STRING) && (returnValue.equals(getText())));


