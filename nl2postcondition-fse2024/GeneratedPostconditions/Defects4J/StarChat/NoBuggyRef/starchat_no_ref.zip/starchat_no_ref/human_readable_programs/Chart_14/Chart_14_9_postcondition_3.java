assert ( //Comment explaining what aspect of the method the symbolic postcondition checks
(markers!= null && index >= 0 && index < markers.size()) || (index == markers.size() && marker == null)
) : "Index out of bounds or null marker";


