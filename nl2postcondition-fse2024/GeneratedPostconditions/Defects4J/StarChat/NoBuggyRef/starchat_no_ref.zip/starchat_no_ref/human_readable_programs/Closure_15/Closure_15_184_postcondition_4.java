Here's a possible symbolic postcondition for the apply method in the ControlFlowGraph.AbstractCfgNodeTraversalCallback interface:

import java.util.HashSet;
import java.util.Set;

import com.google.javascript.jscomp.Node;

public class SymbolicPostcondition {
    public static void checkPostcondition(ControlFlowGraph.AbstractCfgNodeTraversalCallback callback, Node node) {
        Set<Node> visited = new HashSet<Node>();
        Node returnedNode = callback.apply(node, visited);
        assert (returnedNode == node);
    }
}

This postcondition checks that the returnedNode is equal to the input node, and it also checks that the visited set is not modified by the method.


