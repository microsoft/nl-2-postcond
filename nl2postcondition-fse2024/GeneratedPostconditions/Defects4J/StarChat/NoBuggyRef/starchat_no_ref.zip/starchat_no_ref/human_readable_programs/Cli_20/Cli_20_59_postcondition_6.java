//The Javadoc indicates that the method's returned array should have the same length
//as the input array of arguments.
assert returnValue.length == arguments.length : "The returned array should have the same length as the input array";


