import java.io.File;
import java.io.IOException;

public class TarArchiveEntry {
    private final File file;

    public TarArchiveEntry(File file) {
        this.file = file;
    }

    public boolean isDirectory() {
        // Postcondition:
        // The return value is true if the entry represents a directory, and false otherwise.
        assert file.isDirectory() == isDirectory();
        return file.isDirectory();
    }
}


