// Check that the marker is in fact a domain marker and that it is in the list of domain markers for the specified layer
assert marker.isDomainMarker() : "The marker is not a domain marker";
assert layer.equals(Layer.FOREGROUND)? this.domainMarkers.get(index).contains(marker) : this.rangeMarkers.get(index).contains(marker) : "The specified marker does not belong to this plot";

// Check that the new domain minimum/maximum is not outside the data range
assert newValue >= this.dataRange.getLowerBound() && newValue <= this.dataRange.getUpperBound() : "The new value is outside the data range";

// Check that the new domain minimum is not greater than the maximum
assert newValue <= this.domainAxis.getUpperBound() && newValue >= this.domainAxis.getLowerBound() : "The new minimum value is outside the domain axis range";

// Check that the new domain maximum is not less than the minimum
assert newValue >= this.domainAxis.getLowerBound() && newValue <= this.domainAxis.getUpperBound() : "The new maximum value is outside the domain axis range";

// Check that the marker is not the only marker in the layer
assert (layer.equals(Layer.FOREGROUND)? this.domainMarkers.get(index).size() > 1 : this.rangeMarkers.get(index).size() > 1) : "The marker is the only marker in the specified layer";


