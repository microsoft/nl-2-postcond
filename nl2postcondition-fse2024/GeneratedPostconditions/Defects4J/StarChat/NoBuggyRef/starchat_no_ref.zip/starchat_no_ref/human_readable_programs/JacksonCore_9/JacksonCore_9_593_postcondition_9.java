// Check that the return value is either the expected result, or null if the input is null
assert (returnValue.equals(result) || (returnValue == null && input == null)) : "Returned value '" + returnValue + "' does not match expected result '" + result + "'";


