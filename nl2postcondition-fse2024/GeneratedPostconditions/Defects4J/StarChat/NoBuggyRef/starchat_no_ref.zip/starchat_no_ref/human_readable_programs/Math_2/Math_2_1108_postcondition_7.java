// Postcondition for the getNumericalMean() method in the HypergeometricDistribution class:
assert (
    // The population size N
    N > 0 &&
    // The number of successes m
    m >= 0 && m <= N &&
    // The sample size n
    n > 0 && n <= N
)? (
    // The mean is n * m / N
    n * m / N == returnValue
) : true;


