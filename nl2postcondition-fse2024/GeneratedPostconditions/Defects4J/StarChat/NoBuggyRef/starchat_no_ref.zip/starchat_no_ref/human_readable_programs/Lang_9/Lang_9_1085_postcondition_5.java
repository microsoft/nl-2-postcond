public class FastDateParser implements DateParser, Serializable {
    private static final Pattern formatPattern= Pattern.compile(
                "D+|E+|F+|G+|H+|K+|M+|S+|W+|Z+|a+|d+|h+|k+|m+|s+|w+|y+|z+|''|'[^']++(''[^']*+)*+'|[^'A-Za-z]++");
    // Serializing
    //-----------------------------------------------------------------------
        /**
         * Create the object after serialization. This implementation reinitializes the
         * transient properties.
         *
         * @param in ObjectInputStream from which the object is being deserialized.
         * @throws IOException if there is an IO issue.
         * @throws ClassNotFoundException if a class cannot be found.
         */
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
            in.defaultReadObject();
            init();
        }
        /**
         * Obtain a Strategy given a field from a SimpleDateFormat pattern
         * @param formatField A sub-sequence of the SimpleDateFormat pattern
         * @return The Strategy that will handle parsing for the field
         */
    private Strategy getStrategy(String formatField) {
            switch(formatField.charAt(0)) {
            case '\'':
                if(formatField.length()>2) {
                    formatField= formatField.substring(1, formatField.length()-1);
                }
            default:
                return new CopyQuotedStrategy(formatField);
            case 'D':
                return DAY_OF_YEAR_STRATEGY;
            case 'E':
                return DAY_OF_WEEK_STRATEGY;
            case 'F':
                return DAY_OF_WEEK_IN_MONTH_STRATEGY;
            case 'G':
                return ERA_STRATEGY;
            case 'H':
                return MODULO_HOUR_OF_DAY_STRATEGY;
            case 'K':
                return HOUR_STRATEGY;
            case 'M':
                return formatField.length()>=3?TEXT_MONTH_STRATEGY :NUMBER_MONTH_STRATEGY;
            case 'S':
                return MILLISECOND_STRATEGY;
            case 'W':
                return WEEK_OF_MONTH_STRATEGY;
            case 'Z':
                break;
            case 'a':
                return AM_PM_STRATEGY;
            case 'd':
                return DAY_OF_MONTH_STRATEGY;
            case 'h':
                return MODULO_HOUR_STRATEGY;
            case 'k':
                return HOUR_OF_DAY_STRATEGY;
            case'm':
                return MINUTE_STRATEGY;
            case's':
                return SECOND_STRATEGY;
            case 'w':
                return WEEK_OF_YEAR_STRATEGY;
            case 'y':
                return formatField.length()>2?LITERAL_YEAR_STRATEGY :ABBREVIATED_YEAR_STRATEGY;
            case 'z':
                break;
            }
            TimeZoneStrategy tzs= tzsCache.get(locale);
            if(tzs==null) {


