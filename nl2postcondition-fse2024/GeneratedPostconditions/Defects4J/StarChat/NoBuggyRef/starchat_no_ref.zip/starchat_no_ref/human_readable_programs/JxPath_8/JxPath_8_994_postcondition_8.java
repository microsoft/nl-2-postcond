// Check that the elements of the left collection are contained in the right collection
assert containsMatch(reduce(left), reduce(right));

// Iterate through the left collection and check that any element is contained in the right collection
assert findMatch(left.iterator(), right.iterator());


