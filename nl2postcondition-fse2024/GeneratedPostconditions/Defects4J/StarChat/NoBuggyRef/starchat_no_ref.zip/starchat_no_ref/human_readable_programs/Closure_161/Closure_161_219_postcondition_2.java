// Check that the array access is within bounds of the array
assert (right.getType() == Token.NUMBER && right.getDouble() >= 0 
        && right.getDouble() < left.getChildCount()) 
        : "The index is out of bounds";


