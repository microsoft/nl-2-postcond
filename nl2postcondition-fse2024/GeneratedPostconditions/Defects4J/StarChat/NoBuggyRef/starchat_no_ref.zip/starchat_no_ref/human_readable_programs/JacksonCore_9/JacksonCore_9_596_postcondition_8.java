import java.io.IOException;

public class UTF8StreamJsonParser {
    //...

    // Postcondition for the getValueAsString() method:
    // The returned string is a JSON value string.
    // If the method throws an IOException, the postcondition does not hold.
    private String postcondition_getValueAsString(String returnValue) {
        assert returnValue.startsWith("\"") && returnValue.endsWith("\"");
        return returnValue;
    }
}


