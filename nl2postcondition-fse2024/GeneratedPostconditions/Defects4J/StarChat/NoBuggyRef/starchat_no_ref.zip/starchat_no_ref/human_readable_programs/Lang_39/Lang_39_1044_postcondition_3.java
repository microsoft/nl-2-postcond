import java.util.*;

// Postcondition for the replaceEach method:
// Ensures that the returned string has the same length as the input string
// and that no replacements were made if the search list is null or empty
// and that the replacement list is the same length as the search list,
// and that all characters in the returned string were present in the input string.
public static void postconditionForReplaceEach(String text, String[] searchList, String[] replacementList) {
    int inputLength = text.length();
    int searchListLength = searchList == null? 0 : searchList.length;
    int replacementListLength = replacementList == null? 0 : replacementList.length;

    assert inputLength == (searchListLength == 0? text.length() : searchListLength) :
        "Input length must be equal to the length of the search list if the search list is not null or empty";

    assert inputLength == (replacementListLength == 0? text.length() : replacementListLength) :
        "Input length must be equal to the length of the replacement list if the replacement list is not null or empty";

    if (searchList!= null) {
        for (String searchString : searchList) {
            assert searchString!= null : "The search list cannot contain null values";
        }
    }

    if (replacementList!= null) {
        for (String replacementString : replacementList) {
            assert replacementString!= null : "The replacement list cannot contain null values";
        }
    }

    for (int i = 0; i < inputLength; i++) {
        char inputChar = text.charAt(i);

        boolean foundReplacement = false;
        if (searchList!= null) {
            for (int j = 0; j < searchList.length; j++) {
                String searchString = searchList[j];
                if (inputChar == searchString.charAt(0)) {
                    foundReplacement = true;
                    break;
                }
            }
        }

        if (!foundReplacement) {
            assert returnValue.charAt(i) == inputChar :
                "All characters in the returned string must be present in the input string";
        }
    }
}


