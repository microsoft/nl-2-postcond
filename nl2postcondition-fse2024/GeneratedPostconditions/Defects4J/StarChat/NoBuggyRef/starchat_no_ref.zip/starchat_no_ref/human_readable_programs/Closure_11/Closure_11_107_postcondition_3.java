import java.util.Objects;

public class TypeCheck implements NodeTraversal.Callback, CompilerPass {
    private final TypeValidator validator;
    
    private void report(NodeTraversal t, Node n, DiagnosticType diagnosticType,
          String... arguments) {
        if (noTypeCheckSection == 0) {
          t.report(n, diagnosticType, arguments);
        }
      }

    //Relevant Class Context:
    static com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE
    static com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE
    static com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE
    static com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE
    static com.google.javascript.rhino.jstype.JSTypeNative.OBJECT


