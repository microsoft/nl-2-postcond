// Check that the string value returned by the method is a valid JSON string.
assert isValidJsonString(returnValue);


