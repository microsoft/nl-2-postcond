assert (returnValue == null || (returnValue.charAt(0) == '\"' && returnValue.charAt(returnValue.length() - 1) == '\"')) :
    "When the method returns a non-null value, it must be enclosed in double quotes.";


