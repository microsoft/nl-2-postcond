import java.util.HashSet;
import java.util.Set;

import com.google.javascript.rhino.Node;
import com.google.javascript.jscomp.NodeTraversal;

public class SymbolicPostconditionForApplyMethod {
    public static void checkApplyPostcondition(NodeTraversal t, Node n, Set<Node> visited) {
        // This postcondition checks that after a node is visited, all its children
        // have been visited and added to the visited set.
        // The postcondition assumes that all nodes in the current scope have been
        // visited before the current node is visited.
        assert t.inScope(n) ==> (n.hasChildren() == visited.containsAll(n.children()));
    }
}


