//Check that the return value matches the declared return type of the method
assert(returnValue.getJSType().equals(getNativeType(type)));


