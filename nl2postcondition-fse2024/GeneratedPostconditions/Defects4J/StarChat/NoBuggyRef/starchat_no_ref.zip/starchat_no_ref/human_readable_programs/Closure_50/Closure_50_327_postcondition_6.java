// Postcondition:
assert n.getType() == Token.CALL;
String stringResult = "";
for (Node arg : n.getSecondChild().children()) {
  stringResult += arg.getString();
}
assert stringResult.equals(n.getFirstChild().getFirstChild().getString());


