// Ensure the returned string is a valid JSON string
assert(isValidJsonString(returnValue));

// Define the helper method isValidJsonString
public static boolean isValidJsonString(String str) {
    try {
        new JsonParser().parse(str);
        return true;
    } catch (JsonParseException e) {
        return false;
    }
}


