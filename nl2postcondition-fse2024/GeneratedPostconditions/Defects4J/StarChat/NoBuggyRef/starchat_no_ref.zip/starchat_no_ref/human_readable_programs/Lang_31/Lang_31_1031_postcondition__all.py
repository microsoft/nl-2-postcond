
# Response 0
import java.util.Arrays;

public static boolean containsAny(CharSequence cs, char[] searchChars) {
 // Postcondition: The return value of containsAny is true if and only if at least one of the characters in searchChars is found in the CharSequence cs.
    assert (searchChars!= null && searchChars.length > 0)? (Arrays.stream(searchChars).anyMatch(c -> cs.toString().contains(String.valueOf(c)))) : false;
    return false;
}



# Response 1
assert returnValue == (inputCs == null || searchChars == null || searchChars.length == 0 || searchArray.stream().anyMatch(inputCs::contains));



# Response 2
// Method you are writing a postcondition for:
    // ContainsAny
    //-----------------------------------------------------------------------
    /**
     * <p>Checks if the CharSequence contains any character in the given
     * set of characters.</p>
     *
     * <p>A <code>null</code> CharSequence will return <code>false</code>.
     * A <code>null</code> or zero length search array will return <code>false</code>.</p>
     *
     * <pre>
     * StringUtils.containsAny(null, *)                = false
     * StringUtils.containsAny("", *)                  = false
     * StringUtils.containsAny(*, null)                = false
     * StringUtils.containsAny(*, [])                  = false
     * StringUtils.containsAny("zzabyycdxx",['z','a']) = true
     * StringUtils.containsAny("zzabyycdxx",['b','y']) = true
     * StringUtils.containsAny("aba", ['z'])           = false
     * </pre>
     *
     * @param cs  the CharSequence to check, may be null
     * @param searchChars  the chars to search for, may be null
     * @return the <code>true</code> if any of the chars are found,
     * <code>false</code> if no match or null input
     * @since 2.4
     */
    public static boolean containsAny ( CharSequence cs, char [ ] searchChars )
    {
        assert cs!= null;
        assert searchChars!= null;
        
        for (char ch : searchChars) {
            if (cs.toString().contains(ch)) {
                return true;
            }
        }
        
        return false;
    }



# Response 3
import java.util.Objects;

public class SymbolicPostcondition {
  public static boolean containsAny(CharSequence cs, char[] searchChars) {
    Objects.requireNonNull(cs);
    Objects.requireNonNull(searchChars);
    char[] input = cs.toString().toCharArray();
    boolean contains = false;
    for (char c : searchChars) {
      for (char i : input) {
        if (c == i) {
          contains = true;
          break;
        }
      }
    }
    assert contains : "The return value of containsAny() is false when the input contains a character from the search set.";
    return contains;
  }
}



# Response 4
import java.util.Arrays;

//...

public static boolean containsAny(CharSequence cs, char[] searchChars) {
    assert (searchChars!= null) : "The search characters array cannot be null.";

    for (char c : searchChars) {
        if (cs.indexOf(c) >= 0) {
            return true;
        }
    }

    return false;
}



# Response 5
// Postcondition: Checks if the characters in the searchChars array are found in the input string
import java.util.Arrays;

assert (returnValue == false || Arrays.equals(searchChars, searchFor)) : "The searchChars array contains at least one character that was found in the input string";



# Response 6
// Checks if the CharSequence contains any character in the given set of characters.
//
// A null CharSequence will return false. A null or empty search string will return false.
assert (
    (cs == null && search == null) ||
    (cs!= null && search!= null &&!search.isEmpty() && cs.chars().anyMatch(c -> search.indexOf(c)!= -1))
);



# Response 7
// Check that the return value is true if the search string is found in the input string. 
// This checks the special case of an empty search string which should always return true.
assert (returnValue == true) || (cs == null || cs.length() == 0 || searchChars == null || searchChars.length == 0);



# Response 8
import java.util.Arrays;

public static boolean containsAny(CharSequence cs, char[] searchChars) {
    boolean result = false;
    if (cs!= null && searchChars!= null) {
        // The following loop checks if any of the characters in the searchChars array are found in the input string
        for (char c : searchChars) {
            if (cs.toString().indexOf(c)!= -1) {
                result = true;
                break;
            }
        }
    }
    assert result == (Arrays.asList(searchChars).contains(c));
    return result;
}



# Response 9
public static boolean containsAny(CharSequence cs, char[] searchChars) {
    if (cs == null || searchChars == null) {
        return false;
    }
    int csLen = cs.length();
    int searchLen = searchChars.length;
    if (searchLen == 0) {
        return false;
    }
    for (int i = 0; i < csLen; i++) {
        char ch = cs.charAt(i);
        for (int j = 0; j < searchLen; j++) {
            if (searchChars[j] == ch) {
                return true;
            }
        }
    }
    return false;
}


