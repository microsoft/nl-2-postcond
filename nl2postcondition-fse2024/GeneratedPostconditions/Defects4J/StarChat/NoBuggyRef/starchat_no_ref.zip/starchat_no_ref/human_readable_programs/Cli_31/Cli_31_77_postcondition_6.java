import java.util.Objects;

public final class OptionBuilder {
    private static void reset() {
        // postcondition:
        assert Objects.equals(returnValue, null);
    }
}


