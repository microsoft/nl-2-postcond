import java.util.Objects;

public class SymbolicPostcondition {
  public static boolean containsAny(CharSequence cs, char[] searchChars) {
    Objects.requireNonNull(cs);
    Objects.requireNonNull(searchChars);
    char[] input = cs.toString().toCharArray();
    boolean contains = false;
    for (char c : searchChars) {
      for (char i : input) {
        if (c == i) {
          contains = true;
          break;
        }
      }
    }
    assert contains : "The return value of containsAny() is false when the input contains a character from the search set.";
    return contains;
  }
}


