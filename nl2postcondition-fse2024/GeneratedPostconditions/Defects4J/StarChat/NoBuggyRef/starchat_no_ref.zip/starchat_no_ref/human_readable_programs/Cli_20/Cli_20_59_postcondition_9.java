import java.util.Iterator;
import java.util.List;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

public class PosixParser {
    private List tokens = new ArrayList();
    private Options options;
    private Option currentOption;
    private boolean eatTheRest;

    private void init() {
        eatTheRest = false;
        tokens.clear();
        currentOption = null;
    }

    private void gobble(Iterator iter) {
        if (eatTheRest) {
            while (iter.hasNext()) {
                tokens.add(iter.next());
            }
        }
    }

    private void process(String value) {
        if (currentOption!= null && currentOption.hasArg()) {
            if (currentOption.hasArg()) {
                tokens.add(value);
                currentOption = null;
            } else if (currentOption.hasArgs()) {
                tokens.add(value);
            }
        } else {
            eatTheRest = true;
            tokens.add("--");
            tokens.add(value);
        }
    }

    private void processOptionToken(String token, boolean stopAtNonOption) {
        if (options.hasOption(token)) {
            currentOption = options.getOption(token);
        } else if (stopAtNonOption) {
            eatTheRest = true;
        }

        tokens.add(token);
    }

    private void burstToken(String token, boolean stopAtNonOption) {
        for (int i = 1; i < token.length(); i++) {
            String ch = String.valueOf(token.charAt(i));

            if (options.hasOption(ch)) {
                tokens.add("-" + ch);
                currentOption = options.getOption(ch);

                if (currentOption.hasArg() && (token.length()!= (i + 1))) {
                    tokens.add(token.substring(i + 1));

                    break;
                }
            } else if (stopAtNonOption) {
                process(token.substring(i));
                break;
            } else {
                tokens.add(token);
                break;
            }
        }
    }

    // The postcondition:
    // Check that the list of processed tokens contains no duplicate options or values.
    private void checkNoDuplicates() {
        Set seenOptions = new HashSet();
        Set seenValues = new HashSet();
        for (int i = 0; i < tokens.size(); i++) {
            String token = (String) tokens.get(i);
            if (token.startsWith("-")) {
                if (!seenOptions.add(token)) {
                    assert false; // Duplicate option
                }
            } else if (!seenValues.add(token)) {
                assert false; // Duplicate value
            }
        }
    }

    // Body of the method:
    // Add all the tokens from the input arguments
    for (int i = 0; i < arguments.length; i++) {
        String token = arguments[i];
        burstToken(token, stopAtNonOption);
    }

    // Check for duplicates after all tokens have been processed
    checkNoDuplicates();

    // Return the processed tokens
    return (String[]) tokens.toArray(new String[tokens.size()]);
}


