// Check that the return value is positive
assert returnValue >= 0;


