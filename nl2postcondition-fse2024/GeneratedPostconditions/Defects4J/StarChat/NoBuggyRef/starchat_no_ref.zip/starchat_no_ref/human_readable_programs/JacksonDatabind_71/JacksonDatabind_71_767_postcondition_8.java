// Ensures that the return value is non-null
assert (returnValue!= null);


