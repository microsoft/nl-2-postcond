// Postcondition: Checks if the characters in the searchChars array are found in the input string
import java.util.Arrays;

assert (returnValue == false || Arrays.equals(searchChars, searchFor)) : "The searchChars array contains at least one character that was found in the input string";


