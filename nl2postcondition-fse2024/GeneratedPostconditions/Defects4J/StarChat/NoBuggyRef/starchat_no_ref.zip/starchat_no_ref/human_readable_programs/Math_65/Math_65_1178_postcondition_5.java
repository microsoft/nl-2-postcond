public class LeastSquaresOptimizer {

  public double getRMS() {
    // body of method
  }
}


