// Check that the return value is not null
assert returnValue!= null;

// Check that the length of the return value is greater than or equal to the original segment length
assert returnValue.length >= originalSegmentLength;

// Check that the first character of the return value is the same as the last character of the original segment
assert returnValue[0] == originalSegment[originalSegmentLength - 1];

// Check that all characters in the return value come after the first character of the original segment
for (int i = 0; i < originalSegmentLength - 1; i++) {
    assert returnValue[i] > originalSegment[0];
}


