import java.io.IOException;

// Check that the input string is well-formed JSON
assert isValidJSON(returnValue) : "return value is not valid JSON";


