import org.jfree.data.xy.XYDataset;

public class IterateDomainBounds {
    public static Range iterateDomainBounds(XYDataset dataset, boolean includeInterval) {
        // Precondition: dataset is non-null
        assert dataset!= null;

        Range result = null;

        // Postcondition: result is the range of all x-values in the dataset, including or excluding the interval
        assert result == findRange(dataset, includeInterval, dataset.getX(0));

        return result;
    }

    // helper method for finding the range of x-values
    private static Range findRange(XYDataset dataset, boolean includeInterval, double start) {
        double min = start;
        double max = start;

        if (dataset instanceof IntervalXYDataset) {
            // if the dataset is an interval dataset, make sure to include the interval in the range
            if (includeInterval) {
                min = dataset.getStartX(0);
                max = dataset.getEndX(0);
            } else {
                min = dataset.getX(0);
                max = min;
            }
        } else {
            // iterate over the remaining points in the dataset to find the overall range
            for (int i = 1; i < dataset.getItemCount(0); i++) {
                double x = dataset.getX(i);
                if (x < min) {
                    min = x;
                }
                if (x > max) {
                    max = x;
                }
            }
        }

        return new Range(min, max);
    }
}


