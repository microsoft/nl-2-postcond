public void serializeAsColumn ( Object bean, JsonGenerator jgen, SerializerProvider prov ) throws Exception {
    // Insert your code here
}


