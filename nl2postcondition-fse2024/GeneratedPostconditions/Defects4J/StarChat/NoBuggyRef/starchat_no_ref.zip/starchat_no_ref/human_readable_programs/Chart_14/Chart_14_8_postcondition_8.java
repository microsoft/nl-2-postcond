import java.util.List;
import org.jfree.chart.annotations.XYPointerAnnotation;
import org.jfree.chart.plot.Plot;

public class SymbolicPostcondition {
    public static void main(String[] args) {
        Plot plot = new Plot();
        List<XYPointerAnnotation> annotations = plot.getAnnotations();
        XYPointerAnnotation annotation = new XYPointerAnnotation("annotation", 0.5, 0.5);
        annotations.add(annotation);
        assert annotations.contains(annotation);
    }
}


