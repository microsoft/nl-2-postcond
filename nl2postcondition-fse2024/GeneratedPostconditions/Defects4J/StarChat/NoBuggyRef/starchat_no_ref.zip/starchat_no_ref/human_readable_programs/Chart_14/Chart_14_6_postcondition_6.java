/**
 * Comment explaining what aspect of the method the symbolic
 * postcondition checks.
 */
assert (returnValue == false && list.contains(marker)) ||
       (returnValue == true &&!list.contains(marker));


