import java.util.List;

public class FoldArrayJoin {

    /**
     * Try to fold an array join: ['a', 'b', 'c'].join('') -> 'abc';
     */
    public String foldArrayJoin(List<String> list) {
        assert (list.size() >= 1);
        String result = list.get(0);
        for (int i = 1; i < list.size(); i++) {
            result += list.get(i);
        }
        return result;
    }
}


