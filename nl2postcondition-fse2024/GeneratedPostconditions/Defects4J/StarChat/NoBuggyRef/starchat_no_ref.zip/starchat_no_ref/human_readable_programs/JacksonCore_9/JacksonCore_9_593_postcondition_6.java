assert (
    // If the current token is a string, then the return value is equal to the text of the token
    (_currToken == JsonToken.VALUE_STRING) == (returnValue.equals(getText()))
);


