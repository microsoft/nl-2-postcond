import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.spi.Parameters;

public static class BooleanOptionHandler extends OptionHandler<Boolean> {
    private static final Set<String> TRUES = Sets.newHashSet("true", "on", "yes", "1");
    private static final Set<String> FALSES = Sets.newHashSet("false", "off", "no", "0");

    @Override
    public int parseArguments(Parameters params) throws CmdLineException {
        String param = params.getParameter(0);
        if (!TRUES.contains(param) &&!FALSES.contains(param)) {
            throw new CmdLineException(owner, Messages.ILLEGAL_BOOLEAN_VALUE, param);
        }
        Boolean value = TRUES.contains(param);
        owner.setValue(value);
        return 1;
    }
}


