assert (sb == null && returnValue == null) || (sb!= null && returnValue!= null && returnValue.length() == sb.length() + 1 && returnValue.charAt(sb.length()) == ')');


