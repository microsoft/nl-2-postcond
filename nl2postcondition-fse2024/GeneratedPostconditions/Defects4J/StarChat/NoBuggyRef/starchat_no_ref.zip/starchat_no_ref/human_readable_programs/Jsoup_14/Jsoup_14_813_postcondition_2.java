// Postcondition: The input reader is positioned at the next character after the
// Unicode character sequence corresponding to a valid XML character reference. 
void read (Tokeniser t, CharacterReader r) {
    //... method body...
    char firstChar = r.consume();
    if (firstChar == '#') {
        //... method body...
    } else if (firstChar == '&') {
        //... method body...
    } else {
        r.Unconsume();
    }
    assert r.current() == firstChar;
}


