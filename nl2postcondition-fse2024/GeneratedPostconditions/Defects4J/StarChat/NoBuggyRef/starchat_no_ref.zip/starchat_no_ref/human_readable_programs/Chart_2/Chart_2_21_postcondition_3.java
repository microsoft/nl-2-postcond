public static Range iterateRangeBounds(XYDataset dataset, boolean includeInterval) {
    // Postcondition:
    // The result is null if the input dataset is null, otherwise it is a range containing the minimum and maximum values found in the dataset.
    // If the input dataset is a CategoryDataset, the interval parameter is ignored.
    // If the input dataset is not a CategoryDataset, and includeInterval is true, the y-intervals are taken into account when determining the minimum and maximum values.
    // If the input dataset is not a CategoryDataset, and includeInterval is false, only the y-values are used to determine the minimum and maximum values.
    assert (dataset == null)? (returnValue == null) : (
        (dataset instanceof CategoryDataset)? (returnValue.contains(findMin(dataset), findMax(dataset))) : (
            includeInterval? (returnValue.contains(findMinWithInterval(dataset), findMaxWithInterval(dataset))) : (returnValue.contains(findMinWithoutInterval(dataset), findMaxWithoutInterval(dataset)))
        )
    );
    return returnValue;
}


