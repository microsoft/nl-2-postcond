import java.util.Arrays;

// Ensures that the resulting partial has the correct values and fields
assert (Arrays.equals(returnValue.getFieldTypes(), types)) : "Returned Partial's field types do not match input types";
assert (Arrays.equals(returnValue.getValues(), values)) : "Returned Partial's values do not match input values";
assert (returnValue.getChronology().equals(chronology)) : "Returned Partial's chronology does not match input chronology";


