// Check that the return value is true if the search string is found in the input string. 
// This checks the special case of an empty search string which should always return true.
assert (returnValue == true) || (cs == null || cs.length() == 0 || searchChars == null || searchChars.length == 0);


