import java.util.List;

public class Postcondition {
    public static void main(String[] args) {
        List<String> names = List.of("Peter", "Paul", "Mary");
        names.sort((a, b) -> a.compareToIgnoreCase(b));
        assert names.equals(List.of("Mary", "Paul", "Peter")) : "Expected sorted names";
    }
}


