import java.util.HashSet;
import java.util.Set;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.LUDecomposition;
import org.apache.commons.math3.linear.RealMatrix;

public class SimplexTableau {
    private RealMatrix tableau;
    private int numArtificialVariables;
    private int numDecisionVariables;
    private LinearObjectiveFunction f;
    private boolean restrictToNonNegative;
    
    public SimplexTableau(LinearObjectiveFunction f, boolean restrictToNonNegative) {
        this.f = f;
        this.restrictToNonNegative = restrictToNonNegative;
        initialize();
    }
    
    public SimplexTableau(double[][] tableauData, boolean restrictToNonNegative) {
        this.tableau = new Array2DRowRealMatrix(tableauData);
        this.restrictToNonNegative = restrictToNonNegative;
        initialize();
    }
    
    public void setObjectiveFunction(LinearObjectiveFunction f) {
        this.f = f;
    }
    
    public void addRow(int row, double[] coefficients, double constant) {
        tableau.setRow(row, coefficients);
        tableau.setEntry(row, tableau.getColumnDimension() - 1, constant);
    }
    
    public void subtractRow(int row, int subtractRow, double factor) {
        for (int i = 0; i < tableau.getColumnDimension(); i++) {
            tableau.addToEntry(row, i, -factor * tableau.getEntry(subtractRow, i));
        }
    }
    
    public double getEntry(int row, int col) {
        return tableau.getEntry(row, col);
    }
    
    public int getRhsOffset() {
        return tableau.getColumnDimension() - 1;
    }
    
    public int getArtificialVariableOffset() {
        return numDecisionVariables;
    }
    
    public int getNegativeDecisionVariableOffset() {
        return numDecisionVariables + numArtificialVariables;
    }
    
    public int getOriginalNumDecisionVariables() {
        return numDecisionVariables;
    }
    
    public void initialize() {
        numDecisionVariables = tableau.getColumnDimension() - f.getNumCoefficients() - 1;
        
        numArtificialVariables = 0;
        for (int i = 0; i < numDecisionVariables; i++) {
            if (f.getCoefficients()[i] < 0) {
                numArtificialVariables++;
            }
        }
        
        double[] objectiveFunctionCoefficients = new double[numDecisionVariables + numArtificialVariables];
        for (int i = 0; i < numDecisionVariables; i++) {
            objectiveFunctionCoefficients[i] = f.getCoefficients()[i];
        }
        for (int i = 0; i < numArtificial


