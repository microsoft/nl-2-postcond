// The input strings are unchanged
assert text.equals(returnValue);


