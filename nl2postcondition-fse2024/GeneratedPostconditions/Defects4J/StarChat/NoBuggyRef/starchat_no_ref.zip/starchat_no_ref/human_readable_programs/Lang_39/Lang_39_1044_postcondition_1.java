// Postcondition: If any of the search strings or replacement strings are null,
// the output is unaffected
assert (searchList == null || searchList.length == 0 || replacementList == null || replacementList.length == 0) 
    || returnValue.equals(text);


