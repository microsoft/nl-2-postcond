assert (
    // Check that the input list is non-empty
   !tb.stack.isEmpty()
    // Check that the first element on the stack is an opening tag
    && tb.stack.peek().isTagName()
    // Check that the current element is a text node
    && t.isText()
    // Check that the text node is not empty
    &&!t.isBlank()
    // Check that the tag name of the current element is the same as the tag name on the top of the stack
    && tb.stack.peek().tagName().equals(t.tagName())
);


