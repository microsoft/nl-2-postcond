//The returned value and the "this" object must have the same type.
assert getJSType(returnValue).equals(getJSType(n.getJSDocInfo().getThisType()));


