// The return value of the apply method is the same as the input value n
assert apply(n) == n;


