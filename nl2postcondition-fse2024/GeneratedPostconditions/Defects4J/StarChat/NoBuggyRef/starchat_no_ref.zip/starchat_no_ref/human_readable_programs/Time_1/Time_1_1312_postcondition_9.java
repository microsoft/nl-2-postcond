// Ensures that the fields in the partial are in the same order as the input parameters
assert Arrays.equals(types, new DateTimeFieldType[] {DateTimeFieldType.monthOfYear(), DateTimeFieldType.dayOfMonth()});

// Ensures that the values in the partial are the same as the input parameters
assert Arrays.equals(values, new int[] {12, 23});

// Ensures that the chronology in the partial is the same as the input parameter
assert (chronology == null)? (this.chronology == ISOChronology.getInstance()) : (this.chronology == chronology);


