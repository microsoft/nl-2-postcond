// Ensures that, if the "verbose" option is set, the "logLevel" parameter is set to a valid value
assert (isVerbose() && logLevel!= null && VERBOSITY_LEVELS.contains(logLevel))
       || (!isVerbose() && logLevel == null);


