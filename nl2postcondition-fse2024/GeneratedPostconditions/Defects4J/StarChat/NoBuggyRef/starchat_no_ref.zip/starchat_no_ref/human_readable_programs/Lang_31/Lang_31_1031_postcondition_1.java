assert returnValue == (inputCs == null || searchChars == null || searchChars.length == 0 || searchArray.stream().anyMatch(inputCs::contains));


