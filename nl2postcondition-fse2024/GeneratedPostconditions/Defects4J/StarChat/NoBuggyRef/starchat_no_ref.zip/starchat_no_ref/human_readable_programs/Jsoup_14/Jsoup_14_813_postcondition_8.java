void read ( Tokeniser t, CharacterReader r )
// Postcondition:
// The input CharacterReader is not null.
assert r!= null;


