// Check that all the residuals are independent and identically distributed (i.i.d) normal with mean 0 and variance 1/weight
double sumOfResiduals = 0;
for (int i = 0; i < observations.length; i++) {
    double residual = observations[i] - predicted[i];
    sumOfResiduals += residual * residual / weights[i];
}
assert Math.abs(sumOfResiduals - returnValue) <= 1.0e-10 * sumOfResiduals : "The sum of residuals does not approximately match the method output";


