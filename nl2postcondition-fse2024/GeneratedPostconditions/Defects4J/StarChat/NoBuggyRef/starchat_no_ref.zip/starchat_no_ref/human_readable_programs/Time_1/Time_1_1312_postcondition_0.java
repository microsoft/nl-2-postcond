// Postcondition: assert that the types and values arrays have the same length
assert types.length == values.length;


