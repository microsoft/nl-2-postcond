assert Math.abs(linearCombination(a, b) - sumOfProducts(a, b)) < 1e-15 :
    "The linear combination does not match the sum of the products for " +
    "all indices i where a[i] and b[i] are non-zero.";


