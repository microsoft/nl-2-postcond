// Check that the return value is either the value of the
// "value" field in the JSON object, or the defValue parameter
assert (returnValue == defValue) || returnValue.equals(jsonObject.get("value").toString());


