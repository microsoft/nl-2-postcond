assert Arrays.equals(types, new DateTimeFieldType[] { DateTimeFieldType.dayOfMonth(), DateTimeFieldType.monthOfYear(), DateTimeFieldType.year() }) : 
    "Types must be the fields in order of largest to smallest, but got " + Arrays.toString(types);
assert Arrays.equals(values, new int[] { 1, 2, 3 }) : "Values must be specified in the order of the corresponding types, but got " + Arrays.toString(values);
assert chronology.equals(ISOChronology.getInstance()) : "Chronology must be ISO, but got " + chronology.toString();
// Check that the fields are valid and in the correct order
for (int i = 0; i < types.length - 1; i++) {
    // Check that each field is greater than or equal to the previous field
    assert types[i].compareTo(types[i + 1]) <= 0 : "Field " + types[i] + " is not greater than or equal to field " + types[i + 1];
    // Check that the value for each field is valid
    assert values[i] > 0 : "Value for field " + types[i] + " must be positive, but got " + values[i];
}


