// Postcondition:
    // Check that the expected number of residuals are provided.
    assert (residuals.length == weights.length);


