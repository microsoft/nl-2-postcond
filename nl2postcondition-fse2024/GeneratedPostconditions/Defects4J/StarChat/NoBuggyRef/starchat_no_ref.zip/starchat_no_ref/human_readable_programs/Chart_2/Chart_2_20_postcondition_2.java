public static Range iterateDomainBounds(XYDataset dataset, boolean includeInterval) {
    // 1. Collect information about `dataset`
    Set<Double> xValues = new HashSet<>();
    for (int seriesIndex = 0; seriesIndex < dataset.getSeriesCount(); seriesIndex++) {
        if (dataset.isSeriesVisible(seriesIndex)) {
            for (int itemIndex = 0; itemIndex < dataset.getItemCount(seriesIndex); itemIndex++) {
                if (includeInterval) {
                    xValues.add(dataset.getXValue(seriesIndex, itemIndex));
                    xValues.add(dataset.getXValue(seriesIndex, itemIndex));
                } else {
                    xValues.add(dataset.getXValue(seriesIndex, itemIndex));
                }
            }
        }
    }
    
    // 2. Return the range of x-values, or null if the dataset is empty
    if (xValues.isEmpty()) {
        return null;
    } else {
        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        for (double x : xValues) {
            min = Math.min(min, x);
            max = Math.max(max, x);
        }
        return new Range(min, max);
    }
}

assert (returnValue == null && xValues.isEmpty()) || (returnValue!= null &&!xValues.isEmpty() && returnValue.contains(min) && returnValue.contains(max));


