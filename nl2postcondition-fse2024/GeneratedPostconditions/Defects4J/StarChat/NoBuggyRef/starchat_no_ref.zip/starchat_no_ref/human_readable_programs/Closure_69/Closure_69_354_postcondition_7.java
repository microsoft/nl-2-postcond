// ensure that the return value of the visitCall method is an array type
assert returnValue.isArrayType();


