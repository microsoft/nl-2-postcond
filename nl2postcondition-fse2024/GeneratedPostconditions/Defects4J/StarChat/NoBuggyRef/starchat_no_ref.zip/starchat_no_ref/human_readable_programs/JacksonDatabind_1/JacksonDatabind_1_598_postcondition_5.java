Here is a possible symbolic postcondition for the serializeAsColumn method:

//Check that the value returned by get() is serializable by the given serializer
assert(returnValue == null || returnValue instanceof Serializable);


