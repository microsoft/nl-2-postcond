assert:

// Postcondition: If the method returns true, the entry represents a directory
if (returnValue) {
    // The entry's name ends with a slash
    assert name.endsWith("/");
}


