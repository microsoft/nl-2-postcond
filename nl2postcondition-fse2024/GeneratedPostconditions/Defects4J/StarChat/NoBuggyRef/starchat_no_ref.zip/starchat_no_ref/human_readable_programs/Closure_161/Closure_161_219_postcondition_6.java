/**
 * Try to fold array-element. e.g [1, 2, 3][10];
 */
private Node tryFoldGetElem(Node n, Node left, Node right) {
    Preconditions.checkArgument(n.getType() == Token.GETELEM);

    if (left.getType() == Token.OBJECTLIT) {
      return tryFoldObjectPropAccess(n, left, right);
    }

    if (left.getType() == Token.ARRAYLIT) {
      // Postcondition: Check that the index is within bounds
      assert 0 <= right.getDouble() && right.getDouble() < left.size();

      // Calculate the folded value
      int index = (int) right.getDouble();
      Node foldedValue = left.get(index);

      // Check for a constant value
      if (foldedValue.isConst()) {
        return foldedValue;
      }

      return n;
    }
    return n;
  }


