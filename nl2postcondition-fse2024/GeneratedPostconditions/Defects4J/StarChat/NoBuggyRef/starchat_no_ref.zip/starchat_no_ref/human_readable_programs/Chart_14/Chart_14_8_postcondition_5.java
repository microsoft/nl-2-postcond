assert (returnValue == true) ==> (getDomainMarkers(layer).contains(marker) == false);


