Here's a symbolic postcondition for the private Integer getBasicRow(final int col, boolean ignoreObjectiveRows) method from the SimplexTableau class:

// Postcondition: The returned row is the basic row for the variable at the given column, or null if the variable is not basic
assert (returnValue == null &&!isBasic(col)) || (returnValue!= null && isBasic(returnValue, col));

This postcondition checks that the returned row is either null or a basic row for the variable at the given column, depending on whether the variable is basic or not.


