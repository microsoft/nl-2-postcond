import static java.lang.Boolean.TRUE;
import static java.lang.Boolean.FALSE;

import com.google.common.base.Preconditions;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;

public class TryFoldArrayAccess {
    private Node tryFoldArrayAccess(Node n, Node left, Node right) {
        // Check that the input Node is of type GETELEM
        Preconditions.checkArgument(n.getType() == Token.GETELEM);
        
        // Check that the left Node is of type ARRAYLIT
        Preconditions.checkArgument(left.getType() == Token.ARRAYLIT);
        
        // Check that the right Node is a number
        Preconditions.checkArgument(right.getType() == Token.NUMBER);
        double indexValue = right.getDouble();
        
        // Check that the index value is an integer
        Preconditions.checkArgument(Double.isFinite(indexValue));
        int index = (int) indexValue;
        
        // Check that the index is within the bounds of the array
        Preconditions.checkArgument(0 <= index && index < left.getChildCount());
        
        // If all checks pass, return the element at the specified index
        return left.getChildAtIndex(index);
    }
}


