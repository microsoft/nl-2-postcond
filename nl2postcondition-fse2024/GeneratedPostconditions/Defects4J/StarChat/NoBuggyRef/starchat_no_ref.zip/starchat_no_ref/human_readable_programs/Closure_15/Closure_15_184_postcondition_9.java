// Postcondition: Checks that, if the traversal has not yet returned from a recursive call to
// apply, the node's dominance frontier is empty.
assert (this.hasReturnedFromRecursiveCall == false) || (this.currentNode.getDominanceFrontier().size() == 0);


