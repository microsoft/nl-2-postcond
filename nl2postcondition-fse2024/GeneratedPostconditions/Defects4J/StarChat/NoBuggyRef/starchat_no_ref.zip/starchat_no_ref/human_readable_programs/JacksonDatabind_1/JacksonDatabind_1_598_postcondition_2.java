//The list of columns in the JsonArray must be the same length as the input list of beans
assert returnValue.size() == inputList.size() : "The list of columns in the JsonArray must be the same length as the input list of beans";


