// Postcondition: The member variables are reset to their default values.
assert reset() == defaultValue;


