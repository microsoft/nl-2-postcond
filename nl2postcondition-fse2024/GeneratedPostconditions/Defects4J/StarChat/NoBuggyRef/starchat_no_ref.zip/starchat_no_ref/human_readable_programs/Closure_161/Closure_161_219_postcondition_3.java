private Node tryFoldArrayAccess ( Node n, Node left, Node right ) {
    // Postcondition: Array access is only possible on arrays of constant integer expressions
    assert isIntegerConstant(left.getChildAtIndex(0)) : "Array element access requires constant integer indices";
    assert isIntegerConstant(right.getChildAtIndex(0)) : "Array element access requires constant integer indices";
    // Other postconditions go here
    //...
}


