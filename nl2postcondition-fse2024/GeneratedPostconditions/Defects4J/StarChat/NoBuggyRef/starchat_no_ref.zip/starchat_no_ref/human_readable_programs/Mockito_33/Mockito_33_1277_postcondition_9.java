assert hasSameMethod(candidate) == (
        // Check that the method names are the same
        getMethod().getName().equals(candidate.getMethod().getName()) &&
        // Check that the mocks are the same
        getInvocation().getMock() == candidate.getMock() &&
        // Check that the method is not overloaded
       !hasOverloadedMethod(candidate) &&
        // Check that the arguments are the same, ignoring any nulls
        argumentsMatch(candidate.getArguments())
);


