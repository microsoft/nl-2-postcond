// The input parameter defValue can be null
assert (returnValue == null || defValue == null || returnValue.equals(defValue)) :
    "Expected return value of " + returnValue + " to equal " + defValue + " when default value is specified";


