public static void assertSolutionPostcondition() {
  assert (returnValue!= null);
}


