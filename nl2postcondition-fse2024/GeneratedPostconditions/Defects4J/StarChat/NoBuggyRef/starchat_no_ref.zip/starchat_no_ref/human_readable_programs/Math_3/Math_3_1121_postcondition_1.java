// Check that the arrays are the same size
assert a.length == b.length : "Arrays must be the same size";

// Create a sum variable to hold the sum of the products
double sum = 0;

// Loop through the arrays and add up the products
for (int i = 0; i < a.length; i++) {
    sum += a[i] * b[i];
}

// Check that the sum of the products is equal to the return value
assert returnValue == sum : "Sum of products does not match return value";


