import java.util.Arrays;

public static boolean containsAny(CharSequence cs, char[] searchChars) {
 // Postcondition: The return value of containsAny is true if and only if at least one of the characters in searchChars is found in the CharSequence cs.
    assert (searchChars!= null && searchChars.length > 0)? (Arrays.stream(searchChars).anyMatch(c -> cs.toString().contains(String.valueOf(c)))) : false;
    return false;
}


