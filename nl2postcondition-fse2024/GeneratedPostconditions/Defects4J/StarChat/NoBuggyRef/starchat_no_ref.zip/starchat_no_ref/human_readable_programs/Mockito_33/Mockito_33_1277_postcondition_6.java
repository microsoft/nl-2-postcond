public class InvocationMatcher implements PrintableInvocation, PrintingFriendlyInvocation, CapturesArgumensFromInvocation, Serializable {
    private final Invocation invocation;
    
    public boolean matches(Invocation actual) {
            return invocation.getMock().equals(actual.getMock())
                    && hasSameMethod(actual) // New postcondition
                    && new ArgumentsComparator().argumentsMatch(this, actual);
        }
        /**
         * similar means the same method name, same mock, unverified 
         * and: if arguments are the same cannot be overloaded
         */
    public boolean hasSimilarMethod(Invocation candidate) {
            String wantedMethodName = getMethod().getName();
            String currentMethodName = candidate.getMethod().getName();
            
            final boolean methodNameEquals = wantedMethodName.equals(currentMethodName);
            final boolean isUnverified =!candidate.isVerified();
            final boolean mockIsTheSame = getInvocation().getMock() == candidate.getMock();
            final boolean methodEquals = hasSameMethod(candidate);
    
            if (!methodNameEquals ||!isUnverified ||!mockIsTheSame) {
                return false;
            }
    
            final boolean overloadedButSameArgs =!methodEquals && safelyArgumentsMatch(candidate.getArguments());
    
            return!overloadedButSameArgs;
        }
    
    //Method you are writing a postcondition for:
    
    public boolean hasSameMethod ( Invocation candidate ) {
        // Where the body of the method goes
    }

    // Postcondition for hasSameMethod:

    // Check that candidate is not null
    assert candidate!= null;

    // Obtain the method from the invocation object on which this method is being called
    Method method = getInvocation().getMethod();

    // Obtain the method from the candidate invocation object on which this method is being called
    Method candidateMethod = candidate.getMethod();

    // Check that the method names of the invocation object and the candidate invocation object are the same
    assert method.getName().equals(candidateMethod.getName());

    // Check that the declaring class of the method object and the candidate method object are the same
    assert method.getDeclaringClass().equals(candidateMethod.getDecl


