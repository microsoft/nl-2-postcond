// Check that the solution vector is a basic feasible solution
assert(this.isFeasibleSolution(this.getSolution().getPoint()));


