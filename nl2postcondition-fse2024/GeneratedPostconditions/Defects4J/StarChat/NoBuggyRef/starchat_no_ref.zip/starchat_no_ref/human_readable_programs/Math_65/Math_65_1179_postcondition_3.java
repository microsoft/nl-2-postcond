assert getChiSquare() >= 0 : "Chi-Square value must be non-negative";


