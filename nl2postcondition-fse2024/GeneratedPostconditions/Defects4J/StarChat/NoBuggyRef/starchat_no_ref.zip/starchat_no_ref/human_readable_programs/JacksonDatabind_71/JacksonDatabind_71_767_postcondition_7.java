I'm sorry, but I'm not sure I understand what you mean by "natural language comment or Javadoc." Can you rephrase your question?


