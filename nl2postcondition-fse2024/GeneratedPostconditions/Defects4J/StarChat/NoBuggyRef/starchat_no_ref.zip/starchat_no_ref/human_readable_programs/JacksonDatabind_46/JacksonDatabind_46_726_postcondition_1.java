// check that the input StringBuilder object is not null
assert (sb!= null);

// create a new StringBuilder object to store the generic signature
StringBuilder genericSignature = new StringBuilder();

// get the generic signature of the referenced type and store it in the 'genericSignature' StringBuilder
genericSignature.append(_referencedType.getGenericSignature(genericSignature));

// check that the returned StringBuilder object is equal to the 'genericSignature' StringBuilder
assert (sb.equals(genericSignature));


