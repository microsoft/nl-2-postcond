//The value returned by getValueAsString is stored in the variable "returnValue"
assert (returnValue == null || (returnValue.matches("^\".*\"$") && returnValue.charAt(0) == '\"' && returnValue.charAt(returnValue.length() - 1) == '\"') || (returnValue.matches("^'.*'$") && returnValue.charAt(0) == '\'' && returnValue.charAt(returnValue.length() - 1) == '\'')) : "The value returned by getValueAsString must be enclosed in double quotes if it is a string, or enclosed in single quotes if it is a character. Any other value should be returned without quotes.";


