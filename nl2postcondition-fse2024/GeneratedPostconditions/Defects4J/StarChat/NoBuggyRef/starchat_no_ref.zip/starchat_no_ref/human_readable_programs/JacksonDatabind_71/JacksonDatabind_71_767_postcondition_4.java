// Ensures that when the forType method is called, it always returns a StdKeyDeserializer
// object that can be used to deserialize objects of the specified type.
assert (returnValue instanceof StdKeyDeserializer) :
    "The forType method did not return an instance of StdKeyDeserializer."
    + " Instead, it returned a " + returnValue.getClass().getName() + " object.";


