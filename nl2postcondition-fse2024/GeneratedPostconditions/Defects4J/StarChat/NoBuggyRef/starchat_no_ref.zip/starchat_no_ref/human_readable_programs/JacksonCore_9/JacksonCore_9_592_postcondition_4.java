assert (_currToken == JsonToken.VALUE_STRING) ==> (returnValue.equals(getText()));


