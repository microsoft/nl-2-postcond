// Postcondition: The return value of apply is true if and only if the supplied node is a CALL node
assert(this.apply(n) == (n.getType() == NodeType.CALL));


