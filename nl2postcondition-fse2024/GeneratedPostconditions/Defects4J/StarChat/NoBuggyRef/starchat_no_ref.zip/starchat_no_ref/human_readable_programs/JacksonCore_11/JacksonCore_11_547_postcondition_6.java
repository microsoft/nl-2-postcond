import java.util.Arrays;
import java.util.ArrayList;

public class ByteQuadsCanonicalizer {
    //Relevant Class Context:

    public final class ByteQuadsCanonicalizer {
        //Relevant Class Context:

        private ArrayList<String> _symbols;
        private ArrayList<byte[]> _symbolBytes;

        private int _hashSize;
        private int _secondaryStart;
        private int _tertiaryStart;
        private int _tertiaryShift;
        private int _spilloverEnd;
        private int[] _hashArea;
        private int _count;
        private boolean _needRehash;
        private boolean _hashShared;
        private boolean _intern;

        public ByteQuadsCanonicalizer() {
            this(16);
        }

        public ByteQuadsCanonicalizer(int size) {
            _symbols = new ArrayList<String>(size);
            _symbolBytes = new ArrayList<byte[]>(size);
            _hashSize = size;
            _secondaryStart = size << 2;
            _tertiaryStart = _secondaryStart + (_secondaryStart >> 1);
            _tertiaryShift = _calcTertiaryShift(size);
            _spilloverEnd = 0;
            _hashArea = new int[_tertiaryStart + (_hashSize << 3)];
            _count = 0;
            _needRehash = false;
            _hashShared = false;
            _intern = true;
        }

        public String addName(String name, int q1) {
            _verifySharing();
            if (_intern) {
                name = InternCache.instance.intern(name);
            }
            int offset = _findOffsetForAdd(calcHash(q1));
            _hashArea[offset] = q1;
            _hashArea[offset+3] = 1;
            _symbols.add(name);
            _symbolBytes.add(null);
            ++_count;
            _verifyNeedForRehash();
            return name;
        }

        public String addName(String name, int q1, int q2) {
            _verifySharing();
            if (_intern) {
                name = InternCache.instance.intern(name);
            }
            int hash = (q2 == 0)? calcHash(q1) : calcHash(q1, q2);
            int offset = _findOffsetForAdd(hash);
            _hashArea[offset] = q1;
            _hashArea[offset+1] = q2;
            _hashArea[offset+3] = 2;
            _symbols.add(name);
            _symbolBytes.add(null);
            ++_count;
            _verifyNeedForRehash();
            return name;
        }

        public String addName(String name, int q1, int q2, int q3) {
            _verifySharing();
            if (_intern) {
                name = InternCache.instance.intern(name);
            }
            int offset = _findOffsetForAdd(calcHash(q1, q2, q3));
            _hashArea[offset] = q1;
            _hashArea[offset+1] = q2;
            _hashArea[offset+2] = q3;
            _hashArea[offset+3] = 3;
            _symbols.add(name);
            _symbolBytes.add(null);
            ++_count;
            _verifyNeedForRehash();
            return name;
        }

        public String addName(String name, int[] q, int qlen) {
            _verifySharing();
            if (_intern) {
                name = InternCache.instance.intern(name);
            }
            int offset;

            switch (qlen) {
            case 1: {
                offset = _findOffsetForAdd(calcHash(q[0]));
                _hashArea[offset] = q[0];
                _hashArea[offset+3] = 1;
            }
            break;
            case 2: {
                offset = _findOffsetForAdd(calcHash(q[0], q[1]));
                _hashArea[offset] = q[0];
                _hashArea[offset+1] = q[1];
                _hashArea[offset+3] = 2;
            }
            break;
            case 3: {
                offset = _findOffsetForAdd(calcHash(q[0], q[1], q[2]));
                _hashArea[offset] = q[0];
                _hashArea[offset+1] = q[1];


