/**
 * Recursively processes tokens.
 *
 * @param t The token to process
 * @param tb The TreeBuilder to use while processing
 * @return true if the token was consumed, false if not
 */
public boolean process(Token t, TreeBuilder tb) {
    // Create a child node for the current token
    Node node = tb.createChildNode(t);

    // Check if the token is a start tag
    if (t.isStartTag()) {
        // Add the child node to the document's structure
        tb.insert(node);

        // Check if the tag should be processed further
        if (!tb.process(node, t)) {
            // If not, remove the child node from the document's structure
            tb.remove(node);
        }
    } else if (t.isEndTag()) {
        // If the token is an end tag, check if the tag can be closed
        if (tb.isCloseMatch(node)) {
            // If so, close the tag and all of its ancestors
            while (!node.equals(tb.currentNode())) {
                tb.pop();
            }
        } else {
            // If not, add the child node to the stack of open elements
            tb.push(node);
        }
    } else if


