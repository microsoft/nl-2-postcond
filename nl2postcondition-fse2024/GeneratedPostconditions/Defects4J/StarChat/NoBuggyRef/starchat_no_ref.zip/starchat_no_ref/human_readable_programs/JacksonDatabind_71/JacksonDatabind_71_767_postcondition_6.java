public static StdKeyDeserializer forType ( Class <? > raw )
//Comment: forType creates a StdKeyDeserializer instance for a given class, which is identified by the input parameter raw.
{
assert ( raw == String.class || raw == Boolean.class || raw == Integer.class || raw == Long.class || raw == Double.class || raw == Float.class || raw == Short.class || raw == Byte.class || raw == Character.class || raw == java.math.BigDecimal.class || raw == java.math.BigInteger.class );
return new StdKeyDeserializer(raw);
}


