// Ensures that the reset method resets the member variables to their default values
assert reset() == null
    && OptionBuilder.shortOpt == null
    && OptionBuilder.longOpt == null
    && OptionBuilder.argName == null
    && OptionBuilder.desc == null
    && OptionBuilder.numberOfArgs == 0
    && OptionBuilder.optionalArg == false
    && OptionBuilder.type == null;


