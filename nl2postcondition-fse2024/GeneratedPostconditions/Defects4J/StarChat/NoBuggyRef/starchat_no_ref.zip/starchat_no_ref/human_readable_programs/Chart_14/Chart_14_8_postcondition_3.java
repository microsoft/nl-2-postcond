Here's a possible symbolic postcondition for removeDomainMarker:

// Postcondition: The list of domain markers is updated correctly when a
// marker is removed from the specified layer.
assert (List.copyOf(this.domainMarkers.get(layer))
       .equals(List.copyOf(this.domainMarkers.get(layer)).subList(0, index)
               .concat(List.copyOf(this.domainMarkers.get(layer)).subList(index + 1, this.domainMarkers.get(layer).length))
                && this.domainMarkers.get(layer).indexOf(marker) == -1) :
        "The list of domain markers is not updated correctly when a marker is removed.";


