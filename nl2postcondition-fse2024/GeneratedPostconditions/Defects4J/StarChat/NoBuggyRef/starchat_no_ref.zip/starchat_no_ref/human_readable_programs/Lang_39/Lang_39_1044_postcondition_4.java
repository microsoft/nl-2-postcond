// Check that if the repeat parameter is true, the return value is the 
// same as the input text. If the repeat parameter is false, then the
// return value is the same as the input text up to the point at which
// the longest search string is found.
assert (repeat? replaceEach(text, searchList, replacementList, repeat, timeToLive) == text
            : replaceEach(text, searchList, replacementList, repeat, timeToLive).substring(0,
                Math.max(0,
                    text.length() - (searchList == null? 0 : Arrays.stream(searchList)
                       .mapToInt(String::length).max().orElse(0))))) : "replaceEach postcondition";


