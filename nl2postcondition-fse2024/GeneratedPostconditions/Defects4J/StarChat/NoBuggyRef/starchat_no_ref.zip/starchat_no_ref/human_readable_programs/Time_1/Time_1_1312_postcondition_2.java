// Ensures that when the method Partial is implemented, the behavior is as specified in the Javadoc.
assert Partial ( types, values, chronology ) == new Partial ( types, values, chronology ); // Postcondition: when Partial is implemented, the return value is equal to a new Partial with the same fields and values.


