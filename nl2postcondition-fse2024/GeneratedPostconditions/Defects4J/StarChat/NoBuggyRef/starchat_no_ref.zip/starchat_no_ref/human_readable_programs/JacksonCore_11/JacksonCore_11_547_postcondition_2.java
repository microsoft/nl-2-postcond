assert (_hashShared == true) || (_intern == true); // Ensures that either the hash area is shared or that interning is enabled


