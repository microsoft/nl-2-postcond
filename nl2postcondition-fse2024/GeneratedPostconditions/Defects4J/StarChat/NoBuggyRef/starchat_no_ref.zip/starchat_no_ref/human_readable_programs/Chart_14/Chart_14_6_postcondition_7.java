public boolean removeDomainMarker ( int index, Marker marker, Layer layer, boolean notify ) {
	//Remove the marker from the Plot's list of domain markers in the specified layer
	this.domainMarkers.get(layer).remove(marker);
	
	//If notify is true, send a PlotChangeEvent to all registered listeners.
	if ( notify ) {
		PlotChangeEvent event = new PlotChangeEvent(this, index, layer);
		notifyListeners(event);
	}
	
	//Return true since the marker was removed
	return true;
}


