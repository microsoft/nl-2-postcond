// Check that if the method returns true, the name ends with a '/'
assert (isDirectory() && name.endsWith("/")) ||!isDirectory();


