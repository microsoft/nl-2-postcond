// Check that all values are reset to default
assert returnValue == new OptionBuilder().build();


