// Ensures that the output Partial's fields are in the same order as the input types array
assert Arrays.equals(types, returnValue.getFieldTypes());


