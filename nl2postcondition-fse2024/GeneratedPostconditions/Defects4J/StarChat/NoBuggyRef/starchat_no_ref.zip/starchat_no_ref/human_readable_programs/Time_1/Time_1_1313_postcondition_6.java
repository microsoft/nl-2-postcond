public int compareTo(DurationField durationField) {
    // assert statement to check that the input parameter is not null and is of the same type as this object
    assert durationField!= null : "Input parameter must not be null";
    assert durationField.getClass() == this.getClass() : "Input parameter must be of the same type as this object";

    // return statement to indicate that natural ordering of duration fields is not relevant
    return 0;
}


