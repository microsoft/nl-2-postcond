//Check that the number of input values matches the number of field types
assert types.length == values.length;

//Create a Partial with the same field types but with all values set to 0
Partial fullPartial = new Partial(types, new int[values.length], chronology);

//Check that the result of the add method is equal to the original partial
assert fullPartial.add(0).equals(this);


