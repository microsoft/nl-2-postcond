// Check that the marker was removed
assert (returnValue == true) : "The marker was not removed";


