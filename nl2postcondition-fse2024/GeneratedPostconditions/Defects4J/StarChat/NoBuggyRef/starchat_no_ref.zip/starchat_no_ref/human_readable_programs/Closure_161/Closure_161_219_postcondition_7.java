// Postcondition:
// left is an array literal and right is a constant expression that can be
// converted to an integer
assert (left.getType() == Token.ARRAYLIT) == (right instanceof Number);


