assert(n.getType() == Token.CALL);
Node callTarget = n.getFirstChild();
assert(callTarget!= null);
assert(callTarget.getType() == Token.GETELEM);
Node arrayValue = callTarget.getFirstChild();
assert(arrayValue.getType() == Token.ARRAYLIT);
Node joinString = arrayValue.getNext();
assert(joinString!= null);
assert(joinString.getType() == Token.STRING);
String expectedResult = "";
for (int i = 0; i < arrayValue.getChildCount() - 1; i++) {
    expectedResult += arrayValue.getChildAtIndex(i).getString();
}
String actualResult = n.getLastChild().getString();
assert(actualResult.equals(expectedResult));


