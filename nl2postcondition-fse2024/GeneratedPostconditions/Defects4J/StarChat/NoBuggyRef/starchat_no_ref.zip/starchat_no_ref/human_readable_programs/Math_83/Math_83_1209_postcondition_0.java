// Postcondition: Checks whether the given column is basic.
assert(
    (
        // If the column is an artificial variable, the row must be the basic row for that variable
        (col >= getArtificialVariableOffset() && col < (getArtificialVariableOffset() + numArtificialVariables))
       ?
        (
            returnValue == null
            || (
                getEntry(returnValue, getRhsOffset()) == 0
                &&
                getHeight() > (col + 1)
                &&
                (
                    // There is no row below the basic row for the artificial variable
                    getHeight() == (col + 2)
                    ||
                    (
                        // The row below the basic row for the artificial variable contains only zeros
                        getEntry(col + 2, getRhsOffset()) == 0
                        &&
                        // And the row above the basic row for the artificial variable contains only non-zeros
                        getEntry(col - 1, getRhsOffset())!= 0
                    )
                )
            )
        )
        // If the column is not an artificial variable, the row must be the basic row for the corresponding original variable
        :
        (
            returnValue == null
            || (
                getEntry(returnValue, getRhsOffset()) == 0
                &&
                getHeight() > (col - getNegativeDecisionVariableOffset() + 1)
                &&
                (
                    // There is no row below the basic row for the original variable
                    getHeight() == (col - getNegativeDecisionVariableOffset() + 2)
                    ||
                    (
                        // The row below the basic row for the original variable contains only zeros
                        getEntry(col - getNegativeDecisionVariableOffset() + 2, getRhsOffset()) == 0
                        &&
                        // And the row above the basic row for the original variable contains only non-zeros
                        getEntry(col - getNegativeDecisionVariableOffset() - 1, getRhsOffset())!= 0
                    )
                )
            )
        )
    )
    // If the row is not the only row (because the original variables are all non-basic), the row must contain only zeros above the diagonal
    &&
    (
        returnValue == null
        ||
        (
            getHeight() > 0
            &&
            (
                // If the row is not the first row
                getHeight() > 1
                &&
                (
                    // And the row above the row contains only zeros
                    getEntry(returnValue - 1, getRhsOffset()) == 0
                    // And the element in the row and the corresponding original variable are non-zero
                    &&
                    getEntry(returnValue, col)!= 0
                )
            )
            // Repeat the check for each row above the first row
            &&
            (
                forAll(i in 2..(returnValue - 1))
                getEntry(returnValue - 1 - i,


