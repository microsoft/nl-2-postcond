// Check that the row corresponding to col is basic
assert (getBasicRow(col) == null) == (getEntry(getBasicRow(col), col)!= 0) : "Row corresponding to col is basic";


