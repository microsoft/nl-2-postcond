assert (returnValue >= 0) : "The return value should be non-negative";


