import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SymbolicPostconditionExample {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<Integer>(List.of(1, 2, 3, 4, 5));
        List<Integer> sortedList = sortList(list);
        System.out.println(sortedList);
    }

    public static List<Integer> sortList(List<Integer> list) {
        // Sorts the input list and returns a sorted list.
        // The input list should not be modified.
        // A postcondition should be written here:
        assert sortedListAndOriginalListAreEqual(list, sortList(list)) : 
                "The sorted list and the original list should be equal.";
        return sortedList;
    }

    private static <T extends Comparable<? super T>> boolean sortedListAndOriginalListAreEqual(List<T> sortedList, List<T> originalList) {
        // Checks if the sorted list and the original list contain the same elements, in the same order.
        // Should be called from the sortList method.
        return sortedList.equals(originalList);
    }
}


