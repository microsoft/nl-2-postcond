import java.util.Objects;

public class Tokeniser {
    private String input;
    private int pos;
    private Token currentToken;

    public Tokeniser(String input) {
        this.input = input;
    }

    public Token getNextToken() {
        skipWhitespace();
        pos = input.indexOf('<', pos);
        if (pos == -1) {
            currentToken = new Token(TokenType.EOF, "");
        } else {
            String tokenString = input.substring(pos, pos + 1);
            switch (tokenString) {
                case "<":
                    currentToken = new Token(TokenType.OPEN_TAG, tokenString);
                    break;
                case ">":
                    currentToken = new Token(TokenType.CLOSE_TAG, tokenString);
                    break;
                case "/":
                    currentToken = new Token(TokenType.SLASH, tokenString);
                    break;
                default:
                    currentToken = new Token(TokenType.TEXT, tokenString);
                    break;
            }
        }
        pos += 1;
        return currentToken;
    }

    private void skipWhitespace() {
        while (pos < input.length() && Character.isWhitespace(input.charAt(pos))) {
            pos += 1;
        }
    }
}


