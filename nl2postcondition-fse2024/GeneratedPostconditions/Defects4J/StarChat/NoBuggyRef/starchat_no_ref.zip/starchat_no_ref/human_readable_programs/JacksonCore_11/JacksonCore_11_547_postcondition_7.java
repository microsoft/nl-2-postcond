Here is the symbolic postcondition for _verifySharing:

`
// Ensures that the intern cache is in the proper state
assert (_intern? InternCache.instance.inCache(_names[offset >> 2]) : true);
`


