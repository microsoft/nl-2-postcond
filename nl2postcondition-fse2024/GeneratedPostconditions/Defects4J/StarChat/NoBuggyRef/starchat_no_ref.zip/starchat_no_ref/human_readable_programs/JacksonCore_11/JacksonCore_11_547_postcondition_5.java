// Ensures that elements in _hashArea are either shared or not shared, depending on the value of the _intern field
assert (_intern? (_hashArea.length >> 2) == _names.length : true);


