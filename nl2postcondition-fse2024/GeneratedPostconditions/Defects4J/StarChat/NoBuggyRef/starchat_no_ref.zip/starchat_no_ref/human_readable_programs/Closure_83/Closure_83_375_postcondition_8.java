assert sortOrder == SortOrder.ASCENDING || sortOrder == SortOrder.DESCENDING :
    "The sort order must be either ascending or descending.";


