// Postcondition: The return value is the string value stored in the parser,
// which is stored in the "_textBuffer" field of the parser.
assert _textBuffer.contentsAsString().equals(returnValue);


