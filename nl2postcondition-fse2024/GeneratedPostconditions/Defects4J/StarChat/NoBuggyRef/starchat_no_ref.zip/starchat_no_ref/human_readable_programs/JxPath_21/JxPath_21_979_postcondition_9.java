// Check that the return value is non-negative
assert returnValue >= 0 : "The length of a property pointer cannot be negative";


