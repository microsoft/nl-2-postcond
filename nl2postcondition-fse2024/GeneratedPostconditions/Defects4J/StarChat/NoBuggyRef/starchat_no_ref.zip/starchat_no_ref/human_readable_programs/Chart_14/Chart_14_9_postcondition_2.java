assert (returnValue == true) == (//code to check if the marker is actually removed);


