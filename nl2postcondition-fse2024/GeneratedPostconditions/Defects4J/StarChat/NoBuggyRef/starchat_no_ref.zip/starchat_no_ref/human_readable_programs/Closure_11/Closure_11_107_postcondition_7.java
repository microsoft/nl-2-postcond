import java.util.List;

public class TypeCheck implements NodeTraversal.Callback, CompilerPass {

    private final TypeValidator validator;

    private void report(NodeTraversal t, Node n, DiagnosticType diagnosticType, String... arguments) {
        if (noTypeCheckSection == 0) {
            t.report(n, diagnosticType, arguments);
        }
    }

    @Override
    public void visit(NodeTraversal t, Node n, Node parent) {
        JSType childType;
        JSType leftType, rightType;
        Node left, right;
        boolean typeable = true;

        switch (n.getType()) {
            case Token.NAME:
                typeable = visitName(t, n, parent);
                break;

            case Token.PARAM_LIST:
                typeable = false;
                break;

            case Token.COMMA:
                ensureTyped(t, n, getJSType(n.


