// The input string value is valid JSON
assert (isJSON(_input) && isJSON(defValue));


