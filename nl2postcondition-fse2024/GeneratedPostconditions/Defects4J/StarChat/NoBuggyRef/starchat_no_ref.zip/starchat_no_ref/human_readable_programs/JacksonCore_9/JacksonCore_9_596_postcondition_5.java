// The return value of this method should be a string representation of the JSON value that has just been parsed
assert returnValue!= null : "The return value should never be null";


