assert: // Check that if the method is successful, the return value is true if the entry is a directory


