assert (// Comment explaining what aspect of the method the symbolic postcondition checks
        (returnValue || (getDomainMarkers(layer).contains(marker) &&!marker.isDrawAsLine()) ||!getDataset(index).contains(marker))
        && noNullElements(getDomainMarkers(layer))
        && markersAreInSameLayer(layer)
        && indexIsWithinBounds(index)
        && markerBelongsToPlot(marker)
        && layerIsPresent(layer)
        );


