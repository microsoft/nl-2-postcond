//The row corresponding to the column "col" must be basic.
assert(returnValue!= null);


