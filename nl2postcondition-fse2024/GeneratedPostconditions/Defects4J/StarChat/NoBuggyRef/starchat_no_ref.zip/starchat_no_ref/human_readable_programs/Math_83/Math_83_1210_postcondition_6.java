// Ensures that the solution returned by getSolution() satisfies the objective function
assert (getSolution().getValue() == f.getValue(getSolution().getPoint())) :
    "The solution returned by getSolution() does not satisfy the objective function";


