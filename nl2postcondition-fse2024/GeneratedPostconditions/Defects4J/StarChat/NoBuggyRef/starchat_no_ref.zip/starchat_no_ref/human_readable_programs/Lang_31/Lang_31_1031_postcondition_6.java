// Checks if the CharSequence contains any character in the given set of characters.
//
// A null CharSequence will return false. A null or empty search string will return false.
assert (
    (cs == null && search == null) ||
    (cs!= null && search!= null &&!search.isEmpty() && cs.chars().anyMatch(c -> search.indexOf(c)!= -1))
);


