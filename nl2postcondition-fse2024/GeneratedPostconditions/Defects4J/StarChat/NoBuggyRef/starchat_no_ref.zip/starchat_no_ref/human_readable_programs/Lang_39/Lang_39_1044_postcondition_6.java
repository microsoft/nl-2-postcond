import java.util.Arrays;
import java.util.Objects;

public class StringUtils {
  public static String replaceEach(String text, String[] searchList, String[] replacementList) {
    // Postcondition:
    // The return value does not contain any instances of any search string.
    // For example, if the searchList contains "a" and "b", the return value
    // cannot contain "a" or "b".
    assert returnValueDoesNotContainAnyInstancesOfSearchStrings(returnValue, searchList);

    // Implementation omitted for brevity
  }

  private static boolean returnValueDoesNotContainAnyInstancesOfSearchStrings(String returnValue, String[] searchList) {
    for (String searchString : searchList) {
      if (returnValue.contains(searchString)) {
        return false;
      }
    }

    return true;
  }
}


