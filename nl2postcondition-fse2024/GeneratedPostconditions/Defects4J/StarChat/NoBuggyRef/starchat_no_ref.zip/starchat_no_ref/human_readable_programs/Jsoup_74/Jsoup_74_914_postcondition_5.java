// Check that the result of normalizing whitespace matches the input string
assert normaliseWhitespace(string).equals(returnValue);


