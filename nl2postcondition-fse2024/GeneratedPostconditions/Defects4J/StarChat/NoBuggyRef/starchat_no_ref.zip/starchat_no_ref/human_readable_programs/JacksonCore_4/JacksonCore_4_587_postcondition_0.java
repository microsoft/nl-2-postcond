assert (currentSegment == null) || (currentSegmentLength > 0);


