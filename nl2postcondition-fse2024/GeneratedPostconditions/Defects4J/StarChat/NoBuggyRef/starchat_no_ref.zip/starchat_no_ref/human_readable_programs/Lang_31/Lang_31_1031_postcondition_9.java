public static boolean containsAny(CharSequence cs, char[] searchChars) {
    if (cs == null || searchChars == null) {
        return false;
    }
    int csLen = cs.length();
    int searchLen = searchChars.length;
    if (searchLen == 0) {
        return false;
    }
    for (int i = 0; i < csLen; i++) {
        char ch = cs.charAt(i);
        for (int j = 0; j < searchLen; j++) {
            if (searchChars[j] == ch) {
                return true;
            }
        }
    }
    return false;
}


