assert (
    (_currToken == JsonToken.VALUE_STRING && returnValue == getText()) ||
    (_currToken!= JsonToken.VALUE_STRING && returnValue == defaultValue)
);


