// Check that the marker is removed from the list of range markers and that the
// notify parameter is respected.
assert (removeRangeMarker(marker) &&!rangeMarkers.contains(marker))
        || (!notify && removeRangeMarker(marker) && rangeMarkers.contains(marker));


