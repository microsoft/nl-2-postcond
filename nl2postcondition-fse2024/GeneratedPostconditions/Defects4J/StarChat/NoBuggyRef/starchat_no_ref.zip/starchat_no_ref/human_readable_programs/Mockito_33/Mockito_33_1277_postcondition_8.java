assert returnValue == (
   // The method body, including calls to other helper methods
   getMethod().getName().equals(candidate.getMethod().getName())
   && getInvocation().getMock() == candidate.getMock()
   && hasUnverifiedInteractionsOnly()
   && hasSameArguments(candidate)
);


