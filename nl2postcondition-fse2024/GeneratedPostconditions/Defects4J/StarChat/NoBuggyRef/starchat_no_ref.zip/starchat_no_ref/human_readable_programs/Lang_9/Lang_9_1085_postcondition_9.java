// Ensures that the derived fields are properly initialized, according to the
// specification in the Javadoc.
assert returnValue!= null;
assert derivedField1!= null;
assert derivedField2!= null;
//... etc.


