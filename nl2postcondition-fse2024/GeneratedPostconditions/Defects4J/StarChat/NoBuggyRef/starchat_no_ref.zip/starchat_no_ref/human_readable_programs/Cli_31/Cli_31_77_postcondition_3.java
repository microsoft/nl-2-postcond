// Postcondition: Resets the member variables to their default values.
// Ensures that the return value is always false.
assert!reset();


