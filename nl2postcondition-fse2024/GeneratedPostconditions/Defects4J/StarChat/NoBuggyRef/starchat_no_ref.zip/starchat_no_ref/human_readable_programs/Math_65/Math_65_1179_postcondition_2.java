// Check that the returned value is always positive
assert (0.0 <= returnValue && returnValue <= Double.POSITIVE_INFINITY);


