// assert _verifySharing ensures that:
// 1. The internal state of the _hashArea array is consistent and coherent
// 2. The hash table's size, _hashSize, is such that it can hold all of the
//    symbols added to it so far
// 3. Symbols are not added to the hash table more than once.


