// Ensures that the returned String is a properly formatted JSON string.
assert(_isValidJson(_textBuffer.contentsAsString()) : "The returned String should be a properly formatted JSON string.";

// Ensures that the returned String is equal to the input String.
assert(_textBuffer.contentsAsString().equals(defValue) : "The returned String should be equal to the input String.";


