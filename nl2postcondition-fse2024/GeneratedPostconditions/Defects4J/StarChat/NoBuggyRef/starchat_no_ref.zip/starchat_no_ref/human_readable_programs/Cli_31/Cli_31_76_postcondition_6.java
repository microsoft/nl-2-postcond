// Check that when the method is called, buff contains the string
    // "[--app optionName=<value>] " if required is true, or
    // "[--app optionName=<value>]" if required is false, where value is
    // the option's value, if any. The exact format of the string depends
    // on the option's type and whether or not it has a value.
    assertBuffContains(buff, "[--app optionName=" + option.getLongOpt());
    if (option.hasArg()) {
        assertBuffContains(buff, "=" + option.getValue());
    }
    assertBuffContains(buff, "]");
    if (required) {
        assertBuffContains(buff, " ");
    }


