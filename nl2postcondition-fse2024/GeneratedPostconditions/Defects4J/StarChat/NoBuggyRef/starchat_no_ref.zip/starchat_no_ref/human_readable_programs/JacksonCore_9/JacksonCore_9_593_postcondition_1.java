String returnValue = "default value";
// assert statement follows
assert returnValue.equals(getText()) : "The return value of getValueAsString must be equal to the result of getText().";


