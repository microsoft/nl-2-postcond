assert (returnValue == null || (returnValue.getLowerBound() <= returnValue.getUpperBound() &&
        (includeInterval || returnValue.getLowerBound() == dataset.getX(0) ||
        returnValue.getUpperBound() == dataset.getX(dataset.getItemCount() - 1))));


