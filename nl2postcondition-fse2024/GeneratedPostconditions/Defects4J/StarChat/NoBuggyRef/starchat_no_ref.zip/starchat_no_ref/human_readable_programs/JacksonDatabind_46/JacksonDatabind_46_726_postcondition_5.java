assert checkGenericSignature(sb, _referencedType.getGenericSignature(sb));


