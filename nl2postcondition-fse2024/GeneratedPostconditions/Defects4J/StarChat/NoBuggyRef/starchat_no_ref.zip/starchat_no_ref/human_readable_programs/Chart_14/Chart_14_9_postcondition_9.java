// Postcondition for the removeRangeMarker method:
// Ensures that the marker is removed from the plot, and that the
// PlotChangeEvent is fired if the 'notify' parameter is true.
assert (removeRangeMarker(0, marker, layer, true) == true && marker.getOwner() == this
        && marker.getLayer() == layer
        && this.rangeMarkers.get(index).contains(marker) == false
        && (notify == true && fireChangeEvent() == true));


