// Check that the result is non-negative
assert returnValue >= 0 : "The mean of a hypergeometric distribution should not be negative."


