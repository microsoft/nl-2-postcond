// The value of the property must be present on the object
assert(returnValue!= typeRegistry.getNativeType(UNKNOWN_TYPE));


