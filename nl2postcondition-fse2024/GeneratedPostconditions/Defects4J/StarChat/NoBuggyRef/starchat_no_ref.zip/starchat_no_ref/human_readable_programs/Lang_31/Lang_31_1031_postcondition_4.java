import java.util.Arrays;

//...

public static boolean containsAny(CharSequence cs, char[] searchChars) {
    assert (searchChars!= null) : "The search characters array cannot be null.";

    for (char c : searchChars) {
        if (cs.indexOf(c) >= 0) {
            return true;
        }
    }

    return false;
}


