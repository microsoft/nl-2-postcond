// Ensures that when removeRangeMarker is called, the marker is actually removed from the list of range markers,
// and that the chart is updated if the marker is the selected one.
assert (returnValue == true && marker.equals(getRangeMarkers().get(index)))
    || (returnValue == false &&!marker.equals(getRangeMarkers().get(index)));


