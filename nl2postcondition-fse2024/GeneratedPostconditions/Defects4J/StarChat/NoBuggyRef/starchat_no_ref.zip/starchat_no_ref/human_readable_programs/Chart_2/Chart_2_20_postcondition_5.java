import java.util.Arrays;

//Iterate over the items in an XYDataset to find the range of x-values
//includeInterval is a flag that determines, for an IntervalXYDataset, 
//whether the x-interval or just the x-value is used to determine the overall range
assert (returnValue!= null) && (returnValue.getLength() == 2) : 
    "The returned range should have a length of 2";

//The returned range should contain the minimum and maximum x-values in the dataset
assert (returnValue.getLowerBound() <= dataset.getX(0)) && 
    (returnValue.getUpperBound() >= dataset.getX(dataset.getItemCount() - 1)) :
    "The returned range should contain the minimum and maximum x-values in the dataset";

//If the dataset is an instance of IntervalXYDataset, make sure the returned range 
//includes the x-interval as well
if (dataset instanceof IntervalXYDataset && includeInterval) {
    IntervalXYDataset intervalDataset = (IntervalXYDataset) dataset;
    double startX = intervalDataset.getStartX(0);
    double endX = intervalDataset.getEndX(0);
    
    for (int i = 1; i < dataset.getItemCount(); i++) {
        startX = Math.min(startX, intervalDataset.getStartX(i));
        endX = Math.max(endX, intervalDataset.getEndX(i));
    }
    
    //The returned range should include the x-interval as well
    assert (returnValue.getLowerBound() <= startX) && (returnValue.getUpperBound() >= endX) :
        "The returned range should include the x-interval if includeInterval is true";
}


