// CompareTo method postcondition:
// Check that the types of the input fields are the same
assert this.getType() == durationField.getType();

// Check that the units of the input fields are the same
assert this.getUnit() == durationField.getUnit();

// Return value of compareTo: zero indicates that the order of
// the fields is not relevant
int returnValue = 0;

// Check that the return value is always zero
assert returnValue == compareTo(durationField);


