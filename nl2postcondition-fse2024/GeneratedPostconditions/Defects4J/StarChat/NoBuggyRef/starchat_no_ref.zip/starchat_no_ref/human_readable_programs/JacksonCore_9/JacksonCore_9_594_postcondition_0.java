import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ReaderBasedJsonParser {
    private static final boolean[] PRIMITIVE_TYPES = {
            Boolean.class.isAssignableFrom(Boolean.TYPE),
            Character.class.isAssignableFrom(Character.TYPE),
            Byte.class.isAssignableFrom(Byte.TYPE),
            Short.class.isAssignableFrom(Short.TYPE),
            Integer.class.isAssignableFrom(Integer.TYPE),
            Long.class.isAssignableFrom(Long.TYPE),
            Float.class.isAssignableFrom(Float.TYPE),
            Double.class.isAssignableFrom(Double.TYPE),
            String.class.isAssignableFrom(String.class)
    };

    public static final String NULL = "null";

    public static final int TRUE = 1;
    public static final int FALSE = 2;

    private static final String[] RESERVED_WORDS = {
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
            "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
            "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
            "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
            "volatile", "while"
    };

    private final JsonReadContext _parsingContext = new JsonReadContext();
    private char[] _inputBuffer;
    private int _inputPtr;
    private int _inputLen;


