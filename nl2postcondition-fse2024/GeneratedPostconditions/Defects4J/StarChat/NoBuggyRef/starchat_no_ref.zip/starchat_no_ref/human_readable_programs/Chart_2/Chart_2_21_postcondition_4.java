// Postcondition: The return value of the method should not be null.
assert (returnValue!= null);


