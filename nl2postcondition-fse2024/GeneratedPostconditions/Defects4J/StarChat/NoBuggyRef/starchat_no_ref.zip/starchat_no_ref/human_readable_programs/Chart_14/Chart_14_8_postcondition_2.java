import java.util.ArrayList;
import org.jfree.chart.util.Layer;

// Postcondition:
// Ensures that the return value of removeDomainMarker is false if the marker
// was not present in the plot.
assert!returnValue : "The marker was not in the plot, so the return value "
    + "should be false.";


