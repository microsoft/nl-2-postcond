// Ensures that the return value is a character array
// that is one element longer than the input array
assert (returnValue instanceof char[]) && (returnValue.length == input.length + 1);


