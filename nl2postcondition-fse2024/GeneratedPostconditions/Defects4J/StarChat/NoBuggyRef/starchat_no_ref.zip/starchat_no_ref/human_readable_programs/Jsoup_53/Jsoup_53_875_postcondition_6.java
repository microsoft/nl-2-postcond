String input = "(one (two) three) four";
char open = '(', close = ')';

String result = chompBalanced(open, close);

assert result.equals("one (two) three");


