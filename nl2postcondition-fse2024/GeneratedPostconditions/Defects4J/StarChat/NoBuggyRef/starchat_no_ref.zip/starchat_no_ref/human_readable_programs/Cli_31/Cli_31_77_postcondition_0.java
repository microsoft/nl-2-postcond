// postcondition: the list is sorted in ascending order
    assert (returnValue!= null);
    for (int i = 0; i < returnValue.length - 1; i++) {
        assert (returnValue[i] <= returnValue[i + 1]);
    }


