/**
 * Resets the member variables to their default values.
 *
 * Postcondition:
 *   1. The instance variable list is set to an empty list.
 *   2. The instance variable mandatory is set to false.
 *   3. The instance variable name is set to null.
 *   4. The instance variable abbreviation is set to null.
 *   5. The instance variable argument is set to null.
 */
private static void reset() {
    list = new ArrayList<>();
    mandatory = false;
    name = null;
    abbreviation = null;
    argument = null;
}


