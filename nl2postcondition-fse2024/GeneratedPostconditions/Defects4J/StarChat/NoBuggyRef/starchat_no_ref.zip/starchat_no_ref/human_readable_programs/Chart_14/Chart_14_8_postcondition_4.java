// Ensures that the marker is removed from the domain axis and that the plot is
// updated accordingly.
assert (removeDomainMarker(marker) && containsDomainMarker(marker) == false)
    == (removeDomainMarker(marker, Layer.FOREGROUND) &&
        containsDomainMarker(marker, Layer.FOREGROUND) == false)
    && (removeDomainMarker(index, marker, Layer.FOREGROUND) &&
        containsDomainMarker(index, marker, Layer.FOREGROUND) == false);


