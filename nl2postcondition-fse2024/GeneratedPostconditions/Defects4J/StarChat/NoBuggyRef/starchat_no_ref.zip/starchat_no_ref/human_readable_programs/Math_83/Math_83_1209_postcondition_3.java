// Checks that the row identified by rowNum is a basic row in the given column
assert(isBasicRow(rowNum, col) == true);


