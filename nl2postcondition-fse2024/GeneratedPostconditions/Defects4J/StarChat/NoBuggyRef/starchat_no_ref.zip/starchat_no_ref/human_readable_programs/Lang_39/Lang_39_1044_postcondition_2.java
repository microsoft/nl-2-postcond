// Postcondition for replaceEach:

// 1. If the input string is null, the output is also null.
assert (returnValue == null) == (text == null);

// 2. If the input searchList is null or empty, the output is the same as the input text.
assert (returnValue == text) == (searchList == null || searchList.length == 0);

// 3. If the input replacementList is null or empty, the output is the same as the input text.
assert (returnValue == text) == (replacementList == null || replacementList.length == 0);

// 4. If the input searchList and replacementList have different lengths, an
//    IllegalArgumentException is thrown.
assert IllegalArgumentException.class.isAssignableFrom(thrownException.getClass()) == (searchList.length!= replacementList.length);

// 5. If the input repeat parameter is true, the method terminates eventually.
// Note that this means the loop could potentially run forever, so an
// assertion on the number of iterations would be necessary as well.
assert eventuallyTerminates(text, searchList, replacementList, repeat);

// 6. If the input repeat parameter is false, the method terminates after a finite number of iterations.
// Note that this means the loop could potentially run forever, so an
// assertion on the number of iterations would be necessary as well.
assert finiteNumberOfIterations(text, searchList, replacementList, repeat);

// Assertion helper functions:

public static boolean eventuallyTerminates(String text, String[] searchList, String[] replacementList, boolean repeat) {
    boolean eventuallyTerminates = false;
    int iterations = 0;
    while (!eventuallyTerminates) {
        try {
            replaceEach(text, searchList, replacementList, repeat, 100);
            eventuallyTerminates = true;
        } catch (IllegalArgumentException e) {
            // Do nothing, keep looping.
        }
        iterations++;
    }
    return iterations > 0;
}

public static boolean finiteNumberOfIterations(String text, String[] searchList, String[] replacementList, boolean repeat) {
    boolean eventuallyTerminates = false;
    int iterations = 0;
    while (!eventuallyTerminates) {
        try {
            replaceEach(text, searchList, replacementList, repeat, 100);
            eventuallyTerminates = true;
        } catch (IllegalArgumentException e) {
            // Do nothing, keep looping.
        }
        iterations++;
    }
    return iterations < 100;
}


