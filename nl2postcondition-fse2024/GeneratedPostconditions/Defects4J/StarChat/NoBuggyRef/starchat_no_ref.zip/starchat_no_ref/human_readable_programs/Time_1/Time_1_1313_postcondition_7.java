/**
 * Represents a unit of time, such as "seconds" or "days".
 * <p>
 * A duration field is responsible for representing any duration
 * measured in terms of the field, such as "60 seconds" or "4 days".
 * The standard duration fields are defined in {@link DurationFieldType}.
 * Instances of this class are singletons.
 * <p>
 * Note that this interface does not include any methods that provide access
 * to the duration field name or numeric value. Implementations of this
 * interface must be immutable and thread-safe.
 * <p>
 * Calculations on this class are performed using <i>duration units</i>.
 * A duration unit is defined as the number of standard length of this field.
 * For example, a duration field representing "hours" would have a duration
 * unit of 60, as there are 60 minutes in a hour. The duration field
 * representing "miles" would have a duration unit of 1, as there is only one
 * standard length of length in miles.
 * <p>
 * To convert between a duration in terms of the field and the equivalent duration
 * in terms of duration units, use the {@link #getUnitMillis()} method. To
 * convert from a duration in terms of duration units to terms of this field,
 * use the {@


