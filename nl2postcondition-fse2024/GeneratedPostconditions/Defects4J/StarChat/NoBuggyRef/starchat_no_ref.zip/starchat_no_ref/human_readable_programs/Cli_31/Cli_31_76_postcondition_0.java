// Postcondition: Ensure that the options are separated by spaces
assert appendOption("1", new Option("a", "alpha", false), true).equals("1 a");
assert appendOption("1 2", new Option("b", "bravo", false), false).equals("1 2 b");


