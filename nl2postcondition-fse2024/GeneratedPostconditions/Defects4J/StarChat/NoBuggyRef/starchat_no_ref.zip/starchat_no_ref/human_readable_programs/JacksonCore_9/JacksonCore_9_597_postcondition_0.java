// Check that the return value is either defValue or a string representation of a valid JSON value
assert (defValue.equals(returnValue) || (returnValue!= null && isValidJsonValue(returnValue)));


