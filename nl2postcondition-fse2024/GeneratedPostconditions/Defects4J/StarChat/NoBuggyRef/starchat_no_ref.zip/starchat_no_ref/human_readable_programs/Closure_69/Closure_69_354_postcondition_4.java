assert returnValue.isSubtypeOf(getNativeType(UNKNOWN_TYPE)) :
  "visitCall postcondition: type of " + returnValue + " not a subtype of " +
  getNativeType(UNKNOWN_TYPE);


