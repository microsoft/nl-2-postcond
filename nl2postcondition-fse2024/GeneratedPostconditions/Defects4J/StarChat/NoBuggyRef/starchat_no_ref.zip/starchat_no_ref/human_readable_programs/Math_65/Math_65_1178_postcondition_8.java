import java.util.List;

public class AbstractLeastSquaresOptimizer {
    private List<Measurement> measurements;
    private double[] weights;

    public double getRMS() {
        // Initialize the sum of squares to zero
        double sumOfSquares = 0;
        // For each measurement and its weight, add the squared difference to the sum of squares
        for (int i = 0; i < measurements.size(); i++) {
            sumOfSquares += Math.pow(measurements.get(i).value - getEstimate(i), 2) * weights[i];
        }
        // Return the square root of the average of the sum of squares
        return Math.sqrt(sumOfSquares / measurements.size());
    }

    // Hypothetical method that returns the estimate for a given measurement
    private double getEstimate(int i) {
        // TODO: Replace this with the actual implementation
        return 0;
    }
}


