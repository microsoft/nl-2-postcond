// Check that the sum of all squared residuals is equal to the chi-square value
assert Math.abs(
    Stream.iterate(0, i -> i + 1) // Generate a sequence of indices
       .limit(n) // Limit to the number of residuals
       .mapToDouble(i -> residuals[i] * residuals[i]) // Map each squared residual to a double
       .sum() - returnValue) // Sum the squared residuals and subtract from the chi-square value
    < 1e-12 : "The sum of squared residuals must equal the chi-square value";


