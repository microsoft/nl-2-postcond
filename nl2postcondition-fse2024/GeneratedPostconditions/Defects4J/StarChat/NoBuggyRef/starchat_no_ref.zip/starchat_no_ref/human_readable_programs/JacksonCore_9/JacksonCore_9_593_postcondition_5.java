assert (returnValue == null && defaultValue == null) ||
    (returnValue!= null && returnValue.equals(getText()));


