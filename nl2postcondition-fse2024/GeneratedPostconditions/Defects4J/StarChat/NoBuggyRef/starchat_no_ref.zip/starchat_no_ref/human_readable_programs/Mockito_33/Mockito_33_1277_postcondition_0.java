// Check that the invocation's method and the candidate's method are equal
assert getMethod().equals(candidate.getMethod());

// Check that the invocation's mock and the candidate's mock are equal
assert getInvocation().getMock().equals(candidate.getMock());

// Check that the invocation's arguments and the candidate's arguments are equal
assert getArguments().equals(candidate.getArguments());

// Check that the invocation's result and the candidate's result are equal
assert getResult().equals(candidate.getResult());

// Check that the invocation's throwable and the candidate's throwable are equal
assert getThrowable().equals(candidate.getThrowable());


