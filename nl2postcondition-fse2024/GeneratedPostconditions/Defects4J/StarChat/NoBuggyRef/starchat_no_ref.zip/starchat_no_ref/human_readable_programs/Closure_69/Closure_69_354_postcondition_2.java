//Check that the return value is truthy or null
assert (returnValue!= null && returnValue.isTruthy()) || returnValue.isNull();


