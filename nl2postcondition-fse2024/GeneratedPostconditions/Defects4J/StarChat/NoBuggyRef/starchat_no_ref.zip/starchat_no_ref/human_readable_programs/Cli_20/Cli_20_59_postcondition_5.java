// Check that the return value is non-null and nonempty
assert returnValue!= null;
assert returnValue.length > 0;

// Check that the return value is a permutation of the input arguments
for (int i = 0; i < arguments.length; i++) {
    assert ArrayUtils.contains(returnValue, arguments[i]);
}

// Check that the first element in the return value is "--"
assert returnValue[0].equals("--");

// Check that every element in the return value after the first is an argument
for (int i = 1; i < returnValue.length; i++) {
    assert ArrayUtils.contains(arguments, returnValue[i]);
}


