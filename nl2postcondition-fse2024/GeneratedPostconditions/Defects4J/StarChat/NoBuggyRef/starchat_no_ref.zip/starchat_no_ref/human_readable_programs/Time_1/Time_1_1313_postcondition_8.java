// Check that the return value is less than zero if this field's duration
// is shorter than the given field's duration, and greater than zero otherwise
assert (returnValue < 0) == (this.getUnitMillis() < durationField.getUnitMillis());


