// Check if the elements in the left argument are in the right argument.
assert (
    // If the right argument is a collection, find if any element in it matches an element in the left argument.
        (right instanceof Collection)
           ? findMatch(reduce(left), ((Collection) right).iterator())
            // Otherwise, if the right argument is an iterator, find if any element in it matches an element in the left argument.
            : (right instanceof Iterator)
               ? findMatch(reduce(left), (Iterator) right)
                // Otherwise, if the right argument is not a collection or iterator, just return false.
                : false
), "Elements in the left argument must be present in the right argument if it is a collection or an iterator."


