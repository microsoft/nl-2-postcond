// The input parameter "subclass" is a Class object representing the class or interface that the returned
// JavaType instance should have.
assert (returnValue instanceof subclass || returnValue.isSubTypeOf(subclass));


