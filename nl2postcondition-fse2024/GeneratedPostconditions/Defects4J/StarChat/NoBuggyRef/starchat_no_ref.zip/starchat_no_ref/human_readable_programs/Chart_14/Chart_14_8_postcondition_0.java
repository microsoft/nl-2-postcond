// Check that the marker is removed from the domain markers for the specified layer
assert layer.equals(Layer.FOREGROUND)?!domainMarkers.contains(marker) : domainMarkers.get(index).contains(marker);


