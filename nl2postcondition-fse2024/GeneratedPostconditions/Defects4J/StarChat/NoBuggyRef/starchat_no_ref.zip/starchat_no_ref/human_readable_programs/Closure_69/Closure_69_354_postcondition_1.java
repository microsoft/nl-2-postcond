// The return value of visitCall must be a subtype of the declared return type of the function.
assert(returnValue!= null && returnValue.isSubtypeOf(functionType.getReturnType()));


