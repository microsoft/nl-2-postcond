import java.util.Arrays;

public static Range iterateRangeBounds(XYDataset dataset, boolean includeInterval) {
    double[] xData = new double[dataset.getItemCount(0)];
    double[] yData = new double[dataset.getItemCount(0)];

    for (int row = 0; row < dataset.getItemCount(0); row++) {
        xData[row] = dataset.getXValue(row, 0);
        yData[row] = dataset.getYValue(row, 0);
    }

    Arrays.sort(xData);
    Arrays.sort(yData);

    double maxX = xData[xData.length - 1];
    double minX = xData[0];
    double maxY = yData[yData.length - 1];
    double minY = yData[0];

    // If the dataset is an IntervalXYDataset, use the interval for Y values if includeInterval is true,
    // otherwise use only the Y value.
    if (dataset instanceof IntervalXYDataset && includeInterval) {
        double[] yLowData = new double[dataset.getItemCount(0)];
        double[] yHighData = new double[dataset.getItemCount(0)];

        for (int row = 0; row < dataset.getItemCount(0); row++) {
            yLowData[row] = ((IntervalXYDataset) dataset).getYLowValue(row, 0);
            yHighData[row] = ((IntervalXYDataset) dataset).getYHighValue(row, 0);
        }

        Arrays.sort(yLowData);
        Arrays.sort(yHighData);

        maxY = Math.max(maxY, yHighData[yHighData.length - 1]);
        minY = Math.min(minY, yLowData[0]);
    }

    Range range = new Range(minX, maxX, minY, maxY);

    assert (range!= null);
    assert (range.getLowerBound() <= range.getUpperBound());
    assert (range.getLowerBound() == minX && range.getUpperBound() == maxX);
    assert (range.getLowerBound() == minY && range.getUpperBound() == maxY);

    return range;
}


