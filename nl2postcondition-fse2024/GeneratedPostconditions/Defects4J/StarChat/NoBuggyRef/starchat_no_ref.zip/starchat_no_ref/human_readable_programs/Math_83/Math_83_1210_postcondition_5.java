// Check that the objective function value is finite and non-negative.
assert isFinite(returnValue.getValue()) : "Objective function value is not finite.";
assert returnValue.getValue() >= 0 : "Objective function value is negative.";

// Check that the point is finite and non-negative.
assert isFinite(returnValue.getPoint()) : "Point is not finite.";
assert all(isFinite(returnValue.getPoint())) : "Point contains a non-finite value.";
assert all(returnValue.getPoint() >= 0) : "Point contains negative values.";

// Check that the objective vector is finite and non-negative.
assert isFinite(returnValue.getObjective()) : "Objective vector is not finite.";
assert all(isFinite(returnValue.getObjective())) : "Objective vector contains a non-finite value.";
assert all(returnValue.getObjective() >= 0) : "Objective vector contains negative values.";

// Check that the constraint matrix is finite and non-negative.
assert isFinite(returnValue.getConstraintMatrix()) : "Constraint matrix is not finite.";
assert all(isFinite(returnValue.getConstraintMatrix())) : "Constraint matrix contains a non-finite value.";
assert all(returnValue.getConstraintMatrix() >= 0) : "Constraint matrix contains negative values.";

// Check that the dual solution vector is finite and non-negative.
assert isFinite(returnValue.getDualVariables()) : "Dual solution vector is not finite.";
assert all(isFinite(returnValue.getDualVariables())) : "Dual solution vector contains a non-finite value.";
assert all(returnValue.getDualVariables() >= 0) : "Dual solution vector contains negative values.";

// Check that the basic variable vector is either all 0s or all 1s.
final int numDecisionVariables = getOriginalNumDecisionVariables();
final int numConstraints = getHeight() - numDecisionVariables;

final double[] basicVariables = new double[numConstraints];
for (int i = 0; i < numConstraints; i++) {
    final int row = numDecisionVariables + i;
    basicVariables[i] = getEntry(row, numDecisionVariables);
}
assert all(basicVariables == 0) || all(basicVariables == 1) : "Basic variable vector contains values


