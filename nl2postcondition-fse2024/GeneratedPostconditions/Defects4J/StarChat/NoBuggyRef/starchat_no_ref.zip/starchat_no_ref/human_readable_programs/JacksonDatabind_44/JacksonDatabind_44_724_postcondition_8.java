// If the method succeeds, it returns a type that is a subclass of the given class.
Class<?> subclass =...;
JavaType result = _narrow(subclass);
assert result.getRawClass().isAssignableFrom(subclass) : "Resulting type must be a subclass of the given class";


