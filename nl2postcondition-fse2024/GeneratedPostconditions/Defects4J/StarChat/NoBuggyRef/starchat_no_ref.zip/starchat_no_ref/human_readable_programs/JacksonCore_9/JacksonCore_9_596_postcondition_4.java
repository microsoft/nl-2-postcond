// Check that the returned String is a JSON string
assert (isValidJson(_textBuffer.contentsAsString()));


