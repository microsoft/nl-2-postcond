assert (n.getType() == Token.CALL) ==> (returnValue!= n) || (returnValue.getType()!= Token.STRING);


