// Symbolic postcondition for isDirectory() method:
assert returnValue == (name.charAt(name.length() - 1) == '/');


