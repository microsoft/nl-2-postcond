import java.util.Arrays;

public static boolean containsAny(CharSequence cs, char[] searchChars) {
    boolean result = false;
    if (cs!= null && searchChars!= null) {
        // The following loop checks if any of the characters in the searchChars array are found in the input string
        for (char c : searchChars) {
            if (cs.toString().indexOf(c)!= -1) {
                result = true;
                break;
            }
        }
    }
    assert result == (Arrays.asList(searchChars).contains(c));
    return result;
}


