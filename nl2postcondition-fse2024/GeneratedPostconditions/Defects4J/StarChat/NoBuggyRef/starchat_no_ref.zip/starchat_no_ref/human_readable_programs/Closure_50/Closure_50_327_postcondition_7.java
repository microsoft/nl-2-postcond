//post: if the return value is non-null and not undefined, then it is a string
String returnValue = tryFoldArrayJoin(n);
assert returnValue!= null && returnValue!= undefined : "tryFoldArrayJoin always returns a string";


