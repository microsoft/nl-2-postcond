// Check that the returned String is a valid JSON String
assert (isValidJSONString(returnValue));


