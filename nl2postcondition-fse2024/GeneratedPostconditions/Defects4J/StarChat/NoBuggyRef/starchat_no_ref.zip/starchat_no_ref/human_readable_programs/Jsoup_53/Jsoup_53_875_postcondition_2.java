assert ( // the stack before the call to chompBalanced
( // the number of opening brackets before the call to chompBalanced
() // open brackets, if any, that came before the call to chompBalanced
+
numberOfOpenBrackets // the number of opening brackets that were added by the call to chompBalanced
)
*
2
+
numberOfOpenBrackets // the total number of opening brackets added by all previous calls to chompBalanced
)
==
( // the stack after the call to chompBalanced
() // open brackets, if any, that came before the call to chompBalanced
+
numberOfOpenBrackets // the number of opening brackets that were added by the call to chompBalanced
)
&&
( // the stack contains the same number of opening and closing brackets
() // an even number of opening brackets
==
numberOfOpenBrackets
)


