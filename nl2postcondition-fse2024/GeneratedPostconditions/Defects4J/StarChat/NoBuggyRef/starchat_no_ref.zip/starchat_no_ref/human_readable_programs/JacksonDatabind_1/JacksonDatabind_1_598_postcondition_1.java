// The elements in the collection are in sorted order according to the Comparable interface
assert Collections.sort(elements) == elements;


