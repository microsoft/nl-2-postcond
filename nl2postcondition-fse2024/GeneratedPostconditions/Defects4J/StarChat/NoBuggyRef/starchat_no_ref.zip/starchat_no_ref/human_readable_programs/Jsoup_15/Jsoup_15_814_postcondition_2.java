boolean process ( Token t, TreeBuilder tb )


