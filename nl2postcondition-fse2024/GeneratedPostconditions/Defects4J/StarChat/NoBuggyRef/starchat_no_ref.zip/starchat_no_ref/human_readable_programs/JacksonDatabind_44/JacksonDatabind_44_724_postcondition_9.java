// Ensures that the return value is a reference to a subclass of the input parameter
assert returnValue!= null && returnValue.getClass().isAssignableFrom(subclass);


