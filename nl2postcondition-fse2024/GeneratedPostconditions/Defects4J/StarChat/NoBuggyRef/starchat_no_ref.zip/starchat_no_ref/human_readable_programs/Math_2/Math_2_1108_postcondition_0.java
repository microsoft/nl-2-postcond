// Check that the returned value is equal to n * m / N
assert returnValue == n * m / N;


