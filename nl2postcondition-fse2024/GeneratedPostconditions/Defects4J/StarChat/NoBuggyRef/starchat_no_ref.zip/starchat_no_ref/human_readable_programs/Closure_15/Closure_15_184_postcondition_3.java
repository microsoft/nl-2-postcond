// The list is sorted in ascending order
assert (returnValue.stream().allMatch(a -> a == null || a.compareTo(a) == 0));

// The method does not modify the input list
assert (list.equals(inputList));


