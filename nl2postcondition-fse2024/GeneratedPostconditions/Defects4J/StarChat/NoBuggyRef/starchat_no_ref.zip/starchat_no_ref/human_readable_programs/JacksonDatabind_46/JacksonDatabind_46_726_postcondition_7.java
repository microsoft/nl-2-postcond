// Ensures that the return value only contains the simple name of the referenced type
// (i.e., no additional information such as generic type parameters)
assert returnValue.toString().equals(_referencedType.getSimpleName());


