assert (// Code that checks the postcondition) : "Postcondition does not hold true";


