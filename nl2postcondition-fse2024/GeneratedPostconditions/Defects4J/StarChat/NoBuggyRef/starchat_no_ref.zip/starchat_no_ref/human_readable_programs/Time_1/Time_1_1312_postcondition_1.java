// Ensures correct output using Javadoc specification
assert (Arrays.equals(types, new DateTimeFieldType[] {DateTimeFieldType.dayOfMonth(), DateTimeFieldType.monthOfYear(), DateTimeFieldType.year()})) :
"Types should be in order of largest to smallest";


