assert (returnValue == (sampleSize * numberOfSuccesses) / populationSize);


