Here is my symbolic postcondition:

// Check that the input marker is indeed in the domain markers for the given layer
assert layer.equals(Layer.BACKGROUND) || layer.equals(Layer.FOREGROUND) : "The layer must be foreground or background";
assert marker!= null : "The input marker cannot be null";
assert dataset.getDomainMarkers(layer).contains(marker) : "The input marker must be in the domain markers for the given layer";

// Check that the marker is indeed removed from the domain markers for the given layer
ArrayList<Marker> originalDomainMarkers = new ArrayList(dataset.getDomainMarkers(layer));
originalDomainMarkers.remove(marker);
ArrayList<Marker> currentDomainMarkers = new ArrayList(dataset.getDomainMarkers(layer));
assert originalDomainMarkers.equals(currentDomainMarkers) : "The marker must be removed from the domain markers";

// Check that the marker is indeed removed from the dataset's domain marker list in the given layer
int originalDomainMarkerCount = dataset.getDomainMarkerCount(layer);
dataset.removeDomainMarker(marker, layer, false);
int currentDomainMarkerCount = dataset.getDomainMarkerCount(layer);
assert originalDomainMarkerCount - 1 == currentDomainMarkerCount : "The marker must be removed from the dataset's domain marker list";

// Check that the plot's change event is indeed sent if notify is true
if (notify) {
	assert sendChangeEvent(new PlotChangeEvent(this)) : "The plot's change event must be sent if notify is true";
}

// Check that the marker is indeed removed from the given layer in the plot's domain marker list
int originalDomainMarkerCountInPlot = getDomainMarkerCount(layer);
removeDomainMarker(marker, layer, false);
int currentDomainMarkerCountInPlot = getDomainMarkerCount(layer);
assert originalDomainMarkerCountInPlot - 1 == currentDomainMarkerCountInPlot : "The marker must be removed from the plot's domain marker list";

// Check that the marker is indeed removed from the dataset's and plot's domain marker lists for the given layer
ArrayList<Marker> originalDomainMarkersInPlot = new ArrayList(getDomainMarkers(layer));
originalDomainMarkersInPlot.remove(marker);
ArrayList<Marker> currentDomainMarkersInPlot = new ArrayList(getDomainMarkers(layer));
assert originalDomainMarkersInPlot.equals(currentDomainMarkersInPlot) : "The marker must be removed from the dataset's and plot's domain marker lists";


