// The range markers are kept in a list, so we need to find the index of the marker
// to be removed first. We can do this by iterating through the list and finding
// the index of the marker with the same ID.
int index = -1;
for (int i = 0; i < this.rangeMarkers.size(); i++) {
    if (this.rangeMarkers.get(i).getID().equals(marker.getID())) {
        index = i;
        break;
    }
}

// Make sure the marker was found in the list
assert(index!= -1);

// If the layer argument is null, set it to the foreground layer
if (layer == null) {
    layer = Layer.FOREGROUND;
}

// Make sure the layer is valid (it can only be the foreground or background
// layer)
assert(layer == Layer.FOREGROUND || layer == Layer.BACKGROUND);

// Get the dataset and renderer for the marker
XYDataset dataset = this.dataset;
if (index < dataset.getSeriesCount()) {
    dataset = (XYDataset) dataset.getSeries(index);
}
XYItemRenderer renderer = this.getRendererForDataset(dataset);

// Make sure the marker is for the correct dataset/renderer
assert(marker.getRangeIndex() == index);
assert(marker.getDataset() == dataset);
assert(marker.getRenderer() == renderer);

// Find the list of markers for the given layer and dataset/renderer
List<Marker> markers = null;
if (layer == Layer.FOREGROUND) {
    markers = this.rangeMarkers;
}
else if (layer == Layer.BACKGROUND) {
    markers = this.domainMarkers;
}

// Make sure the marker is in the list of markers for the given layer and
// dataset/renderer
assert(markers.contains(marker));

// Remove the marker from the list of markers for the given layer and
// dataset/renderer
markers.remove(marker);

// Set the range axis range if the marker is an axis marker
if (marker instanceof ValueMarker) {
    ValueMarker vm = (ValueMarker) marker;
    double value = vm.getValue();
    Range range = this.rangeAxis.getRange();
    if (value < range.getLowerBound()) {
        this.rangeAxis.setRange(value, range.getUpperBound());
    }
    else if (value > range.getUpperBound()) {
        this.rangeAxis.setRange(range.getLowerBound


