//Postcondition for serializeAsColumn: checks that the output JSON is in the form of a JSON Array
assert (jgen instanceof ArrayJsonGenerator) : "The output JSON must be in the form of a JSON Array";


