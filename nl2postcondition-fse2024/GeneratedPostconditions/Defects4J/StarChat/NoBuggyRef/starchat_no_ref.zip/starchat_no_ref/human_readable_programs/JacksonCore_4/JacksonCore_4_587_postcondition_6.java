// Check that the return value contains the same elements as the input array
assert Arrays.equals(inputArray, returnValue);


