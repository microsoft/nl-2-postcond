// Ensures that the return value indicates whether or not the marker was removed
assert (returnValue == true) || (returnValue == false);


