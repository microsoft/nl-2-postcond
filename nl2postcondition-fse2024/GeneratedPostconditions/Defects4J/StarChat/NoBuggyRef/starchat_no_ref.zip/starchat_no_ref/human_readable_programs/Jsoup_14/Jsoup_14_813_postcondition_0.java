// Ensures that the method returns a non-null CharacterData object
assert (returnValue!= null && returnValue instanceof CharacterData);


