import java.util.Arrays;
import java.util.List;

import org.jfree.data.Range;
import org.jfree.data.xy.XYDataset;

public class SymbolicPostcondition {

  public static void main(String[] args) {
    XYDataset dataset = new ExampleDataset();
    boolean includeInterval = true;
    Range range = iterateRangeBounds(dataset, includeInterval);
    assert range!= null : "The return value must not be null.";

    // If the XYDataset is an instance of CategoryDataset, findRangeBounds will be called recursively.
    if (dataset instanceof CategoryDataset) {
      CategoryDataset categoryDataset = (CategoryDataset) dataset;
      List<String> categories = Arrays.asList(categoryDataset.getCategories());
      assert categories.containsAll(range.getCategories()) : "All categories must be included in the return value's categories.";
    } else {
      assert range.contains(dataset.getXValue(0)) : "The first x-value must be included in the return value.";
      assert range.contains(dataset.getYValue(0)) : "The first y-value must be included in the return value.";
      assert range.contains(dataset.getXValue(dataset.getItemCount() - 1)) : "The last x-value must be included in the return value.";
      assert range.contains(dataset.getYValue(dataset.getItemCount() - 1)) : "The last y-value must be included in the return value.";
    }
  }

  private static Range iterateRangeBounds(XYDataset dataset, boolean includeInterval) {
    if (dataset instanceof RangeInfo) {
      RangeInfo rangeInfo = (RangeInfo) dataset;
      return rangeInfo.getRangeBounds(includeInterval);
    } else {
      double min = Double.POSITIVE_INFINITY;
      double max = Double.NEGATIVE_INFINITY;
      for (int i = 0; i < dataset.getItemCount(); i++) {
        double x = dataset.getXValue(i);
        double y = dataset.getYValue(i);
        if (!Double.isNaN(x) &&!Double.isNaN(y)) {
          min = Math.min(min, x);
          max = Math.max(max, x);
          if (includeInterval) {
            min = Math.min(min, y);
            max = Math.max(max, y);
          }
        }
      }
      if (min == Double.POSITIVE_INFINITY && max == Double.NEGATIVE_INFINITY) {
        return null;
      } else {
        return new Range(min, max);
      }
    }
  }

  private static interface RangeInfo {
    Range getRangeBounds(boolean includeInterval);
  }

  private static class ExampleDataset implements XYDataset, RangeInfo {
    @Override
    public int getSeriesCount() {
      return 0;
    }

    @Override
    public int getItemCount(int series) {
      return 0;
    }

    @Override
    public Number getX(int series, int item) {
      return null;
    }

    @Override
    public Number getY(int series, int item) {
      return null;
    }

    @Override
    public double getXValue(int item) {
      return 0;
    }

    @Override
    public double getYValue(int item) {
      return 0;
    }

    @Override
    public String getTitle() {
      return "Example Dataset";
    }

    @Override
    public String getSeriesKey(int series) {
      return null;
    }

    @Override
    public String getCategoryKey(int category) {
      return null;
    }

    @Override
    public int getCategoryIndex(String category) {
      return 0;
    }

    @Override
    public String[] getCategories() {
      return new String[] {};
    }

    @Override
    public Range getRange


