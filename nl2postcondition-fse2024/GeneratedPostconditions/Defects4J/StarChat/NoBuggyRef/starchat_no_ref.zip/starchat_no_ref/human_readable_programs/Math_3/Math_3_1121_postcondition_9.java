// Check that the input arrays have the same length
assert a.length == b.length : "Input arrays must have the same length.";

// Initialize the sum to zero
double sum = 0;

// Loop through the arrays and add each product to the sum
for (int i = 0; i < a.length; i++) {
    sum += a[i] * b[i];
}

// Return the sum
return sum;


