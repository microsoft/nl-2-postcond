// Check that the returned value is either true or false
assert (returnValue instanceof Boolean) : "The returned value must be either true or false";


