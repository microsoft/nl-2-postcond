assert (returnValue == null || (returnValue.getLowerBound() == null && returnValue.getUpperBound() == null))
    || (returnValue.getLowerBound()!= null && returnValue.getUpperBound()!= null
        && returnValue.getLowerBound().compareTo(returnValue.getUpperBound()) <= 0);


