// Postcondition: the return value is non-null and non-empty
assert (returnValue!= null) &&!returnValue.isEmpty();


