assert list.size() > 0 == (first.value().parent()!= null || first.value().childre().size() > 0);


