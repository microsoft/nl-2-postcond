// Postcondition: When the method returns successfully, the return value is either the string value
// extracted from the input JSON, or the default value if the input token is not a JSON string.
assert (
  // If the input token is a JSON string, the return value is the string value extracted from it
  _isNextToken(JsonToken.VALUE_STRING)?
    _getText() :
    // Otherwise, the return value is the default value
    defValue
).equals(returnValue);


