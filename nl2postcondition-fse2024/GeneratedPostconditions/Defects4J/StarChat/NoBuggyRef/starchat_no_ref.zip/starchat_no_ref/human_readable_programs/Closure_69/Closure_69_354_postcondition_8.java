// Ensures that the call is legal, given the types of the function and its arguments
assert (functionType.checkArguments(t, arguments, call) == CheckArgumentsResult.SUCCESS);


