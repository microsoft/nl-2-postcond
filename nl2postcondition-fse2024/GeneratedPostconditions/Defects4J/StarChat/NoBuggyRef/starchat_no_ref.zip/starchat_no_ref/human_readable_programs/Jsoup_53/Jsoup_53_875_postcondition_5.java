import java.util.Stack;

// The method chompBalanced is used to pull a balanced string off the queue
public String chompBalanced(char open, char close) {
    // Create a stack to hold the openers and closers
    Stack<Character> stack = new Stack<>();
    // Initialize a string to hold the balanced string
    String balancedString = "";

    // Loop through each character in the queue
    while (!this.isEmpty()) {
        // Get the current character
        char currentCharacter = this.consume();

        // If the current character is an opener, push it onto the stack
        if (currentCharacter == open) {
            stack.push(currentCharacter);
        }
        // If the current character is a closer, pop the stack until we find an opener
        else if (currentCharacter == close) {
            if (stack.empty() || stack.peek()!= open) {
                // If the stack is empty or we find a closer that doesn't match the opener,
                // the string is not balanced
                assert false : "Unbalanced string";
            }
            // If we find a matching opener, remove it from the stack
            else {
                stack.pop();
            }
        }

        // If the current character is neither an opener nor a closer, add it to the balanced string
        if (!stack.isEmpty()) {
            balancedString += currentCharacter;
        }
    }

    // Check if the stack is empty, which means the string was properly balanced
    if (!stack.isEmpty()) {
        assert false : "Unbalanced string";
    }

    // Return the balanced string
    return balancedString;
}


