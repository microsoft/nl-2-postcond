import java.util.Arrays;

public class Sample {

    public static int getLength(String[] arr) {
        int length = 0;
        // Write your code here:
        // assert length >= 0;
        return length;
    }
}


