// Check that the output is correct for a specific set of input arrays
assert linearCombination(new double[] {1, 2}, new double[] {3, 4}) == 11;


