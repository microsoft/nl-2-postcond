// Ensure that the returned JavaType is a sub-type of the original type
assert returnValue.isSubTypeOf(this) : "The returned JavaType must be a sub-type of the original type";


