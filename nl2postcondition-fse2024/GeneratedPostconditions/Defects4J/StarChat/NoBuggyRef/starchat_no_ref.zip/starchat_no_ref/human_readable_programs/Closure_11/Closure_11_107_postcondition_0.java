@Override
      public void visit(NodeTraversal t, Node n, Node parent) {
        JSType childType;
        JSType leftType, rightType;
        Node left, right;
        boolean typeable = true;
    
        switch (n.getType()) {
          case Token.NAME:
            typeable = visitName(t, n, parent);
            break;
    
          case Token.PARAM_LIST:
            typeable = false;
            break;
    
          case Token.COMMA:
            ensureTyped(t, n, getJSType(n.getLastChild()));
            break;
    
          case Token.TRUE:
          case Token.FALSE:
            ensureTyped(t, n, BOOLEAN_TYPE);
            break;
    
          case Token.THIS:
            ensureTyped(t, n, t.getScope().getTypeOfThis());
            break;


