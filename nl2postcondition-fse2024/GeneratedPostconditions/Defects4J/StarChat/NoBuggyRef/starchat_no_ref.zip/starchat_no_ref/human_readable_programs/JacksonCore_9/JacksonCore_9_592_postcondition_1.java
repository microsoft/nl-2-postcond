//: strings/Test.java
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import java.io.*;
import java.util.*;

public class Test {
  public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
    String json = "{\"name\":\"John Smith\"}";
    JsonFactory jf = new JsonFactory();
    JsonParser jp = jf.createParser(json);
    ObjectMapper om = new ObjectMapper();
    Map<String, String> map = om.readValue(jp, Map.class);
    System.out.println(map);
  }
}


