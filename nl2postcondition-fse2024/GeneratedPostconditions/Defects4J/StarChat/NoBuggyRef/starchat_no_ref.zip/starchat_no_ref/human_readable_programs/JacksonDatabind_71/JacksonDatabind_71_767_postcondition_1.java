public static StdKeyDeserializer forType ( Class <? > raw )
    {
        switch( raw.getName() ) {
        case "java.net.URI":
        case "java.net.URL":
            //postcondition:
            //assert(returnValue instanceof URIKeyDeserializer);
            return URIKeyDeserializer.instance;
        case "java.util.Calendar":
            //postcondition:
            //assert(returnValue instanceof CalendarKeyDeserializer);
            return CalendarKeyDeserializer.instance;
        //... and so on...
        default:
            return null;
        }
    }


