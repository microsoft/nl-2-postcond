import java.util.List;

// Check that the generic signature of a reference type is equal to
// the concatenation of the generic signatures of its direct and indirect
// superinterfaces, in the order that they appear in the type hierarchy.
assert (List.of(getGenericSignature(new StringBuilder())).equals(
    List.of(getSuperInterfaces().stream()
       .flatMap(t -> List.of(t.getGenericSignature(new StringBuilder())).stream())
       .reduce("", String::concat))));


