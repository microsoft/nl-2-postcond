// Check that the return value is correct according to the method specification
assert (int)(returnValue * sampleSize) == getNumberOfSuccesses() * getPopulationSize() / getSampleSize();


