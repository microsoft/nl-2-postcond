// Check that the returned value is positive
assert returnValue >= 0 : "The returned value must be positive.";


