import java.util.List;

public class ReferenceType extends SimpleType {
    protected final JavaType referencedType;

    public StringBuilder getGenericSignature(StringBuilder sb) {
        // TODO: Replace this with your own logic
        return sb;
    }
}


