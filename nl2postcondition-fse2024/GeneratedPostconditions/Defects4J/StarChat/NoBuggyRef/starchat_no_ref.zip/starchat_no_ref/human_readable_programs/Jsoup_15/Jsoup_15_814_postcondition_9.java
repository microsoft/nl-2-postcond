assert process(t, tb) == true; //the return value of process is true


