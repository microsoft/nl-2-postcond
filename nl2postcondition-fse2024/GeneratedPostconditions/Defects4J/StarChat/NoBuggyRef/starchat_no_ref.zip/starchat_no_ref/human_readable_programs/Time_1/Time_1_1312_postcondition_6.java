// Check that the returned Partial is not null
assert returnValue!= null;

// Check that the chronology field of the returned Partial is set to the specified chronology
assert returnValue.getChronology().equals(chronology);

// Check that the number of fields in the returned Partial is equal to the number of field types
assert returnValue.getFields().size() == types.length;

// Check that each field type in the returned Partial corresponds to the specified field type
for (int i = 0; i < types.length; i++) {
    assert returnValue.getFieldType(i) == types[i];
}

// Check that the values of the returned Partial match the specified values
for (int i = 0; i < types.length; i++) {
    assert returnValue.getValue(i) == values[i];
}


