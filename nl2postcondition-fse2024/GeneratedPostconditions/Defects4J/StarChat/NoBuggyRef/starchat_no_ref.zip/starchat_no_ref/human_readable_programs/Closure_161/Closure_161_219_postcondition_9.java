private Node tryFoldArrayAccess ( Node n, Node left, Node right ) {
        assert (left.getType() == Token.ARRAYLIT) == (right.getType() == Token.NUMBER);
        return n;
    }


