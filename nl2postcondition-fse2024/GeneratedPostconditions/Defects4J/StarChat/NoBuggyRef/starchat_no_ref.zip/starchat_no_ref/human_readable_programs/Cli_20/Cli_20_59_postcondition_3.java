// Check that if stopAtNonOption is true, then the remaining arguments are copied to the processed tokens list
assert(
  if stopAtNonOption is true
    then for all elements a in arguments[1..] do
      tokens contains a
  else
    true
);


