assert (_inputPtr <= _inputEnd); // postcondition assumes valid input
int ptr = _inputPtr; // start at beginning of input
while (ptr < _inputEnd) {
    char ch = _inputBuffer[ptr]; // get next input char
    if (ch == '"') { // found closing quote
        String str = _textBuffer.toString(); // get contents of text buffer
        _inputPtr = ptr + 1; // update input pointer
        return str; // return string
    } else if (ch == '\\') { // found escape char
        ptr++; // skip over escape char
        if (ptr == _inputEnd) {
            break; // unexpected end of input
        }
        ch = _inputBuffer[ptr]; // get next char after escape
        switch (ch) { // handle escape sequences
            case '"':
            case '\\':
            case '/':
                break; // pass through unescaped chars
            case 'b':
                ch = '\b';
                break;
            case 'f':
                ch = '\f';
                break;
            case 'n':
                ch = '\n';
                break;
            case 'r':
                ch = '\r';
                break;
            case 't':
                ch = '\t';
                break;
            case 'u':
                // handle unicode escape sequence
                // skip 4 hex digits
                break;
            default:
                break;
        }
    }
    _textBuffer.append(ch); // add char to text buffer
    ptr++; // move to next input char
}


