assert (returnValue >= 1); //Postcondition: the length of the collection is always >= 1


