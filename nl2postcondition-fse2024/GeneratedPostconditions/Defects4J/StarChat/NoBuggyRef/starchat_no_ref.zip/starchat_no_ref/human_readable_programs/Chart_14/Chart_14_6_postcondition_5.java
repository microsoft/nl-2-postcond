// Check that the list is sorted in ascending order
assert(java.util.Collections.binarySearch(list, item) >= 0);

// Check that the list contains the correct number of elements
assert(list.size() == size);


