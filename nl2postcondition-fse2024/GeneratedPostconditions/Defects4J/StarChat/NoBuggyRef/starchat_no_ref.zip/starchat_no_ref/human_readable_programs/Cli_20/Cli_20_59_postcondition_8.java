import java.util.Iterator;
import java.util.List;

class PosixParser {
    // fields and constructors

    // symbolic postcondition: asserts that the output token list is sorted in ascending order by the length of each token
    public String[] flatten(Options options, String[] arguments, boolean stopAtNonOption) {
        // method body
        List<String> tokens = new ArrayList<>();
        // loop through arguments
        for (String arg : arguments) {
            // if arg is "--", add "--" to token list and continue
            if (arg.equals("--")) {
                tokens.add("--");
                continue;
            }
            // if arg is "-", add "-" to token list and continue
            if (arg.equals("-")) {
                tokens.add("-");
                continue;
            }
            // if arg has length 2 and starts with "-", burst arg and add the resulting tokens to the token list
            if (arg.length() == 2 && arg.charAt(0) == '-') {
                burstToken(arg, stopAtNonOption);
                continue;
            }
            // if arg has length greater than 2 and starts with "-", add "-" followed by each character to the token list
            if (arg.length() > 2 && arg.charAt(0) == '-') {
                for (int i = 0; i < arg.length(); i++) {
                    tokens.add(String.valueOf(arg.charAt(i)));
                }
                continue;
            }
            // if stopAtNonOption is true and arg is not handled by any of the previous rules, add arg to the token list
            if (stopAtNonOption) {
                tokens.add(arg);
            }
        }
        return tokens.toArray(new String[0]);
    }

    // private helper methods
    private void burstToken(String token, boolean stopAtNonOption) {
        // loop through characters in token
        for (int i = 1; i < token.length(); i++) {
            String ch = String.valueOf(token.charAt(i));
            // if an option with id ch exists, add "-" + ch to the token list and set the current option to the option with id ch
            if (options.hasOption(ch)) {
                tokens.add("-" + ch);
                currentOption = options.getOption(ch);
                // if the current option can take an argument and there are remaining characters in the token, add the remaining characters to the token list
                if (currentOption.hasArg() && (token.length()!= (i + 1))) {
                    tokens.add(token.substring(i + 1));
                    break;
                }
            }
            // if stopAtNonOption is true and an option with id ch does not exist, add arg to the token list
            else if (stopAtNonOption) {
                process(token.substring(i));
                break;
            }
            // if stopAtNonOption is false and an option with id ch does not exist, add arg to the token list
            else {
                tokens.add(token);
                break;
            }
        }
    }

    // other methods and classes
}


