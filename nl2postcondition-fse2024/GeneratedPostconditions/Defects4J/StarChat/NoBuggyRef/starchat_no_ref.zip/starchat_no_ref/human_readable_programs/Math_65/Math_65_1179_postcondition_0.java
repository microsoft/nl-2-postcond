Here is the symbolic postcondition for the getChiSquare method:

// The method returns the sum of the square of the reciprocal of the weights multiplied by the differences between the observed and predicted values.
assert Math.abs(returnValue - (sumOfSquares(weights) * sumOfSquaredDifferences(observedValues, predictedValues))
) < 1e-15 : "The calculated Chi-Square value " + returnValue + " does not match the sum of the square of the reciprocal of the weights multiplied by the differences between the observed and predicted values. The difference is: " + (Math.abs(returnValue - (sumOfSquares(weights) * sumOfSquaredDifferences(observedValues, predictedValues)))));


