// Ensures that the string builder after appending the normalised whitespace
// from the input string contains the same number of characters as the input
// string without any leading or trailing whitespace.
assert accum.length() == string.length() - stripLeadingTrailingWhitespace(string);


