// Check that the return value is true if the entry is a directory
assert isDirectory() == (returnValue == true);


