public class TokenQueue {
    private String queue;
        /**
         * Is the queue empty?
         * @return true if no data left in queue.
         */
    public boolean isEmpty() {
            return remainingLength() == 0;
        }
        /**
         * Consume one character off queue.
         * @return first character on queue.
         */
    public char consume() {
            return queue.charAt(pos++);
        }
        /**
         * Consumes the supplied sequence of the queue. If the queue does not start with the supplied sequence, will
         * throw an illegal state exception -- but you should be running match() against that condition.
         <p>
         Case insensitive.
         * @param seq sequence to remove from head of queue.
         */
    public void consume(String seq) {
            if (!matches(seq))
                throw new IllegalStateException("Queue did not match expected sequence");
            int len = seq.length();
            if (len > remainingLength())
                throw new IllegalStateException("Queue not long enough to consume sequence");
            
            pos += len;
        }
    
    //Method you are writing a postcondition for:
    /**
     * Pulls a balanced string off the queue. E.g. if queue is "(one (two) three) four", (,) will return "one (two) three",
     * and leave " four" on the queue. Unbalanced openers and closers can quoted (with'or ") or escaped (with \). Those escapes will be left
     * in the returned string, which is suitable for regexes (where we need to preserve the escape), but unsuitable for
     * contains text strings; use unescape for that.
     * @param open opener
     * @param close closer
     * @return data matched from the queue
     */
    public String chompBalanced ( char open, char close )
    //Where the body of the method will go


Your task is to write a symbolic postcondition for chompBalanced. The postcondition should be in Java and consist of exactly one `assert` statement. A Java comment explaining the postcondition's meaning should precede it. For variables, the postcondition should only use the input parameters defined in the method stub and a hypothetical return value of the method, which we'll assume is


