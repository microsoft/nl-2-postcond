// Check that the beginning of the queue matches the opening character
assert queue.startsWith(String.valueOf(open));


