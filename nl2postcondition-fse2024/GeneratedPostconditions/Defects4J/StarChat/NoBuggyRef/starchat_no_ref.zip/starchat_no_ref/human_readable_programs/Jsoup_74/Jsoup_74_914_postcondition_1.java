// Ensures that the output of appendNormalisedWhitespace does not contain leading whitespace characters if stripLeading is true
assert (stripLeading &&!accum.toString().isEmpty() && Character.isWhitespace(accum.charAt(0))) == false :
    "Output of appendNormalisedWhitespace contains leading whitespace characters when stripLeading is true";


