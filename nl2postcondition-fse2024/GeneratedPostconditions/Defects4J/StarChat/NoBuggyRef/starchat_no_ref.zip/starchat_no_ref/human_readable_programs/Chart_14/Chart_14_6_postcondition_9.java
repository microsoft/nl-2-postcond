assert (returnValue == true && isSorted(getDomainMarkers(layer))
       ? isSorted(getDomainMarkers(layer)) : true);


