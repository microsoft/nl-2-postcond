public void read(Tokeniser t, CharacterReader r) {
    // Precondition: r is not at the end of the input
    assert!r.atEnd();

    // Code that implements the method goes here

    // Postcondition: t.token() returns the next token that has been read from the input
    assert t.token() == getNextExpectedToken(r);
}


