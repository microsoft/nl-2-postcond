I need clarification on which Javadoc to consult for the implementation of the `getRMS()` method. Please provide the URL to the Javadoc so that I can check it out.


