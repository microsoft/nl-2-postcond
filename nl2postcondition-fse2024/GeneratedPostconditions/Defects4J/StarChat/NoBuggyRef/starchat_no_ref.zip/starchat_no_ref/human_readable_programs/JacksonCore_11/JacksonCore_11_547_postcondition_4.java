// Ensure that all symbols hash into the primary table
assert Arrays.equals(new int[hashSize], IntStream.range(0, hashSize).map(i -> -1).toArray());

// Ensure that all symbols hash into the secondary table
assert Arrays.equals(new int[secondaryStart >> 2], IntStream.range(0, secondaryStart >> 2).map(i -> -1).toArray());

// Ensure that all symbols hash into the tertiary table
assert Arrays.equals(new int[tertiaryStart >> 3], IntStream.range(0, tertiaryStart >> 3).map(i -> -1).toArray());

// Ensure that the names array is big enough to hold all symbols
assert names.length >= count;

// Ensure that the hash area is big enough to hold all symbols
assert hashArea.length >= (count << 2);


