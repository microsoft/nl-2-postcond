// check if the column is basic
if (ignoreObjectiveRows) {
    for (int i = 0; i < getNumObjectiveFunctions(); i++) {
        assert getBasicRow(col, i) == null : "column is basic in objective row " + i;
    }
}
assert getBasicRow(col)!= null : "column is basic";


