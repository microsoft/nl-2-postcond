// Postcondition: the return value is the same as the result of evaluating
// the "and" operation on the results of comparing the left value with each
// element of the right list, starting from the start of the right list
assert and(map(left -> compare(left, start(right)), right));


