/**
 * Method that can be used for parsing escaped characters and such.
 * This method is called when the opening double quote has been read
 * and all that is left is the contents.
 *
 * @since 2.1
 */
@Override public final String getValueAsString ( String defValue ) throws IOException


