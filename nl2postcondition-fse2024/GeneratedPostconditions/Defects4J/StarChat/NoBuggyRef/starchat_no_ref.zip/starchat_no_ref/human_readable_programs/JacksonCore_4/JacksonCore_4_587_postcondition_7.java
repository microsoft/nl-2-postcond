// Check that the return value of the method contains the same characters as the input value
assert Arrays.equals(returnValue, inputValue);


