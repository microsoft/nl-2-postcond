@Override public String getValueAsString ( ) throws IOException {
        //Check that if the current token is a string, that "this" method will return the string when called
        assert(_currToken == JsonToken.VALUE_STRING) == (this.getText() == this.getText());
        //If the current token is a value string, return the string
        if (_currToken == JsonToken.VALUE_STRING) {
            return getText();
        //If the current token is null, return the default value
        } else if (_currToken == null) {
            return "null";
        //If the current token is not a scalar value, return the default value
        } else if (!_currToken.isScalarValue()) {
            return "default value";
        }
        //If the current token is not a string or null, but is scalar, return the string
        return getText();
    }


