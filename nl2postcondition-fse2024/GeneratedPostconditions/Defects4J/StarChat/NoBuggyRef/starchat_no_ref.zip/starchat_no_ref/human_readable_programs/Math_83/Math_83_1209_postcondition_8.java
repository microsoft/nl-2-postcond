import java.util.HashSet;
import java.util.Set;

public class SimplexTableau {
    private int getBasicRow(int col, boolean ignoreObjectiveRows) {
        assert (col >= 0 && col < getHeight()) : "col must be in the bounds of the tableau";
        assert (ignoreObjectiveRows || col >= getRhsOffset()) : "col must not be an objective row";

        int row = -1;
        double minRatio = Double.POSITIVE_INFINITY;
        boolean found = false;

        for (int r = 0; r < getHeight(); r++) {
            if (!ignoreObjectiveRows || r < getRhsOffset()) {
                double ratio = getEntry(r, col) / getEntry(r, getLhsOffset(r));
                if (ratio < minRatio) {
                    row = r;
                    minRatio = ratio;
                    found = true;
                }
            }
        }

        assert (found) : "the tableau must have a basic row";
        return row;
    }
}


