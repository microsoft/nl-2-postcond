//Check if apply returns true when given a Node that is a FUNCTION node
assert apply(new Node(Token.FUNCTION)) : 
    "Should return true when given a FUNCTION node";


