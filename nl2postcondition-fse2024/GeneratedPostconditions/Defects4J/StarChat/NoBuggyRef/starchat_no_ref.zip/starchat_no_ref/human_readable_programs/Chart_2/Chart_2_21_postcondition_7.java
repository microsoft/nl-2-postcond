assert (returnValue!= null && returnValue.contains(findDomainBounds(dataset, includeInterval)) && returnValue.contains(findRangeBounds(dataset, includeInterval)));


