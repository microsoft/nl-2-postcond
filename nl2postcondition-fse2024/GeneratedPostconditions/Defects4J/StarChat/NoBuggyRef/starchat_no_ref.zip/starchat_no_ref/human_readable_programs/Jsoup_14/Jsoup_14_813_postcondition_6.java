assert ( //Check that the return value is at most one token long
    (t.eof() && returnValue.length() <= 1) || //Check that the token is not the last token in the input
    (!t.eof() && returnValue.length() == 1) //Check that the token is at most one token long
);


