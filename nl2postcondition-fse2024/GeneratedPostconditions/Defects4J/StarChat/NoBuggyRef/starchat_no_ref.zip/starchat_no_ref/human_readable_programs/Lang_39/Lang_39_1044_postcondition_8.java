// Postcondition for the method replaceEach

assert ( returnValue == null || returnValue.equals(text) ) : "When the returned String is not null, it must be identical to the input text.";

if ( repeat ) {
    // If the repeat flag is set, check that the output is still in a valid state
    assert ( searchList == null || searchList.length == replacementList.length ) : "If the repeat flag is set, the lengths of the search and replacement lists must be equal.";
    assert ( searchList == null || searchList.length == unique(concat(searchList, replacementList)).length ) : "If the repeat flag is set, the combined search and replacement lists must not contain any duplicates.";
}

// The repeat flag must be set to true if the input contains any duplicate elements
assert (!repeat || searchList == null || ( searchList.length == unique(concat(searchList, replacementList)).length ) ) : "If the repeat flag is not set, duplicate elements in the input cannot be replaced.";

// If the repeat flag is set, the timeToLive variable must be non-negative
assert (!repeat || timeToLive >= 0 ) : "If the repeat flag is set, the timeToLive variable must be non-negative.";

// If the repeat flag and the timeToLive variable are both non-negative, decrement the timeToLive variable
if ( repeat && timeToLive >= 0 ) {
    timeToLive--;
}


