//The postcondition checks that the output is as described in the Javadoc
assert ((returnValue == true) && (this.rangeMarkers.remove(index).equals(marker)) && (this.rangeMarkerList.remove(marker)) && (layer == Layer.FOREGROUND)) : "When removeRangeMarker is called with input index " + index + ", marker " + marker + ", and layer " + layer + ", the output is " + returnValue + " and the data structures are " + this.rangeMarkers + " and " + this.rangeMarkerList + ".";


