// Check that the length of the property is consistent with its type
assert(
    "The length of the property must be consistent with its type.",
    (type == PropertyType.COLLECTION && index == WHOLE_COLLECTION) ||
    (type!= PropertyType.COLLECTION && index < getLength())
);


