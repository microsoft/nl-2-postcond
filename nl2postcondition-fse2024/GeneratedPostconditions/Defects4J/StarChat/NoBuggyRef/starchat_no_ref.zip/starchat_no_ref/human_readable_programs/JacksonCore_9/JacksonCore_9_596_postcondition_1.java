assert (returnValue == null || returnValue.equals(new String(outBuf, 0, outPtr, StandardCharsets.UTF_8)) &&
        "The implementation of this method diverges from its Javadoc comment.");


