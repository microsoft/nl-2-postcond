// Postcondition: The return value is a string that contains only valid JSON
// escape sequences.
assert JsonEscapeUtils.isValidJsonEscapeSequence(returnValue) :
    "The return value of getValueAsString should only contain valid JSON escape sequences.";


