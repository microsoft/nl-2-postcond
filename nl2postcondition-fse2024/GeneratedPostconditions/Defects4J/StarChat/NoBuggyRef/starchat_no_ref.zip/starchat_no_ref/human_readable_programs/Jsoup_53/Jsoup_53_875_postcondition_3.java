// Ensures that the returned string has the correct number of openers and closers
assert (returnValue.chars().filter(ch -> ch == open).count() ==
        returnValue.chars().filter(ch -> ch == close).count());


