import java.util.ArrayList;
import java.util.List;

public class TypeCheck {
    private static final String CTX_TYPE = "contextual type";
    private static final String FUNCTION_TYPE = "function type";
    private static final String ARGUMENT_TYPES = "argument types";
    private static final String RETURN_TYPE = "return type";
    private static final String POST


