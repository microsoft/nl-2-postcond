// Postcondition: ensure that the element accessed by the GETPROP node is defined on the object accessed by the GETPROP node's parent.
assert returnValue.isDefinitelyDefined() :
  "The element accessed by the GETPROP node is defined on the object accessed by the GETPROP node's parent.";


