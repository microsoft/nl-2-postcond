import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.jstype.EnumType;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.JSTypeNative;
import com.google.javascript.rhino.jstype.ObjectType;
import com.google.javascript.rhino.jstype.TypeRegistry;

public class TypeCheck {
  private static final TypeRegistry typeRegistry = TypeRegistry.getGlobalTypeRegistry();
  private static final JSTypeNative NUMBER_TYPE = JSTypeNative.NUMBER_TYPE;
  private static final JSTypeNative BOOLEAN_TYPE = JSTypeNative.BOOLEAN_TYPE;
  private static final JSTypeNative STRING_TYPE = JSTypeNative.STRING_TYPE;


