// The postcondition checks that the marker at the specified index in the given layer is removed,
// and that the removed marker is equal to the input marker. It also asserts that the resulting
// list of markers in the given layer is equal to the original list of markers without the removed
// marker, in the same order.
assert (removeDomainMarker(index, marker, layer) && getDomainMarkers(layer).get(index).equals(marker))?
getDomainMarkers(layer).subList(0, index).concat(getDomainMarkers(layer).subList(index + 1, getDomainMarkers(layer).size()))
.equals(getDomainMarkers(layer)) : "The marker at the specified index in the given layer was not removed, or the removed marker was not equal to the input marker.";


