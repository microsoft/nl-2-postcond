// Check that the mean is correct
assert (getSampleSize() * getNumberOfSuccesses() / getPopulationSize()) == returnValue :
    "The mean should be equal to (sample size * number of successes) / population size";


