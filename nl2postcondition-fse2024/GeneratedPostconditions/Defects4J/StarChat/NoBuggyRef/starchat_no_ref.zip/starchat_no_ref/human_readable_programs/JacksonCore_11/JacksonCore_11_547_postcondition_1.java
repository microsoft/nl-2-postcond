// Checks that _verifySharing will not modify the input array
assert Arrays.equals(q, qCopy);


