assert (n instanceof Node) : "The Node n must be an instance of Node";
assert (n.getType() == Token.NAME) : "The Node n must be a NAME Node";

Node parent = n.getParentNode();
assert (parent instanceof Node) : "The parent of Node n must be an instance of Node";

Node grandparent = parent.getParentNode();
assert (grandparent instanceof Node) : "The grandparent of Node n must be an instance of Node";

String name = n.getString();
assert (name!= null) : "The name of the Node n cannot be null";

int nameLength = name.length();
assert (nameLength > 0) : "The name of the Node n cannot be an empty string";


