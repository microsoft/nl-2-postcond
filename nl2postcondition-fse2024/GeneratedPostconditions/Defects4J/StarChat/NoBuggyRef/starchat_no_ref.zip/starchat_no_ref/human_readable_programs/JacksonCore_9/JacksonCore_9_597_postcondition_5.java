// Postcondition: The return value is non-null
assert (String) returnValue!= null;


