assert (defValue == null && returnValue == null) ||
       (defValue!= null && returnValue!= null && returnValue.equals(defValue));


