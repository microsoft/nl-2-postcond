// Check that the arrays have the same length
assert a.length == b.length : "Arrays must have the same length";


