import org.joda.time.DurationField;
import org.joda.time.DurationFieldType;

public final class UnsupportedDurationField extends DurationField implements Serializable {
    //Method you are writing a postcondition for:
    /**
     * Always returns zero, indicating that sort order is not relevent.
     *
     * @return zero always
     */
    public int compareTo ( DurationField durationField ) {
        //Where the body of the method will go
    }
}


