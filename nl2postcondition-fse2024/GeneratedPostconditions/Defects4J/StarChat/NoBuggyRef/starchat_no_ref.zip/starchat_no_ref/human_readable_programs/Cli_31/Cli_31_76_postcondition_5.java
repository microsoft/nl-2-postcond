private void appendOption(final StringBuffer buff, final Option option, final boolean required) {
  // TODO: Write your postcondition here
}


