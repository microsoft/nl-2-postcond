// Check that the returned String value is properly escaped and unescaped,
// and that the escaping/unescaping process is reversible.
assert (new String(returnValue.getBytes()).equals(returnValue)) &&
        (returnValue.equals(new String(returnValue.getBytes())));


