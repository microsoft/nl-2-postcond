Here is my response:

// The input parameter "subclass" is used to narrow the specific type of this JavaType instance to the given subclass.
assert (this.isContainerType() && this.getRawClass().isAssignableFrom(subclass)) ||
        (this.hasGenericTypes() && this.getBindings().values().stream().anyMatch(t -> t.findSuperType(subclass)!= null)) :
        "Cannot narrow " + this + " to " + subclass.getName();


