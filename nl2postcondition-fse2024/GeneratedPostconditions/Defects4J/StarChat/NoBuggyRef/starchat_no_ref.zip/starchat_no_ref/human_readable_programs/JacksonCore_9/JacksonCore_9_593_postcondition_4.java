import java.io.IOException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public class ParserMinimalBase extends JsonParser {
    protected JsonToken _currToken;
    
    @Override
    public String getValueAsString(String defaultValue) throws IOException {
        assert (defaultValue == null || _currToken == JsonToken.VALUE_STRING) :
            "If the current token is not a string, the method should return the default value";
        if (_currToken!= JsonToken.VALUE_STRING) {
            return defaultValue;
        }
        return getText();
    }
}


