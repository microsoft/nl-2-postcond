// The current segment of the text buffer is full, so we need to
// allocate a new segment and add it to the list.

// The size of the new segment will be the size of the current segment.
int newSegmentSize = currentSegment.length;

// Allocate a new char array to use as the new segment.
char [ ] newSegment = new char [newSegmentSize];

// Add the new segment to the list of segments in the text buffer.
segments.add(newSegment);

// Set the current segment to the new segment.
currentSegment = newSegment;

// The size of the new segment will double in each subsequent call to
// expandCurrentSegment.
newSegmentSize = newSegmentSize * 2;

// Check if the new segment size exceeds the maximum segment size. If it
// does, throw an OutOfMemoryError.
if (newSegmentSize > MAX_SEGMENT_SIZE)
{
    throw new OutOfMemoryError("Maximum segment size exceeded.");
}

// The Javadoc guarantees that the return value of this method is
// always the current segment.
return currentSegment;

// The postcondition checks that the size of the current segment in the
// text buffer after calling expandCurrentSegment does not exceed the
// maximum segment size.
assert (currentSegment.length <= MAX_SEGMENT_SIZE);


