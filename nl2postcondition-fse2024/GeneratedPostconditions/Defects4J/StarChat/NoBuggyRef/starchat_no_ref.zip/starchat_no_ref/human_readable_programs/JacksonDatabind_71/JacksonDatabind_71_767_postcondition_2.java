// Ensures that the returned StdKeyDeserializer deserializes strings into objects of the correct type
assert forType(MyClass.class).deserialize("string".toCharArray(), 0, 6, null) instanceof MyClass;


