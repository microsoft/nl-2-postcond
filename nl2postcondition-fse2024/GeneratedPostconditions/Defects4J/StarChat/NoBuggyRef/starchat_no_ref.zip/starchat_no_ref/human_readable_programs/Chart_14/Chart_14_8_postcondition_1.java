import java.util.ArrayList;
import org.jfree.chart.util.Layer;

public class XYPlot {
  // Method signature:
  public boolean removeDomainMarker(int index, Marker marker, Layer layer, boolean notify) {
    // Hypothetical implementation of the method:
    boolean removed = false;
    if (index < 0 || index >= this.domainMarkers.size()) {
      // Invalid index: do nothing
    } else if (marker!= this.domainMarkers.get(index)) {
      // Marker not found: do nothing
    } else if (layer!= Layer.FOREGROUND && layer!= Layer.BACKGROUND) {
      // Invalid layer: do nothing
    } else {
      this.domainMarkers.remove(index);
      removed = true;
      if (notify) {
        notifyListeners(new PlotChangeEvent(this));
      }
    }
    // Postcondition:
    assert (removed == (this.domainMarkers.indexOf(marker)!= -1));
    return removed;
  }
}


