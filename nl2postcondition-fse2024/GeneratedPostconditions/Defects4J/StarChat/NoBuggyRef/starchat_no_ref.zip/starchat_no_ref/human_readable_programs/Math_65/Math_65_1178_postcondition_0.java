Here is my response:


// Check that the elements of the input list are in sorted order (smallest to largest)
assert java.util.Arrays.asList(input).equals(java.util.Arrays.asList(input).stream().sorted().toArray());

The above code checks that the input list is sorted.


