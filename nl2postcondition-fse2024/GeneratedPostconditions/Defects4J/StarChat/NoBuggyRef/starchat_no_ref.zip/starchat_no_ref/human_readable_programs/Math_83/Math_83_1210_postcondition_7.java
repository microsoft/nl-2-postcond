//The symbolic postcondition for the method getSolution checks that the row index returned by getBasicRow is either null or strictly less than the row index of the objective function row in the tableau.
assert (getBasicRow(col) == null || getBasicRow(col) < getNumObjectiveFunctions());


