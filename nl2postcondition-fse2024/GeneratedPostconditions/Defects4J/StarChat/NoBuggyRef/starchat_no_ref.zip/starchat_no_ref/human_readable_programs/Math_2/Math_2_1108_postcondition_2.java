assert (
    // Hypothetical return value of the method
    returnValue == 
    // Sample size * number of successes / population size
    (sampleSize * numberOfSuccesses) / populationSize
);


