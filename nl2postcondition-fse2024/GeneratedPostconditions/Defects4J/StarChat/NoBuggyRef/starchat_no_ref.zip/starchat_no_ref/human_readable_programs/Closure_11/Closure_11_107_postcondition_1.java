// Ensures that when visitGetProp is executed, the value returned by the method is the same as the input value
assert (returnValue.isEquivalentTo(n.getJSType()));


