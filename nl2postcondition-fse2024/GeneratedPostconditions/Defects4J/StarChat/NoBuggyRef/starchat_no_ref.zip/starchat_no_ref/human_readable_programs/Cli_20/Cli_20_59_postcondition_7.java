import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class PosixParser {

    private List tokens;
    private Options options;

    private boolean eatTheRest;
    private Option currentOption;

    public PosixParser() {
        tokens = new ArrayList();
        options = new Options();
    }

    //Resets the members to their original state i.e. remove
    //all of <code>tokens</code> entries, set <code>eatTheRest</code>
    //to false and set <code>currentOption</code> to null.
    private void init() {
        eatTheRest = false;
        tokens.clear();
        currentOption = null;
    }

    //Adds the remaining tokens to the processed tokens list.
    private void gobble(Iterator iter) {
        if (eatTheRest) {
            while (iter.hasNext()) {
                tokens.add(iter.next());
            }
        }
    }

    //If there is a current option and it can have an argument
    //value then add the token to the processed tokens list and 
    //set the current option to null.
    //If there is a current option and it can have argument
    //values then add the token to the processed tokens list.
    //If there is not a current option add the special token
    //"--" and the current <code>value</code> to the processed
    //tokens list.  The add all the remaining <code>argument</code>
    //values to the processed tokens list.
    private void process(String value) {
        if (currentOption!= null && currentOption.hasArg()) {
            if (currentOption.hasArg()) {
                tokens.add(value);
                currentOption = null;
            } else if (currentOption.hasArgs()) {
                tokens.add(value);
            }
        } else {
            eatTheRest = true;
            tokens.add("--");
            tokens.add(value);
        }
    }

    //If an Option exists for <code>token</code> then
    //set the current option and add the token to the processed 
    //list.
    //If an Option does not exist and <code>stopAtNonOption</code>
    //is set then ignore the current token and add the remaining tokens
    //to the processed tokens list directly.
    private void processOptionToken(String token, boolean stopAtNonOption) {
        if (options.hasOption(token)) {
            currentOption = options.getOption(token);
        } else if (stopAtNonOption) {
            eatTheRest = true;
        }

        tokens.add(token);
    }

    //Breaks <code>token</code> into its constituent parts
    //using the following algorithm.
    //<ul>
    //  <li>ignore the first character ("-")</li>
    //  <li>foreach remaining character check if an Option
    //  exists with that id.</li>
    //  <li>if an Option does exist then add that character
    //  prepended with "-" to the list of processed tokens.</li>
    //  <li>if the Option can have an argument value and there 
    //  are remaining characters in the token then add the remaining 
    //  characters as a token to the list of processed tokens.</li>
    //  <li>if an Option does NOT exist AND <code>stopAtNonOption</code> 
    //  IS set then add the special token "--" followed by the remaining 
    //  characters and also the remaining tokens directly to the processed 
    //  tokens list.</li>
    //  <li>if an Option does NOT exist AND <code>stopAtNonOption</code> 
    //  IS NOT set then add that character prepended with "-".
    //</ul>
    private void burstToken(String token, boolean stopAtNonOption) {
        for (int i = 1; i < token.length(); i++) {
            String ch = String.valueOf(token.charAt(i));

            if (options.hasOption(ch)) {
                tokens.add("-" + ch);
                currentOption = options.getOption(ch);

                if (currentOption.hasArg() && (token.length()!= (i + 1))) {
                    tokens.add(token.substring(i + 1));

                    break;
                }
            } else if (stopAtNonOption) {
                process(token.substring(i));
                break;
            } else {
                tokens.add(token);
                break;
            }
        }
    }

    //An implementation of Parser's abstract
    //flatten method.
    //The following are the rules used by this flatten method.
    //<ol>
    //  <li>if <code>stopAtNonOption</code> is true then do not
    //  burst anymore of <code>arguments</code> entries, just add each
    //  successive entry without further processing.  Otherwise, ignore
    //  <code>stopAtNonOption</code>.</li>
    //  <li>if the current <code>arguments</code> entry is "--"
    //  just add the entry to the list of processed tokens</li>
    //  <li>if the current <code>arguments</code> entry is "-"
    //  just add the entry to the list of processed tokens</li>
    //  <li>if the current <code>arguments</code> entry is two characters
    //  in length and


