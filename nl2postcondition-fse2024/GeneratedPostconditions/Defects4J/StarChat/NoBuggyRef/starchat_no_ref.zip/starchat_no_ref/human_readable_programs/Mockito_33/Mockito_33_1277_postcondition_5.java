// Check that the candidate invocation has the same name and mock as this invocation
assert getMethod().getName().equals(candidate.getMethod().getName());
assert getInvocation().getMock() == candidate.getMock();

// Check that the candidate invocation has the same arguments as this invocation
assert Arrays.equals(getArguments(), candidate.getArguments());

// Check that the candidate invocation has the same return type as this invocation
assert getMethod().getReturnType() == candidate.getMethod().getReturnType();


