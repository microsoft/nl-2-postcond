// Check for consistent array lengths
assert a.length == b.length;

// Check that all indices up to (but not including) the length of the shorter array are valid
for (int i = 0; i < Math.min(a.length, b.length); i++) {
  // Check a[i] and b[i] for correctness
  //...

  // Check that the sum of this product does not cause cancellation
  assert Math.abs(returnValue + a[i] * b[i]) > Double.MIN_VALUE;
}


