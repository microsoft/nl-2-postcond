// Postcondition: The return value of the method is the string defValue if the input string is empty
assert (defValue == "" || getValueAsString("") == defValue);


